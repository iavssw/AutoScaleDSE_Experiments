// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xkernel_correlation_asdse.h"

extern XKernel_correlation_asdse_Config XKernel_correlation_asdse_ConfigTable[];

XKernel_correlation_asdse_Config *XKernel_correlation_asdse_LookupConfig(u16 DeviceId) {
	XKernel_correlation_asdse_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XKERNEL_CORRELATION_ASDSE_NUM_INSTANCES; Index++) {
		if (XKernel_correlation_asdse_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XKernel_correlation_asdse_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XKernel_correlation_asdse_Initialize(XKernel_correlation_asdse *InstancePtr, u16 DeviceId) {
	XKernel_correlation_asdse_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XKernel_correlation_asdse_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XKernel_correlation_asdse_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif


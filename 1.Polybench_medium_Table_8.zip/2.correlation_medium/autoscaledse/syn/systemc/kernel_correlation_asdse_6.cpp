#include "kernel_correlation_asdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_correlation_asdse::thread_grp_fu_96055_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p0 = grp_aesl_mux_load_65_4_x_fu_87351_ap_return.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = reg_104429.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = reg_104404.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = reg_104379.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = v1286_reg_83964.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = v1242_reg_83420.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = v1198_reg_82876.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = v1154_reg_82332.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = v1110_reg_81788.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = ap_phi_reg_pp1_iter1_v1066_reg_86156.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = ap_phi_reg_pp1_iter1_v1022_reg_81196.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96055_p0 = ap_phi_reg_pp0_iter13_v964_reg_80489.read();
    } else {
        grp_fu_96055_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96055_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = reg_101194_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = reg_100354_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = reg_101170_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = reg_100330_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = reg_101176_pp2_iter1_reg.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = reg_101194.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = reg_100354.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = reg_101170.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = reg_100330.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = reg_101176.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = reg_100336.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = reg_101182.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = reg_100342.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = reg_101188.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = ap_phi_reg_pp1_iter2_v1287_reg_86884.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = ap_phi_reg_pp1_iter1_v1243_reg_86820.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = ap_phi_reg_pp1_iter1_v1199_reg_86756.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = ap_phi_reg_pp1_iter1_v1155_reg_86692.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = ap_phi_reg_pp1_iter1_v1111_reg_86628.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = ap_phi_reg_pp1_iter1_v1067_reg_86292.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96055_p1 = ap_phi_reg_pp1_iter1_v1023_reg_81332.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96055_p1 = ap_const_lv32_0;
    } else {
        grp_fu_96055_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96061_opcode() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage5_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage6_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96061_opcode = ap_const_lv2_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96061_opcode = ap_const_lv2_0;
    } else {
        grp_fu_96061_opcode =  (sc_lv<2>) ("XX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96061_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = reg_104435.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = reg_104410.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = reg_104385.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = v1297_reg_84100.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = v1253_reg_83556.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = v1209_reg_83012.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = v1165_reg_82468.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = v1121_reg_81924.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = ap_phi_reg_pp1_iter1_v1077_reg_86308.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = ap_phi_reg_pp1_iter1_v1033_reg_81348.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96061_p0 = ap_phi_reg_pp0_iter13_v969_reg_80547.read();
    } else {
        grp_fu_96061_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96061_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96061_p1 = ap_phi_reg_pp1_iter2_v1298_reg_86900.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96061_p1 = ap_phi_reg_pp1_iter1_v1254_reg_86836.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96061_p1 = ap_phi_reg_pp1_iter1_v1210_reg_86772.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96061_p1 = ap_phi_reg_pp1_iter1_v1166_reg_86708.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96061_p1 = ap_phi_reg_pp1_iter1_v1122_reg_86644.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96061_p1 = ap_phi_reg_pp1_iter1_v1078_reg_86444.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96061_p1 = ap_phi_reg_pp1_iter1_v1034_reg_81484.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96061_p1 = ap_const_lv32_0;
    } else {
        grp_fu_96061_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96067_opcode() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage5_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage6_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96067_opcode = ap_const_lv2_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96067_opcode = ap_const_lv2_0;
    } else {
        grp_fu_96067_opcode =  (sc_lv<2>) ("XX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96067_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = reg_104441.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = reg_104416.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = reg_104391.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = v1308_reg_84236.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = v1264_reg_83692.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = v1220_reg_83148.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = v1176_reg_82604.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = v1132_reg_82060.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = ap_phi_reg_pp1_iter1_v1088_reg_86460.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = ap_phi_reg_pp1_iter1_v1044_reg_81500.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96067_p0 = ap_phi_reg_pp0_iter13_v974_reg_80605.read();
    } else {
        grp_fu_96067_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96067_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96067_p1 = ap_phi_reg_pp1_iter2_v1309_reg_86916.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96067_p1 = ap_phi_reg_pp1_iter1_v1265_reg_86852.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96067_p1 = ap_phi_reg_pp1_iter1_v1221_reg_86788.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96067_p1 = ap_phi_reg_pp1_iter1_v1177_reg_86724.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96067_p1 = ap_phi_reg_pp1_iter1_v1133_reg_86660.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96067_p1 = ap_phi_reg_pp1_iter1_v1089_reg_86596.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96067_p1 = ap_phi_reg_pp1_iter1_v1045_reg_81636.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96067_p1 = ap_const_lv32_0;
    } else {
        grp_fu_96067_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96073_opcode() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96073_opcode = ap_const_lv2_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96073_opcode = ap_const_lv2_0;
    } else {
        grp_fu_96073_opcode =  (sc_lv<2>) ("XX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96073_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96073_p0 = reg_104504.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96073_p0 = reg_104498.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96073_p0 = reg_104422.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96073_p0 = reg_104397.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96073_p0 = reg_104372.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_96073_p0 = reg_104447.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96073_p0 = v1407_reg_85460.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96073_p0 = v1363_reg_84916.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96073_p0 = v1319_reg_84372.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96073_p0 = ap_phi_reg_pp0_iter13_v979_reg_80663.read();
    } else {
        grp_fu_96073_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96073_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96073_p1 = ap_phi_reg_pp1_iter2_v1408_reg_87060.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96073_p1 = ap_phi_reg_pp1_iter2_v1364_reg_86996.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96073_p1 = ap_phi_reg_pp1_iter2_v1320_reg_86932.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_96073_p1 = ap_const_lv32_0;
    } else {
        grp_fu_96073_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96079_opcode() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96079_opcode = ap_const_lv2_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96079_opcode = ap_const_lv2_0;
    } else {
        grp_fu_96079_opcode =  (sc_lv<2>) ("XX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96079_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96079_p0 = v1421_reg_131420.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96079_p0 = v1377_reg_131385.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96079_p0 = reg_104429.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96079_p0 = reg_104404.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96079_p0 = reg_104379.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_96079_p0 = reg_104453.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96079_p0 = v1418_reg_85596.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96079_p0 = v1374_reg_85052.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96079_p0 = v1330_reg_84508.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96079_p0 = ap_phi_reg_pp0_iter13_v984_reg_80721.read();
    } else {
        grp_fu_96079_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96079_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96079_p1 = ap_phi_reg_pp1_iter2_v1419_reg_87076.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96079_p1 = ap_phi_reg_pp1_iter2_v1375_reg_87012.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96079_p1 = ap_phi_reg_pp1_iter2_v1331_reg_86948.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_96079_p1 = ap_const_lv32_0;
    } else {
        grp_fu_96079_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96085_opcode() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96085_opcode = ap_const_lv2_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96085_opcode = ap_const_lv2_0;
    } else {
        grp_fu_96085_opcode =  (sc_lv<2>) ("XX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96085_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96085_p0 = v1432_reg_131425.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96085_p0 = v1388_reg_131390.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96085_p0 = reg_104435.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96085_p0 = reg_104410.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96085_p0 = reg_104385.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_96085_p0 = reg_104458.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96085_p0 = v1429_reg_85732.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96085_p0 = v1385_reg_85188.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96085_p0 = v1341_reg_84644.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96085_p0 = ap_phi_reg_pp0_iter13_v989_reg_80779.read();
    } else {
        grp_fu_96085_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96085_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96085_p1 = ap_phi_reg_pp1_iter2_v1430_reg_87092.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96085_p1 = ap_phi_reg_pp1_iter2_v1386_reg_87028.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96085_p1 = ap_phi_reg_pp1_iter2_v1342_reg_86964.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_96085_p1 = ap_const_lv32_0;
    } else {
        grp_fu_96085_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96091_opcode() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_00001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96091_opcode = ap_const_lv2_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9_00001.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0_00001.read(), ap_const_boolean_0)))) {
        grp_fu_96091_opcode = ap_const_lv2_0;
    } else {
        grp_fu_96091_opcode =  (sc_lv<2>) ("XX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96091_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96091_p0 = v1443_reg_131430.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96091_p0 = v1399_reg_131395.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96091_p0 = reg_104441.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96091_p0 = reg_104416.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96091_p0 = reg_104391.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_96091_p0 = reg_104463.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96091_p0 = v1440_reg_85868.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96091_p0 = v1396_reg_85324.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96091_p0 = v1352_reg_84780.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96091_p0 = ap_phi_reg_pp0_iter13_v994_reg_80837.read();
    } else {
        grp_fu_96091_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96091_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96091_p1 = ap_phi_reg_pp1_iter2_v1441_reg_87108.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96091_p1 = ap_phi_reg_pp1_iter2_v1397_reg_87044.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96091_p1 = ap_phi_reg_pp1_iter2_v1353_reg_86980.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_96091_p1 = ap_const_lv32_0;
    } else {
        grp_fu_96091_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96197_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96197_p0 = v2321_reg_137587.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0)))) {
        grp_fu_96197_p0 = reg_104510.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96197_p0 = v1409_reg_131321.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96197_p0 = v1365_reg_131287.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96197_p0 = reg_99464.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96197_p0 = reg_104346.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96197_p0 = reg_104320.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96197_p0 = reg_99434.read();
    } else {
        grp_fu_96197_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96197_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v2322_reg_137592.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1571_reg_132468.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1565_reg_132463.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1559_reg_132458.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1553_reg_132453.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1547_reg_132448.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1541_reg_132443.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1535_reg_132438.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1529_reg_132433.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1523_reg_132428.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1517_reg_132423.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1511_reg_132418.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1505_reg_132413.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1499_reg_132408.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1493_reg_132403.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1487_reg_132398.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1481_reg_132393.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1475_reg_132388.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1469_reg_132383.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1463_reg_132378.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v6_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1409_reg_131321.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = v1365_reg_131287.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96197_p1 = reg_99464.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96197_p1 = reg_104346.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96197_p1 = reg_104320.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96197_p1 = reg_99434.read();
    } else {
        grp_fu_96197_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96201_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96201_p0 = v1420_reg_131327.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96201_p0 = v1376_reg_131293.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96201_p0 = reg_99471.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96201_p0 = reg_104353.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96201_p0 = reg_104327.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96201_p0 = reg_99443.read();
    } else {
        grp_fu_96201_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96201_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96201_p1 = v1420_reg_131327.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96201_p1 = v1376_reg_131293.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96201_p1 = reg_99471.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96201_p1 = reg_104353.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96201_p1 = reg_104327.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96201_p1 = reg_99443.read();
    } else {
        grp_fu_96201_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96205_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96205_p0 = v1431_reg_131333.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96205_p0 = v1387_reg_131299.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96205_p0 = reg_99478.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96205_p0 = reg_104360.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96205_p0 = reg_104334.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96205_p0 = reg_99450.read();
    } else {
        grp_fu_96205_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96205_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96205_p1 = v1431_reg_131333.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96205_p1 = v1387_reg_131299.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96205_p1 = reg_99478.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96205_p1 = reg_104360.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96205_p1 = reg_104334.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96205_p1 = reg_99450.read();
    } else {
        grp_fu_96205_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96209_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96209_p0 = v1442_reg_131339.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96209_p0 = v1398_reg_131305.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96209_p0 = reg_99485.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96209_p0 = reg_104366.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96209_p0 = reg_104340.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96209_p0 = reg_99457.read();
    } else {
        grp_fu_96209_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96209_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96209_p1 = v1442_reg_131339.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96209_p1 = v1398_reg_131305.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96209_p1 = reg_99485.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96209_p1 = reg_104366.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96209_p1 = reg_104340.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96209_p1 = reg_99457.read();
    } else {
        grp_fu_96209_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96214_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage23.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage24.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage25.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage25.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage39.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage39.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage40.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage40.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage41.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage41.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage55.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage55.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage56.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage56.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage57.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage57.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p0 = grp_fu_96049_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p0 = grp_fu_96189_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = v1412_reg_131495.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = v1368_reg_131475.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = v1324_reg_131455.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = v1280_reg_131435.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = v1236_reg_131400.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = v1192_reg_131365.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = v1148_reg_131345.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = reg_104488.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = reg_104478.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96214_p0 = reg_104468.read();
    } else if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter17.read()))) {
        grp_fu_96214_p0 = reg_99434.read();
    } else {
        grp_fu_96214_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96214_p1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage25.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage25.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage41.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage41.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage57.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage57.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = v1566_reg_132567.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage24.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage24.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage40.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage40.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage56.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage56.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = v1554_reg_132557.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage23.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage39.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage39.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage55.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage55.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = v1542_reg_132547.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = v1530_reg_132537.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = v1518_reg_132527.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = v1506_reg_132507.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = v1494_reg_132497.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = reg_104498.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = reg_104422.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = reg_104372.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter17.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96214_p1 = v2_read_reg_112889.read();
    } else {
        grp_fu_96214_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96218_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage23.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage24.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage25.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage25.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage39.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage39.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage40.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage40.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage41.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage41.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage55.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage55.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage56.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage56.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage57.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage57.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p0 = grp_fu_96055_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p0 = grp_fu_96049_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = v1423_reg_131500.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = v1379_reg_131480.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = v1335_reg_131460.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = v1291_reg_131440.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = v1247_reg_131405.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = v1203_reg_131370.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = v1159_reg_131350.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = reg_104493.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = reg_104483.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96218_p0 = reg_104473.read();
    } else if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter17.read()))) {
        grp_fu_96218_p0 = reg_99443.read();
    } else {
        grp_fu_96218_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96218_p1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage25.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage25.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage41.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage41.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage57.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage57.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = v1572_reg_132572.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage24.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage24.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage40.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage40.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage56.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage56.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = v1560_reg_132562.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage23.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage39.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage39.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage55.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage55.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = v1548_reg_132552.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = v1536_reg_132542.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = v1524_reg_132532.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = v1512_reg_132522.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = v1500_reg_132502.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = reg_104504.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = reg_104447.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = reg_104397.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter17.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_96218_p1 = v2_read_reg_112889.read();
    } else {
        grp_fu_96218_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96222_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1434_reg_131505.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1390_reg_131485.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1346_reg_131465.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1302_reg_131445.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1258_reg_131410.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1214_reg_131375.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1170_reg_131355.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1126_reg_131311.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1082_reg_131277.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96222_p0 = v1038_reg_131267.read();
    } else if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter17.read()))) {
        grp_fu_96222_p0 = reg_99450.read();
    } else {
        grp_fu_96222_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_96226_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1445_reg_131510.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1401_reg_131490.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1357_reg_131470.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1313_reg_131450.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1269_reg_131415.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1225_reg_131380.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1181_reg_131360.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1137_reg_131316.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1093_reg_131282.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_96226_p0 = v1049_reg_131272.read();
    } else if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter17.read()))) {
        grp_fu_96226_p0 = reg_99457.read();
    } else {
        grp_fu_96226_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_97558_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_97558_p0 = v1415_reg_132015.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_97558_p0 = reg_104571.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_97558_p0 = reg_104531.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)))) {
        grp_fu_97558_p0 = reg_104510.read();
    } else {
        grp_fu_97558_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_97561_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_97561_p0 = v1426_reg_132021.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_97561_p0 = reg_104576.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_97561_p0 = reg_104536.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)))) {
        grp_fu_97561_p0 = reg_104516.read();
    } else {
        grp_fu_97561_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_97564_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_97564_p0 = v1437_reg_132027.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_97564_p0 = reg_104581.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_97564_p0 = reg_104541.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)))) {
        grp_fu_97564_p0 = reg_104521.read();
    } else {
        grp_fu_97564_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_97567_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_97567_p0 = v1448_reg_132033.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_97567_p0 = reg_104586.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_97567_p0 = reg_104546.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)))) {
        grp_fu_97567_p0 = reg_104526.read();
    } else {
        grp_fu_97567_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_97570_p1() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state92.read())) {
        grp_fu_97570_p1 = v2_read_reg_112889.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = v1414_reg_131675.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = v1370_reg_131655.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = v1326_reg_131635.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = v1282_reg_131615.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = v1238_reg_131595.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = v1194_reg_131575.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = v1150_reg_131555.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = v1106_reg_131535.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = v1062_reg_131515.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_97570_p1 = reg_99492.read();
    } else {
        grp_fu_97570_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_97575_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = v1425_reg_131680.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = v1381_reg_131660.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = v1337_reg_131640.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = v1293_reg_131620.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = v1249_reg_131600.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = v1205_reg_131580.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = v1161_reg_131560.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = v1117_reg_131540.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = v1073_reg_131520.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_97575_p1 = reg_99499.read();
    } else {
        grp_fu_97575_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_97580_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = v1436_reg_131685.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = v1392_reg_131665.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = v1348_reg_131645.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = v1304_reg_131625.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = v1260_reg_131605.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = v1216_reg_131585.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = v1172_reg_131565.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = v1128_reg_131545.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = v1084_reg_131525.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_97580_p1 = reg_99506.read();
    } else {
        grp_fu_97580_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_grp_fu_97585_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = v1447_reg_131690.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = v1403_reg_131670.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = v1359_reg_131650.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = v1315_reg_131630.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = v1271_reg_131610.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = v1227_reg_131590.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = v1183_reg_131570.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = v1139_reg_131550.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = v1095_reg_131530.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_97585_p1 = reg_99513.read();
    } else {
        grp_fu_97585_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_icmp_ln1581_fu_105508_p2() {
    icmp_ln1581_fu_105508_p2 = (!trunc_ln54_fu_105104_p1.read().is_01() || !ap_const_lv5_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln54_fu_105104_p1.read() == ap_const_lv5_0);
}

void kernel_correlation_asdse::thread_icmp_ln1589_fu_105502_p2() {
    icmp_ln1589_fu_105502_p2 = (!trunc_ln62_fu_105147_p1.read().is_01() || !ap_const_lv5_1.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln62_fu_105147_p1.read() == ap_const_lv5_1);
}

void kernel_correlation_asdse::thread_icmp_ln1656_fu_105630_p2() {
    icmp_ln1656_fu_105630_p2 = (!ap_phi_mux_indvar_flatten6_phi_fu_81015_p4.read().is_01() || !ap_const_lv11_618.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten6_phi_fu_81015_p4.read() == ap_const_lv11_618);
}

void kernel_correlation_asdse::thread_icmp_ln1657_fu_105648_p2() {
    icmp_ln1657_fu_105648_p2 = (!ap_phi_mux_v1010_0_phi_fu_81037_p4.read().is_01() || !ap_const_lv6_3C.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v1010_0_phi_fu_81037_p4.read() == ap_const_lv6_3C);
}

void kernel_correlation_asdse::thread_icmp_ln1670_1_fu_109393_p2() {
    icmp_ln1670_1_fu_109393_p2 = (!trunc_ln1670_fu_109383_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1670_fu_109383_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1670_fu_109387_p2() {
    icmp_ln1670_fu_109387_p2 = (!tmp_43_fu_109373_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_43_fu_109373_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1684_1_fu_109423_p2() {
    icmp_ln1684_1_fu_109423_p2 = (!trunc_ln1684_fu_109413_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1684_fu_109413_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1684_fu_109417_p2() {
    icmp_ln1684_fu_109417_p2 = (!tmp_45_fu_109403_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_45_fu_109403_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1698_1_fu_109453_p2() {
    icmp_ln1698_1_fu_109453_p2 = (!trunc_ln1698_fu_109443_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1698_fu_109443_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1698_fu_109447_p2() {
    icmp_ln1698_fu_109447_p2 = (!tmp_47_fu_109433_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_47_fu_109433_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1712_1_fu_109483_p2() {
    icmp_ln1712_1_fu_109483_p2 = (!trunc_ln1712_fu_109473_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1712_fu_109473_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1712_fu_109477_p2() {
    icmp_ln1712_fu_109477_p2 = (!tmp_49_fu_109463_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_49_fu_109463_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1726_1_fu_109605_p2() {
    icmp_ln1726_1_fu_109605_p2 = (!trunc_ln1726_fu_109595_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1726_fu_109595_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1726_fu_109599_p2() {
    icmp_ln1726_fu_109599_p2 = (!tmp_51_fu_109585_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_51_fu_109585_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1740_1_fu_109635_p2() {
    icmp_ln1740_1_fu_109635_p2 = (!trunc_ln1740_fu_109625_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1740_fu_109625_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1740_fu_109629_p2() {
    icmp_ln1740_fu_109629_p2 = (!tmp_53_fu_109615_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_53_fu_109615_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1754_1_fu_109665_p2() {
    icmp_ln1754_1_fu_109665_p2 = (!trunc_ln1754_fu_109655_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1754_fu_109655_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1754_fu_109659_p2() {
    icmp_ln1754_fu_109659_p2 = (!tmp_55_fu_109645_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_55_fu_109645_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1768_1_fu_109695_p2() {
    icmp_ln1768_1_fu_109695_p2 = (!trunc_ln1768_fu_109685_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1768_fu_109685_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1768_fu_109689_p2() {
    icmp_ln1768_fu_109689_p2 = (!tmp_57_fu_109675_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_57_fu_109675_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1782_1_fu_109817_p2() {
    icmp_ln1782_1_fu_109817_p2 = (!trunc_ln1782_fu_109807_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1782_fu_109807_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1782_fu_109811_p2() {
    icmp_ln1782_fu_109811_p2 = (!tmp_59_fu_109797_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_59_fu_109797_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1796_1_fu_109847_p2() {
    icmp_ln1796_1_fu_109847_p2 = (!trunc_ln1796_fu_109837_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1796_fu_109837_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1796_fu_109841_p2() {
    icmp_ln1796_fu_109841_p2 = (!tmp_61_fu_109827_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_61_fu_109827_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1810_1_fu_109877_p2() {
    icmp_ln1810_1_fu_109877_p2 = (!trunc_ln1810_fu_109867_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1810_fu_109867_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1810_fu_109871_p2() {
    icmp_ln1810_fu_109871_p2 = (!tmp_63_fu_109857_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_63_fu_109857_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1824_1_fu_109907_p2() {
    icmp_ln1824_1_fu_109907_p2 = (!trunc_ln1824_fu_109897_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1824_fu_109897_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1824_fu_109901_p2() {
    icmp_ln1824_fu_109901_p2 = (!tmp_65_fu_109887_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_65_fu_109887_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1838_1_fu_110029_p2() {
    icmp_ln1838_1_fu_110029_p2 = (!trunc_ln1838_fu_110019_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1838_fu_110019_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1838_fu_110023_p2() {
    icmp_ln1838_fu_110023_p2 = (!tmp_67_fu_110009_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_67_fu_110009_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1852_1_fu_110059_p2() {
    icmp_ln1852_1_fu_110059_p2 = (!trunc_ln1852_fu_110049_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1852_fu_110049_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1852_fu_110053_p2() {
    icmp_ln1852_fu_110053_p2 = (!tmp_69_fu_110039_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_69_fu_110039_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1866_1_fu_110089_p2() {
    icmp_ln1866_1_fu_110089_p2 = (!trunc_ln1866_fu_110079_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1866_fu_110079_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1866_fu_110083_p2() {
    icmp_ln1866_fu_110083_p2 = (!tmp_71_fu_110069_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_71_fu_110069_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1880_1_fu_110119_p2() {
    icmp_ln1880_1_fu_110119_p2 = (!trunc_ln1880_fu_110109_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1880_fu_110109_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1880_fu_110113_p2() {
    icmp_ln1880_fu_110113_p2 = (!tmp_73_fu_110099_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_73_fu_110099_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1894_1_fu_110241_p2() {
    icmp_ln1894_1_fu_110241_p2 = (!trunc_ln1894_fu_110231_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1894_fu_110231_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1894_fu_110235_p2() {
    icmp_ln1894_fu_110235_p2 = (!tmp_75_fu_110221_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_75_fu_110221_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1908_1_fu_110271_p2() {
    icmp_ln1908_1_fu_110271_p2 = (!trunc_ln1908_fu_110261_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1908_fu_110261_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1908_fu_110265_p2() {
    icmp_ln1908_fu_110265_p2 = (!tmp_77_fu_110251_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_77_fu_110251_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1922_1_fu_110301_p2() {
    icmp_ln1922_1_fu_110301_p2 = (!trunc_ln1922_fu_110291_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1922_fu_110291_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1922_fu_110295_p2() {
    icmp_ln1922_fu_110295_p2 = (!tmp_79_fu_110281_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_79_fu_110281_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1936_1_fu_110331_p2() {
    icmp_ln1936_1_fu_110331_p2 = (!trunc_ln1936_fu_110321_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1936_fu_110321_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1936_fu_110325_p2() {
    icmp_ln1936_fu_110325_p2 = (!tmp_81_fu_110311_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_81_fu_110311_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1950_1_fu_110453_p2() {
    icmp_ln1950_1_fu_110453_p2 = (!trunc_ln1950_fu_110443_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1950_fu_110443_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1950_fu_110447_p2() {
    icmp_ln1950_fu_110447_p2 = (!tmp_83_fu_110433_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_83_fu_110433_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1964_1_fu_110483_p2() {
    icmp_ln1964_1_fu_110483_p2 = (!trunc_ln1964_fu_110473_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1964_fu_110473_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1964_fu_110477_p2() {
    icmp_ln1964_fu_110477_p2 = (!tmp_85_fu_110463_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_85_fu_110463_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1978_1_fu_110513_p2() {
    icmp_ln1978_1_fu_110513_p2 = (!trunc_ln1978_fu_110503_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1978_fu_110503_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1978_fu_110507_p2() {
    icmp_ln1978_fu_110507_p2 = (!tmp_87_fu_110493_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_87_fu_110493_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln1992_1_fu_110543_p2() {
    icmp_ln1992_1_fu_110543_p2 = (!trunc_ln1992_fu_110533_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln1992_fu_110533_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln1992_fu_110537_p2() {
    icmp_ln1992_fu_110537_p2 = (!tmp_89_fu_110523_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_89_fu_110523_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2006_1_fu_110665_p2() {
    icmp_ln2006_1_fu_110665_p2 = (!trunc_ln2006_fu_110655_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2006_fu_110655_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2006_fu_110659_p2() {
    icmp_ln2006_fu_110659_p2 = (!tmp_91_fu_110645_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_91_fu_110645_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2020_1_fu_110695_p2() {
    icmp_ln2020_1_fu_110695_p2 = (!trunc_ln2020_fu_110685_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2020_fu_110685_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2020_fu_110689_p2() {
    icmp_ln2020_fu_110689_p2 = (!tmp_93_fu_110675_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_93_fu_110675_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2034_1_fu_110725_p2() {
    icmp_ln2034_1_fu_110725_p2 = (!trunc_ln2034_fu_110715_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2034_fu_110715_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2034_fu_110719_p2() {
    icmp_ln2034_fu_110719_p2 = (!tmp_95_fu_110705_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_95_fu_110705_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2048_1_fu_110755_p2() {
    icmp_ln2048_1_fu_110755_p2 = (!trunc_ln2048_fu_110745_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2048_fu_110745_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2048_fu_110749_p2() {
    icmp_ln2048_fu_110749_p2 = (!tmp_97_fu_110735_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_97_fu_110735_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2062_1_fu_110877_p2() {
    icmp_ln2062_1_fu_110877_p2 = (!trunc_ln2062_fu_110867_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2062_fu_110867_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2062_fu_110871_p2() {
    icmp_ln2062_fu_110871_p2 = (!tmp_99_fu_110857_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_99_fu_110857_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2076_1_fu_110907_p2() {
    icmp_ln2076_1_fu_110907_p2 = (!trunc_ln2076_fu_110897_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2076_fu_110897_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2076_fu_110901_p2() {
    icmp_ln2076_fu_110901_p2 = (!tmp_101_fu_110887_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_101_fu_110887_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2090_1_fu_110937_p2() {
    icmp_ln2090_1_fu_110937_p2 = (!trunc_ln2090_fu_110927_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2090_fu_110927_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2090_fu_110931_p2() {
    icmp_ln2090_fu_110931_p2 = (!tmp_103_fu_110917_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_103_fu_110917_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2104_1_fu_110967_p2() {
    icmp_ln2104_1_fu_110967_p2 = (!trunc_ln2104_fu_110957_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2104_fu_110957_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2104_fu_110961_p2() {
    icmp_ln2104_fu_110961_p2 = (!tmp_105_fu_110947_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_105_fu_110947_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2118_1_fu_111089_p2() {
    icmp_ln2118_1_fu_111089_p2 = (!trunc_ln2118_fu_111079_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2118_fu_111079_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2118_fu_111083_p2() {
    icmp_ln2118_fu_111083_p2 = (!tmp_107_fu_111069_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_107_fu_111069_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2132_1_fu_111119_p2() {
    icmp_ln2132_1_fu_111119_p2 = (!trunc_ln2132_fu_111109_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2132_fu_111109_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2132_fu_111113_p2() {
    icmp_ln2132_fu_111113_p2 = (!tmp_109_fu_111099_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_109_fu_111099_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2146_1_fu_111149_p2() {
    icmp_ln2146_1_fu_111149_p2 = (!trunc_ln2146_fu_111139_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2146_fu_111139_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2146_fu_111143_p2() {
    icmp_ln2146_fu_111143_p2 = (!tmp_111_fu_111129_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_111_fu_111129_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2160_1_fu_111179_p2() {
    icmp_ln2160_1_fu_111179_p2 = (!trunc_ln2160_fu_111169_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2160_fu_111169_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2160_fu_111173_p2() {
    icmp_ln2160_fu_111173_p2 = (!tmp_113_fu_111159_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_113_fu_111159_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2174_1_fu_111301_p2() {
    icmp_ln2174_1_fu_111301_p2 = (!trunc_ln2174_fu_111291_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2174_fu_111291_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2174_fu_111295_p2() {
    icmp_ln2174_fu_111295_p2 = (!tmp_115_fu_111281_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_115_fu_111281_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2188_1_fu_111331_p2() {
    icmp_ln2188_1_fu_111331_p2 = (!trunc_ln2188_fu_111321_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2188_fu_111321_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2188_fu_111325_p2() {
    icmp_ln2188_fu_111325_p2 = (!tmp_117_fu_111311_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_117_fu_111311_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2202_1_fu_111361_p2() {
    icmp_ln2202_1_fu_111361_p2 = (!trunc_ln2202_fu_111351_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2202_fu_111351_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2202_fu_111355_p2() {
    icmp_ln2202_fu_111355_p2 = (!tmp_119_fu_111341_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_119_fu_111341_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2216_1_fu_111391_p2() {
    icmp_ln2216_1_fu_111391_p2 = (!trunc_ln2216_fu_111381_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln2216_fu_111381_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_asdse::thread_icmp_ln2216_fu_111385_p2() {
    icmp_ln2216_fu_111385_p2 = (!tmp_121_fu_111371_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_121_fu_111371_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_asdse::thread_icmp_ln2222_fu_111485_p2() {
    icmp_ln2222_fu_111485_p2 = (!ap_phi_mux_indvar_flatten13_phi_fu_87128_p4.read().is_01() || !ap_const_lv10_30C.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten13_phi_fu_87128_p4.read() == ap_const_lv10_30C);
}

void kernel_correlation_asdse::thread_icmp_ln2223_fu_111503_p2() {
    icmp_ln2223_fu_111503_p2 = (!ap_phi_mux_v1453_0_phi_fu_87150_p4.read().is_01() || !ap_const_lv4_C.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v1453_0_phi_fu_87150_p4.read() == ap_const_lv4_C);
}

void kernel_correlation_asdse::thread_icmp_ln2867_fu_112370_p2() {
    icmp_ln2867_fu_112370_p2 = (!ap_phi_mux_indvar_flatten309_phi_fu_87161_p4.read().is_01() || !ap_const_lv18_37C84.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten309_phi_fu_87161_p4.read() == ap_const_lv18_37C84);
}

void kernel_correlation_asdse::thread_icmp_ln2868_fu_112388_p2() {
    icmp_ln2868_fu_112388_p2 = (!ap_phi_mux_indvar_flatten22_phi_fu_87184_p4.read().is_01() || !ap_const_lv11_3BC.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten22_phi_fu_87184_p4.read() == ap_const_lv11_3BC);
}

void kernel_correlation_asdse::thread_icmp_ln2869_fu_112414_p2() {
    icmp_ln2869_fu_112414_p2 = (!ap_phi_mux_v1936_0_phi_fu_87195_p4.read().is_01() || !ap_const_lv3_4.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v1936_0_phi_fu_87195_p4.read() == ap_const_lv3_4);
}

void kernel_correlation_asdse::thread_icmp_ln51_fu_104689_p2() {
    icmp_ln51_fu_104689_p2 = (!indvar_flatten_reg_80398.read().is_01() || !ap_const_lv9_138.is_01())? sc_lv<1>(): sc_lv<1>(indvar_flatten_reg_80398.read() == ap_const_lv9_138);
}

void kernel_correlation_asdse::thread_icmp_ln52_fu_104707_p2() {
    icmp_ln52_fu_104707_p2 = (!v8_0_reg_80420.read().is_01() || !ap_const_lv5_18.is_01())? sc_lv<1>(): sc_lv<1>(v8_0_reg_80420.read() == ap_const_lv5_18);
}

void kernel_correlation_asdse::thread_mul_ln102_fu_104989_p1() {
    mul_ln102_fu_104989_p1 =  (sc_lv<8>) (mul_ln102_fu_104989_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln102_fu_104989_p10() {
    mul_ln102_fu_104989_p10 = esl_zext<18,8>(add_ln102_fu_104980_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln102_fu_104989_p2() {
    mul_ln102_fu_104989_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln102_fu_104989_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln102_fu_104989_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln110_fu_105014_p1() {
    mul_ln110_fu_105014_p1 =  (sc_lv<8>) (mul_ln110_fu_105014_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln110_fu_105014_p10() {
    mul_ln110_fu_105014_p10 = esl_zext<18,8>(add_ln110_fu_105005_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln110_fu_105014_p2() {
    mul_ln110_fu_105014_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln110_fu_105014_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln110_fu_105014_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln118_fu_105039_p1() {
    mul_ln118_fu_105039_p1 =  (sc_lv<8>) (mul_ln118_fu_105039_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln118_fu_105039_p10() {
    mul_ln118_fu_105039_p10 = esl_zext<18,8>(add_ln118_fu_105030_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln118_fu_105039_p2() {
    mul_ln118_fu_105039_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln118_fu_105039_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln118_fu_105039_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln126_fu_105064_p1() {
    mul_ln126_fu_105064_p1 =  (sc_lv<8>) (mul_ln126_fu_105064_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln126_fu_105064_p10() {
    mul_ln126_fu_105064_p10 = esl_zext<18,8>(add_ln126_fu_105055_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln126_fu_105064_p2() {
    mul_ln126_fu_105064_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln126_fu_105064_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln126_fu_105064_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_1_fu_105767_p1() {
    mul_ln1656_1_fu_105767_p1 =  (sc_lv<8>) (mul_ln1656_1_fu_105767_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_1_fu_105767_p10() {
    mul_ln1656_1_fu_105767_p10 = esl_zext<18,8>(or_ln1656_fu_105758_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_1_fu_105767_p2() {
    mul_ln1656_1_fu_105767_p2 = (!ap_const_lv18_1F9.is_01() || !mul_ln1656_1_fu_105767_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_1F9) * sc_biguint<8>(mul_ln1656_1_fu_105767_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_2_fu_105958_p1() {
    mul_ln1656_2_fu_105958_p1 =  (sc_lv<8>) (mul_ln1656_2_fu_105958_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_2_fu_105958_p10() {
    mul_ln1656_2_fu_105958_p10 = esl_zext<18,8>(add_ln1656_fu_105949_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_2_fu_105958_p2() {
    mul_ln1656_2_fu_105958_p2 = (!ap_const_lv18_1F9.is_01() || !mul_ln1656_2_fu_105958_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_1F9) * sc_biguint<8>(mul_ln1656_2_fu_105958_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_3_fu_105983_p1() {
    mul_ln1656_3_fu_105983_p1 =  (sc_lv<8>) (mul_ln1656_3_fu_105983_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_3_fu_105983_p10() {
    mul_ln1656_3_fu_105983_p10 = esl_zext<18,8>(add_ln1656_1_fu_105974_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_3_fu_105983_p2() {
    mul_ln1656_3_fu_105983_p2 = (!ap_const_lv18_1F9.is_01() || !mul_ln1656_3_fu_105983_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_1F9) * sc_biguint<8>(mul_ln1656_3_fu_105983_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_4_fu_106008_p1() {
    mul_ln1656_4_fu_106008_p1 =  (sc_lv<8>) (mul_ln1656_4_fu_106008_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_4_fu_106008_p10() {
    mul_ln1656_4_fu_106008_p10 = esl_zext<18,8>(add_ln1656_2_fu_105999_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_4_fu_106008_p2() {
    mul_ln1656_4_fu_106008_p2 = (!ap_const_lv18_1F9.is_01() || !mul_ln1656_4_fu_106008_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_1F9) * sc_biguint<8>(mul_ln1656_4_fu_106008_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_5_fu_106033_p1() {
    mul_ln1656_5_fu_106033_p1 =  (sc_lv<8>) (mul_ln1656_5_fu_106033_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_5_fu_106033_p10() {
    mul_ln1656_5_fu_106033_p10 = esl_zext<18,8>(add_ln1656_3_fu_106024_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_5_fu_106033_p2() {
    mul_ln1656_5_fu_106033_p2 = (!ap_const_lv18_1F9.is_01() || !mul_ln1656_5_fu_106033_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_1F9) * sc_biguint<8>(mul_ln1656_5_fu_106033_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_fu_105706_p1() {
    mul_ln1656_fu_105706_p1 =  (sc_lv<8>) (mul_ln1656_fu_105706_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_fu_105706_p10() {
    mul_ln1656_fu_105706_p10 = esl_zext<18,8>(select_ln1656_1_fu_105688_p3.read());
}

void kernel_correlation_asdse::thread_mul_ln1656_fu_105706_p2() {
    mul_ln1656_fu_105706_p2 = (!ap_const_lv18_1F9.is_01() || !mul_ln1656_fu_105706_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_1F9) * sc_biguint<8>(mul_ln1656_fu_105706_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln1659_fu_105840_p1() {
    mul_ln1659_fu_105840_p1 =  (sc_lv<8>) (mul_ln1659_fu_105840_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln1659_fu_105840_p10() {
    mul_ln1659_fu_105840_p10 = esl_zext<18,8>(shl_ln3_reg_114458.read());
}

void kernel_correlation_asdse::thread_mul_ln1659_fu_105840_p2() {
    mul_ln1659_fu_105840_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln1659_fu_105840_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln1659_fu_105840_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln1673_fu_105883_p0() {
    mul_ln1673_fu_105883_p0 =  (sc_lv<8>) (mul_ln1673_fu_105883_p00.read());
}

void kernel_correlation_asdse::thread_mul_ln1673_fu_105883_p00() {
    mul_ln1673_fu_105883_p00 = esl_zext<18,8>(or_ln1673_fu_105874_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln1673_fu_105883_p2() {
    mul_ln1673_fu_105883_p2 = (!mul_ln1673_fu_105883_p0.read().is_01() || !ap_const_lv18_19A.is_01())? sc_lv<18>(): sc_biguint<8>(mul_ln1673_fu_105883_p0.read()) * sc_biguint<18>(ap_const_lv18_19A);
}

void kernel_correlation_asdse::thread_mul_ln1687_fu_105908_p0() {
    mul_ln1687_fu_105908_p0 =  (sc_lv<8>) (mul_ln1687_fu_105908_p00.read());
}

void kernel_correlation_asdse::thread_mul_ln1687_fu_105908_p00() {
    mul_ln1687_fu_105908_p00 = esl_zext<18,8>(or_ln1687_fu_105899_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln1687_fu_105908_p2() {
    mul_ln1687_fu_105908_p2 = (!mul_ln1687_fu_105908_p0.read().is_01() || !ap_const_lv18_19A.is_01())? sc_lv<18>(): sc_biguint<8>(mul_ln1687_fu_105908_p0.read()) * sc_biguint<18>(ap_const_lv18_19A);
}

void kernel_correlation_asdse::thread_mul_ln1701_fu_105933_p0() {
    mul_ln1701_fu_105933_p0 =  (sc_lv<8>) (mul_ln1701_fu_105933_p00.read());
}

void kernel_correlation_asdse::thread_mul_ln1701_fu_105933_p00() {
    mul_ln1701_fu_105933_p00 = esl_zext<18,8>(or_ln1701_fu_105924_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln1701_fu_105933_p2() {
    mul_ln1701_fu_105933_p2 = (!mul_ln1701_fu_105933_p0.read().is_01() || !ap_const_lv18_19A.is_01())? sc_lv<18>(): sc_biguint<8>(mul_ln1701_fu_105933_p0.read()) * sc_biguint<18>(ap_const_lv18_19A);
}

void kernel_correlation_asdse::thread_mul_ln2222_1_fu_112865_p0() {
    mul_ln2222_1_fu_112865_p0 =  (sc_lv<11>) (ap_const_lv20_3F1);
}

void kernel_correlation_asdse::thread_mul_ln2222_1_fu_112865_p1() {
    mul_ln2222_1_fu_112865_p1 =  (sc_lv<9>) (mul_ln2222_1_fu_112865_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln2222_1_fu_112865_p10() {
    mul_ln2222_1_fu_112865_p10 = esl_zext<20,9>(or_ln2222_fu_111621_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln2222_2_fu_112873_p0() {
    mul_ln2222_2_fu_112873_p0 =  (sc_lv<11>) (ap_const_lv20_3F1);
}

void kernel_correlation_asdse::thread_mul_ln2222_2_fu_112873_p1() {
    mul_ln2222_2_fu_112873_p1 =  (sc_lv<9>) (mul_ln2222_2_fu_112873_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln2222_2_fu_112873_p10() {
    mul_ln2222_2_fu_112873_p10 = esl_zext<20,9>(or_ln2222_1_fu_111648_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln2222_3_fu_112881_p0() {
    mul_ln2222_3_fu_112881_p0 =  (sc_lv<11>) (ap_const_lv20_3F1);
}

void kernel_correlation_asdse::thread_mul_ln2222_3_fu_112881_p1() {
    mul_ln2222_3_fu_112881_p1 =  (sc_lv<9>) (mul_ln2222_3_fu_112881_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln2222_3_fu_112881_p10() {
    mul_ln2222_3_fu_112881_p10 = esl_zext<20,9>(or_ln2222_2_fu_111675_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln2222_fu_112857_p0() {
    mul_ln2222_fu_112857_p0 =  (sc_lv<11>) (ap_const_lv20_3F1);
}

void kernel_correlation_asdse::thread_mul_ln2222_fu_112857_p1() {
    mul_ln2222_fu_112857_p1 =  (sc_lv<9>) (mul_ln2222_fu_112857_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln2222_fu_112857_p10() {
    mul_ln2222_fu_112857_p10 = esl_zext<20,9>(select_ln2222_1_fu_111533_p3.read());
}

void kernel_correlation_asdse::thread_mul_ln2867_fu_112572_p1() {
    mul_ln2867_fu_112572_p1 =  (sc_lv<8>) (mul_ln2867_fu_112572_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln2867_fu_112572_p10() {
    mul_ln2867_fu_112572_p10 = esl_zext<18,8>(select_ln2867_1_reg_137323_pp3_iter1_reg.read());
}

void kernel_correlation_asdse::thread_mul_ln2867_fu_112572_p2() {
    mul_ln2867_fu_112572_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln2867_fu_112572_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln2867_fu_112572_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln2875_1_fu_112610_p1() {
    mul_ln2875_1_fu_112610_p1 =  (sc_lv<8>) (mul_ln2875_1_fu_112610_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln2875_1_fu_112610_p10() {
    mul_ln2875_1_fu_112610_p10 = esl_zext<18,8>(add_ln2873_1_fu_112594_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln2875_1_fu_112610_p2() {
    mul_ln2875_1_fu_112610_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln2875_1_fu_112610_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln2875_1_fu_112610_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln2875_fu_112655_p1() {
    mul_ln2875_fu_112655_p1 =  (sc_lv<8>) (mul_ln2875_fu_112655_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln2875_fu_112655_p10() {
    mul_ln2875_fu_112655_p10 = esl_zext<18,8>(v1935_reg_137390_pp3_iter2_reg.read());
}

void kernel_correlation_asdse::thread_mul_ln2875_fu_112655_p2() {
    mul_ln2875_fu_112655_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln2875_fu_112655_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln2875_fu_112655_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln54_fu_104864_p1() {
    mul_ln54_fu_104864_p1 =  (sc_lv<8>) (mul_ln54_fu_104864_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln54_fu_104864_p10() {
    mul_ln54_fu_104864_p10 = esl_zext<18,8>(add_ln54_reg_112938_pp0_iter9_reg.read());
}

void kernel_correlation_asdse::thread_mul_ln54_fu_104864_p2() {
    mul_ln54_fu_104864_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln54_fu_104864_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln54_fu_104864_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln62_fu_104839_p1() {
    mul_ln62_fu_104839_p1 =  (sc_lv<8>) (mul_ln62_fu_104839_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln62_fu_104839_p10() {
    mul_ln62_fu_104839_p10 = esl_zext<18,8>(or_ln62_fu_104823_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln62_fu_104839_p2() {
    mul_ln62_fu_104839_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln62_fu_104839_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln62_fu_104839_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln70_fu_104889_p1() {
    mul_ln70_fu_104889_p1 =  (sc_lv<8>) (mul_ln70_fu_104889_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln70_fu_104889_p10() {
    mul_ln70_fu_104889_p10 = esl_zext<18,8>(add_ln70_fu_104880_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln70_fu_104889_p2() {
    mul_ln70_fu_104889_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln70_fu_104889_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln70_fu_104889_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln78_fu_104914_p1() {
    mul_ln78_fu_104914_p1 =  (sc_lv<8>) (mul_ln78_fu_104914_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln78_fu_104914_p10() {
    mul_ln78_fu_104914_p10 = esl_zext<18,8>(add_ln78_fu_104905_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln78_fu_104914_p2() {
    mul_ln78_fu_104914_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln78_fu_104914_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln78_fu_104914_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln86_fu_104939_p1() {
    mul_ln86_fu_104939_p1 =  (sc_lv<8>) (mul_ln86_fu_104939_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln86_fu_104939_p10() {
    mul_ln86_fu_104939_p10 = esl_zext<18,8>(add_ln86_fu_104930_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln86_fu_104939_p2() {
    mul_ln86_fu_104939_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln86_fu_104939_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln86_fu_104939_p1.read());
}

void kernel_correlation_asdse::thread_mul_ln94_fu_104964_p1() {
    mul_ln94_fu_104964_p1 =  (sc_lv<8>) (mul_ln94_fu_104964_p10.read());
}

void kernel_correlation_asdse::thread_mul_ln94_fu_104964_p10() {
    mul_ln94_fu_104964_p10 = esl_zext<18,8>(add_ln94_fu_104955_p2.read());
}

void kernel_correlation_asdse::thread_mul_ln94_fu_104964_p2() {
    mul_ln94_fu_104964_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln94_fu_104964_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln94_fu_104964_p1.read());
}

void kernel_correlation_asdse::thread_or_ln1656_fu_105758_p2() {
    or_ln1656_fu_105758_p2 = (select_ln1656_1_reg_114394.read() | ap_const_lv8_1);
}

void kernel_correlation_asdse::thread_or_ln1670_fu_109489_p2() {
    or_ln1670_fu_109489_p2 = (icmp_ln1670_1_reg_131700.read() | icmp_ln1670_reg_131695.read());
}

void kernel_correlation_asdse::thread_or_ln1673_fu_105874_p2() {
    or_ln1673_fu_105874_p2 = (shl_ln3_reg_114458.read() | ap_const_lv8_1);
}

void kernel_correlation_asdse::thread_or_ln1684_fu_109512_p2() {
    or_ln1684_fu_109512_p2 = (icmp_ln1684_1_reg_131710.read() | icmp_ln1684_reg_131705.read());
}

void kernel_correlation_asdse::thread_or_ln1687_fu_105899_p2() {
    or_ln1687_fu_105899_p2 = (shl_ln3_reg_114458.read() | ap_const_lv8_2);
}

void kernel_correlation_asdse::thread_or_ln1698_fu_109535_p2() {
    or_ln1698_fu_109535_p2 = (icmp_ln1698_1_reg_131720.read() | icmp_ln1698_reg_131715.read());
}

void kernel_correlation_asdse::thread_or_ln1701_fu_105924_p2() {
    or_ln1701_fu_105924_p2 = (shl_ln3_reg_114458.read() | ap_const_lv8_3);
}

void kernel_correlation_asdse::thread_or_ln1712_fu_109558_p2() {
    or_ln1712_fu_109558_p2 = (icmp_ln1712_1_reg_131730.read() | icmp_ln1712_reg_131725.read());
}

void kernel_correlation_asdse::thread_or_ln1726_fu_109701_p2() {
    or_ln1726_fu_109701_p2 = (icmp_ln1726_1_reg_131740.read() | icmp_ln1726_reg_131735.read());
}

void kernel_correlation_asdse::thread_or_ln1740_fu_109724_p2() {
    or_ln1740_fu_109724_p2 = (icmp_ln1740_1_reg_131750.read() | icmp_ln1740_reg_131745.read());
}

void kernel_correlation_asdse::thread_or_ln1754_fu_109747_p2() {
    or_ln1754_fu_109747_p2 = (icmp_ln1754_1_reg_131760.read() | icmp_ln1754_reg_131755.read());
}

void kernel_correlation_asdse::thread_or_ln1768_fu_109770_p2() {
    or_ln1768_fu_109770_p2 = (icmp_ln1768_1_reg_131770.read() | icmp_ln1768_reg_131765.read());
}

void kernel_correlation_asdse::thread_or_ln1782_fu_109913_p2() {
    or_ln1782_fu_109913_p2 = (icmp_ln1782_1_reg_131780.read() | icmp_ln1782_reg_131775.read());
}

void kernel_correlation_asdse::thread_or_ln1796_fu_109936_p2() {
    or_ln1796_fu_109936_p2 = (icmp_ln1796_1_reg_131790.read() | icmp_ln1796_reg_131785.read());
}

void kernel_correlation_asdse::thread_or_ln1810_fu_109959_p2() {
    or_ln1810_fu_109959_p2 = (icmp_ln1810_1_reg_131800.read() | icmp_ln1810_reg_131795.read());
}

void kernel_correlation_asdse::thread_or_ln1824_fu_109982_p2() {
    or_ln1824_fu_109982_p2 = (icmp_ln1824_1_reg_131810.read() | icmp_ln1824_reg_131805.read());
}

void kernel_correlation_asdse::thread_or_ln1838_fu_110125_p2() {
    or_ln1838_fu_110125_p2 = (icmp_ln1838_1_reg_131820.read() | icmp_ln1838_reg_131815.read());
}

void kernel_correlation_asdse::thread_or_ln1852_fu_110148_p2() {
    or_ln1852_fu_110148_p2 = (icmp_ln1852_1_reg_131830.read() | icmp_ln1852_reg_131825.read());
}

void kernel_correlation_asdse::thread_or_ln1866_fu_110171_p2() {
    or_ln1866_fu_110171_p2 = (icmp_ln1866_1_reg_131840.read() | icmp_ln1866_reg_131835.read());
}

void kernel_correlation_asdse::thread_or_ln1880_fu_110194_p2() {
    or_ln1880_fu_110194_p2 = (icmp_ln1880_1_reg_131850.read() | icmp_ln1880_reg_131845.read());
}

void kernel_correlation_asdse::thread_or_ln1894_fu_110337_p2() {
    or_ln1894_fu_110337_p2 = (icmp_ln1894_1_reg_131860.read() | icmp_ln1894_reg_131855.read());
}

void kernel_correlation_asdse::thread_or_ln1908_fu_110360_p2() {
    or_ln1908_fu_110360_p2 = (icmp_ln1908_1_reg_131870.read() | icmp_ln1908_reg_131865.read());
}

void kernel_correlation_asdse::thread_or_ln1922_fu_110383_p2() {
    or_ln1922_fu_110383_p2 = (icmp_ln1922_1_reg_131880.read() | icmp_ln1922_reg_131875.read());
}

void kernel_correlation_asdse::thread_or_ln1936_fu_110406_p2() {
    or_ln1936_fu_110406_p2 = (icmp_ln1936_1_reg_131890.read() | icmp_ln1936_reg_131885.read());
}

void kernel_correlation_asdse::thread_or_ln1950_fu_110549_p2() {
    or_ln1950_fu_110549_p2 = (icmp_ln1950_1_reg_131900.read() | icmp_ln1950_reg_131895.read());
}

void kernel_correlation_asdse::thread_or_ln1964_fu_110572_p2() {
    or_ln1964_fu_110572_p2 = (icmp_ln1964_1_reg_131910.read() | icmp_ln1964_reg_131905.read());
}

void kernel_correlation_asdse::thread_or_ln1978_fu_110595_p2() {
    or_ln1978_fu_110595_p2 = (icmp_ln1978_1_reg_131920.read() | icmp_ln1978_reg_131915.read());
}

void kernel_correlation_asdse::thread_or_ln1992_fu_110618_p2() {
    or_ln1992_fu_110618_p2 = (icmp_ln1992_1_reg_131930.read() | icmp_ln1992_reg_131925.read());
}

void kernel_correlation_asdse::thread_or_ln2006_fu_110761_p2() {
    or_ln2006_fu_110761_p2 = (icmp_ln2006_1_reg_131940.read() | icmp_ln2006_reg_131935.read());
}

void kernel_correlation_asdse::thread_or_ln2020_fu_110784_p2() {
    or_ln2020_fu_110784_p2 = (icmp_ln2020_1_reg_131950.read() | icmp_ln2020_reg_131945.read());
}

void kernel_correlation_asdse::thread_or_ln2034_fu_110807_p2() {
    or_ln2034_fu_110807_p2 = (icmp_ln2034_1_reg_131960.read() | icmp_ln2034_reg_131955.read());
}

void kernel_correlation_asdse::thread_or_ln2048_fu_110830_p2() {
    or_ln2048_fu_110830_p2 = (icmp_ln2048_1_reg_131970.read() | icmp_ln2048_reg_131965.read());
}

void kernel_correlation_asdse::thread_or_ln2062_fu_110973_p2() {
    or_ln2062_fu_110973_p2 = (icmp_ln2062_1_reg_131980.read() | icmp_ln2062_reg_131975.read());
}

void kernel_correlation_asdse::thread_or_ln2076_fu_110996_p2() {
    or_ln2076_fu_110996_p2 = (icmp_ln2076_1_reg_131990.read() | icmp_ln2076_reg_131985.read());
}

void kernel_correlation_asdse::thread_or_ln2090_fu_111019_p2() {
    or_ln2090_fu_111019_p2 = (icmp_ln2090_1_reg_132000.read() | icmp_ln2090_reg_131995.read());
}

void kernel_correlation_asdse::thread_or_ln2104_fu_111042_p2() {
    or_ln2104_fu_111042_p2 = (icmp_ln2104_1_reg_132010.read() | icmp_ln2104_reg_132005.read());
}

void kernel_correlation_asdse::thread_or_ln2118_fu_111185_p2() {
    or_ln2118_fu_111185_p2 = (icmp_ln2118_1_reg_132044.read() | icmp_ln2118_reg_132039.read());
}

void kernel_correlation_asdse::thread_or_ln2132_fu_111208_p2() {
    or_ln2132_fu_111208_p2 = (icmp_ln2132_1_reg_132054.read() | icmp_ln2132_reg_132049.read());
}

void kernel_correlation_asdse::thread_or_ln2146_fu_111231_p2() {
    or_ln2146_fu_111231_p2 = (icmp_ln2146_1_reg_132064.read() | icmp_ln2146_reg_132059.read());
}

void kernel_correlation_asdse::thread_or_ln2160_fu_111254_p2() {
    or_ln2160_fu_111254_p2 = (icmp_ln2160_1_reg_132074.read() | icmp_ln2160_reg_132069.read());
}

void kernel_correlation_asdse::thread_or_ln2174_fu_111397_p2() {
    or_ln2174_fu_111397_p2 = (icmp_ln2174_1_reg_132084.read() | icmp_ln2174_reg_132079.read());
}

void kernel_correlation_asdse::thread_or_ln2188_fu_111419_p2() {
    or_ln2188_fu_111419_p2 = (icmp_ln2188_1_reg_132094.read() | icmp_ln2188_reg_132089.read());
}

void kernel_correlation_asdse::thread_or_ln2202_fu_111441_p2() {
    or_ln2202_fu_111441_p2 = (icmp_ln2202_1_reg_132104.read() | icmp_ln2202_reg_132099.read());
}

void kernel_correlation_asdse::thread_or_ln2216_fu_111463_p2() {
    or_ln2216_fu_111463_p2 = (icmp_ln2216_1_reg_132114.read() | icmp_ln2216_reg_132109.read());
}

void kernel_correlation_asdse::thread_or_ln2222_1_fu_111648_p2() {
    or_ln2222_1_fu_111648_p2 = (select_ln2222_1_reg_132136.read() | ap_const_lv9_2);
}

void kernel_correlation_asdse::thread_or_ln2222_2_fu_111675_p2() {
    or_ln2222_2_fu_111675_p2 = (select_ln2222_1_reg_132136.read() | ap_const_lv9_3);
}

void kernel_correlation_asdse::thread_or_ln2222_fu_111621_p2() {
    or_ln2222_fu_111621_p2 = (select_ln2222_1_reg_132136.read() | ap_const_lv9_1);
}

void kernel_correlation_asdse::thread_or_ln2868_fu_112426_p2() {
    or_ln2868_fu_112426_p2 = (and_ln2867_fu_112420_p2.read() | icmp_ln2868_fu_112388_p2.read());
}

void kernel_correlation_asdse::thread_or_ln62_fu_104823_p2() {
    or_ln62_fu_104823_p2 = (add_ln54_fu_104811_p2.read() | ap_const_lv8_1);
}

void kernel_correlation_asdse::thread_select_ln1656_1_fu_105688_p3() {
    select_ln1656_1_fu_105688_p3 = (!icmp_ln1657_fu_105648_p2.read()[0].is_01())? sc_lv<8>(): ((icmp_ln1657_fu_105648_p2.read()[0].to_bool())? add_ln1660_1_fu_105682_p2.read(): add_ln1660_fu_105624_p2.read());
}

void kernel_correlation_asdse::thread_select_ln1656_2_fu_105744_p3() {
    select_ln1656_2_fu_105744_p3 = (!icmp_ln1657_fu_105648_p2.read()[0].is_01())? sc_lv<5>(): ((icmp_ln1657_fu_105648_p2.read()[0].to_bool())? v1009_fu_105642_p2.read(): ap_phi_mux_v1009_0_phi_fu_81026_p4.read());
}

void kernel_correlation_asdse::thread_select_ln1656_fu_105654_p3() {
    select_ln1656_fu_105654_p3 = (!icmp_ln1657_fu_105648_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln1657_fu_105648_p2.read()[0].to_bool())? ap_const_lv6_0: ap_phi_mux_v1010_0_phi_fu_81037_p4.read());
}

void kernel_correlation_asdse::thread_select_ln2222_1_fu_111533_p3() {
    select_ln2222_1_fu_111533_p3 = (!icmp_ln2223_fu_111503_p2.read()[0].is_01())? sc_lv<9>(): ((icmp_ln2223_fu_111503_p2.read()[0].to_bool())? shl_ln2226_mid1_fu_111517_p3.read(): shl_ln4_fu_111525_p3.read());
}

void kernel_correlation_asdse::thread_select_ln2222_2_fu_111569_p3() {
    select_ln2222_2_fu_111569_p3 = (!icmp_ln2223_fu_111503_p2.read()[0].is_01())? sc_lv<7>(): ((icmp_ln2223_fu_111503_p2.read()[0].to_bool())? v1452_fu_111497_p2.read(): ap_phi_mux_v1452_0_phi_fu_87139_p4.read());
}

void kernel_correlation_asdse::thread_select_ln2222_fu_111509_p3() {
    select_ln2222_fu_111509_p3 = (!icmp_ln2223_fu_111503_p2.read()[0].is_01())? sc_lv<4>(): ((icmp_ln2223_fu_111503_p2.read()[0].to_bool())? ap_const_lv4_0: ap_phi_mux_v1453_0_phi_fu_87150_p4.read());
}

void kernel_correlation_asdse::thread_select_ln2867_1_fu_112394_p3() {
    select_ln2867_1_fu_112394_p3 = (!icmp_ln2868_fu_112388_p2.read()[0].is_01())? sc_lv<8>(): ((icmp_ln2868_fu_112388_p2.read()[0].to_bool())? v1934_fu_112382_p2.read(): ap_phi_mux_v1934_0_phi_fu_87172_p4.read());
}

void kernel_correlation_asdse::thread_select_ln2867_2_fu_112521_p3() {
    select_ln2867_2_fu_112521_p3 = (!icmp_ln2868_reg_137314.read()[0].is_01())? sc_lv<1>(): ((icmp_ln2868_reg_137314.read()[0].to_bool())? tmp_182_fu_112513_p3.read(): tmp_179_fu_112474_p3.read());
}

void kernel_correlation_asdse::thread_select_ln2867_3_fu_112588_p3() {
    select_ln2867_3_fu_112588_p3 = (!icmp_ln2868_reg_137314_pp3_iter2_reg.read()[0].is_01())? sc_lv<8>(): ((icmp_ln2868_reg_137314_pp3_iter2_reg.read()[0].to_bool())? ap_const_lv8_1: v1935_reg_137390_pp3_iter2_reg.read());
}

void kernel_correlation_asdse::thread_select_ln2867_4_fu_112674_p3() {
    select_ln2867_4_fu_112674_p3 = (!icmp_ln2868_reg_137314_pp3_iter3_reg.read()[0].is_01())? sc_lv<5>(): ((icmp_ln2868_reg_137314_pp3_iter3_reg.read()[0].to_bool())? ap_const_lv5_0: trunc_ln2875_fu_112661_p1.read());
}

void kernel_correlation_asdse::thread_select_ln2867_5_fu_112681_p3() {
    select_ln2867_5_fu_112681_p3 = (!icmp_ln2868_reg_137314_pp3_iter3_reg.read()[0].is_01())? sc_lv<4>(): ((icmp_ln2868_reg_137314_pp3_iter3_reg.read()[0].to_bool())? ap_const_lv4_0: trunc_ln2875_1_fu_112664_p4.read());
}

void kernel_correlation_asdse::thread_select_ln2867_fu_112494_p3() {
    select_ln2867_fu_112494_p3 = (!icmp_ln2868_reg_137314.read()[0].is_01())? sc_lv<8>(): ((icmp_ln2868_reg_137314.read()[0].to_bool())? ap_const_lv8_0: ap_phi_mux_v1935_0_phi_fu_87206_p4.read());
}

void kernel_correlation_asdse::thread_select_ln2868_1_fu_112552_p3() {
    select_ln2868_1_fu_112552_p3 = (!and_ln2867_reg_137334.read()[0].is_01())? sc_lv<1>(): ((and_ln2867_reg_137334.read()[0].to_bool())? tmp_183_fu_112544_p3.read(): select_ln2867_2_fu_112521_p3.read());
}

void kernel_correlation_asdse::thread_select_ln2868_2_fu_112599_p3() {
    select_ln2868_2_fu_112599_p3 = (!and_ln2867_reg_137334_pp3_iter2_reg.read()[0].is_01())? sc_lv<8>(): ((and_ln2867_reg_137334_pp3_iter2_reg.read()[0].to_bool())? add_ln2873_1_fu_112594_p2.read(): select_ln2867_3_fu_112588_p3.read());
}

void kernel_correlation_asdse::thread_select_ln2868_3_fu_112692_p3() {
    select_ln2868_3_fu_112692_p3 = (!and_ln2867_reg_137334_pp3_iter3_reg.read()[0].is_01())? sc_lv<5>(): ((and_ln2867_reg_137334_pp3_iter3_reg.read()[0].to_bool())? trunc_ln2875_2_fu_112688_p1.read(): select_ln2867_4_fu_112674_p3.read());
}

void kernel_correlation_asdse::thread_select_ln2868_4_fu_112708_p3() {
    select_ln2868_4_fu_112708_p3 = (!and_ln2867_reg_137334_pp3_iter3_reg.read()[0].is_01())? sc_lv<4>(): ((and_ln2867_reg_137334_pp3_iter3_reg.read()[0].to_bool())? trunc_ln2875_1_mid1_fu_112699_p4.read(): select_ln2867_5_fu_112681_p3.read());
}

void kernel_correlation_asdse::thread_select_ln2868_5_fu_112564_p3() {
    select_ln2868_5_fu_112564_p3 = (!and_ln2867_reg_137334.read()[0].is_01())? sc_lv<8>(): ((and_ln2867_reg_137334.read()[0].to_bool())? add_ln2873_reg_137402.read(): select_ln2867_reg_137396.read());
}

void kernel_correlation_asdse::thread_select_ln2868_6_fu_112452_p3() {
    select_ln2868_6_fu_112452_p3 = (!icmp_ln2868_fu_112388_p2.read()[0].is_01())? sc_lv<11>(): ((icmp_ln2868_fu_112388_p2.read()[0].to_bool())? ap_const_lv11_1: add_ln2868_fu_112446_p2.read());
}

void kernel_correlation_asdse::thread_select_ln2868_fu_112432_p3() {
    select_ln2868_fu_112432_p3 = (!or_ln2868_fu_112426_p2.read()[0].is_01())? sc_lv<3>(): ((or_ln2868_fu_112426_p2.read()[0].to_bool())? ap_const_lv3_0: ap_phi_mux_v1936_0_phi_fu_87195_p4.read());
}

void kernel_correlation_asdse::thread_select_ln51_1_fu_104747_p3() {
    select_ln51_1_fu_104747_p3 = (!icmp_ln52_fu_104707_p2.read()[0].is_01())? sc_lv<8>(): ((icmp_ln52_fu_104707_p2.read()[0].to_bool())? add_ln55_1_fu_104741_p2.read(): add_ln55_fu_104683_p2.read());
}

void kernel_correlation_asdse::thread_select_ln51_2_fu_104783_p3() {
    select_ln51_2_fu_104783_p3 = (!icmp_ln52_fu_104707_p2.read()[0].is_01())? sc_lv<4>(): ((icmp_ln52_fu_104707_p2.read()[0].to_bool())? v7_fu_104701_p2.read(): v7_0_reg_80409.read());
}

void kernel_correlation_asdse::thread_select_ln51_fu_104713_p3() {
    select_ln51_fu_104713_p3 = (!icmp_ln52_fu_104707_p2.read()[0].is_01())? sc_lv<5>(): ((icmp_ln52_fu_104707_p2.read()[0].to_bool())? ap_const_lv5_0: v8_0_reg_80420.read());
}

void kernel_correlation_asdse::thread_sext_ln102_fu_105568_p1() {
    sext_ln102_fu_105568_p1 = esl_sext<8,5>(tmp_132_reg_112998_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln110_fu_105577_p1() {
    sext_ln110_fu_105577_p1 = esl_sext<8,5>(tmp_133_reg_113004_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln118_fu_105586_p1() {
    sext_ln118_fu_105586_p1 = esl_sext<8,5>(tmp_134_reg_113010_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln126_fu_105595_p1() {
    sext_ln126_fu_105595_p1 = esl_sext<8,5>(tmp_135_reg_113016_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln1575_1_fu_105108_p1() {
    sext_ln1575_1_fu_105108_p1 = esl_sext<7,5>(tmp_126_reg_112968.read());
}

void kernel_correlation_asdse::thread_sext_ln1575_2_fu_105117_p1() {
    sext_ln1575_2_fu_105117_p1 = esl_sext<64,7>(add_ln1575_fu_105111_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1575_fu_105094_p1() {
    sext_ln1575_fu_105094_p1 = esl_sext<7,6>(tmp_125_fu_105087_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln1583_1_fu_105160_p1() {
    sext_ln1583_1_fu_105160_p1 = esl_sext<64,7>(add_ln1583_fu_105154_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1583_fu_105151_p1() {
    sext_ln1583_fu_105151_p1 = esl_sext<7,5>(tmp_127_reg_112957_pp0_iter10_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln1591_1_fu_105199_p1() {
    sext_ln1591_1_fu_105199_p1 = esl_sext<64,7>(add_ln1591_fu_105193_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1591_fu_105190_p1() {
    sext_ln1591_fu_105190_p1 = esl_sext<7,5>(tmp_128_reg_112974.read());
}

void kernel_correlation_asdse::thread_sext_ln1599_1_fu_105238_p1() {
    sext_ln1599_1_fu_105238_p1 = esl_sext<64,7>(add_ln1599_fu_105232_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1599_fu_105229_p1() {
    sext_ln1599_fu_105229_p1 = esl_sext<7,5>(tmp_129_reg_112980.read());
}

void kernel_correlation_asdse::thread_sext_ln1607_1_fu_105277_p1() {
    sext_ln1607_1_fu_105277_p1 = esl_sext<64,7>(add_ln1607_fu_105271_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1607_fu_105268_p1() {
    sext_ln1607_fu_105268_p1 = esl_sext<7,5>(tmp_130_reg_112986.read());
}

void kernel_correlation_asdse::thread_sext_ln1615_1_fu_105316_p1() {
    sext_ln1615_1_fu_105316_p1 = esl_sext<64,7>(add_ln1615_fu_105310_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1615_fu_105307_p1() {
    sext_ln1615_fu_105307_p1 = esl_sext<7,5>(tmp_131_reg_112992.read());
}

void kernel_correlation_asdse::thread_sext_ln1623_1_fu_105355_p1() {
    sext_ln1623_1_fu_105355_p1 = esl_sext<64,7>(add_ln1623_fu_105349_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1623_fu_105346_p1() {
    sext_ln1623_fu_105346_p1 = esl_sext<7,5>(tmp_132_reg_112998.read());
}

void kernel_correlation_asdse::thread_sext_ln1631_1_fu_105394_p1() {
    sext_ln1631_1_fu_105394_p1 = esl_sext<64,7>(add_ln1631_fu_105388_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1631_fu_105385_p1() {
    sext_ln1631_fu_105385_p1 = esl_sext<7,5>(tmp_133_reg_113004.read());
}

void kernel_correlation_asdse::thread_sext_ln1639_1_fu_105433_p1() {
    sext_ln1639_1_fu_105433_p1 = esl_sext<64,7>(add_ln1639_fu_105427_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1639_fu_105424_p1() {
    sext_ln1639_fu_105424_p1 = esl_sext<7,5>(tmp_134_reg_113010.read());
}

void kernel_correlation_asdse::thread_sext_ln1647_1_fu_105472_p1() {
    sext_ln1647_1_fu_105472_p1 = esl_sext<64,7>(add_ln1647_fu_105466_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1647_fu_105463_p1() {
    sext_ln1647_fu_105463_p1 = esl_sext<7,5>(tmp_135_reg_113016.read());
}

void kernel_correlation_asdse::thread_sext_ln1659_fu_106293_p1() {
    sext_ln1659_fu_106293_p1 = esl_sext<8,5>(tmp_166_reg_114477.read());
}

void kernel_correlation_asdse::thread_sext_ln1660_1_fu_106310_p1() {
    sext_ln1660_1_fu_106310_p1 = esl_sext<7,5>(tmp_166_reg_114477.read());
}

void kernel_correlation_asdse::thread_sext_ln1660_2_fu_106319_p1() {
    sext_ln1660_2_fu_106319_p1 = esl_sext<64,7>(add_ln1660_2_fu_106313_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1660_fu_106063_p1() {
    sext_ln1660_fu_106063_p1 = esl_sext<7,5>(tmp_138_fu_106056_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln1673_fu_106994_p1() {
    sext_ln1673_fu_106994_p1 = esl_sext<8,5>(tmp_186_reg_114493.read());
}

void kernel_correlation_asdse::thread_sext_ln1674_1_fu_107020_p1() {
    sext_ln1674_1_fu_107020_p1 = esl_sext<64,7>(add_ln1674_fu_107014_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1674_fu_107011_p1() {
    sext_ln1674_fu_107011_p1 = esl_sext<7,5>(tmp_186_reg_114493.read());
}

void kernel_correlation_asdse::thread_sext_ln1687_fu_107695_p1() {
    sext_ln1687_fu_107695_p1 = esl_sext<8,5>(tmp_187_reg_114499.read());
}

void kernel_correlation_asdse::thread_sext_ln1688_1_fu_107721_p1() {
    sext_ln1688_1_fu_107721_p1 = esl_sext<64,7>(add_ln1688_fu_107715_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1688_fu_107712_p1() {
    sext_ln1688_fu_107712_p1 = esl_sext<7,5>(tmp_187_reg_114499.read());
}

void kernel_correlation_asdse::thread_sext_ln1701_fu_108396_p1() {
    sext_ln1701_fu_108396_p1 = esl_sext<8,5>(tmp_188_reg_114505.read());
}

void kernel_correlation_asdse::thread_sext_ln1702_1_fu_108422_p1() {
    sext_ln1702_1_fu_108422_p1 = esl_sext<64,7>(add_ln1702_fu_108416_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1702_fu_108413_p1() {
    sext_ln1702_fu_108413_p1 = esl_sext<7,5>(tmp_188_reg_114505.read());
}

void kernel_correlation_asdse::thread_sext_ln1716_1_fu_109097_p1() {
    sext_ln1716_1_fu_109097_p1 = esl_sext<64,7>(add_ln1716_reg_114593.read());
}

void kernel_correlation_asdse::thread_sext_ln1716_fu_106087_p1() {
    sext_ln1716_fu_106087_p1 = esl_sext<7,5>(tmp_141_fu_106080_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln1730_fu_109165_p1() {
    sext_ln1730_fu_109165_p1 = esl_sext<64,7>(add_ln1730_reg_117573.read());
}

void kernel_correlation_asdse::thread_sext_ln1744_fu_109233_p1() {
    sext_ln1744_fu_109233_p1 = esl_sext<64,7>(add_ln1744_reg_120553.read());
}

void kernel_correlation_asdse::thread_sext_ln1758_fu_109301_p1() {
    sext_ln1758_fu_109301_p1 = esl_sext<64,7>(add_ln1758_reg_123533.read());
}

void kernel_correlation_asdse::thread_sext_ln1772_1_fu_106550_p1() {
    sext_ln1772_1_fu_106550_p1 = esl_sext<64,7>(add_ln1772_fu_106544_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1772_fu_106111_p1() {
    sext_ln1772_fu_106111_p1 = esl_sext<7,5>(tmp_144_fu_106104_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln1786_fu_107251_p1() {
    sext_ln1786_fu_107251_p1 = esl_sext<64,7>(add_ln1786_fu_107245_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1800_fu_107952_p1() {
    sext_ln1800_fu_107952_p1 = esl_sext<64,7>(add_ln1800_fu_107946_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1814_fu_108653_p1() {
    sext_ln1814_fu_108653_p1 = esl_sext<64,7>(add_ln1814_fu_108647_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1828_1_fu_106700_p1() {
    sext_ln1828_1_fu_106700_p1 = esl_sext<64,7>(add_ln1828_fu_106694_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1828_fu_106135_p1() {
    sext_ln1828_fu_106135_p1 = esl_sext<7,5>(tmp_147_fu_106128_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln1842_fu_107401_p1() {
    sext_ln1842_fu_107401_p1 = esl_sext<64,7>(add_ln1842_fu_107395_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1856_fu_108102_p1() {
    sext_ln1856_fu_108102_p1 = esl_sext<64,7>(add_ln1856_fu_108096_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1870_fu_108803_p1() {
    sext_ln1870_fu_108803_p1 = esl_sext<64,7>(add_ln1870_fu_108797_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1884_1_fu_106850_p1() {
    sext_ln1884_1_fu_106850_p1 = esl_sext<64,7>(add_ln1884_fu_106844_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1884_fu_106159_p1() {
    sext_ln1884_fu_106159_p1 = esl_sext<7,5>(tmp_150_fu_106152_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln1898_fu_107551_p1() {
    sext_ln1898_fu_107551_p1 = esl_sext<64,7>(add_ln1898_fu_107545_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1912_fu_108252_p1() {
    sext_ln1912_fu_108252_p1 = esl_sext<64,7>(add_ln1912_fu_108246_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1926_fu_108953_p1() {
    sext_ln1926_fu_108953_p1 = esl_sext<64,7>(add_ln1926_fu_108947_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1940_1_fu_106394_p1() {
    sext_ln1940_1_fu_106394_p1 = esl_sext<64,7>(add_ln1940_fu_106388_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1940_fu_106183_p1() {
    sext_ln1940_fu_106183_p1 = esl_sext<7,5>(tmp_153_fu_106176_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln1954_fu_107095_p1() {
    sext_ln1954_fu_107095_p1 = esl_sext<64,7>(add_ln1954_fu_107089_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1968_fu_107796_p1() {
    sext_ln1968_fu_107796_p1 = esl_sext<64,7>(add_ln1968_fu_107790_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1982_fu_108497_p1() {
    sext_ln1982_fu_108497_p1 = esl_sext<64,7>(add_ln1982_fu_108491_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1996_1_fu_106475_p1() {
    sext_ln1996_1_fu_106475_p1 = esl_sext<64,7>(add_ln1996_fu_106469_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln1996_fu_106207_p1() {
    sext_ln1996_fu_106207_p1 = esl_sext<7,6>(tmp_156_fu_106200_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln2010_fu_107176_p1() {
    sext_ln2010_fu_107176_p1 = esl_sext<64,7>(add_ln2010_fu_107170_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2024_fu_107877_p1() {
    sext_ln2024_fu_107877_p1 = esl_sext<64,7>(add_ln2024_fu_107871_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2038_fu_108578_p1() {
    sext_ln2038_fu_108578_p1 = esl_sext<64,7>(add_ln2038_fu_108572_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2052_1_fu_106625_p1() {
    sext_ln2052_1_fu_106625_p1 = esl_sext<64,7>(add_ln2052_fu_106619_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2052_fu_106231_p1() {
    sext_ln2052_fu_106231_p1 = esl_sext<7,6>(tmp_159_fu_106224_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln2066_fu_107326_p1() {
    sext_ln2066_fu_107326_p1 = esl_sext<64,7>(add_ln2066_fu_107320_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2080_fu_108027_p1() {
    sext_ln2080_fu_108027_p1 = esl_sext<64,7>(add_ln2080_fu_108021_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2094_fu_108728_p1() {
    sext_ln2094_fu_108728_p1 = esl_sext<64,7>(add_ln2094_fu_108722_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2108_1_fu_106775_p1() {
    sext_ln2108_1_fu_106775_p1 = esl_sext<64,7>(add_ln2108_fu_106769_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2108_fu_106255_p1() {
    sext_ln2108_fu_106255_p1 = esl_sext<7,6>(tmp_162_fu_106248_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln2122_fu_107476_p1() {
    sext_ln2122_fu_107476_p1 = esl_sext<64,7>(add_ln2122_fu_107470_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2136_fu_108177_p1() {
    sext_ln2136_fu_108177_p1 = esl_sext<64,7>(add_ln2136_fu_108171_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2150_fu_108878_p1() {
    sext_ln2150_fu_108878_p1 = esl_sext<64,7>(add_ln2150_fu_108872_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2164_1_fu_106925_p1() {
    sext_ln2164_1_fu_106925_p1 = esl_sext<64,7>(add_ln2164_fu_106919_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2164_fu_106279_p1() {
    sext_ln2164_fu_106279_p1 = esl_sext<7,6>(tmp_165_fu_106272_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln2178_fu_107626_p1() {
    sext_ln2178_fu_107626_p1 = esl_sext<64,7>(add_ln2178_fu_107620_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2192_fu_108327_p1() {
    sext_ln2192_fu_108327_p1 = esl_sext<64,7>(add_ln2192_fu_108321_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2206_fu_109028_p1() {
    sext_ln2206_fu_109028_p1 = esl_sext<64,7>(add_ln2206_fu_109022_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2226_1_fu_111745_p1() {
    sext_ln2226_1_fu_111745_p1 = esl_sext<64,7>(add_ln2226_fu_111739_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2226_fu_111726_p1() {
    sext_ln2226_fu_111726_p1 = esl_sext<7,6>(tmp_169_fu_111719_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln2386_1_fu_111966_p1() {
    sext_ln2386_1_fu_111966_p1 = esl_sext<64,7>(add_ln2386_reg_133758.read());
}

void kernel_correlation_asdse::thread_sext_ln2386_fu_111893_p1() {
    sext_ln2386_fu_111893_p1 = esl_sext<7,6>(tmp_172_fu_111886_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln2546_1_fu_112099_p1() {
    sext_ln2546_1_fu_112099_p1 = esl_sext<64,7>(add_ln2546_reg_133763.read());
}

void kernel_correlation_asdse::thread_sext_ln2546_fu_111917_p1() {
    sext_ln2546_fu_111917_p1 = esl_sext<7,6>(tmp_175_fu_111910_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln2706_1_fu_112237_p1() {
    sext_ln2706_1_fu_112237_p1 = esl_sext<64,7>(add_ln2706_reg_133768.read());
}

void kernel_correlation_asdse::thread_sext_ln2706_fu_111941_p1() {
    sext_ln2706_fu_111941_p1 = esl_sext<7,6>(tmp_178_fu_111934_p3.read());
}

void kernel_correlation_asdse::thread_sext_ln2872_fu_112752_p1() {
    sext_ln2872_fu_112752_p1 = esl_sext<64,17>(add_ln2872_fu_112746_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln2873_fu_112766_p1() {
    sext_ln2873_fu_112766_p1 = esl_sext<64,17>(add_ln2873_2_fu_112760_p2.read());
}

void kernel_correlation_asdse::thread_sext_ln54_fu_105514_p1() {
    sext_ln54_fu_105514_p1 = esl_sext<8,5>(tmp_126_reg_112968_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln62_fu_105523_p1() {
    sext_ln62_fu_105523_p1 = esl_sext<8,5>(tmp_127_reg_112957_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln70_fu_105532_p1() {
    sext_ln70_fu_105532_p1 = esl_sext<8,5>(tmp_128_reg_112974_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln78_fu_105541_p1() {
    sext_ln78_fu_105541_p1 = esl_sext<8,5>(tmp_129_reg_112980_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln86_fu_105550_p1() {
    sext_ln86_fu_105550_p1 = esl_sext<8,5>(tmp_130_reg_112986_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_sext_ln94_fu_105559_p1() {
    sext_ln94_fu_105559_p1 = esl_sext<8,5>(tmp_131_reg_112992_pp0_iter28_reg.read());
}

void kernel_correlation_asdse::thread_shl_ln1660_1_fu_105612_p3() {
    shl_ln1660_1_fu_105612_p3 = esl_concat<5,1>(ap_phi_mux_v1009_0_phi_fu_81026_p4.read(), ap_const_lv1_0);
}

void kernel_correlation_asdse::thread_shl_ln1660_1_mid1_fu_105670_p3() {
    shl_ln1660_1_mid1_fu_105670_p3 = esl_concat<5,1>(v1009_fu_105642_p2.read(), ap_const_lv1_0);
}

void kernel_correlation_asdse::thread_shl_ln1660_mid1_fu_105662_p3() {
    shl_ln1660_mid1_fu_105662_p3 = esl_concat<5,3>(v1009_fu_105642_p2.read(), ap_const_lv3_0);
}

void kernel_correlation_asdse::thread_shl_ln1_fu_104791_p3() {
    shl_ln1_fu_104791_p3 = esl_concat<5,3>(select_ln51_fu_104713_p3.read(), ap_const_lv3_0);
}

void kernel_correlation_asdse::thread_shl_ln2226_mid1_fu_111517_p3() {
    shl_ln2226_mid1_fu_111517_p3 = esl_concat<7,2>(v1452_fu_111497_p2.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_shl_ln2_fu_105604_p3() {
    shl_ln2_fu_105604_p3 = esl_concat<5,3>(ap_phi_mux_v1009_0_phi_fu_81026_p4.read(), ap_const_lv3_0);
}

void kernel_correlation_asdse::thread_shl_ln3_fu_105801_p3() {
    shl_ln3_fu_105801_p3 = esl_concat<6,2>(select_ln1656_reg_114389.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_shl_ln4_fu_111525_p3() {
    shl_ln4_fu_111525_p3 = esl_concat<7,2>(ap_phi_mux_v1452_0_phi_fu_87139_p4.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_shl_ln54_1_fu_104799_p3() {
    shl_ln54_1_fu_104799_p3 = esl_concat<5,1>(select_ln51_fu_104713_p3.read(), ap_const_lv1_0);
}

void kernel_correlation_asdse::thread_shl_ln55_1_fu_104671_p3() {
    shl_ln55_1_fu_104671_p3 = esl_concat<4,2>(v7_0_reg_80409.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_shl_ln55_1_mid1_fu_104729_p3() {
    shl_ln55_1_mid1_fu_104729_p3 = esl_concat<4,2>(v7_fu_104701_p2.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_shl_ln55_mid1_fu_104721_p3() {
    shl_ln55_mid1_fu_104721_p3 = esl_concat<4,4>(v7_fu_104701_p2.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_shl_ln_fu_104663_p3() {
    shl_ln_fu_104663_p3 = esl_concat<4,4>(v7_0_reg_80409.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_sub_ln1575_fu_105098_p2() {
    sub_ln1575_fu_105098_p2 = (!zext_ln1575_cast_fu_105080_p3.read().is_01() || !sext_ln1575_fu_105094_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln1575_cast_fu_105080_p3.read()) - sc_bigint<7>(sext_ln1575_fu_105094_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln1660_fu_106067_p2() {
    sub_ln1660_fu_106067_p2 = (!tmp_137_fu_106049_p3.read().is_01() || !sext_ln1660_fu_106063_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(tmp_137_fu_106049_p3.read()) - sc_bigint<7>(sext_ln1660_fu_106063_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln1716_fu_106091_p2() {
    sub_ln1716_fu_106091_p2 = (!tmp_140_fu_106073_p3.read().is_01() || !sext_ln1716_fu_106087_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(tmp_140_fu_106073_p3.read()) - sc_bigint<7>(sext_ln1716_fu_106087_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln1772_fu_106115_p2() {
    sub_ln1772_fu_106115_p2 = (!tmp_143_fu_106097_p3.read().is_01() || !sext_ln1772_fu_106111_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(tmp_143_fu_106097_p3.read()) - sc_bigint<7>(sext_ln1772_fu_106111_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln1828_fu_106139_p2() {
    sub_ln1828_fu_106139_p2 = (!tmp_146_fu_106121_p3.read().is_01() || !sext_ln1828_fu_106135_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(tmp_146_fu_106121_p3.read()) - sc_bigint<7>(sext_ln1828_fu_106135_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln1884_fu_106163_p2() {
    sub_ln1884_fu_106163_p2 = (!tmp_149_fu_106145_p3.read().is_01() || !sext_ln1884_fu_106159_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(tmp_149_fu_106145_p3.read()) - sc_bigint<7>(sext_ln1884_fu_106159_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln1940_fu_106187_p2() {
    sub_ln1940_fu_106187_p2 = (!tmp_152_fu_106169_p3.read().is_01() || !sext_ln1940_fu_106183_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(tmp_152_fu_106169_p3.read()) - sc_bigint<7>(sext_ln1940_fu_106183_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln1996_fu_106211_p2() {
    sub_ln1996_fu_106211_p2 = (!zext_ln1996_cast_fu_106193_p3.read().is_01() || !sext_ln1996_fu_106207_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln1996_cast_fu_106193_p3.read()) - sc_bigint<7>(sext_ln1996_fu_106207_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2052_fu_106235_p2() {
    sub_ln2052_fu_106235_p2 = (!zext_ln2052_cast_fu_106217_p3.read().is_01() || !sext_ln2052_fu_106231_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln2052_cast_fu_106217_p3.read()) - sc_bigint<7>(sext_ln2052_fu_106231_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2108_fu_106259_p2() {
    sub_ln2108_fu_106259_p2 = (!zext_ln2108_cast_fu_106241_p3.read().is_01() || !sext_ln2108_fu_106255_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln2108_cast_fu_106241_p3.read()) - sc_bigint<7>(sext_ln2108_fu_106255_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2164_fu_106283_p2() {
    sub_ln2164_fu_106283_p2 = (!zext_ln2164_cast_fu_106265_p3.read().is_01() || !sext_ln2164_fu_106279_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln2164_cast_fu_106265_p3.read()) - sc_bigint<7>(sext_ln2164_fu_106279_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2226_fu_111730_p2() {
    sub_ln2226_fu_111730_p2 = (!zext_ln2226_cast_fu_111712_p3.read().is_01() || !sext_ln2226_fu_111726_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln2226_cast_fu_111712_p3.read()) - sc_bigint<7>(sext_ln2226_fu_111726_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2386_fu_111897_p2() {
    sub_ln2386_fu_111897_p2 = (!zext_ln2386_cast_fu_111879_p3.read().is_01() || !sext_ln2386_fu_111893_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln2386_cast_fu_111879_p3.read()) - sc_bigint<7>(sext_ln2386_fu_111893_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2546_fu_111921_p2() {
    sub_ln2546_fu_111921_p2 = (!zext_ln2546_cast_fu_111903_p3.read().is_01() || !sext_ln2546_fu_111917_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln2546_cast_fu_111903_p3.read()) - sc_bigint<7>(sext_ln2546_fu_111917_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2706_fu_111945_p2() {
    sub_ln2706_fu_111945_p2 = (!zext_ln2706_cast_fu_111927_p3.read().is_01() || !sext_ln2706_fu_111941_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln2706_cast_fu_111927_p3.read()) - sc_bigint<7>(sext_ln2706_fu_111941_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2871_1_fu_112507_p2() {
    sub_ln2871_1_fu_112507_p2 = (!ap_const_lv9_0.is_01() || !zext_ln2867_1_fu_112501_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(ap_const_lv9_0) - sc_biguint<9>(zext_ln2867_1_fu_112501_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2871_2_fu_112538_p2() {
    sub_ln2871_2_fu_112538_p2 = (!zext_ln2868_1_fu_112534_p1.read().is_01() || !zext_ln2867_2_fu_112504_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln2868_1_fu_112534_p1.read()) - sc_biguint<9>(zext_ln2867_2_fu_112504_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2871_fu_112468_p2() {
    sub_ln2871_fu_112468_p2 = (!zext_ln2868_fu_112464_p1.read().is_01() || !zext_ln2867_fu_112460_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln2868_fu_112464_p1.read()) - sc_biguint<9>(zext_ln2867_fu_112460_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2872_fu_112740_p2() {
    sub_ln2872_fu_112740_p2 = (!zext_ln2872_1_fu_112725_p1.read().is_01() || !zext_ln2872_2_fu_112736_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(zext_ln2872_1_fu_112725_p1.read()) - sc_biguint<17>(zext_ln2872_2_fu_112736_p1.read()));
}

void kernel_correlation_asdse::thread_sub_ln2881_fu_112793_p2() {
    sub_ln2881_fu_112793_p2 = (!zext_ln2881_fu_112778_p1.read().is_01() || !zext_ln2881_1_fu_112789_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(zext_ln2881_fu_112778_p1.read()) - sc_biguint<17>(zext_ln2881_1_fu_112789_p1.read()));
}

void kernel_correlation_asdse::thread_tmp_101_fu_110887_p4() {
    tmp_101_fu_110887_p4 = bitcast_ln2076_fu_110883_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_103_fu_110917_p4() {
    tmp_103_fu_110917_p4 = bitcast_ln2090_fu_110913_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_105_fu_110947_p4() {
    tmp_105_fu_110947_p4 = bitcast_ln2104_fu_110943_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_107_fu_111069_p4() {
    tmp_107_fu_111069_p4 = bitcast_ln2118_fu_111065_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_109_fu_111099_p4() {
    tmp_109_fu_111099_p4 = bitcast_ln2132_fu_111095_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_111_fu_111129_p4() {
    tmp_111_fu_111129_p4 = bitcast_ln2146_fu_111125_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_113_fu_111159_p4() {
    tmp_113_fu_111159_p4 = bitcast_ln2160_fu_111155_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_115_fu_111281_p4() {
    tmp_115_fu_111281_p4 = bitcast_ln2174_fu_111277_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_117_fu_111311_p4() {
    tmp_117_fu_111311_p4 = bitcast_ln2188_fu_111307_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_119_fu_111341_p4() {
    tmp_119_fu_111341_p4 = bitcast_ln2202_fu_111337_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_121_fu_111371_p4() {
    tmp_121_fu_111371_p4 = bitcast_ln2216_fu_111367_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_125_fu_105087_p3() {
    tmp_125_fu_105087_p3 = esl_concat<4,2>(tmp_123_reg_112923_pp0_iter10_reg.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_137_fu_106049_p3() {
    tmp_137_fu_106049_p3 = esl_concat<3,4>(tmp_136_reg_114404_pp1_iter1_reg.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_tmp_138_fu_106056_p3() {
    tmp_138_fu_106056_p3 = esl_concat<3,2>(tmp_136_reg_114404_pp1_iter1_reg.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_140_fu_106073_p3() {
    tmp_140_fu_106073_p3 = esl_concat<3,4>(tmp_139_reg_114442_pp1_iter1_reg.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_tmp_141_fu_106080_p3() {
    tmp_141_fu_106080_p3 = esl_concat<3,2>(tmp_139_reg_114442_pp1_iter1_reg.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_143_fu_106097_p3() {
    tmp_143_fu_106097_p3 = esl_concat<3,4>(tmp_142_reg_114511.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_tmp_144_fu_106104_p3() {
    tmp_144_fu_106104_p3 = esl_concat<3,2>(tmp_142_reg_114511.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_146_fu_106121_p3() {
    tmp_146_fu_106121_p3 = esl_concat<3,4>(tmp_145_reg_114517.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_tmp_147_fu_106128_p3() {
    tmp_147_fu_106128_p3 = esl_concat<3,2>(tmp_145_reg_114517.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_149_fu_106145_p3() {
    tmp_149_fu_106145_p3 = esl_concat<3,4>(tmp_148_reg_114523.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_tmp_150_fu_106152_p3() {
    tmp_150_fu_106152_p3 = esl_concat<3,2>(tmp_148_reg_114523.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_152_fu_106169_p3() {
    tmp_152_fu_106169_p3 = esl_concat<3,4>(tmp_151_reg_114529.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_tmp_153_fu_106176_p3() {
    tmp_153_fu_106176_p3 = esl_concat<3,2>(tmp_151_reg_114529.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_156_fu_106200_p3() {
    tmp_156_fu_106200_p3 = esl_concat<4,2>(tmp_154_reg_114417_pp1_iter1_reg.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_159_fu_106224_p3() {
    tmp_159_fu_106224_p3 = esl_concat<4,2>(tmp_157_reg_114448_pp1_iter1_reg.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_162_fu_106248_p3() {
    tmp_162_fu_106248_p3 = esl_concat<4,2>(tmp_160_reg_114467.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_165_fu_106272_p3() {
    tmp_165_fu_106272_p3 = esl_concat<4,2>(tmp_163_reg_114483.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_169_fu_111719_p3() {
    tmp_169_fu_111719_p3 = esl_concat<4,2>(tmp_167_reg_132144.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_172_fu_111886_p3() {
    tmp_172_fu_111886_p3 = esl_concat<4,2>(tmp_170_reg_132361.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_175_fu_111910_p3() {
    tmp_175_fu_111910_p3 = esl_concat<4,2>(tmp_173_reg_132473.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_178_fu_111934_p3() {
    tmp_178_fu_111934_p3 = esl_concat<4,2>(tmp_176_reg_132485.read(), ap_const_lv2_0);
}

void kernel_correlation_asdse::thread_tmp_179_fu_112474_p3() {
    tmp_179_fu_112474_p3 = sub_ln2871_fu_112468_p2.read().range(8, 8);
}

void kernel_correlation_asdse::thread_tmp_180_fu_112718_p3() {
    tmp_180_fu_112718_p3 = esl_concat<8,8>(select_ln2867_1_reg_137323_pp3_iter5_reg.read(), ap_const_lv8_0);
}

void kernel_correlation_asdse::thread_tmp_181_fu_112729_p3() {
    tmp_181_fu_112729_p3 = esl_concat<8,4>(select_ln2867_1_reg_137323_pp3_iter5_reg.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_tmp_182_fu_112513_p3() {
    tmp_182_fu_112513_p3 = sub_ln2871_1_fu_112507_p2.read().range(8, 8);
}

void kernel_correlation_asdse::thread_tmp_183_fu_112544_p3() {
    tmp_183_fu_112544_p3 = sub_ln2871_2_fu_112538_p2.read().range(8, 8);
}

void kernel_correlation_asdse::thread_tmp_184_fu_112771_p3() {
    tmp_184_fu_112771_p3 = esl_concat<8,8>(select_ln2868_2_reg_137454_pp3_iter4_reg.read(), ap_const_lv8_0);
}

void kernel_correlation_asdse::thread_tmp_185_fu_112782_p3() {
    tmp_185_fu_112782_p3 = esl_concat<8,4>(select_ln2868_2_reg_137454_pp3_iter4_reg.read(), ap_const_lv4_0);
}

void kernel_correlation_asdse::thread_tmp_43_fu_109373_p4() {
    tmp_43_fu_109373_p4 = bitcast_ln1670_fu_109369_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_45_fu_109403_p4() {
    tmp_45_fu_109403_p4 = bitcast_ln1684_fu_109399_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_47_fu_109433_p4() {
    tmp_47_fu_109433_p4 = bitcast_ln1698_fu_109429_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_49_fu_109463_p4() {
    tmp_49_fu_109463_p4 = bitcast_ln1712_fu_109459_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_51_fu_109585_p4() {
    tmp_51_fu_109585_p4 = bitcast_ln1726_fu_109581_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_53_fu_109615_p4() {
    tmp_53_fu_109615_p4 = bitcast_ln1740_fu_109611_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_55_fu_109645_p4() {
    tmp_55_fu_109645_p4 = bitcast_ln1754_fu_109641_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_57_fu_109675_p4() {
    tmp_57_fu_109675_p4 = bitcast_ln1768_fu_109671_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_59_fu_109797_p4() {
    tmp_59_fu_109797_p4 = bitcast_ln1782_fu_109793_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_61_fu_109827_p4() {
    tmp_61_fu_109827_p4 = bitcast_ln1796_fu_109823_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_63_fu_109857_p4() {
    tmp_63_fu_109857_p4 = bitcast_ln1810_fu_109853_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_65_fu_109887_p4() {
    tmp_65_fu_109887_p4 = bitcast_ln1824_fu_109883_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_67_fu_110009_p4() {
    tmp_67_fu_110009_p4 = bitcast_ln1838_fu_110005_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_69_fu_110039_p4() {
    tmp_69_fu_110039_p4 = bitcast_ln1852_fu_110035_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_71_fu_110069_p4() {
    tmp_71_fu_110069_p4 = bitcast_ln1866_fu_110065_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_73_fu_110099_p4() {
    tmp_73_fu_110099_p4 = bitcast_ln1880_fu_110095_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_75_fu_110221_p4() {
    tmp_75_fu_110221_p4 = bitcast_ln1894_fu_110217_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_77_fu_110251_p4() {
    tmp_77_fu_110251_p4 = bitcast_ln1908_fu_110247_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_79_fu_110281_p4() {
    tmp_79_fu_110281_p4 = bitcast_ln1922_fu_110277_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_81_fu_110311_p4() {
    tmp_81_fu_110311_p4 = bitcast_ln1936_fu_110307_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_83_fu_110433_p4() {
    tmp_83_fu_110433_p4 = bitcast_ln1950_fu_110429_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_85_fu_110463_p4() {
    tmp_85_fu_110463_p4 = bitcast_ln1964_fu_110459_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_87_fu_110493_p4() {
    tmp_87_fu_110493_p4 = bitcast_ln1978_fu_110489_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_89_fu_110523_p4() {
    tmp_89_fu_110523_p4 = bitcast_ln1992_fu_110519_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_91_fu_110645_p4() {
    tmp_91_fu_110645_p4 = bitcast_ln2006_fu_110641_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_93_fu_110675_p4() {
    tmp_93_fu_110675_p4 = bitcast_ln2020_fu_110671_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_95_fu_110705_p4() {
    tmp_95_fu_110705_p4 = bitcast_ln2034_fu_110701_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_97_fu_110735_p4() {
    tmp_97_fu_110735_p4 = bitcast_ln2048_fu_110731_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_tmp_99_fu_110857_p4() {
    tmp_99_fu_110857_p4 = bitcast_ln2062_fu_110853_p1.read().range(62, 52);
}

void kernel_correlation_asdse::thread_trunc_ln1659_fu_106289_p1() {
    trunc_ln1659_fu_106289_p1 = grp_fu_105808_p2.read().range(6-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1670_fu_109383_p1() {
    trunc_ln1670_fu_109383_p1 = bitcast_ln1670_fu_109369_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1684_fu_109413_p1() {
    trunc_ln1684_fu_109413_p1 = bitcast_ln1684_fu_109399_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1698_fu_109443_p1() {
    trunc_ln1698_fu_109443_p1 = bitcast_ln1698_fu_109429_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1712_fu_109473_p1() {
    trunc_ln1712_fu_109473_p1 = bitcast_ln1712_fu_109459_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1726_fu_109595_p1() {
    trunc_ln1726_fu_109595_p1 = bitcast_ln1726_fu_109581_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1740_fu_109625_p1() {
    trunc_ln1740_fu_109625_p1 = bitcast_ln1740_fu_109611_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1754_fu_109655_p1() {
    trunc_ln1754_fu_109655_p1 = bitcast_ln1754_fu_109641_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1768_fu_109685_p1() {
    trunc_ln1768_fu_109685_p1 = bitcast_ln1768_fu_109671_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1782_fu_109807_p1() {
    trunc_ln1782_fu_109807_p1 = bitcast_ln1782_fu_109793_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1796_fu_109837_p1() {
    trunc_ln1796_fu_109837_p1 = bitcast_ln1796_fu_109823_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1810_fu_109867_p1() {
    trunc_ln1810_fu_109867_p1 = bitcast_ln1810_fu_109853_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1824_fu_109897_p1() {
    trunc_ln1824_fu_109897_p1 = bitcast_ln1824_fu_109883_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1838_fu_110019_p1() {
    trunc_ln1838_fu_110019_p1 = bitcast_ln1838_fu_110005_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1852_fu_110049_p1() {
    trunc_ln1852_fu_110049_p1 = bitcast_ln1852_fu_110035_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1866_fu_110079_p1() {
    trunc_ln1866_fu_110079_p1 = bitcast_ln1866_fu_110065_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1880_fu_110109_p1() {
    trunc_ln1880_fu_110109_p1 = bitcast_ln1880_fu_110095_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1894_fu_110231_p1() {
    trunc_ln1894_fu_110231_p1 = bitcast_ln1894_fu_110217_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1908_fu_110261_p1() {
    trunc_ln1908_fu_110261_p1 = bitcast_ln1908_fu_110247_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1922_fu_110291_p1() {
    trunc_ln1922_fu_110291_p1 = bitcast_ln1922_fu_110277_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1936_fu_110321_p1() {
    trunc_ln1936_fu_110321_p1 = bitcast_ln1936_fu_110307_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1950_fu_110443_p1() {
    trunc_ln1950_fu_110443_p1 = bitcast_ln1950_fu_110429_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1964_fu_110473_p1() {
    trunc_ln1964_fu_110473_p1 = bitcast_ln1964_fu_110459_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1978_fu_110503_p1() {
    trunc_ln1978_fu_110503_p1 = bitcast_ln1978_fu_110489_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln1992_fu_110533_p1() {
    trunc_ln1992_fu_110533_p1 = bitcast_ln1992_fu_110519_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2006_fu_110655_p1() {
    trunc_ln2006_fu_110655_p1 = bitcast_ln2006_fu_110641_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2020_fu_110685_p1() {
    trunc_ln2020_fu_110685_p1 = bitcast_ln2020_fu_110671_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2034_fu_110715_p1() {
    trunc_ln2034_fu_110715_p1 = bitcast_ln2034_fu_110701_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2048_fu_110745_p1() {
    trunc_ln2048_fu_110745_p1 = bitcast_ln2048_fu_110731_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2062_fu_110867_p1() {
    trunc_ln2062_fu_110867_p1 = bitcast_ln2062_fu_110853_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2076_fu_110897_p1() {
    trunc_ln2076_fu_110897_p1 = bitcast_ln2076_fu_110883_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2090_fu_110927_p1() {
    trunc_ln2090_fu_110927_p1 = bitcast_ln2090_fu_110913_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2104_fu_110957_p1() {
    trunc_ln2104_fu_110957_p1 = bitcast_ln2104_fu_110943_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2118_fu_111079_p1() {
    trunc_ln2118_fu_111079_p1 = bitcast_ln2118_fu_111065_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2132_fu_111109_p1() {
    trunc_ln2132_fu_111109_p1 = bitcast_ln2132_fu_111095_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2146_fu_111139_p1() {
    trunc_ln2146_fu_111139_p1 = bitcast_ln2146_fu_111125_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2160_fu_111169_p1() {
    trunc_ln2160_fu_111169_p1 = bitcast_ln2160_fu_111155_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2174_fu_111291_p1() {
    trunc_ln2174_fu_111291_p1 = bitcast_ln2174_fu_111277_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2188_fu_111321_p1() {
    trunc_ln2188_fu_111321_p1 = bitcast_ln2188_fu_111307_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2202_fu_111351_p1() {
    trunc_ln2202_fu_111351_p1 = bitcast_ln2202_fu_111337_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2216_fu_111381_p1() {
    trunc_ln2216_fu_111381_p1 = bitcast_ln2216_fu_111367_p1.read().range(52-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2222_1_fu_111706_p1() {
    trunc_ln2222_1_fu_111706_p1 = grp_fu_111541_p2.read().range(7-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2222_fu_111702_p1() {
    trunc_ln2222_fu_111702_p1 = grp_fu_111541_p2.read().range(8-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2867_fu_112616_p1() {
    trunc_ln2867_fu_112616_p1 = urem_ln2867_reg_137466.read().range(5-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2875_1_fu_112664_p4() {
    trunc_ln2875_1_fu_112664_p4 = mul_ln2875_fu_112655_p2.read().range(16, 13);
}

void kernel_correlation_asdse::thread_trunc_ln2875_1_mid1_fu_112699_p4() {
    trunc_ln2875_1_mid1_fu_112699_p4 = mul_ln2875_1_reg_137461.read().range(16, 13);
}

void kernel_correlation_asdse::thread_trunc_ln2875_2_fu_112688_p1() {
    trunc_ln2875_2_fu_112688_p1 = grp_fu_112559_p2.read().range(5-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln2875_fu_112661_p1() {
    trunc_ln2875_fu_112661_p1 = urem_ln2875_reg_137471.read().range(5-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln54_fu_105104_p1() {
    trunc_ln54_fu_105104_p1 = grp_fu_104817_p2.read().range(5-1, 0);
}

void kernel_correlation_asdse::thread_trunc_ln62_fu_105147_p1() {
    trunc_ln62_fu_105147_p1 = grp_fu_104829_p2.read().range(5-1, 0);
}

void kernel_correlation_asdse::thread_v1009_fu_105642_p2() {
    v1009_fu_105642_p2 = (!ap_const_lv5_1.is_01() || !ap_phi_mux_v1009_0_phi_fu_81026_p4.read().is_01())? sc_lv<5>(): (sc_biguint<5>(ap_const_lv5_1) + sc_biguint<5>(ap_phi_mux_v1009_0_phi_fu_81026_p4.read()));
}

void kernel_correlation_asdse::thread_v1010_fu_105752_p2() {
    v1010_fu_105752_p2 = (!select_ln1656_fu_105654_p3.read().is_01() || !ap_const_lv6_1.is_01())? sc_lv<6>(): (sc_biguint<6>(select_ln1656_fu_105654_p3.read()) + sc_biguint<6>(ap_const_lv6_1));
}

void kernel_correlation_asdse::thread_v1019_2_fu_109499_p3() {
    v1019_2_fu_109499_p3 = (!and_ln1670_fu_109493_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1670_fu_109493_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104510.read());
}

void kernel_correlation_asdse::thread_v1030_2_fu_109522_p3() {
    v1030_2_fu_109522_p3 = (!and_ln1684_fu_109516_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1684_fu_109516_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104516.read());
}

void kernel_correlation_asdse::thread_v1041_2_fu_109545_p3() {
    v1041_2_fu_109545_p3 = (!and_ln1698_fu_109539_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1698_fu_109539_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104521.read());
}

void kernel_correlation_asdse::thread_v1052_2_fu_109568_p3() {
    v1052_2_fu_109568_p3 = (!and_ln1712_fu_109562_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1712_fu_109562_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104526.read());
}

void kernel_correlation_asdse::thread_v1063_2_fu_109711_p3() {
    v1063_2_fu_109711_p3 = (!and_ln1726_fu_109705_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1726_fu_109705_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104531.read());
}

void kernel_correlation_asdse::thread_v1074_2_fu_109734_p3() {
    v1074_2_fu_109734_p3 = (!and_ln1740_fu_109728_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1740_fu_109728_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104536.read());
}

void kernel_correlation_asdse::thread_v1085_2_fu_109757_p3() {
    v1085_2_fu_109757_p3 = (!and_ln1754_fu_109751_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1754_fu_109751_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104541.read());
}

void kernel_correlation_asdse::thread_v1096_2_fu_109780_p3() {
    v1096_2_fu_109780_p3 = (!and_ln1768_fu_109774_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1768_fu_109774_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104546.read());
}

void kernel_correlation_asdse::thread_v1107_2_fu_109923_p3() {
    v1107_2_fu_109923_p3 = (!and_ln1782_fu_109917_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1782_fu_109917_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104571.read());
}

void kernel_correlation_asdse::thread_v1118_2_fu_109946_p3() {
    v1118_2_fu_109946_p3 = (!and_ln1796_fu_109940_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1796_fu_109940_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104576.read());
}

void kernel_correlation_asdse::thread_v1129_2_fu_109969_p3() {
    v1129_2_fu_109969_p3 = (!and_ln1810_fu_109963_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1810_fu_109963_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104581.read());
}

void kernel_correlation_asdse::thread_v1140_2_fu_109992_p3() {
    v1140_2_fu_109992_p3 = (!and_ln1824_fu_109986_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1824_fu_109986_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104586.read());
}

void kernel_correlation_asdse::thread_v1151_2_fu_110135_p3() {
    v1151_2_fu_110135_p3 = (!and_ln1838_fu_110129_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1838_fu_110129_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104510.read());
}

void kernel_correlation_asdse::thread_v1162_2_fu_110158_p3() {
    v1162_2_fu_110158_p3 = (!and_ln1852_fu_110152_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1852_fu_110152_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104516.read());
}

void kernel_correlation_asdse::thread_v1173_2_fu_110181_p3() {
    v1173_2_fu_110181_p3 = (!and_ln1866_fu_110175_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1866_fu_110175_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104521.read());
}

void kernel_correlation_asdse::thread_v1184_2_fu_110204_p3() {
    v1184_2_fu_110204_p3 = (!and_ln1880_fu_110198_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1880_fu_110198_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104526.read());
}

void kernel_correlation_asdse::thread_v1195_2_fu_110347_p3() {
    v1195_2_fu_110347_p3 = (!and_ln1894_fu_110341_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1894_fu_110341_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104531.read());
}

void kernel_correlation_asdse::thread_v1206_2_fu_110370_p3() {
    v1206_2_fu_110370_p3 = (!and_ln1908_fu_110364_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1908_fu_110364_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104536.read());
}

void kernel_correlation_asdse::thread_v1217_2_fu_110393_p3() {
    v1217_2_fu_110393_p3 = (!and_ln1922_fu_110387_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1922_fu_110387_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104541.read());
}

void kernel_correlation_asdse::thread_v1228_2_fu_110416_p3() {
    v1228_2_fu_110416_p3 = (!and_ln1936_fu_110410_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1936_fu_110410_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104546.read());
}

void kernel_correlation_asdse::thread_v1239_2_fu_110559_p3() {
    v1239_2_fu_110559_p3 = (!and_ln1950_fu_110553_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1950_fu_110553_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104571.read());
}

void kernel_correlation_asdse::thread_v1250_2_fu_110582_p3() {
    v1250_2_fu_110582_p3 = (!and_ln1964_fu_110576_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1964_fu_110576_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104576.read());
}

void kernel_correlation_asdse::thread_v1261_2_fu_110605_p3() {
    v1261_2_fu_110605_p3 = (!and_ln1978_fu_110599_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1978_fu_110599_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104581.read());
}

void kernel_correlation_asdse::thread_v1272_2_fu_110628_p3() {
    v1272_2_fu_110628_p3 = (!and_ln1992_fu_110622_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln1992_fu_110622_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104586.read());
}

void kernel_correlation_asdse::thread_v1283_2_fu_110771_p3() {
    v1283_2_fu_110771_p3 = (!and_ln2006_fu_110765_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2006_fu_110765_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104510.read());
}

void kernel_correlation_asdse::thread_v1294_2_fu_110794_p3() {
    v1294_2_fu_110794_p3 = (!and_ln2020_fu_110788_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2020_fu_110788_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104516.read());
}

void kernel_correlation_asdse::thread_v1305_2_fu_110817_p3() {
    v1305_2_fu_110817_p3 = (!and_ln2034_fu_110811_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2034_fu_110811_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104521.read());
}

void kernel_correlation_asdse::thread_v1316_2_fu_110840_p3() {
    v1316_2_fu_110840_p3 = (!and_ln2048_fu_110834_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2048_fu_110834_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104526.read());
}

void kernel_correlation_asdse::thread_v1327_2_fu_110983_p3() {
    v1327_2_fu_110983_p3 = (!and_ln2062_fu_110977_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2062_fu_110977_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104531.read());
}

void kernel_correlation_asdse::thread_v1338_2_fu_111006_p3() {
    v1338_2_fu_111006_p3 = (!and_ln2076_fu_111000_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2076_fu_111000_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104536.read());
}

void kernel_correlation_asdse::thread_v1349_2_fu_111029_p3() {
    v1349_2_fu_111029_p3 = (!and_ln2090_fu_111023_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2090_fu_111023_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104541.read());
}

void kernel_correlation_asdse::thread_v1360_2_fu_111052_p3() {
    v1360_2_fu_111052_p3 = (!and_ln2104_fu_111046_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2104_fu_111046_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104546.read());
}

void kernel_correlation_asdse::thread_v1371_2_fu_111195_p3() {
    v1371_2_fu_111195_p3 = (!and_ln2118_fu_111189_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2118_fu_111189_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104571.read());
}

void kernel_correlation_asdse::thread_v1382_2_fu_111218_p3() {
    v1382_2_fu_111218_p3 = (!and_ln2132_fu_111212_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2132_fu_111212_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104576.read());
}

void kernel_correlation_asdse::thread_v1393_2_fu_111241_p3() {
    v1393_2_fu_111241_p3 = (!and_ln2146_fu_111235_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2146_fu_111235_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104581.read());
}

void kernel_correlation_asdse::thread_v1404_2_fu_111264_p3() {
    v1404_2_fu_111264_p3 = (!and_ln2160_fu_111258_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2160_fu_111258_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_104586.read());
}

void kernel_correlation_asdse::thread_v1415_2_fu_111407_p3() {
    v1415_2_fu_111407_p3 = (!and_ln2174_fu_111401_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2174_fu_111401_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v1415_reg_132015.read());
}

void kernel_correlation_asdse::thread_v1426_2_fu_111429_p3() {
    v1426_2_fu_111429_p3 = (!and_ln2188_fu_111423_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2188_fu_111423_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v1426_reg_132021.read());
}

void kernel_correlation_asdse::thread_v1437_2_fu_111451_p3() {
    v1437_2_fu_111451_p3 = (!and_ln2202_fu_111445_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2202_fu_111445_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v1437_reg_132027.read());
}

void kernel_correlation_asdse::thread_v1448_2_fu_111473_p3() {
    v1448_2_fu_111473_p3 = (!and_ln2216_fu_111467_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln2216_fu_111467_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v1448_reg_132033.read());
}

void kernel_correlation_asdse::thread_v1452_fu_111497_p2() {
    v1452_fu_111497_p2 = (!ap_const_lv7_1.is_01() || !ap_phi_mux_v1452_0_phi_fu_87139_p4.read().is_01())? sc_lv<7>(): (sc_biguint<7>(ap_const_lv7_1) + sc_biguint<7>(ap_phi_mux_v1452_0_phi_fu_87139_p4.read()));
}

void kernel_correlation_asdse::thread_v1453_fu_112232_p2() {
    v1453_fu_112232_p2 = (!select_ln2222_reg_132128.read().is_01() || !ap_const_lv4_1.is_01())? sc_lv<4>(): (sc_biguint<4>(select_ln2222_reg_132128.read()) + sc_biguint<4>(ap_const_lv4_1));
}

void kernel_correlation_asdse::thread_v1934_fu_112382_p2() {
    v1934_fu_112382_p2 = (!ap_const_lv8_1.is_01() || !ap_phi_mux_v1934_0_phi_fu_87172_p4.read().is_01())? sc_lv<8>(): (sc_biguint<8>(ap_const_lv8_1) + sc_biguint<8>(ap_phi_mux_v1934_0_phi_fu_87172_p4.read()));
}

void kernel_correlation_asdse::thread_v1935_fu_112482_p2() {
    v1935_fu_112482_p2 = (!ap_const_lv8_1.is_01() || !ap_phi_mux_v1935_0_phi_fu_87206_p4.read().is_01())? sc_lv<8>(): (sc_biguint<8>(ap_const_lv8_1) + sc_biguint<8>(ap_phi_mux_v1935_0_phi_fu_87206_p4.read()));
}

void kernel_correlation_asdse::thread_v1936_fu_112440_p2() {
    v1936_fu_112440_p2 = (!select_ln2868_fu_112432_p3.read().is_01() || !ap_const_lv3_1.is_01())? sc_lv<3>(): (sc_biguint<3>(select_ln2868_fu_112432_p3.read()) + sc_biguint<3>(ap_const_lv3_1));
}

void kernel_correlation_asdse::thread_v3_0_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
         (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_0_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_94_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_0_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_75_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage28.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)))) {
        v3_0_0_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage44.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)))) {
        v3_0_0_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage60.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)))) {
        v3_0_0_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)))) {
        v3_0_0_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_0_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61364.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1940_1_fu_106394_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1660_2_fu_106319_p1.read());
        } else {
            v3_0_0_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_0_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_0_Addr_B() {
    v3_0_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_0_0_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_fu_112237_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage59.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage59.read(), ap_const_boolean_0))) {
        v3_0_0_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_fu_112099_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage43.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage43.read(), ap_const_boolean_0))) {
        v3_0_0_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_fu_111966_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage27.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage27.read(), ap_const_boolean_0))) {
        v3_0_0_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_fu_111745_p1.read());
    } else {
        v3_0_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_0_Clk_A() {
    v3_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_0_Clk_B() {
    v3_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_0_Din_A() {
    v3_0_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_0_Din_B() {
    v3_0_0_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_0_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_94_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_0_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_75_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage28.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)))) {
        v3_0_0_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage44.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)))) {
        v3_0_0_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage60.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)))) {
        v3_0_0_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)))) {
        v3_0_0_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage27_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage43.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage43_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage59.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage59_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_0_0_EN_B = ap_const_logic_1;
    } else {
        v3_0_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_0_Rst_A() {
    v3_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_0_Rst_B() {
    v3_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_0_WEN_A() {
    v3_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage27_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage43.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage43_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage59.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage59_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E)))) {
        v3_0_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_10_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_85_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_10_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_84_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)))) {
        v3_0_10_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)))) {
        v3_0_10_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v3_0_10_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)))) {
        v3_0_10_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_10_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61380.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_10_Addr_A_orig =  (sc_lv<32>) (sext_ln1968_fu_107796_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_10_Addr_A_orig =  (sc_lv<32>) (sext_ln1688_1_fu_107721_p1.read());
        } else {
            v3_0_10_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_10_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_10_Addr_B() {
    v3_0_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_10_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0))) {
        v3_0_10_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v3_0_10_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0))) {
        v3_0_10_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0))) {
        v3_0_10_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_10_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_10_Clk_A() {
    v3_0_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_10_Clk_B() {
    v3_0_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_10_Din_A() {
    v3_0_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_10_Din_B() {
    v3_0_10_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_10_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_10_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_85_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_10_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_84_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)))) {
        v3_0_10_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)))) {
        v3_0_10_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v3_0_10_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)))) {
        v3_0_10_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_10_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage32_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage48_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage16_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())))) {
        v3_0_10_EN_B = ap_const_logic_1;
    } else {
        v3_0_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_10_Rst_A() {
    v3_0_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_10_Rst_B() {
    v3_0_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_10_WEN_A() {
    v3_0_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_10_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage32_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage48_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage16_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_11_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_86_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_11_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_85_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)))) {
        v3_0_11_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)))) {
        v3_0_11_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v3_0_11_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)))) {
        v3_0_11_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_11_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61380.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_11_Addr_A_orig =  (sc_lv<32>) (sext_ln1982_fu_108497_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_11_Addr_A_orig =  (sc_lv<32>) (sext_ln1702_1_fu_108422_p1.read());
        } else {
            v3_0_11_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_11_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_11_Addr_B() {
    v3_0_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_11_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0))) {
        v3_0_11_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v3_0_11_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0))) {
        v3_0_11_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0))) {
        v3_0_11_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_11_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_11_Clk_A() {
    v3_0_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_11_Clk_B() {
    v3_0_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_11_Din_A() {
    v3_0_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_11_Din_B() {
    v3_0_11_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_11_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_11_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_86_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_11_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_85_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)))) {
        v3_0_11_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)))) {
        v3_0_11_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v3_0_11_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)))) {
        v3_0_11_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_11_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage32_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage48_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage16_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())))) {
        v3_0_11_EN_B = ap_const_logic_1;
    } else {
        v3_0_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_11_Rst_A() {
    v3_0_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_11_Rst_B() {
    v3_0_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_11_WEN_A() {
    v3_0_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_11_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage32_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage48_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage16_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_12_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_87_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_12_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_86_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)))) {
        v3_0_12_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)))) {
        v3_0_12_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v3_0_12_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)))) {
        v3_0_12_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_12_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61383.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_12_Addr_A_orig =  (sc_lv<32>) (sext_ln1940_1_fu_106394_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_12_Addr_A_orig =  (sc_lv<32>) (sext_ln1660_2_fu_106319_p1.read());
        } else {
            v3_0_12_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_12_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_12_Addr_B() {
    v3_0_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_12_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0))) {
        v3_0_12_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v3_0_12_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0))) {
        v3_0_12_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0))) {
        v3_0_12_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_12_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_12_Clk_A() {
    v3_0_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_12_Clk_B() {
    v3_0_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_12_Din_A() {
    v3_0_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_12_Din_B() {
    v3_0_12_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_12_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_12_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_87_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_12_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_86_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)))) {
        v3_0_12_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)))) {
        v3_0_12_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v3_0_12_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)))) {
        v3_0_12_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_12_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17_11001.read(), ap_const_boolean_0)))) {
        v3_0_12_EN_B = ap_const_logic_1;
    } else {
        v3_0_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_12_Rst_A() {
    v3_0_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_12_Rst_B() {
    v3_0_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_12_WEN_A() {
    v3_0_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_12_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_13_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_88_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_13_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_87_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)))) {
        v3_0_13_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)))) {
        v3_0_13_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v3_0_13_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)))) {
        v3_0_13_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_13_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61383.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_13_Addr_A_orig =  (sc_lv<32>) (sext_ln1954_fu_107095_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_13_Addr_A_orig =  (sc_lv<32>) (sext_ln1674_1_fu_107020_p1.read());
        } else {
            v3_0_13_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_13_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_13_Addr_B() {
    v3_0_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_13_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0))) {
        v3_0_13_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v3_0_13_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0))) {
        v3_0_13_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0))) {
        v3_0_13_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_13_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_13_Clk_A() {
    v3_0_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_13_Clk_B() {
    v3_0_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_13_Din_A() {
    v3_0_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_13_Din_B() {
    v3_0_13_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_13_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_13_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_88_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_13_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_87_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)))) {
        v3_0_13_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)))) {
        v3_0_13_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v3_0_13_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)))) {
        v3_0_13_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_13_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17_11001.read(), ap_const_boolean_0)))) {
        v3_0_13_EN_B = ap_const_logic_1;
    } else {
        v3_0_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_13_Rst_A() {
    v3_0_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_13_Rst_B() {
    v3_0_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_13_WEN_A() {
    v3_0_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_13_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_14_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_89_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_14_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_88_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)))) {
        v3_0_14_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)))) {
        v3_0_14_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v3_0_14_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)))) {
        v3_0_14_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_14_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61383.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_14_Addr_A_orig =  (sc_lv<32>) (sext_ln1968_fu_107796_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_14_Addr_A_orig =  (sc_lv<32>) (sext_ln1688_1_fu_107721_p1.read());
        } else {
            v3_0_14_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_14_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_14_Addr_B() {
    v3_0_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_14_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0))) {
        v3_0_14_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v3_0_14_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0))) {
        v3_0_14_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0))) {
        v3_0_14_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_14_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_14_Clk_A() {
    v3_0_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_14_Clk_B() {
    v3_0_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_14_Din_A() {
    v3_0_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_14_Din_B() {
    v3_0_14_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_14_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_14_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_89_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_14_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_88_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)))) {
        v3_0_14_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)))) {
        v3_0_14_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v3_0_14_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)))) {
        v3_0_14_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_14_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18_11001.read(), ap_const_boolean_0)))) {
        v3_0_14_EN_B = ap_const_logic_1;
    } else {
        v3_0_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_14_Rst_A() {
    v3_0_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_14_Rst_B() {
    v3_0_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_14_WEN_A() {
    v3_0_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_14_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_15_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_90_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_15_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_89_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)))) {
        v3_0_15_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)))) {
        v3_0_15_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v3_0_15_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)))) {
        v3_0_15_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_15_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61383.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_15_Addr_A_orig =  (sc_lv<32>) (sext_ln1982_fu_108497_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_15_Addr_A_orig =  (sc_lv<32>) (sext_ln1702_1_fu_108422_p1.read());
        } else {
            v3_0_15_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_15_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_15_Addr_B() {
    v3_0_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_15_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0))) {
        v3_0_15_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v3_0_15_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0))) {
        v3_0_15_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0))) {
        v3_0_15_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_15_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_15_Clk_A() {
    v3_0_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_15_Clk_B() {
    v3_0_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_15_Din_A() {
    v3_0_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_15_Din_B() {
    v3_0_15_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_15_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_15_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_90_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_15_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_89_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)))) {
        v3_0_15_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)))) {
        v3_0_15_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v3_0_15_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)))) {
        v3_0_15_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_15_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18_11001.read(), ap_const_boolean_0)))) {
        v3_0_15_EN_B = ap_const_logic_1;
    } else {
        v3_0_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_15_Rst_A() {
    v3_0_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_15_Rst_B() {
    v3_0_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_15_WEN_A() {
    v3_0_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_15_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_16_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_91_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_16_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_90_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)))) {
        v3_0_16_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)))) {
        v3_0_16_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v3_0_16_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)))) {
        v3_0_16_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_16_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61389.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_16_Addr_A_orig =  (sc_lv<32>) (sext_ln1940_1_fu_106394_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_16_Addr_A_orig =  (sc_lv<32>) (sext_ln1660_2_fu_106319_p1.read());
        } else {
            v3_0_16_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_16_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_16_Addr_B() {
    v3_0_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_16_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0))) {
        v3_0_16_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v3_0_16_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0))) {
        v3_0_16_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0))) {
        v3_0_16_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_16_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_16_Clk_A() {
    v3_0_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_16_Clk_B() {
    v3_0_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_16_Din_A() {
    v3_0_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_16_Din_B() {
    v3_0_16_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_16_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_16_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_91_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_16_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_90_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)))) {
        v3_0_16_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)))) {
        v3_0_16_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v3_0_16_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)))) {
        v3_0_16_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_16_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19_11001.read(), ap_const_boolean_0)))) {
        v3_0_16_EN_B = ap_const_logic_1;
    } else {
        v3_0_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_16_Rst_A() {
    v3_0_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_16_Rst_B() {
    v3_0_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_16_WEN_A() {
    v3_0_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_16_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_17_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_92_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_17_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_91_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)))) {
        v3_0_17_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)))) {
        v3_0_17_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v3_0_17_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)))) {
        v3_0_17_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_17_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61389.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_17_Addr_A_orig =  (sc_lv<32>) (sext_ln1954_fu_107095_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_17_Addr_A_orig =  (sc_lv<32>) (sext_ln1674_1_fu_107020_p1.read());
        } else {
            v3_0_17_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_17_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_17_Addr_B() {
    v3_0_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_17_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0))) {
        v3_0_17_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v3_0_17_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0))) {
        v3_0_17_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0))) {
        v3_0_17_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_17_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_17_Clk_A() {
    v3_0_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_17_Clk_B() {
    v3_0_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_17_Din_A() {
    v3_0_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_17_Din_B() {
    v3_0_17_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_17_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_17_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_92_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_17_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_91_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)))) {
        v3_0_17_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)))) {
        v3_0_17_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v3_0_17_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)))) {
        v3_0_17_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_17_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19_11001.read(), ap_const_boolean_0)))) {
        v3_0_17_EN_B = ap_const_logic_1;
    } else {
        v3_0_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_17_Rst_A() {
    v3_0_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_17_Rst_B() {
    v3_0_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_17_WEN_A() {
    v3_0_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_17_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_18_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_93_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_18_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_92_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)))) {
        v3_0_18_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)))) {
        v3_0_18_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v3_0_18_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)))) {
        v3_0_18_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_18_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61389.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_18_Addr_A_orig =  (sc_lv<32>) (sext_ln1968_fu_107796_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_18_Addr_A_orig =  (sc_lv<32>) (sext_ln1688_1_fu_107721_p1.read());
        } else {
            v3_0_18_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_18_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_18_Addr_B() {
    v3_0_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_18_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0))) {
        v3_0_18_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v3_0_18_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0))) {
        v3_0_18_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0))) {
        v3_0_18_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_18_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_18_Clk_A() {
    v3_0_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_18_Clk_B() {
    v3_0_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_18_Din_A() {
    v3_0_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_18_Din_B() {
    v3_0_18_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_18_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_18_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_93_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_18_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_92_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)))) {
        v3_0_18_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)))) {
        v3_0_18_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v3_0_18_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)))) {
        v3_0_18_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_18_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage36_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage52_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage20_11001.read(), ap_const_boolean_0)))) {
        v3_0_18_EN_B = ap_const_logic_1;
    } else {
        v3_0_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_18_Rst_A() {
    v3_0_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_18_Rst_B() {
    v3_0_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_18_WEN_A() {
    v3_0_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_18_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage36_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage52_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage20_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_19_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_94_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_19_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_93_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)))) {
        v3_0_19_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)))) {
        v3_0_19_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v3_0_19_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)))) {
        v3_0_19_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_19_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61389.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_19_Addr_A_orig =  (sc_lv<32>) (sext_ln1982_fu_108497_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_19_Addr_A_orig =  (sc_lv<32>) (sext_ln1702_1_fu_108422_p1.read());
        } else {
            v3_0_19_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_19_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_19_Addr_B() {
    v3_0_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_19_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0))) {
        v3_0_19_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v3_0_19_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0))) {
        v3_0_19_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0))) {
        v3_0_19_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_19_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_19_Clk_A() {
    v3_0_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_19_Clk_B() {
    v3_0_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_19_Din_A() {
    v3_0_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_19_Din_B() {
    v3_0_19_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_19_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_19_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_94_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_19_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_93_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)))) {
        v3_0_19_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)))) {
        v3_0_19_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v3_0_19_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)))) {
        v3_0_19_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_19_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage36_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage52_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage20_11001.read(), ap_const_boolean_0)))) {
        v3_0_19_EN_B = ap_const_logic_1;
    } else {
        v3_0_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_19_Rst_A() {
    v3_0_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_19_Rst_B() {
    v3_0_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_19_WEN_A() {
    v3_0_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_19_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage36_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage52_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage20_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_1_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_76_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_1_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_75_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage28.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)))) {
        v3_0_1_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage44.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)))) {
        v3_0_1_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage60.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)))) {
        v3_0_1_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)))) {
        v3_0_1_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_1_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61364.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1954_fu_107095_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1674_1_fu_107020_p1.read());
        } else {
            v3_0_1_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_1_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_1_Addr_B() {
    v3_0_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_0_1_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_fu_112237_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage59.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage59.read(), ap_const_boolean_0))) {
        v3_0_1_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_fu_112099_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage43.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage43.read(), ap_const_boolean_0))) {
        v3_0_1_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_fu_111966_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage27.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage27.read(), ap_const_boolean_0))) {
        v3_0_1_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_fu_111745_p1.read());
    } else {
        v3_0_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_1_Clk_A() {
    v3_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_1_Clk_B() {
    v3_0_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_1_Din_A() {
    v3_0_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_1_Din_B() {
    v3_0_1_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_1_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_76_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_1_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_75_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage28.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)))) {
        v3_0_1_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage44.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)))) {
        v3_0_1_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage60.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)))) {
        v3_0_1_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)))) {
        v3_0_1_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage27_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage43.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage43_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage59.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage59_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_0_1_EN_B = ap_const_logic_1;
    } else {
        v3_0_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_1_Rst_A() {
    v3_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_1_Rst_B() {
    v3_0_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_1_WEN_A() {
    v3_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage27_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage43.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage43_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage59.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage59_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E)))) {
        v3_0_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_2_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_77_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_2_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_76_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)))) {
        v3_0_2_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)))) {
        v3_0_2_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)))) {
        v3_0_2_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)))) {
        v3_0_2_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_2_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61364.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_2_Addr_A_orig =  (sc_lv<32>) (sext_ln1968_fu_107796_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_2_Addr_A_orig =  (sc_lv<32>) (sext_ln1688_1_fu_107721_p1.read());
        } else {
            v3_0_2_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_2_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_2_Addr_B() {
    v3_0_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v3_0_2_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage60.read(), ap_const_boolean_0))) {
        v3_0_2_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage44.read(), ap_const_boolean_0))) {
        v3_0_2_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage28.read(), ap_const_boolean_0))) {
        v3_0_2_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_2_Clk_A() {
    v3_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_2_Clk_B() {
    v3_0_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_2_Din_A() {
    v3_0_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_2_Din_B() {
    v3_0_2_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_2_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_77_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_2_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_76_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)))) {
        v3_0_2_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)))) {
        v3_0_2_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)))) {
        v3_0_2_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)))) {
        v3_0_2_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage28_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage44_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage60_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0)))) {
        v3_0_2_EN_B = ap_const_logic_1;
    } else {
        v3_0_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_2_Rst_A() {
    v3_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_2_Rst_B() {
    v3_0_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_2_WEN_A() {
    v3_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage28_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage44_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage60_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E)))) {
        v3_0_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_3_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_78_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_3_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_77_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)))) {
        v3_0_3_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)))) {
        v3_0_3_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)))) {
        v3_0_3_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)))) {
        v3_0_3_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_3_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61364.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_3_Addr_A_orig =  (sc_lv<32>) (sext_ln1982_fu_108497_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_3_Addr_A_orig =  (sc_lv<32>) (sext_ln1702_1_fu_108422_p1.read());
        } else {
            v3_0_3_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_3_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_3_Addr_B() {
    v3_0_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v3_0_3_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage60.read(), ap_const_boolean_0))) {
        v3_0_3_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage44.read(), ap_const_boolean_0))) {
        v3_0_3_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage28.read(), ap_const_boolean_0))) {
        v3_0_3_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_3_Clk_A() {
    v3_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_3_Clk_B() {
    v3_0_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_3_Din_A() {
    v3_0_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_3_Din_B() {
    v3_0_3_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_3_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_78_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_3_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_77_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)))) {
        v3_0_3_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)))) {
        v3_0_3_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)))) {
        v3_0_3_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)))) {
        v3_0_3_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage28_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage44_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage60_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0)))) {
        v3_0_3_EN_B = ap_const_logic_1;
    } else {
        v3_0_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_3_Rst_A() {
    v3_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_3_Rst_B() {
    v3_0_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_3_WEN_A() {
    v3_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage28_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage44_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage60_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E)))) {
        v3_0_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_4_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_79_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_4_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_78_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)))) {
        v3_0_4_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)))) {
        v3_0_4_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)))) {
        v3_0_4_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)))) {
        v3_0_4_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_4_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61392.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1940_1_fu_106394_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1660_2_fu_106319_p1.read());
        } else {
            v3_0_4_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_4_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_4_Addr_B() {
    v3_0_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0))) {
        v3_0_4_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0))) {
        v3_0_4_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0))) {
        v3_0_4_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0))) {
        v3_0_4_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_4_Clk_A() {
    v3_0_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_4_Clk_B() {
    v3_0_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_4_Din_A() {
    v3_0_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_4_Din_B() {
    v3_0_4_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_4_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_79_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_4_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_78_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)))) {
        v3_0_4_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)))) {
        v3_0_4_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)))) {
        v3_0_4_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)))) {
        v3_0_4_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage29_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage45_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage61_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0)))) {
        v3_0_4_EN_B = ap_const_logic_1;
    } else {
        v3_0_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_4_Rst_A() {
    v3_0_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_4_Rst_B() {
    v3_0_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_4_WEN_A() {
    v3_0_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage29_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage45_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage61_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_5_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_80_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_5_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_79_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)))) {
        v3_0_5_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)))) {
        v3_0_5_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)))) {
        v3_0_5_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)))) {
        v3_0_5_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_5_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61392.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_5_Addr_A_orig =  (sc_lv<32>) (sext_ln1954_fu_107095_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_5_Addr_A_orig =  (sc_lv<32>) (sext_ln1674_1_fu_107020_p1.read());
        } else {
            v3_0_5_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_5_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_5_Addr_B() {
    v3_0_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_5_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0))) {
        v3_0_5_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0))) {
        v3_0_5_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0))) {
        v3_0_5_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0))) {
        v3_0_5_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_5_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_5_Clk_A() {
    v3_0_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_5_Clk_B() {
    v3_0_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_5_Din_A() {
    v3_0_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_5_Din_B() {
    v3_0_5_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_5_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_5_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_80_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_5_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_79_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)))) {
        v3_0_5_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)))) {
        v3_0_5_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)))) {
        v3_0_5_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)))) {
        v3_0_5_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_5_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage29_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage45_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage61_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0)))) {
        v3_0_5_EN_B = ap_const_logic_1;
    } else {
        v3_0_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_5_Rst_A() {
    v3_0_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_5_Rst_B() {
    v3_0_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_5_WEN_A() {
    v3_0_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_5_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage29_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage45_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage61_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_6_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_81_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_6_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_80_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)))) {
        v3_0_6_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)))) {
        v3_0_6_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)))) {
        v3_0_6_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)))) {
        v3_0_6_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_6_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61392.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_6_Addr_A_orig =  (sc_lv<32>) (sext_ln1968_fu_107796_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_6_Addr_A_orig =  (sc_lv<32>) (sext_ln1688_1_fu_107721_p1.read());
        } else {
            v3_0_6_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_6_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_6_Addr_B() {
    v3_0_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_6_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v3_0_6_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0))) {
        v3_0_6_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0))) {
        v3_0_6_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0))) {
        v3_0_6_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_6_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_6_Clk_A() {
    v3_0_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_6_Clk_B() {
    v3_0_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_6_Din_A() {
    v3_0_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_6_Din_B() {
    v3_0_6_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_6_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_6_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_81_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_6_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_80_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)))) {
        v3_0_6_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)))) {
        v3_0_6_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)))) {
        v3_0_6_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)))) {
        v3_0_6_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_6_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage30_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage46_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage62_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)))) {
        v3_0_6_EN_B = ap_const_logic_1;
    } else {
        v3_0_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_6_Rst_A() {
    v3_0_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_6_Rst_B() {
    v3_0_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_6_WEN_A() {
    v3_0_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_6_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage30_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage46_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage62_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_7_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_82_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_7_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_81_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)))) {
        v3_0_7_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)))) {
        v3_0_7_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)))) {
        v3_0_7_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)))) {
        v3_0_7_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_7_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61392.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_7_Addr_A_orig =  (sc_lv<32>) (sext_ln1982_fu_108497_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_7_Addr_A_orig =  (sc_lv<32>) (sext_ln1702_1_fu_108422_p1.read());
        } else {
            v3_0_7_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_7_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_7_Addr_B() {
    v3_0_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_7_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v3_0_7_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage62.read(), ap_const_boolean_0))) {
        v3_0_7_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage46.read(), ap_const_boolean_0))) {
        v3_0_7_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage30.read(), ap_const_boolean_0))) {
        v3_0_7_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_7_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_7_Clk_A() {
    v3_0_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_7_Clk_B() {
    v3_0_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_7_Din_A() {
    v3_0_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_7_Din_B() {
    v3_0_7_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_7_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_7_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_82_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_7_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_81_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)))) {
        v3_0_7_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)))) {
        v3_0_7_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0)))) {
        v3_0_7_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)))) {
        v3_0_7_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_7_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage30_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage46_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage62_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)))) {
        v3_0_7_EN_B = ap_const_logic_1;
    } else {
        v3_0_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_7_Rst_A() {
    v3_0_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_7_Rst_B() {
    v3_0_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_7_WEN_A() {
    v3_0_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_7_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage30_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage46.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage46_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage62.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage62_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_8_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_83_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_8_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_82_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)))) {
        v3_0_8_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)))) {
        v3_0_8_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v3_0_8_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)))) {
        v3_0_8_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_Addr_A.read();
    } else {
        v3_0_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_8_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61380.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_8_Addr_A_orig =  (sc_lv<32>) (sext_ln1940_1_fu_106394_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_8_Addr_A_orig =  (sc_lv<32>) (sext_ln1660_2_fu_106319_p1.read());
        } else {
            v3_0_8_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_8_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_8_Addr_B() {
    v3_0_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_8_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0))) {
        v3_0_8_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0))) {
        v3_0_8_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0))) {
        v3_0_8_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0))) {
        v3_0_8_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_8_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_8_Clk_A() {
    v3_0_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_8_Clk_B() {
    v3_0_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_8_Din_A() {
    v3_0_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_8_Din_B() {
    v3_0_8_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_8_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_8_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_83_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_8_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_82_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)))) {
        v3_0_8_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)))) {
        v3_0_8_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v3_0_8_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)))) {
        v3_0_8_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_8_EN_A.read();
    } else {
        v3_0_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_8_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage31_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage47_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage63_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage15_11001.read(), ap_const_boolean_0)))) {
        v3_0_8_EN_B = ap_const_logic_1;
    } else {
        v3_0_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_8_Rst_A() {
    v3_0_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_8_Rst_B() {
    v3_0_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_8_WEN_A() {
    v3_0_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_8_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage31_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage47_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage63_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage15_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_9_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_84_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_9_Addr_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_83_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)))) {
        v3_0_9_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)))) {
        v3_0_9_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v3_0_9_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)))) {
        v3_0_9_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_Addr_A.read();
    } else {
        v3_0_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_0_9_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61380.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_condition_61375.read(), ap_const_boolean_1)) {
            v3_0_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1954_fu_107095_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0)) {
            v3_0_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1674_1_fu_107020_p1.read());
        } else {
            v3_0_9_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_0_9_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_9_Addr_B() {
    v3_0_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_0_9_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage15.read(), ap_const_boolean_0))) {
        v3_0_9_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage63.read(), ap_const_boolean_0))) {
        v3_0_9_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage47.read(), ap_const_boolean_0))) {
        v3_0_9_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage31.read(), ap_const_boolean_0))) {
        v3_0_9_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_0_9_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_0_9_Clk_A() {
    v3_0_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_9_Clk_B() {
    v3_0_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_0_9_Din_A() {
    v3_0_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_0_9_Din_B() {
    v3_0_9_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_0_9_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_0) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_F) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_14) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_19) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_1E) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_23) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_28) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_2D) && 
          !esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_32) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, urem_ln1656_reg_114535.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())))) {
        v3_0_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_0_9_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_84_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_0_9_EN_A = grp_aesl_mux_load_20_4_x_fu_92558_empty_83_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)))) {
        v3_0_9_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_72_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)))) {
        v3_0_9_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_71_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v3_0_9_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_70_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)))) {
        v3_0_9_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_8_EN_A.read();
    } else {
        v3_0_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_9_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage31_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage47_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage63_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage15_11001.read(), ap_const_boolean_0)))) {
        v3_0_9_EN_B = ap_const_logic_1;
    } else {
        v3_0_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_0_9_Rst_A() {
    v3_0_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_9_Rst_B() {
    v3_0_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_0_9_WEN_A() {
    v3_0_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_0_9_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage31_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage47.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage47_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,8,8>(ap_const_lv8_0, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_4) && 
          !esl_seteq<1,8,8>(ap_const_lv8_5, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_6, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9) && 
          !esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_B, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_E) && 
          !esl_seteq<1,8,8>(ap_const_lv8_F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_10, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_11) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_12) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_13) && 
          !esl_seteq<1,8,8>(ap_const_lv8_14, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_15, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_16) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_17) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_18) && 
          !esl_seteq<1,8,8>(ap_const_lv8_19, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1A, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_1D) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_1F, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_20) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_21) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_22) && 
          !esl_seteq<1,8,8>(ap_const_lv8_23, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_24, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_25) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_26) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_27) && 
          !esl_seteq<1,8,8>(ap_const_lv8_28, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_29, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2C) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2D, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_2E, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_2F) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_30) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_31) && 
          !esl_seteq<1,8,8>(ap_const_lv8_32, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_33, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_34) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_35) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_36) && 
          !esl_seteq<1,8,8>(ap_const_lv8_37, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(ap_const_lv8_38, trunc_ln2222_reg_132512.read()) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_39) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3A) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3B) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3C) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3D) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3E) && 
          !esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage63.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage63_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_3F)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage15_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_3E)))) {
        v3_0_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
         (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_0_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_94_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_0_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_75_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)))) {
        v3_10_0_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage28.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)))) {
        v3_10_0_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage44.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)))) {
        v3_10_0_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage60.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)))) {
        v3_10_0_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_Addr_A.read();
    } else {
        v3_10_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_0_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61364.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1940_1_fu_106394_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1660_2_fu_106319_p1.read());
        } else {
            v3_10_0_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_0_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_0_Addr_B() {
    v3_10_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_10_0_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_fu_112237_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage59.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage59.read(), ap_const_boolean_0))) {
        v3_10_0_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_fu_112099_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage43.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage43.read(), ap_const_boolean_0))) {
        v3_10_0_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_fu_111966_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage27.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage27.read(), ap_const_boolean_0))) {
        v3_10_0_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_fu_111745_p1.read());
    } else {
        v3_10_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_0_Clk_A() {
    v3_10_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_0_Clk_B() {
    v3_10_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_0_Din_A() {
    v3_10_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_0_Din_B() {
    v3_10_0_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_0_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_94_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_0_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_75_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0)))) {
        v3_10_0_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage28.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage28.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage29.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage29.read(), ap_const_boolean_0)))) {
        v3_10_0_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage44.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage44.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage45.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage45.read(), ap_const_boolean_0)))) {
        v3_10_0_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage60.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage60.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage61.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage61.read(), ap_const_boolean_0)))) {
        v3_10_0_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_EN_A.read();
    } else {
        v3_10_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage27_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage43.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage43_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage59.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage59_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_10_0_EN_B = ap_const_logic_1;
    } else {
        v3_10_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_0_Rst_A() {
    v3_10_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_0_Rst_B() {
    v3_10_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_0_WEN_A() {
    v3_10_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_10_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage27_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage43.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage43_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage59.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage59_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_7)))) {
        v3_10_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_10_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_85_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_10_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_84_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)))) {
        v3_10_10_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)))) {
        v3_10_10_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)))) {
        v3_10_10_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v3_10_10_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_Addr_A.read();
    } else {
        v3_10_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_10_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61380.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_10_Addr_A_orig =  (sc_lv<32>) (sext_ln1968_fu_107796_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_10_Addr_A_orig =  (sc_lv<32>) (sext_ln1688_1_fu_107721_p1.read());
        } else {
            v3_10_10_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_10_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_10_Addr_B() {
    v3_10_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_10_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0))) {
        v3_10_10_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v3_10_10_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0))) {
        v3_10_10_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0))) {
        v3_10_10_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_10_10_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_10_Clk_A() {
    v3_10_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_10_Clk_B() {
    v3_10_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_10_Din_A() {
    v3_10_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_10_Din_B() {
    v3_10_10_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_10_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_10_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_85_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_10_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_84_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)))) {
        v3_10_10_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)))) {
        v3_10_10_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)))) {
        v3_10_10_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v3_10_10_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_EN_A.read();
    } else {
        v3_10_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_10_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage32_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage48_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage16_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())))) {
        v3_10_10_EN_B = ap_const_logic_1;
    } else {
        v3_10_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_10_Rst_A() {
    v3_10_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_10_Rst_B() {
    v3_10_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_10_WEN_A() {
    v3_10_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_10_10_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage32_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage48_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage16_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_7)))) {
        v3_10_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_11_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_86_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_11_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_85_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)))) {
        v3_10_11_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)))) {
        v3_10_11_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)))) {
        v3_10_11_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v3_10_11_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_15_Addr_A.read();
    } else {
        v3_10_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_11_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61380.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_11_Addr_A_orig =  (sc_lv<32>) (sext_ln1982_fu_108497_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_11_Addr_A_orig =  (sc_lv<32>) (sext_ln1702_1_fu_108422_p1.read());
        } else {
            v3_10_11_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_11_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_11_Addr_B() {
    v3_10_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_11_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage16.read(), ap_const_boolean_0))) {
        v3_10_11_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v3_10_11_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage48.read(), ap_const_boolean_0))) {
        v3_10_11_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage32.read(), ap_const_boolean_0))) {
        v3_10_11_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_10_11_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_11_Clk_A() {
    v3_10_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_11_Clk_B() {
    v3_10_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_11_Din_A() {
    v3_10_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_11_Din_B() {
    v3_10_11_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_11_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_11_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_86_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_11_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_85_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)))) {
        v3_10_11_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)))) {
        v3_10_11_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)))) {
        v3_10_11_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v3_10_11_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_15_EN_A.read();
    } else {
        v3_10_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_11_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage32_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage48_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage16_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())))) {
        v3_10_11_EN_B = ap_const_logic_1;
    } else {
        v3_10_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_11_Rst_A() {
    v3_10_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_11_Rst_B() {
    v3_10_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_11_WEN_A() {
    v3_10_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_10_11_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage32.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage32_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage48.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage48_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage16_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_7)))) {
        v3_10_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_12_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_87_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_12_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_86_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)))) {
        v3_10_12_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)))) {
        v3_10_12_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)))) {
        v3_10_12_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v3_10_12_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_Addr_A.read();
    } else {
        v3_10_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_12_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61383.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_12_Addr_A_orig =  (sc_lv<32>) (sext_ln1940_1_fu_106394_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_12_Addr_A_orig =  (sc_lv<32>) (sext_ln1660_2_fu_106319_p1.read());
        } else {
            v3_10_12_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_12_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_12_Addr_B() {
    v3_10_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_12_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0))) {
        v3_10_12_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v3_10_12_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0))) {
        v3_10_12_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0))) {
        v3_10_12_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_10_12_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_12_Clk_A() {
    v3_10_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_12_Clk_B() {
    v3_10_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_12_Din_A() {
    v3_10_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_12_Din_B() {
    v3_10_12_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_12_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_12_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_87_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_12_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_86_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)))) {
        v3_10_12_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)))) {
        v3_10_12_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)))) {
        v3_10_12_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v3_10_12_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_EN_A.read();
    } else {
        v3_10_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_12_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17_11001.read(), ap_const_boolean_0)))) {
        v3_10_12_EN_B = ap_const_logic_1;
    } else {
        v3_10_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_12_Rst_A() {
    v3_10_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_12_Rst_B() {
    v3_10_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_12_WEN_A() {
    v3_10_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_10_12_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_7)))) {
        v3_10_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_13_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_88_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_13_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_87_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)))) {
        v3_10_13_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)))) {
        v3_10_13_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)))) {
        v3_10_13_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v3_10_13_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_15_Addr_A.read();
    } else {
        v3_10_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_13_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61383.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_13_Addr_A_orig =  (sc_lv<32>) (sext_ln1954_fu_107095_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_13_Addr_A_orig =  (sc_lv<32>) (sext_ln1674_1_fu_107020_p1.read());
        } else {
            v3_10_13_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_13_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_13_Addr_B() {
    v3_10_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_13_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage17.read(), ap_const_boolean_0))) {
        v3_10_13_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v3_10_13_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage49.read(), ap_const_boolean_0))) {
        v3_10_13_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage33.read(), ap_const_boolean_0))) {
        v3_10_13_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_10_13_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_13_Clk_A() {
    v3_10_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_13_Clk_B() {
    v3_10_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_13_Din_A() {
    v3_10_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_13_Din_B() {
    v3_10_13_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_13_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_13_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_88_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_13_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_87_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)))) {
        v3_10_13_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)))) {
        v3_10_13_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)))) {
        v3_10_13_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v3_10_13_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_15_EN_A.read();
    } else {
        v3_10_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_13_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17_11001.read(), ap_const_boolean_0)))) {
        v3_10_13_EN_B = ap_const_logic_1;
    } else {
        v3_10_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_13_Rst_A() {
    v3_10_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_13_Rst_B() {
    v3_10_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_13_WEN_A() {
    v3_10_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_10_13_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage33.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage33_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage49.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage49_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage17_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_7)))) {
        v3_10_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_14_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_89_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_14_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_88_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)))) {
        v3_10_14_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)))) {
        v3_10_14_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)))) {
        v3_10_14_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v3_10_14_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_Addr_A.read();
    } else {
        v3_10_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_14_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61383.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_14_Addr_A_orig =  (sc_lv<32>) (sext_ln1968_fu_107796_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_14_Addr_A_orig =  (sc_lv<32>) (sext_ln1688_1_fu_107721_p1.read());
        } else {
            v3_10_14_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_14_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_14_Addr_B() {
    v3_10_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_14_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0))) {
        v3_10_14_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v3_10_14_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0))) {
        v3_10_14_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0))) {
        v3_10_14_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_10_14_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_14_Clk_A() {
    v3_10_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_14_Clk_B() {
    v3_10_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_14_Din_A() {
    v3_10_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_14_Din_B() {
    v3_10_14_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_14_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_14_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_89_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_14_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_88_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)))) {
        v3_10_14_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)))) {
        v3_10_14_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)))) {
        v3_10_14_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v3_10_14_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_EN_A.read();
    } else {
        v3_10_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_14_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18_11001.read(), ap_const_boolean_0)))) {
        v3_10_14_EN_B = ap_const_logic_1;
    } else {
        v3_10_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_14_Rst_A() {
    v3_10_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_14_Rst_B() {
    v3_10_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_14_WEN_A() {
    v3_10_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_10_14_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_7)))) {
        v3_10_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_15_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_90_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_15_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_89_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)))) {
        v3_10_15_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)))) {
        v3_10_15_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)))) {
        v3_10_15_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v3_10_15_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_15_Addr_A.read();
    } else {
        v3_10_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_15_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61383.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_15_Addr_A_orig =  (sc_lv<32>) (sext_ln1982_fu_108497_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_15_Addr_A_orig =  (sc_lv<32>) (sext_ln1702_1_fu_108422_p1.read());
        } else {
            v3_10_15_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_15_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_15_Addr_B() {
    v3_10_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_15_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage18.read(), ap_const_boolean_0))) {
        v3_10_15_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v3_10_15_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage50.read(), ap_const_boolean_0))) {
        v3_10_15_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage34.read(), ap_const_boolean_0))) {
        v3_10_15_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_10_15_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_15_Clk_A() {
    v3_10_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_15_Clk_B() {
    v3_10_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_15_Din_A() {
    v3_10_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_15_Din_B() {
    v3_10_15_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_15_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_15_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_90_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_15_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_89_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)))) {
        v3_10_15_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)))) {
        v3_10_15_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)))) {
        v3_10_15_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v3_10_15_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_15_EN_A.read();
    } else {
        v3_10_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_15_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18_11001.read(), ap_const_boolean_0)))) {
        v3_10_15_EN_B = ap_const_logic_1;
    } else {
        v3_10_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_15_Rst_A() {
    v3_10_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_15_Rst_B() {
    v3_10_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_15_WEN_A() {
    v3_10_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_10_15_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage34.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage34_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage50.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage50_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage18_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_7)))) {
        v3_10_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_16_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_91_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_16_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_90_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)))) {
        v3_10_16_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)))) {
        v3_10_16_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)))) {
        v3_10_16_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v3_10_16_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_Addr_A.read();
    } else {
        v3_10_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_16_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61389.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_16_Addr_A_orig =  (sc_lv<32>) (sext_ln1940_1_fu_106394_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_16_Addr_A_orig =  (sc_lv<32>) (sext_ln1660_2_fu_106319_p1.read());
        } else {
            v3_10_16_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_16_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_16_Addr_B() {
    v3_10_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_16_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0))) {
        v3_10_16_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v3_10_16_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0))) {
        v3_10_16_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0))) {
        v3_10_16_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_10_16_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_16_Clk_A() {
    v3_10_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_16_Clk_B() {
    v3_10_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_16_Din_A() {
    v3_10_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_16_Din_B() {
    v3_10_16_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_16_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_16_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_91_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_16_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_90_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)))) {
        v3_10_16_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)))) {
        v3_10_16_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)))) {
        v3_10_16_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v3_10_16_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_EN_A.read();
    } else {
        v3_10_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_16_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19_11001.read(), ap_const_boolean_0)))) {
        v3_10_16_EN_B = ap_const_logic_1;
    } else {
        v3_10_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_16_Rst_A() {
    v3_10_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_16_Rst_B() {
    v3_10_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_16_WEN_A() {
    v3_10_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_10_16_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_7)))) {
        v3_10_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_17_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_92_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_17_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_91_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)))) {
        v3_10_17_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)))) {
        v3_10_17_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)))) {
        v3_10_17_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v3_10_17_Addr_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_15_Addr_A.read();
    } else {
        v3_10_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_17_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61389.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_17_Addr_A_orig =  (sc_lv<32>) (sext_ln1954_fu_107095_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_17_Addr_A_orig =  (sc_lv<32>) (sext_ln1674_1_fu_107020_p1.read());
        } else {
            v3_10_17_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_17_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_17_Addr_B() {
    v3_10_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_17_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage19.read(), ap_const_boolean_0))) {
        v3_10_17_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v3_10_17_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage51.read(), ap_const_boolean_0))) {
        v3_10_17_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage35.read(), ap_const_boolean_0))) {
        v3_10_17_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_10_17_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_17_Clk_A() {
    v3_10_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_17_Clk_B() {
    v3_10_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_17_Din_A() {
    v3_10_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_17_Din_B() {
    v3_10_17_Din_B = grp_fu_96218_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_17_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_17_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_92_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_17_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_91_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)))) {
        v3_10_17_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)))) {
        v3_10_17_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)))) {
        v3_10_17_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v3_10_17_EN_A = grp_aesl_mux_load_65_4_x_fu_87351_empty_15_EN_A.read();
    } else {
        v3_10_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_17_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19_11001.read(), ap_const_boolean_0)))) {
        v3_10_17_EN_B = ap_const_logic_1;
    } else {
        v3_10_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_17_Rst_A() {
    v3_10_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_17_Rst_B() {
    v3_10_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_17_WEN_A() {
    v3_10_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_asdse::thread_v3_10_17_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage35.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage35_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(ap_const_lv8_A, trunc_ln2222_reg_132512.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage51.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage51_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512.read(), ap_const_lv8_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage19_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,8,8>(trunc_ln2222_reg_132512_pp2_iter1_reg.read(), ap_const_lv8_7)))) {
        v3_10_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_18_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_93_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_18_Addr_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_92_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)))) {
        v3_10_18_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)))) {
        v3_10_18_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)))) {
        v3_10_18_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v3_10_18_Addr_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_Addr_A.read();
    } else {
        v3_10_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_asdse::thread_v3_10_18_Addr_A_orig() {
    if (esl_seteq<1,1,1>(ap_condition_61389.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5)) {
            v3_10_18_Addr_A_orig =  (sc_lv<32>) (sext_ln1968_fu_107796_p1.read());
        } else if (esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A)) {
            v3_10_18_Addr_A_orig =  (sc_lv<32>) (sext_ln1688_1_fu_107721_p1.read());
        } else {
            v3_10_18_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v3_10_18_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_18_Addr_B() {
    v3_10_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_asdse::thread_v3_10_18_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage20.read(), ap_const_boolean_0))) {
        v3_10_18_Addr_B_orig =  (sc_lv<32>) (sext_ln2706_1_reg_136126.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v3_10_18_Addr_B_orig =  (sc_lv<32>) (sext_ln2546_1_reg_134947.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage52.read(), ap_const_boolean_0))) {
        v3_10_18_Addr_B_orig =  (sc_lv<32>) (sext_ln2386_1_reg_133773.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage36.read(), ap_const_boolean_0))) {
        v3_10_18_Addr_B_orig =  (sc_lv<32>) (sext_ln2226_1_reg_132584.read());
    } else {
        v3_10_18_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_asdse::thread_v3_10_18_Clk_A() {
    v3_10_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_18_Clk_B() {
    v3_10_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_asdse::thread_v3_10_18_Din_A() {
    v3_10_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_asdse::thread_v3_10_18_Din_B() {
    v3_10_18_Din_B = grp_fu_96214_p2.read();
}

void kernel_correlation_asdse::thread_v3_10_18_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_5) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1656_reg_114380_pp1_iter1_reg.read()) && 
          esl_seteq<1,8,8>(urem_ln1656_reg_114535.read(), ap_const_lv8_A) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,6,6>(ap_const_lv6_0, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_4, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_8, trunc_ln1659_fu_106289_p1.read()) && 
          !esl_seteq<1,6,6>(ap_const_lv6_C, trunc_ln1659_fu_106289_p1.read())))) {
        v3_10_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2867_reg_137300_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, select_ln2868_1_reg_137408_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)))) {
        v3_10_18_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_93_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read())) || 
                (esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(select_ln2868_1_reg_137408_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(icmp_ln2867_reg_137300_pp3_iter3_reg.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read())))) {
        v3_10_18_EN_A = grp_aesl_mux_load_20_4_x_fu_93028_empty_92_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage21.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage22.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage22.read(), ap_const_boolean_0)))) {
        v3_10_18_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage37.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage37.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage38.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage38.read(), ap_const_boolean_0)))) {
        v3_10_18_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage53.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage53.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln2222_reg_132119.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage54.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage54.read(), ap_const_boolean_0)))) {
        v3_10_18_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v3_10_18_EN_A = grp_aesl_mux_load_65_4_x_fu_87214_empty_15_EN_A.read();
    } else {
        v3_10_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_18_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage36.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage36_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage52.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage52_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage20_11001.read(), ap_const_boolean_0)))) {
        v3_10_18_EN_B = ap_const_logic_1;
    } else {
        v3_10_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_asdse::thread_v3_10_18_Rst_A() {
    v3_10_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_asdse::thread_v3_10_18_Rst_B() {
    v3_10_18_Rst_B = ap_rst_n_inv.read();
}

}


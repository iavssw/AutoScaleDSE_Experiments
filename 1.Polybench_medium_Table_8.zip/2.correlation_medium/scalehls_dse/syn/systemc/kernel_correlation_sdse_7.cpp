#include "kernel_correlation_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_correlation_sdse::thread_v3_10_21_Din_A() {
    v3_10_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_21_Din_B() {
    v3_10_21_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_429_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_428_EN_A.read();
    } else {
        v3_10_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_21_EN_B = ap_const_logic_1;
    } else {
        v3_10_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_21_Rst_A() {
    v3_10_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_21_Rst_B() {
    v3_10_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_21_WEN_A() {
    v3_10_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_430_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_429_Addr_A.read();
    } else {
        v3_10_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_22_Addr_A_orig() {
    v3_10_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_22_Addr_B() {
    v3_10_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_22_Addr_B_orig() {
    v3_10_22_Addr_B_orig =  (sc_lv<32>) (v3_10_22_addr_reg_63482.read());
}

void kernel_correlation_sdse::thread_v3_10_22_Clk_A() {
    v3_10_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_22_Clk_B() {
    v3_10_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_22_Din_A() {
    v3_10_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_22_Din_B() {
    v3_10_22_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_430_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_429_EN_A.read();
    } else {
        v3_10_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_22_EN_B = ap_const_logic_1;
    } else {
        v3_10_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_22_Rst_A() {
    v3_10_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_22_Rst_B() {
    v3_10_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_22_WEN_A() {
    v3_10_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_431_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_430_Addr_A.read();
    } else {
        v3_10_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_23_Addr_A_orig() {
    v3_10_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_23_Addr_B() {
    v3_10_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_23_Addr_B_orig() {
    v3_10_23_Addr_B_orig =  (sc_lv<32>) (v3_10_23_addr_reg_65142.read());
}

void kernel_correlation_sdse::thread_v3_10_23_Clk_A() {
    v3_10_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_23_Clk_B() {
    v3_10_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_23_Din_A() {
    v3_10_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_23_Din_B() {
    v3_10_23_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_431_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_430_EN_A.read();
    } else {
        v3_10_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_23_EN_B = ap_const_logic_1;
    } else {
        v3_10_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_23_Rst_A() {
    v3_10_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_23_Rst_B() {
    v3_10_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_23_WEN_A() {
    v3_10_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_432_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_431_Addr_A.read();
    } else {
        v3_10_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_24_Addr_A_orig() {
    v3_10_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_24_Addr_B() {
    v3_10_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_24_Addr_B_orig() {
    v3_10_24_Addr_B_orig =  (sc_lv<32>) (v3_10_24_addr_reg_60168.read());
}

void kernel_correlation_sdse::thread_v3_10_24_Clk_A() {
    v3_10_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_24_Clk_B() {
    v3_10_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_24_Din_A() {
    v3_10_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_24_Din_B() {
    v3_10_24_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_432_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_431_EN_A.read();
    } else {
        v3_10_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_24_EN_B = ap_const_logic_1;
    } else {
        v3_10_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_24_Rst_A() {
    v3_10_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_24_Rst_B() {
    v3_10_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_24_WEN_A() {
    v3_10_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_433_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_432_Addr_A.read();
    } else {
        v3_10_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_25_Addr_A_orig() {
    v3_10_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_25_Addr_B() {
    v3_10_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_25_Addr_B_orig() {
    v3_10_25_Addr_B_orig =  (sc_lv<32>) (v3_10_25_addr_reg_61828.read());
}

void kernel_correlation_sdse::thread_v3_10_25_Clk_A() {
    v3_10_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_25_Clk_B() {
    v3_10_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_25_Din_A() {
    v3_10_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_25_Din_B() {
    v3_10_25_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_433_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_432_EN_A.read();
    } else {
        v3_10_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_25_EN_B = ap_const_logic_1;
    } else {
        v3_10_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_25_Rst_A() {
    v3_10_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_25_Rst_B() {
    v3_10_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_25_WEN_A() {
    v3_10_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_434_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_433_Addr_A.read();
    } else {
        v3_10_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_26_Addr_A_orig() {
    v3_10_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_26_Addr_B() {
    v3_10_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_26_Addr_B_orig() {
    v3_10_26_Addr_B_orig =  (sc_lv<32>) (v3_10_26_addr_reg_63488.read());
}

void kernel_correlation_sdse::thread_v3_10_26_Clk_A() {
    v3_10_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_26_Clk_B() {
    v3_10_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_26_Din_A() {
    v3_10_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_26_Din_B() {
    v3_10_26_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_434_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_433_EN_A.read();
    } else {
        v3_10_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_26_EN_B = ap_const_logic_1;
    } else {
        v3_10_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_26_Rst_A() {
    v3_10_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_26_Rst_B() {
    v3_10_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_26_WEN_A() {
    v3_10_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_435_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_434_Addr_A.read();
    } else {
        v3_10_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_27_Addr_A_orig() {
    v3_10_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_27_Addr_B() {
    v3_10_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_27_Addr_B_orig() {
    v3_10_27_Addr_B_orig =  (sc_lv<32>) (v3_10_27_addr_reg_65148.read());
}

void kernel_correlation_sdse::thread_v3_10_27_Clk_A() {
    v3_10_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_27_Clk_B() {
    v3_10_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_27_Din_A() {
    v3_10_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_27_Din_B() {
    v3_10_27_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_435_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_434_EN_A.read();
    } else {
        v3_10_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_27_EN_B = ap_const_logic_1;
    } else {
        v3_10_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_27_Rst_A() {
    v3_10_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_27_Rst_B() {
    v3_10_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_27_WEN_A() {
    v3_10_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_436_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_435_Addr_A.read();
    } else {
        v3_10_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_28_Addr_A_orig() {
    v3_10_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_28_Addr_B() {
    v3_10_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_28_Addr_B_orig() {
    v3_10_28_Addr_B_orig =  (sc_lv<32>) (v3_10_28_addr_reg_60174.read());
}

void kernel_correlation_sdse::thread_v3_10_28_Clk_A() {
    v3_10_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_28_Clk_B() {
    v3_10_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_28_Din_A() {
    v3_10_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_28_Din_B() {
    v3_10_28_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_436_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_435_EN_A.read();
    } else {
        v3_10_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_28_EN_B = ap_const_logic_1;
    } else {
        v3_10_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_28_Rst_A() {
    v3_10_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_28_Rst_B() {
    v3_10_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_28_WEN_A() {
    v3_10_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_437_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_436_Addr_A.read();
    } else {
        v3_10_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_29_Addr_A_orig() {
    v3_10_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_29_Addr_B() {
    v3_10_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_29_Addr_B_orig() {
    v3_10_29_Addr_B_orig =  (sc_lv<32>) (v3_10_29_addr_reg_61834.read());
}

void kernel_correlation_sdse::thread_v3_10_29_Clk_A() {
    v3_10_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_29_Clk_B() {
    v3_10_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_29_Din_A() {
    v3_10_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_29_Din_B() {
    v3_10_29_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_437_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_436_EN_A.read();
    } else {
        v3_10_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_29_EN_B = ap_const_logic_1;
    } else {
        v3_10_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_29_Rst_A() {
    v3_10_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_29_Rst_B() {
    v3_10_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_29_WEN_A() {
    v3_10_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_410_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_409_Addr_A.read();
    } else {
        v3_10_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_2_Addr_A_orig() {
    v3_10_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_2_Addr_B() {
    v3_10_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_2_Addr_B_orig() {
    v3_10_2_Addr_B_orig =  (sc_lv<32>) (v3_10_2_addr_reg_63452.read());
}

void kernel_correlation_sdse::thread_v3_10_2_Clk_A() {
    v3_10_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_2_Clk_B() {
    v3_10_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_2_Din_A() {
    v3_10_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_2_Din_B() {
    v3_10_2_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_410_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_409_EN_A.read();
    } else {
        v3_10_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_2_EN_B = ap_const_logic_1;
    } else {
        v3_10_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_2_Rst_A() {
    v3_10_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_2_Rst_B() {
    v3_10_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_2_WEN_A() {
    v3_10_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_438_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_437_Addr_A.read();
    } else {
        v3_10_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_30_Addr_A_orig() {
    v3_10_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_30_Addr_B() {
    v3_10_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_30_Addr_B_orig() {
    v3_10_30_Addr_B_orig =  (sc_lv<32>) (v3_10_30_addr_reg_63494.read());
}

void kernel_correlation_sdse::thread_v3_10_30_Clk_A() {
    v3_10_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_30_Clk_B() {
    v3_10_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_30_Din_A() {
    v3_10_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_30_Din_B() {
    v3_10_30_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_438_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_437_EN_A.read();
    } else {
        v3_10_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_30_EN_B = ap_const_logic_1;
    } else {
        v3_10_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_30_Rst_A() {
    v3_10_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_30_Rst_B() {
    v3_10_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_30_WEN_A() {
    v3_10_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_439_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_438_Addr_A.read();
    } else {
        v3_10_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_31_Addr_A_orig() {
    v3_10_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_31_Addr_B() {
    v3_10_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_31_Addr_B_orig() {
    v3_10_31_Addr_B_orig =  (sc_lv<32>) (v3_10_31_addr_reg_65154.read());
}

void kernel_correlation_sdse::thread_v3_10_31_Clk_A() {
    v3_10_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_31_Clk_B() {
    v3_10_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_31_Din_A() {
    v3_10_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_31_Din_B() {
    v3_10_31_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_439_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_438_EN_A.read();
    } else {
        v3_10_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_31_EN_B = ap_const_logic_1;
    } else {
        v3_10_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_31_Rst_A() {
    v3_10_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_31_Rst_B() {
    v3_10_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_31_WEN_A() {
    v3_10_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_31_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_32_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_440_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_439_Addr_A.read();
    } else {
        v3_10_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_32_Addr_A_orig() {
    v3_10_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_32_Addr_B() {
    v3_10_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_32_Addr_B_orig() {
    v3_10_32_Addr_B_orig =  (sc_lv<32>) (v3_10_32_addr_reg_60180.read());
}

void kernel_correlation_sdse::thread_v3_10_32_Clk_A() {
    v3_10_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_32_Clk_B() {
    v3_10_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_32_Din_A() {
    v3_10_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_32_Din_B() {
    v3_10_32_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_32_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_440_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_439_EN_A.read();
    } else {
        v3_10_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_32_EN_B = ap_const_logic_1;
    } else {
        v3_10_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_32_Rst_A() {
    v3_10_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_32_Rst_B() {
    v3_10_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_32_WEN_A() {
    v3_10_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_32_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_33_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_441_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_440_Addr_A.read();
    } else {
        v3_10_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_33_Addr_A_orig() {
    v3_10_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_33_Addr_B() {
    v3_10_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_33_Addr_B_orig() {
    v3_10_33_Addr_B_orig =  (sc_lv<32>) (v3_10_33_addr_reg_61840.read());
}

void kernel_correlation_sdse::thread_v3_10_33_Clk_A() {
    v3_10_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_33_Clk_B() {
    v3_10_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_33_Din_A() {
    v3_10_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_33_Din_B() {
    v3_10_33_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_33_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_441_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_440_EN_A.read();
    } else {
        v3_10_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_33_EN_B = ap_const_logic_1;
    } else {
        v3_10_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_33_Rst_A() {
    v3_10_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_33_Rst_B() {
    v3_10_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_33_WEN_A() {
    v3_10_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_33_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_34_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_442_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_441_Addr_A.read();
    } else {
        v3_10_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_34_Addr_A_orig() {
    v3_10_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_34_Addr_B() {
    v3_10_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_34_Addr_B_orig() {
    v3_10_34_Addr_B_orig =  (sc_lv<32>) (v3_10_34_addr_reg_63500.read());
}

void kernel_correlation_sdse::thread_v3_10_34_Clk_A() {
    v3_10_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_34_Clk_B() {
    v3_10_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_34_Din_A() {
    v3_10_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_34_Din_B() {
    v3_10_34_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_34_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_442_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_441_EN_A.read();
    } else {
        v3_10_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_34_EN_B = ap_const_logic_1;
    } else {
        v3_10_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_34_Rst_A() {
    v3_10_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_34_Rst_B() {
    v3_10_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_34_WEN_A() {
    v3_10_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_34_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_35_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_443_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_442_Addr_A.read();
    } else {
        v3_10_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_35_Addr_A_orig() {
    v3_10_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_35_Addr_B() {
    v3_10_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_35_Addr_B_orig() {
    v3_10_35_Addr_B_orig =  (sc_lv<32>) (v3_10_35_addr_reg_65160.read());
}

void kernel_correlation_sdse::thread_v3_10_35_Clk_A() {
    v3_10_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_35_Clk_B() {
    v3_10_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_35_Din_A() {
    v3_10_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_35_Din_B() {
    v3_10_35_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_35_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_443_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_442_EN_A.read();
    } else {
        v3_10_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_35_EN_B = ap_const_logic_1;
    } else {
        v3_10_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_35_Rst_A() {
    v3_10_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_35_Rst_B() {
    v3_10_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_35_WEN_A() {
    v3_10_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_35_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_36_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_444_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_443_Addr_A.read();
    } else {
        v3_10_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_36_Addr_A_orig() {
    v3_10_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_36_Addr_B() {
    v3_10_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_36_Addr_B_orig() {
    v3_10_36_Addr_B_orig =  (sc_lv<32>) (v3_10_36_addr_reg_60186.read());
}

void kernel_correlation_sdse::thread_v3_10_36_Clk_A() {
    v3_10_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_36_Clk_B() {
    v3_10_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_36_Din_A() {
    v3_10_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_36_Din_B() {
    v3_10_36_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_36_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_444_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_443_EN_A.read();
    } else {
        v3_10_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_36_EN_B = ap_const_logic_1;
    } else {
        v3_10_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_36_Rst_A() {
    v3_10_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_36_Rst_B() {
    v3_10_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_36_WEN_A() {
    v3_10_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_36_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_37_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_445_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_444_Addr_A.read();
    } else {
        v3_10_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_37_Addr_A_orig() {
    v3_10_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_37_Addr_B() {
    v3_10_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_37_Addr_B_orig() {
    v3_10_37_Addr_B_orig =  (sc_lv<32>) (v3_10_37_addr_reg_61846.read());
}

void kernel_correlation_sdse::thread_v3_10_37_Clk_A() {
    v3_10_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_37_Clk_B() {
    v3_10_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_37_Din_A() {
    v3_10_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_37_Din_B() {
    v3_10_37_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_445_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_444_EN_A.read();
    } else {
        v3_10_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_37_EN_B = ap_const_logic_1;
    } else {
        v3_10_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_37_Rst_A() {
    v3_10_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_37_Rst_B() {
    v3_10_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_37_WEN_A() {
    v3_10_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_446_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_445_Addr_A.read();
    } else {
        v3_10_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_38_Addr_A_orig() {
    v3_10_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_38_Addr_B() {
    v3_10_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_38_Addr_B_orig() {
    v3_10_38_Addr_B_orig =  (sc_lv<32>) (v3_10_38_addr_reg_63506.read());
}

void kernel_correlation_sdse::thread_v3_10_38_Clk_A() {
    v3_10_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_38_Clk_B() {
    v3_10_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_38_Din_A() {
    v3_10_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_38_Din_B() {
    v3_10_38_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_446_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_445_EN_A.read();
    } else {
        v3_10_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_38_EN_B = ap_const_logic_1;
    } else {
        v3_10_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_38_Rst_A() {
    v3_10_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_38_Rst_B() {
    v3_10_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_38_WEN_A() {
    v3_10_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_447_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_446_Addr_A.read();
    } else {
        v3_10_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_39_Addr_A_orig() {
    v3_10_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_39_Addr_B() {
    v3_10_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_39_Addr_B_orig() {
    v3_10_39_Addr_B_orig =  (sc_lv<32>) (v3_10_39_addr_reg_65166.read());
}

void kernel_correlation_sdse::thread_v3_10_39_Clk_A() {
    v3_10_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_39_Clk_B() {
    v3_10_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_39_Din_A() {
    v3_10_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_39_Din_B() {
    v3_10_39_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_447_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_446_EN_A.read();
    } else {
        v3_10_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_39_EN_B = ap_const_logic_1;
    } else {
        v3_10_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_39_Rst_A() {
    v3_10_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_39_Rst_B() {
    v3_10_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_39_WEN_A() {
    v3_10_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_411_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_410_Addr_A.read();
    } else {
        v3_10_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_3_Addr_A_orig() {
    v3_10_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_3_Addr_B() {
    v3_10_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_3_Addr_B_orig() {
    v3_10_3_Addr_B_orig =  (sc_lv<32>) (v3_10_3_addr_reg_65112.read());
}

void kernel_correlation_sdse::thread_v3_10_3_Clk_A() {
    v3_10_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_3_Clk_B() {
    v3_10_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_3_Din_A() {
    v3_10_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_3_Din_B() {
    v3_10_3_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_411_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_410_EN_A.read();
    } else {
        v3_10_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_3_EN_B = ap_const_logic_1;
    } else {
        v3_10_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_3_Rst_A() {
    v3_10_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_3_Rst_B() {
    v3_10_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_3_WEN_A() {
    v3_10_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_412_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_411_Addr_A.read();
    } else {
        v3_10_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_4_Addr_A_orig() {
    v3_10_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_4_Addr_B() {
    v3_10_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_4_Addr_B_orig() {
    v3_10_4_Addr_B_orig =  (sc_lv<32>) (v3_10_4_addr_reg_60138.read());
}

void kernel_correlation_sdse::thread_v3_10_4_Clk_A() {
    v3_10_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_4_Clk_B() {
    v3_10_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_4_Din_A() {
    v3_10_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_4_Din_B() {
    v3_10_4_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_412_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_411_EN_A.read();
    } else {
        v3_10_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_4_EN_B = ap_const_logic_1;
    } else {
        v3_10_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_4_Rst_A() {
    v3_10_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_4_Rst_B() {
    v3_10_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_4_WEN_A() {
    v3_10_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_413_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_412_Addr_A.read();
    } else {
        v3_10_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_5_Addr_A_orig() {
    v3_10_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_5_Addr_B() {
    v3_10_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_5_Addr_B_orig() {
    v3_10_5_Addr_B_orig =  (sc_lv<32>) (v3_10_5_addr_reg_61798.read());
}

void kernel_correlation_sdse::thread_v3_10_5_Clk_A() {
    v3_10_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_5_Clk_B() {
    v3_10_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_5_Din_A() {
    v3_10_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_5_Din_B() {
    v3_10_5_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_413_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_412_EN_A.read();
    } else {
        v3_10_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_5_EN_B = ap_const_logic_1;
    } else {
        v3_10_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_5_Rst_A() {
    v3_10_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_5_Rst_B() {
    v3_10_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_5_WEN_A() {
    v3_10_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_414_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_413_Addr_A.read();
    } else {
        v3_10_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_6_Addr_A_orig() {
    v3_10_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_6_Addr_B() {
    v3_10_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_6_Addr_B_orig() {
    v3_10_6_Addr_B_orig =  (sc_lv<32>) (v3_10_6_addr_reg_63458.read());
}

void kernel_correlation_sdse::thread_v3_10_6_Clk_A() {
    v3_10_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_6_Clk_B() {
    v3_10_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_6_Din_A() {
    v3_10_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_6_Din_B() {
    v3_10_6_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_414_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_413_EN_A.read();
    } else {
        v3_10_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_6_EN_B = ap_const_logic_1;
    } else {
        v3_10_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_6_Rst_A() {
    v3_10_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_6_Rst_B() {
    v3_10_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_6_WEN_A() {
    v3_10_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_6_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_415_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_414_Addr_A.read();
    } else {
        v3_10_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_7_Addr_A_orig() {
    v3_10_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_7_Addr_B() {
    v3_10_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_7_Addr_B_orig() {
    v3_10_7_Addr_B_orig =  (sc_lv<32>) (v3_10_7_addr_reg_65118.read());
}

void kernel_correlation_sdse::thread_v3_10_7_Clk_A() {
    v3_10_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_7_Clk_B() {
    v3_10_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_7_Din_A() {
    v3_10_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_7_Din_B() {
    v3_10_7_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_415_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_414_EN_A.read();
    } else {
        v3_10_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_7_EN_B = ap_const_logic_1;
    } else {
        v3_10_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_7_Rst_A() {
    v3_10_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_7_Rst_B() {
    v3_10_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_7_WEN_A() {
    v3_10_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_7_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_416_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_415_Addr_A.read();
    } else {
        v3_10_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_8_Addr_A_orig() {
    v3_10_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_8_Addr_B() {
    v3_10_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_8_Addr_B_orig() {
    v3_10_8_Addr_B_orig =  (sc_lv<32>) (v3_10_8_addr_reg_60144.read());
}

void kernel_correlation_sdse::thread_v3_10_8_Clk_A() {
    v3_10_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_8_Clk_B() {
    v3_10_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_8_Din_A() {
    v3_10_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_8_Din_B() {
    v3_10_8_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_416_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_415_EN_A.read();
    } else {
        v3_10_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_8_EN_B = ap_const_logic_1;
    } else {
        v3_10_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_8_Rst_A() {
    v3_10_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_8_Rst_B() {
    v3_10_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_8_WEN_A() {
    v3_10_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_8_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_417_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_416_Addr_A.read();
    } else {
        v3_10_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_9_Addr_A_orig() {
    v3_10_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_9_Addr_B() {
    v3_10_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_9_Addr_B_orig() {
    v3_10_9_Addr_B_orig =  (sc_lv<32>) (v3_10_9_addr_reg_61804.read());
}

void kernel_correlation_sdse::thread_v3_10_9_Clk_A() {
    v3_10_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_9_Clk_B() {
    v3_10_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_9_Din_A() {
    v3_10_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_9_Din_B() {
    v3_10_9_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_417_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_416_EN_A.read();
    } else {
        v3_10_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_9_EN_B = ap_const_logic_1;
    } else {
        v3_10_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_9_Rst_A() {
    v3_10_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_9_Rst_B() {
    v3_10_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_9_WEN_A() {
    v3_10_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_9_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_487_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_448_Addr_A.read();
    } else {
        v3_11_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_0_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_0_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_0_Addr_B() {
    v3_11_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_0_Addr_B_orig() {
    v3_11_0_Addr_B_orig =  (sc_lv<32>) (v3_11_0_addr_2_reg_60192.read());
}

void kernel_correlation_sdse::thread_v3_11_0_Clk_A() {
    v3_11_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_0_Clk_B() {
    v3_11_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_0_Din_A() {
    v3_11_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_0_Din_B() {
    v3_11_0_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_487_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_448_EN_A.read();
    } else {
        v3_11_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_0_EN_B = ap_const_logic_1;
    } else {
        v3_11_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_0_Rst_A() {
    v3_11_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_0_Rst_B() {
    v3_11_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_0_WEN_A() {
    v3_11_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_458_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_457_Addr_A.read();
    } else {
        v3_11_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_10_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_10_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_10_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_10_Addr_B() {
    v3_11_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_10_Addr_B_orig() {
    v3_11_10_Addr_B_orig =  (sc_lv<32>) (v3_11_10_addr_2_reg_63524.read());
}

void kernel_correlation_sdse::thread_v3_11_10_Clk_A() {
    v3_11_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_10_Clk_B() {
    v3_11_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_10_Din_A() {
    v3_11_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_10_Din_B() {
    v3_11_10_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_10_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_458_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_457_EN_A.read();
    } else {
        v3_11_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_10_EN_B = ap_const_logic_1;
    } else {
        v3_11_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_10_Rst_A() {
    v3_11_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_10_Rst_B() {
    v3_11_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_10_WEN_A() {
    v3_11_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_459_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_458_Addr_A.read();
    } else {
        v3_11_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_11_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_11_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_11_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_11_Addr_B() {
    v3_11_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_11_Addr_B_orig() {
    v3_11_11_Addr_B_orig =  (sc_lv<32>) (v3_11_11_addr_2_reg_65184.read());
}

void kernel_correlation_sdse::thread_v3_11_11_Clk_A() {
    v3_11_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_11_Clk_B() {
    v3_11_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_11_Din_A() {
    v3_11_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_11_Din_B() {
    v3_11_11_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_11_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_459_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_458_EN_A.read();
    } else {
        v3_11_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_11_EN_B = ap_const_logic_1;
    } else {
        v3_11_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_11_Rst_A() {
    v3_11_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_11_Rst_B() {
    v3_11_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_11_WEN_A() {
    v3_11_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_460_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_459_Addr_A.read();
    } else {
        v3_11_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_12_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_12_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_12_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_12_Addr_B() {
    v3_11_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_12_Addr_B_orig() {
    v3_11_12_Addr_B_orig =  (sc_lv<32>) (v3_11_12_addr_2_reg_60210.read());
}

void kernel_correlation_sdse::thread_v3_11_12_Clk_A() {
    v3_11_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_12_Clk_B() {
    v3_11_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_12_Din_A() {
    v3_11_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_12_Din_B() {
    v3_11_12_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_12_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_460_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_459_EN_A.read();
    } else {
        v3_11_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_12_EN_B = ap_const_logic_1;
    } else {
        v3_11_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_12_Rst_A() {
    v3_11_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_12_Rst_B() {
    v3_11_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_12_WEN_A() {
    v3_11_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_461_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_460_Addr_A.read();
    } else {
        v3_11_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_13_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_13_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_13_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_13_Addr_B() {
    v3_11_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_13_Addr_B_orig() {
    v3_11_13_Addr_B_orig =  (sc_lv<32>) (v3_11_13_addr_2_reg_61870.read());
}

void kernel_correlation_sdse::thread_v3_11_13_Clk_A() {
    v3_11_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_13_Clk_B() {
    v3_11_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_13_Din_A() {
    v3_11_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_13_Din_B() {
    v3_11_13_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_13_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_461_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_460_EN_A.read();
    } else {
        v3_11_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_13_EN_B = ap_const_logic_1;
    } else {
        v3_11_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_13_Rst_A() {
    v3_11_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_13_Rst_B() {
    v3_11_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_13_WEN_A() {
    v3_11_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_462_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_461_Addr_A.read();
    } else {
        v3_11_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_14_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_14_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_14_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_14_Addr_B() {
    v3_11_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_14_Addr_B_orig() {
    v3_11_14_Addr_B_orig =  (sc_lv<32>) (v3_11_14_addr_2_reg_63530.read());
}

void kernel_correlation_sdse::thread_v3_11_14_Clk_A() {
    v3_11_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_14_Clk_B() {
    v3_11_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_14_Din_A() {
    v3_11_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_14_Din_B() {
    v3_11_14_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_14_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_462_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_461_EN_A.read();
    } else {
        v3_11_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_14_EN_B = ap_const_logic_1;
    } else {
        v3_11_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_14_Rst_A() {
    v3_11_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_14_Rst_B() {
    v3_11_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_14_WEN_A() {
    v3_11_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_463_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_462_Addr_A.read();
    } else {
        v3_11_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_15_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_15_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_15_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_15_Addr_B() {
    v3_11_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_15_Addr_B_orig() {
    v3_11_15_Addr_B_orig =  (sc_lv<32>) (v3_11_15_addr_2_reg_65190.read());
}

void kernel_correlation_sdse::thread_v3_11_15_Clk_A() {
    v3_11_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_15_Clk_B() {
    v3_11_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_15_Din_A() {
    v3_11_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_15_Din_B() {
    v3_11_15_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_15_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_463_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_462_EN_A.read();
    } else {
        v3_11_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_15_EN_B = ap_const_logic_1;
    } else {
        v3_11_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_15_Rst_A() {
    v3_11_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_15_Rst_B() {
    v3_11_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_15_WEN_A() {
    v3_11_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_464_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_463_Addr_A.read();
    } else {
        v3_11_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_16_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_16_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_16_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_16_Addr_B() {
    v3_11_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_16_Addr_B_orig() {
    v3_11_16_Addr_B_orig =  (sc_lv<32>) (v3_11_16_addr_2_reg_60216.read());
}

void kernel_correlation_sdse::thread_v3_11_16_Clk_A() {
    v3_11_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_16_Clk_B() {
    v3_11_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_16_Din_A() {
    v3_11_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_16_Din_B() {
    v3_11_16_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_16_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_464_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_463_EN_A.read();
    } else {
        v3_11_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_16_EN_B = ap_const_logic_1;
    } else {
        v3_11_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_16_Rst_A() {
    v3_11_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_16_Rst_B() {
    v3_11_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_16_WEN_A() {
    v3_11_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_465_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_464_Addr_A.read();
    } else {
        v3_11_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_17_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_17_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_17_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_17_Addr_B() {
    v3_11_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_17_Addr_B_orig() {
    v3_11_17_Addr_B_orig =  (sc_lv<32>) (v3_11_17_addr_2_reg_61876.read());
}

void kernel_correlation_sdse::thread_v3_11_17_Clk_A() {
    v3_11_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_17_Clk_B() {
    v3_11_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_17_Din_A() {
    v3_11_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_17_Din_B() {
    v3_11_17_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_17_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_465_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_464_EN_A.read();
    } else {
        v3_11_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_17_EN_B = ap_const_logic_1;
    } else {
        v3_11_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_17_Rst_A() {
    v3_11_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_17_Rst_B() {
    v3_11_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_17_WEN_A() {
    v3_11_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_466_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_465_Addr_A.read();
    } else {
        v3_11_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_18_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_18_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_18_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_18_Addr_B() {
    v3_11_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_18_Addr_B_orig() {
    v3_11_18_Addr_B_orig =  (sc_lv<32>) (v3_11_18_addr_2_reg_63536.read());
}

void kernel_correlation_sdse::thread_v3_11_18_Clk_A() {
    v3_11_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_18_Clk_B() {
    v3_11_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_18_Din_A() {
    v3_11_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_18_Din_B() {
    v3_11_18_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_18_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_466_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_465_EN_A.read();
    } else {
        v3_11_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_18_EN_B = ap_const_logic_1;
    } else {
        v3_11_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_18_Rst_A() {
    v3_11_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_18_Rst_B() {
    v3_11_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_18_WEN_A() {
    v3_11_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_467_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_466_Addr_A.read();
    } else {
        v3_11_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_19_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_19_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_19_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_19_Addr_B() {
    v3_11_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_19_Addr_B_orig() {
    v3_11_19_Addr_B_orig =  (sc_lv<32>) (v3_11_19_addr_2_reg_65196.read());
}

void kernel_correlation_sdse::thread_v3_11_19_Clk_A() {
    v3_11_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_19_Clk_B() {
    v3_11_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_19_Din_A() {
    v3_11_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_19_Din_B() {
    v3_11_19_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_19_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_467_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_466_EN_A.read();
    } else {
        v3_11_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_19_EN_B = ap_const_logic_1;
    } else {
        v3_11_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_19_Rst_A() {
    v3_11_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_19_Rst_B() {
    v3_11_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_19_WEN_A() {
    v3_11_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_449_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_448_Addr_A.read();
    } else {
        v3_11_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_1_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_1_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_1_Addr_B() {
    v3_11_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_1_Addr_B_orig() {
    v3_11_1_Addr_B_orig =  (sc_lv<32>) (v3_11_1_addr_2_reg_61852.read());
}

void kernel_correlation_sdse::thread_v3_11_1_Clk_A() {
    v3_11_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_1_Clk_B() {
    v3_11_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_1_Din_A() {
    v3_11_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_1_Din_B() {
    v3_11_1_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_449_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_448_EN_A.read();
    } else {
        v3_11_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_1_EN_B = ap_const_logic_1;
    } else {
        v3_11_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_1_Rst_A() {
    v3_11_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_1_Rst_B() {
    v3_11_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_1_WEN_A() {
    v3_11_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_468_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_467_Addr_A.read();
    } else {
        v3_11_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_20_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_20_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_20_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_20_Addr_B() {
    v3_11_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_20_Addr_B_orig() {
    v3_11_20_Addr_B_orig =  (sc_lv<32>) (v3_11_20_addr_2_reg_60222.read());
}

void kernel_correlation_sdse::thread_v3_11_20_Clk_A() {
    v3_11_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_20_Clk_B() {
    v3_11_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_20_Din_A() {
    v3_11_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_20_Din_B() {
    v3_11_20_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_20_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_468_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_467_EN_A.read();
    } else {
        v3_11_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_20_EN_B = ap_const_logic_1;
    } else {
        v3_11_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_20_Rst_A() {
    v3_11_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_20_Rst_B() {
    v3_11_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_20_WEN_A() {
    v3_11_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_469_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_468_Addr_A.read();
    } else {
        v3_11_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_21_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_21_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_21_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_21_Addr_B() {
    v3_11_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_21_Addr_B_orig() {
    v3_11_21_Addr_B_orig =  (sc_lv<32>) (v3_11_21_addr_2_reg_61882.read());
}

void kernel_correlation_sdse::thread_v3_11_21_Clk_A() {
    v3_11_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_21_Clk_B() {
    v3_11_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_21_Din_A() {
    v3_11_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_21_Din_B() {
    v3_11_21_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_21_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_469_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_468_EN_A.read();
    } else {
        v3_11_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_21_EN_B = ap_const_logic_1;
    } else {
        v3_11_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_21_Rst_A() {
    v3_11_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_21_Rst_B() {
    v3_11_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_21_WEN_A() {
    v3_11_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_470_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_469_Addr_A.read();
    } else {
        v3_11_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_22_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_22_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_22_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_22_Addr_B() {
    v3_11_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_22_Addr_B_orig() {
    v3_11_22_Addr_B_orig =  (sc_lv<32>) (v3_11_22_addr_2_reg_63542.read());
}

void kernel_correlation_sdse::thread_v3_11_22_Clk_A() {
    v3_11_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_22_Clk_B() {
    v3_11_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_22_Din_A() {
    v3_11_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_22_Din_B() {
    v3_11_22_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_22_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_470_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_469_EN_A.read();
    } else {
        v3_11_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_22_EN_B = ap_const_logic_1;
    } else {
        v3_11_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_22_Rst_A() {
    v3_11_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_22_Rst_B() {
    v3_11_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_22_WEN_A() {
    v3_11_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_471_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_470_Addr_A.read();
    } else {
        v3_11_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_23_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_23_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_23_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_23_Addr_B() {
    v3_11_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_23_Addr_B_orig() {
    v3_11_23_Addr_B_orig =  (sc_lv<32>) (v3_11_23_addr_2_reg_65202.read());
}

void kernel_correlation_sdse::thread_v3_11_23_Clk_A() {
    v3_11_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_23_Clk_B() {
    v3_11_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_23_Din_A() {
    v3_11_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_23_Din_B() {
    v3_11_23_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_23_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_471_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_470_EN_A.read();
    } else {
        v3_11_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_23_EN_B = ap_const_logic_1;
    } else {
        v3_11_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_23_Rst_A() {
    v3_11_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_23_Rst_B() {
    v3_11_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_23_WEN_A() {
    v3_11_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_472_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_471_Addr_A.read();
    } else {
        v3_11_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_24_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_24_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_24_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_24_Addr_B() {
    v3_11_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_24_Addr_B_orig() {
    v3_11_24_Addr_B_orig =  (sc_lv<32>) (v3_11_24_addr_2_reg_60228.read());
}

void kernel_correlation_sdse::thread_v3_11_24_Clk_A() {
    v3_11_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_24_Clk_B() {
    v3_11_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_24_Din_A() {
    v3_11_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_24_Din_B() {
    v3_11_24_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_24_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_472_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_471_EN_A.read();
    } else {
        v3_11_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_24_EN_B = ap_const_logic_1;
    } else {
        v3_11_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_24_Rst_A() {
    v3_11_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_24_Rst_B() {
    v3_11_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_24_WEN_A() {
    v3_11_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_473_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_472_Addr_A.read();
    } else {
        v3_11_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_25_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_25_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_25_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_25_Addr_B() {
    v3_11_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_25_Addr_B_orig() {
    v3_11_25_Addr_B_orig =  (sc_lv<32>) (v3_11_25_addr_2_reg_61888.read());
}

void kernel_correlation_sdse::thread_v3_11_25_Clk_A() {
    v3_11_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_25_Clk_B() {
    v3_11_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_25_Din_A() {
    v3_11_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_25_Din_B() {
    v3_11_25_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_25_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_473_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_472_EN_A.read();
    } else {
        v3_11_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_25_EN_B = ap_const_logic_1;
    } else {
        v3_11_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_25_Rst_A() {
    v3_11_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_25_Rst_B() {
    v3_11_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_25_WEN_A() {
    v3_11_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_474_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_473_Addr_A.read();
    } else {
        v3_11_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_26_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_26_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_26_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_26_Addr_B() {
    v3_11_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_26_Addr_B_orig() {
    v3_11_26_Addr_B_orig =  (sc_lv<32>) (v3_11_26_addr_2_reg_63548.read());
}

void kernel_correlation_sdse::thread_v3_11_26_Clk_A() {
    v3_11_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_26_Clk_B() {
    v3_11_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_26_Din_A() {
    v3_11_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_26_Din_B() {
    v3_11_26_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_26_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_474_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_473_EN_A.read();
    } else {
        v3_11_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_26_EN_B = ap_const_logic_1;
    } else {
        v3_11_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_26_Rst_A() {
    v3_11_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_26_Rst_B() {
    v3_11_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_26_WEN_A() {
    v3_11_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_475_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_474_Addr_A.read();
    } else {
        v3_11_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_27_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_27_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_27_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_27_Addr_B() {
    v3_11_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_27_Addr_B_orig() {
    v3_11_27_Addr_B_orig =  (sc_lv<32>) (v3_11_27_addr_2_reg_65208.read());
}

void kernel_correlation_sdse::thread_v3_11_27_Clk_A() {
    v3_11_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_27_Clk_B() {
    v3_11_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_27_Din_A() {
    v3_11_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_27_Din_B() {
    v3_11_27_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_27_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_475_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_474_EN_A.read();
    } else {
        v3_11_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_27_EN_B = ap_const_logic_1;
    } else {
        v3_11_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_27_Rst_A() {
    v3_11_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_27_Rst_B() {
    v3_11_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_27_WEN_A() {
    v3_11_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_476_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_475_Addr_A.read();
    } else {
        v3_11_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_28_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_28_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_28_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_28_Addr_B() {
    v3_11_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_28_Addr_B_orig() {
    v3_11_28_Addr_B_orig =  (sc_lv<32>) (v3_11_28_addr_2_reg_60234.read());
}

void kernel_correlation_sdse::thread_v3_11_28_Clk_A() {
    v3_11_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_28_Clk_B() {
    v3_11_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_28_Din_A() {
    v3_11_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_28_Din_B() {
    v3_11_28_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_28_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_476_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_475_EN_A.read();
    } else {
        v3_11_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_28_EN_B = ap_const_logic_1;
    } else {
        v3_11_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_28_Rst_A() {
    v3_11_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_28_Rst_B() {
    v3_11_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_28_WEN_A() {
    v3_11_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_477_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_476_Addr_A.read();
    } else {
        v3_11_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_29_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_29_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_29_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_29_Addr_B() {
    v3_11_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_29_Addr_B_orig() {
    v3_11_29_Addr_B_orig =  (sc_lv<32>) (v3_11_29_addr_2_reg_61894.read());
}

void kernel_correlation_sdse::thread_v3_11_29_Clk_A() {
    v3_11_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_29_Clk_B() {
    v3_11_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_29_Din_A() {
    v3_11_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_29_Din_B() {
    v3_11_29_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_29_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_477_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_476_EN_A.read();
    } else {
        v3_11_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_29_EN_B = ap_const_logic_1;
    } else {
        v3_11_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_29_Rst_A() {
    v3_11_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_29_Rst_B() {
    v3_11_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_29_WEN_A() {
    v3_11_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_450_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_449_Addr_A.read();
    } else {
        v3_11_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_2_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_2_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_2_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_2_Addr_B() {
    v3_11_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_2_Addr_B_orig() {
    v3_11_2_Addr_B_orig =  (sc_lv<32>) (v3_11_2_addr_2_reg_63512.read());
}

void kernel_correlation_sdse::thread_v3_11_2_Clk_A() {
    v3_11_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_2_Clk_B() {
    v3_11_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_2_Din_A() {
    v3_11_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_2_Din_B() {
    v3_11_2_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_450_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_449_EN_A.read();
    } else {
        v3_11_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_2_EN_B = ap_const_logic_1;
    } else {
        v3_11_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_2_Rst_A() {
    v3_11_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_2_Rst_B() {
    v3_11_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_2_WEN_A() {
    v3_11_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_478_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_477_Addr_A.read();
    } else {
        v3_11_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_30_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_30_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_30_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_30_Addr_B() {
    v3_11_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_30_Addr_B_orig() {
    v3_11_30_Addr_B_orig =  (sc_lv<32>) (v3_11_30_addr_2_reg_63554.read());
}

void kernel_correlation_sdse::thread_v3_11_30_Clk_A() {
    v3_11_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_30_Clk_B() {
    v3_11_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_30_Din_A() {
    v3_11_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_30_Din_B() {
    v3_11_30_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_30_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_478_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_477_EN_A.read();
    } else {
        v3_11_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_30_EN_B = ap_const_logic_1;
    } else {
        v3_11_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_30_Rst_A() {
    v3_11_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_30_Rst_B() {
    v3_11_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_30_WEN_A() {
    v3_11_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_479_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_478_Addr_A.read();
    } else {
        v3_11_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_31_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_31_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_31_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_31_Addr_B() {
    v3_11_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_31_Addr_B_orig() {
    v3_11_31_Addr_B_orig =  (sc_lv<32>) (v3_11_31_addr_2_reg_65214.read());
}

void kernel_correlation_sdse::thread_v3_11_31_Clk_A() {
    v3_11_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_31_Clk_B() {
    v3_11_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_31_Din_A() {
    v3_11_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_31_Din_B() {
    v3_11_31_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_31_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_479_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_478_EN_A.read();
    } else {
        v3_11_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_31_EN_B = ap_const_logic_1;
    } else {
        v3_11_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_31_Rst_A() {
    v3_11_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_31_Rst_B() {
    v3_11_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_31_WEN_A() {
    v3_11_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_31_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_32_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_480_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_479_Addr_A.read();
    } else {
        v3_11_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_32_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_32_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_32_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_32_Addr_B() {
    v3_11_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_32_Addr_B_orig() {
    v3_11_32_Addr_B_orig =  (sc_lv<32>) (v3_11_32_addr_2_reg_60240.read());
}

void kernel_correlation_sdse::thread_v3_11_32_Clk_A() {
    v3_11_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_32_Clk_B() {
    v3_11_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_32_Din_A() {
    v3_11_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_32_Din_B() {
    v3_11_32_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_32_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_32_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_480_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_479_EN_A.read();
    } else {
        v3_11_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_32_EN_B = ap_const_logic_1;
    } else {
        v3_11_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_32_Rst_A() {
    v3_11_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_32_Rst_B() {
    v3_11_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_32_WEN_A() {
    v3_11_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_32_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_33_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_481_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_480_Addr_A.read();
    } else {
        v3_11_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_33_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_33_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_33_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_33_Addr_B() {
    v3_11_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_33_Addr_B_orig() {
    v3_11_33_Addr_B_orig =  (sc_lv<32>) (v3_11_33_addr_2_reg_61900.read());
}

void kernel_correlation_sdse::thread_v3_11_33_Clk_A() {
    v3_11_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_33_Clk_B() {
    v3_11_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_33_Din_A() {
    v3_11_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_33_Din_B() {
    v3_11_33_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_33_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_33_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_481_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_480_EN_A.read();
    } else {
        v3_11_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_33_EN_B = ap_const_logic_1;
    } else {
        v3_11_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_33_Rst_A() {
    v3_11_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_33_Rst_B() {
    v3_11_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_33_WEN_A() {
    v3_11_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_33_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_34_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_482_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_481_Addr_A.read();
    } else {
        v3_11_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_34_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_34_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_34_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_34_Addr_B() {
    v3_11_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_34_Addr_B_orig() {
    v3_11_34_Addr_B_orig =  (sc_lv<32>) (v3_11_34_addr_2_reg_63560.read());
}

void kernel_correlation_sdse::thread_v3_11_34_Clk_A() {
    v3_11_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_34_Clk_B() {
    v3_11_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_34_Din_A() {
    v3_11_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_34_Din_B() {
    v3_11_34_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_34_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_34_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_482_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_481_EN_A.read();
    } else {
        v3_11_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_34_EN_B = ap_const_logic_1;
    } else {
        v3_11_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_34_Rst_A() {
    v3_11_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_34_Rst_B() {
    v3_11_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_34_WEN_A() {
    v3_11_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_34_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_35_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_483_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_482_Addr_A.read();
    } else {
        v3_11_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_35_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_35_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_35_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_35_Addr_B() {
    v3_11_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_35_Addr_B_orig() {
    v3_11_35_Addr_B_orig =  (sc_lv<32>) (v3_11_35_addr_2_reg_65220.read());
}

void kernel_correlation_sdse::thread_v3_11_35_Clk_A() {
    v3_11_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_35_Clk_B() {
    v3_11_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_35_Din_A() {
    v3_11_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_35_Din_B() {
    v3_11_35_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_35_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_35_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_483_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_482_EN_A.read();
    } else {
        v3_11_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_35_EN_B = ap_const_logic_1;
    } else {
        v3_11_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_35_Rst_A() {
    v3_11_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_35_Rst_B() {
    v3_11_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_35_WEN_A() {
    v3_11_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_35_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_36_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_484_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_483_Addr_A.read();
    } else {
        v3_11_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_36_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_36_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_36_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_36_Addr_B() {
    v3_11_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_36_Addr_B_orig() {
    v3_11_36_Addr_B_orig =  (sc_lv<32>) (v3_11_36_addr_2_reg_60246.read());
}

void kernel_correlation_sdse::thread_v3_11_36_Clk_A() {
    v3_11_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_36_Clk_B() {
    v3_11_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_36_Din_A() {
    v3_11_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_36_Din_B() {
    v3_11_36_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_36_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_36_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_484_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_483_EN_A.read();
    } else {
        v3_11_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_36_EN_B = ap_const_logic_1;
    } else {
        v3_11_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_36_Rst_A() {
    v3_11_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_36_Rst_B() {
    v3_11_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_36_WEN_A() {
    v3_11_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_36_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_37_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_485_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_484_Addr_A.read();
    } else {
        v3_11_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_37_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_37_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_37_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_37_Addr_B() {
    v3_11_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_37_Addr_B_orig() {
    v3_11_37_Addr_B_orig =  (sc_lv<32>) (v3_11_37_addr_2_reg_61906.read());
}

void kernel_correlation_sdse::thread_v3_11_37_Clk_A() {
    v3_11_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_37_Clk_B() {
    v3_11_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_37_Din_A() {
    v3_11_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_37_Din_B() {
    v3_11_37_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_37_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_485_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_484_EN_A.read();
    } else {
        v3_11_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_37_EN_B = ap_const_logic_1;
    } else {
        v3_11_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_37_Rst_A() {
    v3_11_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_37_Rst_B() {
    v3_11_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_37_WEN_A() {
    v3_11_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_486_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_485_Addr_A.read();
    } else {
        v3_11_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_38_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_38_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_38_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_38_Addr_B() {
    v3_11_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_38_Addr_B_orig() {
    v3_11_38_Addr_B_orig =  (sc_lv<32>) (v3_11_38_addr_2_reg_63566.read());
}

void kernel_correlation_sdse::thread_v3_11_38_Clk_A() {
    v3_11_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_38_Clk_B() {
    v3_11_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_38_Din_A() {
    v3_11_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_38_Din_B() {
    v3_11_38_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_38_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_486_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_485_EN_A.read();
    } else {
        v3_11_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_38_EN_B = ap_const_logic_1;
    } else {
        v3_11_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_38_Rst_A() {
    v3_11_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_38_Rst_B() {
    v3_11_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_38_WEN_A() {
    v3_11_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_487_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_486_Addr_A.read();
    } else {
        v3_11_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_39_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_39_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_39_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_39_Addr_B() {
    v3_11_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_39_Addr_B_orig() {
    v3_11_39_Addr_B_orig =  (sc_lv<32>) (v3_11_39_addr_2_reg_65226.read());
}

void kernel_correlation_sdse::thread_v3_11_39_Clk_A() {
    v3_11_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_39_Clk_B() {
    v3_11_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_39_Din_A() {
    v3_11_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_39_Din_B() {
    v3_11_39_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_39_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_487_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_486_EN_A.read();
    } else {
        v3_11_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_39_EN_B = ap_const_logic_1;
    } else {
        v3_11_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_39_Rst_A() {
    v3_11_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_39_Rst_B() {
    v3_11_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_39_WEN_A() {
    v3_11_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_451_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_450_Addr_A.read();
    } else {
        v3_11_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_3_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_3_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_3_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_3_Addr_B() {
    v3_11_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_3_Addr_B_orig() {
    v3_11_3_Addr_B_orig =  (sc_lv<32>) (v3_11_3_addr_2_reg_65172.read());
}

void kernel_correlation_sdse::thread_v3_11_3_Clk_A() {
    v3_11_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_3_Clk_B() {
    v3_11_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_3_Din_A() {
    v3_11_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_3_Din_B() {
    v3_11_3_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_451_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_450_EN_A.read();
    } else {
        v3_11_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_3_EN_B = ap_const_logic_1;
    } else {
        v3_11_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_3_Rst_A() {
    v3_11_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_3_Rst_B() {
    v3_11_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_3_WEN_A() {
    v3_11_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_452_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_451_Addr_A.read();
    } else {
        v3_11_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_4_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_4_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_4_Addr_B() {
    v3_11_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_4_Addr_B_orig() {
    v3_11_4_Addr_B_orig =  (sc_lv<32>) (v3_11_4_addr_2_reg_60198.read());
}

void kernel_correlation_sdse::thread_v3_11_4_Clk_A() {
    v3_11_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_4_Clk_B() {
    v3_11_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_4_Din_A() {
    v3_11_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_4_Din_B() {
    v3_11_4_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_452_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_451_EN_A.read();
    } else {
        v3_11_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_4_EN_B = ap_const_logic_1;
    } else {
        v3_11_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_4_Rst_A() {
    v3_11_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_4_Rst_B() {
    v3_11_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_4_WEN_A() {
    v3_11_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_453_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_452_Addr_A.read();
    } else {
        v3_11_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_5_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_5_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_5_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_5_Addr_B() {
    v3_11_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_5_Addr_B_orig() {
    v3_11_5_Addr_B_orig =  (sc_lv<32>) (v3_11_5_addr_2_reg_61858.read());
}

void kernel_correlation_sdse::thread_v3_11_5_Clk_A() {
    v3_11_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_5_Clk_B() {
    v3_11_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_5_Din_A() {
    v3_11_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_5_Din_B() {
    v3_11_5_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_5_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_453_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_452_EN_A.read();
    } else {
        v3_11_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_5_EN_B = ap_const_logic_1;
    } else {
        v3_11_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_5_Rst_A() {
    v3_11_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_5_Rst_B() {
    v3_11_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_5_WEN_A() {
    v3_11_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_454_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_453_Addr_A.read();
    } else {
        v3_11_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_6_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_6_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_6_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_6_Addr_B() {
    v3_11_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_6_Addr_B_orig() {
    v3_11_6_Addr_B_orig =  (sc_lv<32>) (v3_11_6_addr_2_reg_63518.read());
}

void kernel_correlation_sdse::thread_v3_11_6_Clk_A() {
    v3_11_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_6_Clk_B() {
    v3_11_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_6_Din_A() {
    v3_11_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_6_Din_B() {
    v3_11_6_Din_B = grp_fu_42196_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_6_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_454_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_453_EN_A.read();
    } else {
        v3_11_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_6_EN_B = ap_const_logic_1;
    } else {
        v3_11_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_6_Rst_A() {
    v3_11_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_6_Rst_B() {
    v3_11_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_6_WEN_A() {
    v3_11_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_6_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_455_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_454_Addr_A.read();
    } else {
        v3_11_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_7_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_7_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_7_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_7_Addr_B() {
    v3_11_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_7_Addr_B_orig() {
    v3_11_7_Addr_B_orig =  (sc_lv<32>) (v3_11_7_addr_2_reg_65178.read());
}

void kernel_correlation_sdse::thread_v3_11_7_Clk_A() {
    v3_11_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_7_Clk_B() {
    v3_11_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_7_Din_A() {
    v3_11_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_7_Din_B() {
    v3_11_7_Din_B = grp_fu_42212_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_7_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_455_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_454_EN_A.read();
    } else {
        v3_11_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_7_EN_B = ap_const_logic_1;
    } else {
        v3_11_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_7_Rst_A() {
    v3_11_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_7_Rst_B() {
    v3_11_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_7_WEN_A() {
    v3_11_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_7_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_456_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_455_Addr_A.read();
    } else {
        v3_11_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_8_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_8_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_8_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_8_Addr_B() {
    v3_11_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_8_Addr_B_orig() {
    v3_11_8_Addr_B_orig =  (sc_lv<32>) (v3_11_8_addr_2_reg_60204.read());
}

void kernel_correlation_sdse::thread_v3_11_8_Clk_A() {
    v3_11_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_8_Clk_B() {
    v3_11_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_8_Din_A() {
    v3_11_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_8_Din_B() {
    v3_11_8_Din_B = grp_fu_42166_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_8_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_456_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_455_EN_A.read();
    } else {
        v3_11_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_8_EN_B = ap_const_logic_1;
    } else {
        v3_11_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_8_Rst_A() {
    v3_11_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_8_Rst_B() {
    v3_11_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_8_WEN_A() {
    v3_11_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_8_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_457_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_456_Addr_A.read();
    } else {
        v3_11_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_11_9_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_11_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_11_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_11_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_11_9_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_11_9_Addr_B() {
    v3_11_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_11_9_Addr_B_orig() {
    v3_11_9_Addr_B_orig =  (sc_lv<32>) (v3_11_9_addr_2_reg_61864.read());
}

void kernel_correlation_sdse::thread_v3_11_9_Clk_A() {
    v3_11_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_9_Clk_B() {
    v3_11_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_11_9_Din_A() {
    v3_11_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_11_9_Din_B() {
    v3_11_9_Din_B = grp_fu_42181_p2.read();
}

void kernel_correlation_sdse::thread_v3_11_9_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_11_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_11_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_457_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_11_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_456_EN_A.read();
    } else {
        v3_11_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_9_EN_B = ap_const_logic_1;
    } else {
        v3_11_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_11_9_Rst_A() {
    v3_11_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_9_Rst_B() {
    v3_11_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_11_9_WEN_A() {
    v3_11_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_11_9_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_11_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_527_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_488_Addr_A.read();
    } else {
        v3_12_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_0_Addr_A_orig() {
    v3_12_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_0_Addr_B() {
    v3_12_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_0_Addr_B_orig() {
    v3_12_0_Addr_B_orig =  (sc_lv<32>) (v3_12_0_addr_reg_60252.read());
}

void kernel_correlation_sdse::thread_v3_12_0_Clk_A() {
    v3_12_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_0_Clk_B() {
    v3_12_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_0_Din_A() {
    v3_12_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_0_Din_B() {
    v3_12_0_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_527_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_488_EN_A.read();
    } else {
        v3_12_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_0_EN_B = ap_const_logic_1;
    } else {
        v3_12_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_0_Rst_A() {
    v3_12_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_0_Rst_B() {
    v3_12_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_0_WEN_A() {
    v3_12_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_498_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_497_Addr_A.read();
    } else {
        v3_12_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_10_Addr_A_orig() {
    v3_12_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_10_Addr_B() {
    v3_12_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_10_Addr_B_orig() {
    v3_12_10_Addr_B_orig =  (sc_lv<32>) (v3_12_10_addr_reg_63584.read());
}

void kernel_correlation_sdse::thread_v3_12_10_Clk_A() {
    v3_12_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_10_Clk_B() {
    v3_12_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_10_Din_A() {
    v3_12_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_10_Din_B() {
    v3_12_10_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_498_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_497_EN_A.read();
    } else {
        v3_12_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_10_EN_B = ap_const_logic_1;
    } else {
        v3_12_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_10_Rst_A() {
    v3_12_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_10_Rst_B() {
    v3_12_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_10_WEN_A() {
    v3_12_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_499_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_498_Addr_A.read();
    } else {
        v3_12_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_11_Addr_A_orig() {
    v3_12_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_11_Addr_B() {
    v3_12_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_11_Addr_B_orig() {
    v3_12_11_Addr_B_orig =  (sc_lv<32>) (v3_12_11_addr_reg_65244.read());
}

void kernel_correlation_sdse::thread_v3_12_11_Clk_A() {
    v3_12_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_11_Clk_B() {
    v3_12_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_11_Din_A() {
    v3_12_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_11_Din_B() {
    v3_12_11_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_499_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_498_EN_A.read();
    } else {
        v3_12_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_11_EN_B = ap_const_logic_1;
    } else {
        v3_12_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_11_Rst_A() {
    v3_12_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_11_Rst_B() {
    v3_12_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_11_WEN_A() {
    v3_12_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_500_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_499_Addr_A.read();
    } else {
        v3_12_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_12_Addr_A_orig() {
    v3_12_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_12_Addr_B() {
    v3_12_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_12_Addr_B_orig() {
    v3_12_12_Addr_B_orig =  (sc_lv<32>) (v3_12_12_addr_reg_60270.read());
}

void kernel_correlation_sdse::thread_v3_12_12_Clk_A() {
    v3_12_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_12_Clk_B() {
    v3_12_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_12_Din_A() {
    v3_12_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_12_Din_B() {
    v3_12_12_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_500_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_499_EN_A.read();
    } else {
        v3_12_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_12_EN_B = ap_const_logic_1;
    } else {
        v3_12_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_12_Rst_A() {
    v3_12_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_12_Rst_B() {
    v3_12_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_12_WEN_A() {
    v3_12_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_501_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_500_Addr_A.read();
    } else {
        v3_12_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_13_Addr_A_orig() {
    v3_12_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_13_Addr_B() {
    v3_12_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_13_Addr_B_orig() {
    v3_12_13_Addr_B_orig =  (sc_lv<32>) (v3_12_13_addr_reg_61930.read());
}

void kernel_correlation_sdse::thread_v3_12_13_Clk_A() {
    v3_12_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_13_Clk_B() {
    v3_12_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_13_Din_A() {
    v3_12_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_13_Din_B() {
    v3_12_13_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_501_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_500_EN_A.read();
    } else {
        v3_12_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_13_EN_B = ap_const_logic_1;
    } else {
        v3_12_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_13_Rst_A() {
    v3_12_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_13_Rst_B() {
    v3_12_13_Rst_B = ap_rst_n_inv.read();
}

}


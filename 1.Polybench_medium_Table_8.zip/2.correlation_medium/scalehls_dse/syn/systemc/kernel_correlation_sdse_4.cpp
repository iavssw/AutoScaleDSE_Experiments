#include "kernel_correlation_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_correlation_sdse::thread_add_ln1015_fu_47196_p2() {
    add_ln1015_fu_47196_p2 = (!zext_ln1015_fu_47193_p1.read().is_01() || !sub_ln1015_fu_47187_p2.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln1015_fu_47193_p1.read()) + sc_biguint<7>(sub_ln1015_fu_47187_p2.read()));
}

void kernel_correlation_sdse::thread_add_ln1336_fu_47783_p2() {
    add_ln1336_fu_47783_p2 = (!ap_phi_mux_indvar_flatten6_phi_fu_32143_p4.read().is_01() || !ap_const_lv9_1.is_01())? sc_lv<9>(): (sc_biguint<9>(ap_phi_mux_indvar_flatten6_phi_fu_32143_p4.read()) + sc_biguint<9>(ap_const_lv9_1));
}

void kernel_correlation_sdse::thread_add_ln3020_fu_47926_p2() {
    add_ln3020_fu_47926_p2 = (!zext_ln3020_fu_47923_p1.read().is_01() || !sub_ln3020_fu_47917_p2.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln3020_fu_47923_p1.read()) + sc_biguint<7>(sub_ln3020_fu_47917_p2.read()));
}

void kernel_correlation_sdse::thread_add_ln3582_fu_50391_p2() {
    add_ln3582_fu_50391_p2 = (!ap_phi_mux_indvar_flatten13_phi_fu_33456_p4.read().is_01() || !ap_const_lv10_1.is_01())? sc_lv<10>(): (sc_biguint<10>(ap_phi_mux_indvar_flatten13_phi_fu_33456_p4.read()) + sc_biguint<10>(ap_const_lv10_1));
}

void kernel_correlation_sdse::thread_add_ln3586_fu_50592_p2() {
    add_ln3586_fu_50592_p2 = (!sub_ln3586_fu_50552_p2.read().is_01() || !sext_ln3586_fu_50589_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(sub_ln3586_fu_50552_p2.read()) + sc_bigint<7>(sext_ln3586_fu_50589_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln3594_fu_50892_p2() {
    add_ln3594_fu_50892_p2 = (!sub_ln3586_fu_50552_p2.read().is_01() || !sext_ln3594_fu_50889_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(sub_ln3586_fu_50552_p2.read()) + sc_bigint<7>(sext_ln3594_fu_50889_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln3602_fu_51192_p2() {
    add_ln3602_fu_51192_p2 = (!sub_ln3586_fu_50552_p2.read().is_01() || !sext_ln3602_fu_51189_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(sub_ln3586_fu_50552_p2.read()) + sc_bigint<7>(sext_ln3602_fu_51189_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln3610_fu_51492_p2() {
    add_ln3610_fu_51492_p2 = (!sub_ln3586_fu_50552_p2.read().is_01() || !sext_ln3610_fu_51489_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(sub_ln3586_fu_50552_p2.read()) + sc_bigint<7>(sext_ln3610_fu_51489_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4420_1_fu_52076_p2() {
    add_ln4420_1_fu_52076_p2 = (!ap_const_lv21_1.is_01() || !indvar_flatten60_reg_37508.read().is_01())? sc_lv<21>(): (sc_biguint<21>(ap_const_lv21_1) + sc_biguint<21>(indvar_flatten60_reg_37508.read()));
}

void kernel_correlation_sdse::thread_add_ln4420_fu_52026_p2() {
    add_ln4420_fu_52026_p2 = (!zext_ln4420_fu_52022_p1.read().is_01() || !sub_ln4423_1_reg_66680.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln4420_fu_52022_p1.read()) + sc_biguint<9>(sub_ln4423_1_reg_66680.read()));
}

void kernel_correlation_sdse::thread_add_ln4421_1_fu_51976_p2() {
    add_ln4421_1_fu_51976_p2 = (!ap_phi_mux_indvar_flatten20_phi_fu_37524_p4.read().is_01() || !ap_const_lv14_1.is_01())? sc_lv<14>(): (sc_biguint<14>(ap_phi_mux_indvar_flatten20_phi_fu_37524_p4.read()) + sc_biguint<14>(ap_const_lv14_1));
}

void kernel_correlation_sdse::thread_add_ln4423_1_fu_51825_p2() {
    add_ln4423_1_fu_51825_p2 = (!ap_const_lv5_F.is_01() || !trunc_ln4423_fu_51815_p1.read().is_01())? sc_lv<5>(): (sc_biguint<5>(ap_const_lv5_F) + sc_biguint<5>(trunc_ln4423_fu_51815_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4423_2_fu_51867_p2() {
    add_ln4423_2_fu_51867_p2 = (!zext_ln4423_2_fu_51852_p1.read().is_01() || !zext_ln4423_3_fu_51863_p1.read().is_01())? sc_lv<14>(): (sc_biguint<14>(zext_ln4423_2_fu_51852_p1.read()) + sc_biguint<14>(zext_ln4423_3_fu_51863_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4423_3_fu_51954_p2() {
    add_ln4423_3_fu_51954_p2 = (!ap_phi_mux_v3201_0_phi_fu_37547_p4.read().is_01() || !ap_const_lv5_1.is_01())? sc_lv<5>(): (sc_biguint<5>(ap_phi_mux_v3201_0_phi_fu_37547_p4.read()) + sc_biguint<5>(ap_const_lv5_1));
}

void kernel_correlation_sdse::thread_add_ln4423_fu_51819_p2() {
    add_ln4423_fu_51819_p2 = (!ap_const_lv9_EF.is_01() || !sub_ln4423_1_fu_51809_p2.read().is_01())? sc_lv<9>(): (sc_biguint<9>(ap_const_lv9_EF) + sc_biguint<9>(sub_ln4423_1_fu_51809_p2.read()));
}

void kernel_correlation_sdse::thread_add_ln4425_1_fu_52051_p2() {
    add_ln4425_1_fu_52051_p2 = (!zext_ln4422_2_fu_52034_p1.read().is_01() || !shl_ln4423_1_reg_66675.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln4422_2_fu_52034_p1.read()) + sc_biguint<6>(shl_ln4423_1_reg_66675.read()));
}

void kernel_correlation_sdse::thread_add_ln4425_2_fu_52367_p2() {
    add_ln4425_2_fu_52367_p2 = (!sub_ln4425_fu_52361_p2.read().is_01() || !zext_ln4425_1_fu_52336_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(sub_ln4425_fu_52361_p2.read()) + sc_biguint<17>(zext_ln4425_1_fu_52336_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4425_fu_52060_p2() {
    add_ln4425_fu_52060_p2 = (!shl_ln1_reg_66670.read().is_01() || !zext_ln4425_fu_52056_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(shl_ln1_reg_66670.read()) + sc_biguint<8>(zext_ln4425_fu_52056_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4426_1_fu_52378_p2() {
    add_ln4426_1_fu_52378_p2 = (!sub_ln4425_fu_52361_p2.read().is_01() || !zext_ln4434_fu_52305_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(sub_ln4425_fu_52361_p2.read()) + sc_biguint<17>(zext_ln4434_fu_52305_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4426_2_fu_52002_p2() {
    add_ln4426_2_fu_52002_p2 = (!ap_const_lv8_1.is_01() || !ap_phi_mux_v3199_0_phi_fu_37558_p4.read().is_01())? sc_lv<8>(): (sc_biguint<8>(ap_const_lv8_1) + sc_biguint<8>(ap_phi_mux_v3199_0_phi_fu_37558_p4.read()));
}

void kernel_correlation_sdse::thread_add_ln4426_fu_51996_p2() {
    add_ln4426_fu_51996_p2 = (!ap_const_lv8_2.is_01() || !ap_phi_mux_v3199_0_phi_fu_37558_p4.read().is_01())? sc_lv<8>(): (sc_biguint<8>(ap_const_lv8_2) + sc_biguint<8>(ap_phi_mux_v3199_0_phi_fu_37558_p4.read()));
}

void kernel_correlation_sdse::thread_add_ln4427_1_fu_52136_p2() {
    add_ln4427_1_fu_52136_p2 = (!zext_ln4427_fu_52132_p1.read().is_01() || !shl_ln2_fu_52116_p3.read().is_01())? sc_lv<10>(): (sc_biguint<10>(zext_ln4427_fu_52132_p1.read()) + sc_biguint<10>(shl_ln2_fu_52116_p3.read()));
}

void kernel_correlation_sdse::thread_add_ln4427_2_fu_52218_p2() {
    add_ln4427_2_fu_52218_p2 = (!shl_ln4427_mid1_fu_52198_p3.read().is_01() || !zext_ln4427_2_fu_52214_p1.read().is_01())? sc_lv<10>(): (sc_biguint<10>(shl_ln4427_mid1_fu_52198_p3.read()) + sc_biguint<10>(zext_ln4427_2_fu_52214_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4427_fu_52255_p2() {
    add_ln4427_fu_52255_p2 = (!zext_ln4422_fu_52231_p1.read().is_01() || !zext_ln4427_3_fu_52251_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln4422_fu_52231_p1.read()) + sc_biguint<11>(zext_ln4427_3_fu_52251_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4428_1_fu_52292_p2() {
    add_ln4428_1_fu_52292_p2 = (!zext_ln4420_1_fu_52279_p1.read().is_01() || !zext_ln4427_4_fu_52289_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln4420_1_fu_52279_p1.read()) + sc_biguint<11>(zext_ln4427_4_fu_52289_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4428_fu_52146_p2() {
    add_ln4428_fu_52146_p2 = (!zext_ln4427_1_fu_52142_p1.read().is_01() || !zext_ln4428_fu_52104_p1.read().is_01())? sc_lv<11>(): (sc_biguint<11>(zext_ln4427_1_fu_52142_p1.read()) + sc_biguint<11>(zext_ln4428_fu_52104_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln4434_fu_52384_p2() {
    add_ln4434_fu_52384_p2 = (!sub_ln4434_fu_52330_p2.read().is_01() || !zext_ln4425_1_fu_52336_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(sub_ln4434_fu_52330_p2.read()) + sc_biguint<17>(zext_ln4425_1_fu_52336_p1.read()));
}

void kernel_correlation_sdse::thread_add_ln51_fu_47097_p2() {
    add_ln51_fu_47097_p2 = (!ap_phi_mux_indvar_flatten_phi_fu_30830_p4.read().is_01() || !ap_const_lv9_1.is_01())? sc_lv<9>(): (sc_biguint<9>(ap_phi_mux_indvar_flatten_phi_fu_30830_p4.read()) + sc_biguint<9>(ap_const_lv9_1));
}

void kernel_correlation_sdse::thread_and_ln3030_fu_48888_p2() {
    and_ln3030_fu_48888_p2 = (or_ln3030_fu_48884_p2.read() & grp_fu_43208_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3044_fu_48907_p2() {
    and_ln3044_fu_48907_p2 = (or_ln3044_fu_48903_p2.read() & grp_fu_43214_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3058_fu_48925_p2() {
    and_ln3058_fu_48925_p2 = (or_ln3058_fu_48921_p2.read() & grp_fu_43220_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3072_fu_48943_p2() {
    and_ln3072_fu_48943_p2 = (or_ln3072_fu_48939_p2.read() & grp_fu_43226_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3086_fu_48961_p2() {
    and_ln3086_fu_48961_p2 = (or_ln3086_fu_48957_p2.read() & grp_fu_43232_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3100_fu_48979_p2() {
    and_ln3100_fu_48979_p2 = (or_ln3100_fu_48975_p2.read() & grp_fu_43238_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3114_fu_48997_p2() {
    and_ln3114_fu_48997_p2 = (or_ln3114_fu_48993_p2.read() & grp_fu_43244_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3128_fu_49015_p2() {
    and_ln3128_fu_49015_p2 = (or_ln3128_fu_49011_p2.read() & grp_fu_43250_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3142_fu_49033_p2() {
    and_ln3142_fu_49033_p2 = (or_ln3142_fu_49029_p2.read() & grp_fu_43256_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3156_fu_49051_p2() {
    and_ln3156_fu_49051_p2 = (or_ln3156_fu_49047_p2.read() & grp_fu_43262_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3170_fu_49069_p2() {
    and_ln3170_fu_49069_p2 = (or_ln3170_fu_49065_p2.read() & grp_fu_43268_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3184_fu_49087_p2() {
    and_ln3184_fu_49087_p2 = (or_ln3184_fu_49083_p2.read() & grp_fu_43274_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3198_fu_49105_p2() {
    and_ln3198_fu_49105_p2 = (or_ln3198_fu_49101_p2.read() & grp_fu_43280_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3212_fu_49123_p2() {
    and_ln3212_fu_49123_p2 = (or_ln3212_fu_49119_p2.read() & grp_fu_43286_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3226_fu_49561_p2() {
    and_ln3226_fu_49561_p2 = (or_ln3226_fu_49557_p2.read() & grp_fu_43208_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3240_fu_49579_p2() {
    and_ln3240_fu_49579_p2 = (or_ln3240_fu_49575_p2.read() & grp_fu_43214_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3254_fu_49597_p2() {
    and_ln3254_fu_49597_p2 = (or_ln3254_fu_49593_p2.read() & grp_fu_43220_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3268_fu_49615_p2() {
    and_ln3268_fu_49615_p2 = (or_ln3268_fu_49611_p2.read() & grp_fu_43226_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3282_fu_49633_p2() {
    and_ln3282_fu_49633_p2 = (or_ln3282_fu_49629_p2.read() & grp_fu_43232_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3296_fu_49651_p2() {
    and_ln3296_fu_49651_p2 = (or_ln3296_fu_49647_p2.read() & grp_fu_43238_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3310_fu_49669_p2() {
    and_ln3310_fu_49669_p2 = (or_ln3310_fu_49665_p2.read() & grp_fu_43244_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3324_fu_49687_p2() {
    and_ln3324_fu_49687_p2 = (or_ln3324_fu_49683_p2.read() & grp_fu_43250_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3338_fu_49705_p2() {
    and_ln3338_fu_49705_p2 = (or_ln3338_fu_49701_p2.read() & grp_fu_43256_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3352_fu_49723_p2() {
    and_ln3352_fu_49723_p2 = (or_ln3352_fu_49719_p2.read() & grp_fu_43262_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3366_fu_49741_p2() {
    and_ln3366_fu_49741_p2 = (or_ln3366_fu_49737_p2.read() & grp_fu_43268_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3380_fu_49759_p2() {
    and_ln3380_fu_49759_p2 = (or_ln3380_fu_49755_p2.read() & grp_fu_43274_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3394_fu_49777_p2() {
    and_ln3394_fu_49777_p2 = (or_ln3394_fu_49773_p2.read() & grp_fu_43280_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3408_fu_49795_p2() {
    and_ln3408_fu_49795_p2 = (or_ln3408_fu_49791_p2.read() & grp_fu_43286_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3422_fu_50173_p2() {
    and_ln3422_fu_50173_p2 = (or_ln3422_fu_50169_p2.read() & grp_fu_43208_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3436_fu_50191_p2() {
    and_ln3436_fu_50191_p2 = (or_ln3436_fu_50187_p2.read() & grp_fu_43214_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3450_fu_50209_p2() {
    and_ln3450_fu_50209_p2 = (or_ln3450_fu_50205_p2.read() & grp_fu_43220_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3464_fu_50227_p2() {
    and_ln3464_fu_50227_p2 = (or_ln3464_fu_50223_p2.read() & grp_fu_43226_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3478_fu_50245_p2() {
    and_ln3478_fu_50245_p2 = (or_ln3478_fu_50241_p2.read() & grp_fu_43232_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3492_fu_50263_p2() {
    and_ln3492_fu_50263_p2 = (or_ln3492_fu_50259_p2.read() & grp_fu_43238_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3506_fu_50281_p2() {
    and_ln3506_fu_50281_p2 = (or_ln3506_fu_50277_p2.read() & grp_fu_43244_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3520_fu_50299_p2() {
    and_ln3520_fu_50299_p2 = (or_ln3520_fu_50295_p2.read() & grp_fu_43250_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3534_fu_50317_p2() {
    and_ln3534_fu_50317_p2 = (or_ln3534_fu_50313_p2.read() & grp_fu_43256_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3548_fu_50335_p2() {
    and_ln3548_fu_50335_p2 = (or_ln3548_fu_50331_p2.read() & grp_fu_43262_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3562_fu_50353_p2() {
    and_ln3562_fu_50353_p2 = (or_ln3562_fu_50349_p2.read() & grp_fu_43268_p2.read());
}

void kernel_correlation_sdse::thread_and_ln3576_fu_50371_p2() {
    and_ln3576_fu_50371_p2 = (or_ln3576_fu_50367_p2.read() & grp_fu_43274_p2.read());
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp0_stage0() {
    ap_CS_fsm_pp0_stage0 = ap_CS_fsm.read()[1];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp0_stage1() {
    ap_CS_fsm_pp0_stage1 = ap_CS_fsm.read()[2];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp1_stage0() {
    ap_CS_fsm_pp1_stage0 = ap_CS_fsm.read()[4];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp1_stage1() {
    ap_CS_fsm_pp1_stage1 = ap_CS_fsm.read()[5];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp1_stage2() {
    ap_CS_fsm_pp1_stage2 = ap_CS_fsm.read()[6];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage0() {
    ap_CS_fsm_pp2_stage0 = ap_CS_fsm.read()[17];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage1() {
    ap_CS_fsm_pp2_stage1 = ap_CS_fsm.read()[18];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage10() {
    ap_CS_fsm_pp2_stage10 = ap_CS_fsm.read()[27];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage11() {
    ap_CS_fsm_pp2_stage11 = ap_CS_fsm.read()[28];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage12() {
    ap_CS_fsm_pp2_stage12 = ap_CS_fsm.read()[29];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage13() {
    ap_CS_fsm_pp2_stage13 = ap_CS_fsm.read()[30];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage14() {
    ap_CS_fsm_pp2_stage14 = ap_CS_fsm.read()[31];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage15() {
    ap_CS_fsm_pp2_stage15 = ap_CS_fsm.read()[32];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage2() {
    ap_CS_fsm_pp2_stage2 = ap_CS_fsm.read()[19];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp2_stage3() {
    ap_CS_fsm_pp2_stage3 = ap_CS_fsm.read()[20];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp3_stage0() {
    ap_CS_fsm_pp3_stage0 = ap_CS_fsm.read()[36];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp3_stage1() {
    ap_CS_fsm_pp3_stage1 = ap_CS_fsm.read()[37];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp3_stage2() {
    ap_CS_fsm_pp3_stage2 = ap_CS_fsm.read()[38];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_pp3_stage3() {
    ap_CS_fsm_pp3_stage3 = ap_CS_fsm.read()[39];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_state1() {
    ap_CS_fsm_state1 = ap_CS_fsm.read()[0];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_state127() {
    ap_CS_fsm_state127 = ap_CS_fsm.read()[33];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_state128() {
    ap_CS_fsm_state128 = ap_CS_fsm.read()[34];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_state129() {
    ap_CS_fsm_state129 = ap_CS_fsm.read()[35];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_state156() {
    ap_CS_fsm_state156 = ap_CS_fsm.read()[40];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_state34() {
    ap_CS_fsm_state34 = ap_CS_fsm.read()[3];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_state90() {
    ap_CS_fsm_state90 = ap_CS_fsm.read()[7];
}

void kernel_correlation_sdse::thread_ap_CS_fsm_state99() {
    ap_CS_fsm_state99 = ap_CS_fsm.read()[16];
}

void kernel_correlation_sdse::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp0_stage0_00001() {
    ap_block_pp0_stage0_00001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp0_stage0_subdone() {
    ap_block_pp0_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp0_stage1() {
    ap_block_pp0_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp0_stage1_00001() {
    ap_block_pp0_stage1_00001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp0_stage1_11001() {
    ap_block_pp0_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp0_stage1_subdone() {
    ap_block_pp0_stage1_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage0() {
    ap_block_pp1_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage0_00001() {
    ap_block_pp1_stage0_00001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage0_11001() {
    ap_block_pp1_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage0_subdone() {
    ap_block_pp1_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage1() {
    ap_block_pp1_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage1_00001() {
    ap_block_pp1_stage1_00001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage1_11001() {
    ap_block_pp1_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage1_subdone() {
    ap_block_pp1_stage1_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage2() {
    ap_block_pp1_stage2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage2_00001() {
    ap_block_pp1_stage2_00001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage2_11001() {
    ap_block_pp1_stage2_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp1_stage2_subdone() {
    ap_block_pp1_stage2_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage0() {
    ap_block_pp2_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage0_11001() {
    ap_block_pp2_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage0_subdone() {
    ap_block_pp2_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage1() {
    ap_block_pp2_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage10() {
    ap_block_pp2_stage10 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage10_11001() {
    ap_block_pp2_stage10_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage10_subdone() {
    ap_block_pp2_stage10_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage11() {
    ap_block_pp2_stage11 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage11_11001() {
    ap_block_pp2_stage11_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage11_subdone() {
    ap_block_pp2_stage11_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage12() {
    ap_block_pp2_stage12 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage12_00001() {
    ap_block_pp2_stage12_00001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage12_11001() {
    ap_block_pp2_stage12_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage12_subdone() {
    ap_block_pp2_stage12_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage13() {
    ap_block_pp2_stage13 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage13_11001() {
    ap_block_pp2_stage13_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage13_subdone() {
    ap_block_pp2_stage13_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage14_11001() {
    ap_block_pp2_stage14_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage14_subdone() {
    ap_block_pp2_stage14_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage15() {
    ap_block_pp2_stage15 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage15_11001() {
    ap_block_pp2_stage15_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage15_subdone() {
    ap_block_pp2_stage15_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage1_11001() {
    ap_block_pp2_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage1_subdone() {
    ap_block_pp2_stage1_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage2() {
    ap_block_pp2_stage2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage2_11001() {
    ap_block_pp2_stage2_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage2_subdone() {
    ap_block_pp2_stage2_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage3() {
    ap_block_pp2_stage3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage3_11001() {
    ap_block_pp2_stage3_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage3_subdone() {
    ap_block_pp2_stage3_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage4_11001() {
    ap_block_pp2_stage4_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage4_subdone() {
    ap_block_pp2_stage4_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage5_11001() {
    ap_block_pp2_stage5_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage5_subdone() {
    ap_block_pp2_stage5_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage6_11001() {
    ap_block_pp2_stage6_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage6_subdone() {
    ap_block_pp2_stage6_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage7_11001() {
    ap_block_pp2_stage7_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage7_subdone() {
    ap_block_pp2_stage7_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage8_11001() {
    ap_block_pp2_stage8_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage8_subdone() {
    ap_block_pp2_stage8_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage9_11001() {
    ap_block_pp2_stage9_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp2_stage9_subdone() {
    ap_block_pp2_stage9_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage0() {
    ap_block_pp3_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage0_00001() {
    ap_block_pp3_stage0_00001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage0_11001() {
    ap_block_pp3_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage0_subdone() {
    ap_block_pp3_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage1() {
    ap_block_pp3_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage1_11001() {
    ap_block_pp3_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage1_subdone() {
    ap_block_pp3_stage1_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage2() {
    ap_block_pp3_stage2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage2_11001() {
    ap_block_pp3_stage2_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage2_subdone() {
    ap_block_pp3_stage2_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage3() {
    ap_block_pp3_stage3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage3_11001() {
    ap_block_pp3_stage3_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_pp3_stage3_subdone() {
    ap_block_pp3_stage3_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state100_pp2_stage0_iter0() {
    ap_block_state100_pp2_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state101_pp2_stage1_iter0() {
    ap_block_state101_pp2_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state102_pp2_stage2_iter0() {
    ap_block_state102_pp2_stage2_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state103_pp2_stage3_iter0() {
    ap_block_state103_pp2_stage3_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state104_pp2_stage4_iter0() {
    ap_block_state104_pp2_stage4_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state105_pp2_stage5_iter0() {
    ap_block_state105_pp2_stage5_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state106_pp2_stage6_iter0() {
    ap_block_state106_pp2_stage6_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state107_pp2_stage7_iter0() {
    ap_block_state107_pp2_stage7_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state108_pp2_stage8_iter0() {
    ap_block_state108_pp2_stage8_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state109_pp2_stage9_iter0() {
    ap_block_state109_pp2_stage9_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state10_pp0_stage0_iter4() {
    ap_block_state10_pp0_stage0_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state110_pp2_stage10_iter0() {
    ap_block_state110_pp2_stage10_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state111_pp2_stage11_iter0() {
    ap_block_state111_pp2_stage11_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state112_pp2_stage12_iter0() {
    ap_block_state112_pp2_stage12_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state113_pp2_stage13_iter0() {
    ap_block_state113_pp2_stage13_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state114_pp2_stage14_iter0() {
    ap_block_state114_pp2_stage14_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state115_pp2_stage15_iter0() {
    ap_block_state115_pp2_stage15_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state116_pp2_stage0_iter1() {
    ap_block_state116_pp2_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state117_pp2_stage1_iter1() {
    ap_block_state117_pp2_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state118_pp2_stage2_iter1() {
    ap_block_state118_pp2_stage2_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state119_pp2_stage3_iter1() {
    ap_block_state119_pp2_stage3_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state11_pp0_stage1_iter4() {
    ap_block_state11_pp0_stage1_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state120_pp2_stage4_iter1() {
    ap_block_state120_pp2_stage4_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state121_pp2_stage5_iter1() {
    ap_block_state121_pp2_stage5_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state122_pp2_stage6_iter1() {
    ap_block_state122_pp2_stage6_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state123_pp2_stage7_iter1() {
    ap_block_state123_pp2_stage7_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state124_pp2_stage8_iter1() {
    ap_block_state124_pp2_stage8_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state125_pp2_stage9_iter1() {
    ap_block_state125_pp2_stage9_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state126_pp2_stage10_iter1() {
    ap_block_state126_pp2_stage10_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state12_pp0_stage0_iter5() {
    ap_block_state12_pp0_stage0_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state130_pp3_stage0_iter0() {
    ap_block_state130_pp3_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state131_pp3_stage1_iter0() {
    ap_block_state131_pp3_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state132_pp3_stage2_iter0() {
    ap_block_state132_pp3_stage2_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state133_pp3_stage3_iter0() {
    ap_block_state133_pp3_stage3_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state134_pp3_stage0_iter1() {
    ap_block_state134_pp3_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state135_pp3_stage1_iter1() {
    ap_block_state135_pp3_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state136_pp3_stage2_iter1() {
    ap_block_state136_pp3_stage2_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state137_pp3_stage3_iter1() {
    ap_block_state137_pp3_stage3_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state138_pp3_stage0_iter2() {
    ap_block_state138_pp3_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state139_pp3_stage1_iter2() {
    ap_block_state139_pp3_stage1_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state13_pp0_stage1_iter5() {
    ap_block_state13_pp0_stage1_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state140_pp3_stage2_iter2() {
    ap_block_state140_pp3_stage2_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state141_pp3_stage3_iter2() {
    ap_block_state141_pp3_stage3_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state142_pp3_stage0_iter3() {
    ap_block_state142_pp3_stage0_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state143_pp3_stage1_iter3() {
    ap_block_state143_pp3_stage1_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state144_pp3_stage2_iter3() {
    ap_block_state144_pp3_stage2_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state145_pp3_stage3_iter3() {
    ap_block_state145_pp3_stage3_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state146_pp3_stage0_iter4() {
    ap_block_state146_pp3_stage0_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state147_pp3_stage1_iter4() {
    ap_block_state147_pp3_stage1_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state148_pp3_stage2_iter4() {
    ap_block_state148_pp3_stage2_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state149_pp3_stage3_iter4() {
    ap_block_state149_pp3_stage3_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state14_pp0_stage0_iter6() {
    ap_block_state14_pp0_stage0_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state150_pp3_stage0_iter5() {
    ap_block_state150_pp3_stage0_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state151_pp3_stage1_iter5() {
    ap_block_state151_pp3_stage1_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state152_pp3_stage2_iter5() {
    ap_block_state152_pp3_stage2_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state153_pp3_stage3_iter5() {
    ap_block_state153_pp3_stage3_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state154_pp3_stage0_iter6() {
    ap_block_state154_pp3_stage0_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state155_pp3_stage1_iter6() {
    ap_block_state155_pp3_stage1_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state15_pp0_stage1_iter6() {
    ap_block_state15_pp0_stage1_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state16_pp0_stage0_iter7() {
    ap_block_state16_pp0_stage0_iter7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state17_pp0_stage1_iter7() {
    ap_block_state17_pp0_stage1_iter7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state18_pp0_stage0_iter8() {
    ap_block_state18_pp0_stage0_iter8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state19_pp0_stage1_iter8() {
    ap_block_state19_pp0_stage1_iter8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state20_pp0_stage0_iter9() {
    ap_block_state20_pp0_stage0_iter9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state21_pp0_stage1_iter9() {
    ap_block_state21_pp0_stage1_iter9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state22_pp0_stage0_iter10() {
    ap_block_state22_pp0_stage0_iter10 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state23_pp0_stage1_iter10() {
    ap_block_state23_pp0_stage1_iter10 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state24_pp0_stage0_iter11() {
    ap_block_state24_pp0_stage0_iter11 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state25_pp0_stage1_iter11() {
    ap_block_state25_pp0_stage1_iter11 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state26_pp0_stage0_iter12() {
    ap_block_state26_pp0_stage0_iter12 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state27_pp0_stage1_iter12() {
    ap_block_state27_pp0_stage1_iter12 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state28_pp0_stage0_iter13() {
    ap_block_state28_pp0_stage0_iter13 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state29_pp0_stage1_iter13() {
    ap_block_state29_pp0_stage1_iter13 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state2_pp0_stage0_iter0() {
    ap_block_state2_pp0_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state30_pp0_stage0_iter14() {
    ap_block_state30_pp0_stage0_iter14 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state31_pp0_stage1_iter14() {
    ap_block_state31_pp0_stage1_iter14 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state32_pp0_stage0_iter15() {
    ap_block_state32_pp0_stage0_iter15 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state33_pp0_stage1_iter15() {
    ap_block_state33_pp0_stage1_iter15 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state35_pp1_stage0_iter0() {
    ap_block_state35_pp1_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state36_pp1_stage1_iter0() {
    ap_block_state36_pp1_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state37_pp1_stage2_iter0() {
    ap_block_state37_pp1_stage2_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state38_pp1_stage0_iter1() {
    ap_block_state38_pp1_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state39_pp1_stage1_iter1() {
    ap_block_state39_pp1_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state3_pp0_stage1_iter0() {
    ap_block_state3_pp0_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state40_pp1_stage2_iter1() {
    ap_block_state40_pp1_stage2_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state41_pp1_stage0_iter2() {
    ap_block_state41_pp1_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state42_pp1_stage1_iter2() {
    ap_block_state42_pp1_stage1_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state43_pp1_stage2_iter2() {
    ap_block_state43_pp1_stage2_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state44_pp1_stage0_iter3() {
    ap_block_state44_pp1_stage0_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state45_pp1_stage1_iter3() {
    ap_block_state45_pp1_stage1_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state46_pp1_stage2_iter3() {
    ap_block_state46_pp1_stage2_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state47_pp1_stage0_iter4() {
    ap_block_state47_pp1_stage0_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state48_pp1_stage1_iter4() {
    ap_block_state48_pp1_stage1_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state49_pp1_stage2_iter4() {
    ap_block_state49_pp1_stage2_iter4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state4_pp0_stage0_iter1() {
    ap_block_state4_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state50_pp1_stage0_iter5() {
    ap_block_state50_pp1_stage0_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state51_pp1_stage1_iter5() {
    ap_block_state51_pp1_stage1_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state52_pp1_stage2_iter5() {
    ap_block_state52_pp1_stage2_iter5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state53_pp1_stage0_iter6() {
    ap_block_state53_pp1_stage0_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state54_pp1_stage1_iter6() {
    ap_block_state54_pp1_stage1_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state55_pp1_stage2_iter6() {
    ap_block_state55_pp1_stage2_iter6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state56_pp1_stage0_iter7() {
    ap_block_state56_pp1_stage0_iter7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state57_pp1_stage1_iter7() {
    ap_block_state57_pp1_stage1_iter7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state58_pp1_stage2_iter7() {
    ap_block_state58_pp1_stage2_iter7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state59_pp1_stage0_iter8() {
    ap_block_state59_pp1_stage0_iter8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state5_pp0_stage1_iter1() {
    ap_block_state5_pp0_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state60_pp1_stage1_iter8() {
    ap_block_state60_pp1_stage1_iter8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state61_pp1_stage2_iter8() {
    ap_block_state61_pp1_stage2_iter8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state62_pp1_stage0_iter9() {
    ap_block_state62_pp1_stage0_iter9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state63_pp1_stage1_iter9() {
    ap_block_state63_pp1_stage1_iter9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state64_pp1_stage2_iter9() {
    ap_block_state64_pp1_stage2_iter9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state65_pp1_stage0_iter10() {
    ap_block_state65_pp1_stage0_iter10 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state66_pp1_stage1_iter10() {
    ap_block_state66_pp1_stage1_iter10 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state67_pp1_stage2_iter10() {
    ap_block_state67_pp1_stage2_iter10 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state68_pp1_stage0_iter11() {
    ap_block_state68_pp1_stage0_iter11 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state69_pp1_stage1_iter11() {
    ap_block_state69_pp1_stage1_iter11 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state6_pp0_stage0_iter2() {
    ap_block_state6_pp0_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state70_pp1_stage2_iter11() {
    ap_block_state70_pp1_stage2_iter11 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state71_pp1_stage0_iter12() {
    ap_block_state71_pp1_stage0_iter12 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state72_pp1_stage1_iter12() {
    ap_block_state72_pp1_stage1_iter12 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state73_pp1_stage2_iter12() {
    ap_block_state73_pp1_stage2_iter12 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state74_pp1_stage0_iter13() {
    ap_block_state74_pp1_stage0_iter13 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state75_pp1_stage1_iter13() {
    ap_block_state75_pp1_stage1_iter13 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state76_pp1_stage2_iter13() {
    ap_block_state76_pp1_stage2_iter13 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state77_pp1_stage0_iter14() {
    ap_block_state77_pp1_stage0_iter14 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state78_pp1_stage1_iter14() {
    ap_block_state78_pp1_stage1_iter14 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state79_pp1_stage2_iter14() {
    ap_block_state79_pp1_stage2_iter14 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state7_pp0_stage1_iter2() {
    ap_block_state7_pp0_stage1_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state80_pp1_stage0_iter15() {
    ap_block_state80_pp1_stage0_iter15 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state81_pp1_stage1_iter15() {
    ap_block_state81_pp1_stage1_iter15 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state82_pp1_stage2_iter15() {
    ap_block_state82_pp1_stage2_iter15 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state83_pp1_stage0_iter16() {
    ap_block_state83_pp1_stage0_iter16 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state84_pp1_stage1_iter16() {
    ap_block_state84_pp1_stage1_iter16 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state85_pp1_stage2_iter16() {
    ap_block_state85_pp1_stage2_iter16 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state86_pp1_stage0_iter17() {
    ap_block_state86_pp1_stage0_iter17 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state87_pp1_stage1_iter17() {
    ap_block_state87_pp1_stage1_iter17 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state88_pp1_stage2_iter17() {
    ap_block_state88_pp1_stage2_iter17 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state89_pp1_stage0_iter18() {
    ap_block_state89_pp1_stage0_iter18 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state8_pp0_stage0_iter3() {
    ap_block_state8_pp0_stage0_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_block_state9_pp0_stage1_iter3() {
    ap_block_state9_pp0_stage1_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_correlation_sdse::thread_ap_condition_19734() {
    ap_condition_19734 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0));
}

void kernel_correlation_sdse::thread_ap_condition_19905() {
    ap_condition_19905 = (esl_seteq<1,1,1>(icmp_ln51_reg_52463_pp0_iter6_reg.read(), ap_const_lv1_0) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_0) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_2) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_4) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_6) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_8) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_A) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_C) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_E) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_10) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_12) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_14) && !esl_seteq<1,6,6>(trunc_ln51_reg_52509.read(), ap_const_lv6_16));
}

void kernel_correlation_sdse::thread_ap_condition_33518() {
    ap_condition_33518 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0));
}

void kernel_correlation_sdse::thread_ap_condition_35574() {
    ap_condition_35574 = (!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20));
}

void kernel_correlation_sdse::thread_ap_condition_41810() {
    ap_condition_41810 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0));
}

void kernel_correlation_sdse::thread_ap_condition_41815() {
    ap_condition_41815 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0));
}

void kernel_correlation_sdse::thread_ap_condition_41819() {
    ap_condition_41819 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0));
}

void kernel_correlation_sdse::thread_ap_condition_41824() {
    ap_condition_41824 = (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0));
}

void kernel_correlation_sdse::thread_ap_condition_pp0_exit_iter0_state2() {
    if (esl_seteq<1,1,1>(icmp_ln51_fu_47091_p2.read(), ap_const_lv1_1)) {
        ap_condition_pp0_exit_iter0_state2 = ap_const_logic_1;
    } else {
        ap_condition_pp0_exit_iter0_state2 = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_condition_pp1_exit_iter0_state35() {
    if (esl_seteq<1,1,1>(icmp_ln1336_fu_47777_p2.read(), ap_const_lv1_1)) {
        ap_condition_pp1_exit_iter0_state35 = ap_const_logic_1;
    } else {
        ap_condition_pp1_exit_iter0_state35 = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_condition_pp2_exit_iter0_state100() {
    if (esl_seteq<1,1,1>(icmp_ln3582_fu_50385_p2.read(), ap_const_lv1_1)) {
        ap_condition_pp2_exit_iter0_state100 = ap_const_logic_1;
    } else {
        ap_condition_pp2_exit_iter0_state100 = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_condition_pp3_exit_iter3_state142() {
    if ((esl_seteq<1,1,1>(ap_enable_reg_pp3_iter3.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp3_iter2.read(), ap_const_logic_0))) {
        ap_condition_pp3_exit_iter3_state142 = ap_const_logic_1;
    } else {
        ap_condition_pp3_exit_iter3_state142 = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_done() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state128.read()) && 
         esl_seteq<1,1,1>(icmp_ln4419_fu_51767_p2.read(), ap_const_lv1_1))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void kernel_correlation_sdse::thread_ap_enable_pp1() {
    ap_enable_pp1 = (ap_idle_pp1.read() ^ ap_const_logic_1);
}

void kernel_correlation_sdse::thread_ap_enable_pp2() {
    ap_enable_pp2 = (ap_idle_pp2.read() ^ ap_const_logic_1);
}

void kernel_correlation_sdse::thread_ap_enable_pp3() {
    ap_enable_pp3 = (ap_idle_pp3.read() ^ ap_const_logic_1);
}

void kernel_correlation_sdse::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter5.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter9.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter10.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter12.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter13.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter14.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter15.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_idle_pp1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter5.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter9.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter10.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter12.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter13.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter14.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter15.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter16.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter17.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter18.read()))) {
        ap_idle_pp1 = ap_const_logic_1;
    } else {
        ap_idle_pp1 = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_idle_pp2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter1.read()))) {
        ap_idle_pp2 = ap_const_logic_1;
    } else {
        ap_idle_pp2 = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_idle_pp3() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter5.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp3_iter6.read()))) {
        ap_idle_pp3 = ap_const_logic_1;
    } else {
        ap_idle_pp3 = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_indvar_flatten13_phi_fu_33456_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten13_phi_fu_33456_p4 = add_ln3582_reg_59479.read();
    } else {
        ap_phi_mux_indvar_flatten13_phi_fu_33456_p4 = indvar_flatten13_reg_33452.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_indvar_flatten20_phi_fu_37524_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten20_phi_fu_37524_p4 = select_ln4421_1_reg_66751.read();
    } else {
        ap_phi_mux_indvar_flatten20_phi_fu_37524_p4 = indvar_flatten20_reg_37520.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_indvar_flatten60_phi_fu_37512_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten60_phi_fu_37512_p4 = add_ln4420_1_reg_66787.read();
    } else {
        ap_phi_mux_indvar_flatten60_phi_fu_37512_p4 = indvar_flatten60_reg_37508.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_indvar_flatten6_phi_fu_32143_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1336_reg_55213.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten6_phi_fu_32143_p4 = add_ln1336_reg_55217.read();
    } else {
        ap_phi_mux_indvar_flatten6_phi_fu_32143_p4 = indvar_flatten6_reg_32139.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_indvar_flatten_phi_fu_30830_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(icmp_ln51_reg_52463.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten_phi_fu_30830_p4 = add_ln51_reg_52467.read();
    } else {
        ap_phi_mux_indvar_flatten_phi_fu_30830_p4 = indvar_flatten_reg_30826.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2572_0_phi_fu_33467_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v2572_0_phi_fu_33467_p4 = select_ln3586_1_reg_59489.read();
    } else {
        ap_phi_mux_v2572_0_phi_fu_33467_p4 = v2572_0_reg_33463.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2573_0_phi_fu_33478_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v2573_0_phi_fu_33478_p4 = v2573_reg_66657.read();
    } else {
        ap_phi_mux_v2573_0_phi_fu_33478_p4 = v2573_0_reg_33474.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2574_phi_fu_33488_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2574_phi_fu_33488_p20 = v5_0_Dout_A.read();
        } else {
            ap_phi_mux_v2574_phi_fu_33488_p20 = ap_phi_reg_pp2_iter0_v2574_reg_33485.read();
        }
    } else {
        ap_phi_mux_v2574_phi_fu_33488_p20 = ap_phi_reg_pp2_iter0_v2574_reg_33485.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2575_phi_fu_33524_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2575_phi_fu_33524_p20 = v3_0_0_Dout_A.read();
        } else {
            ap_phi_mux_v2575_phi_fu_33524_p20 = ap_phi_reg_pp2_iter0_v2575_reg_33521.read();
        }
    } else {
        ap_phi_mux_v2575_phi_fu_33524_p20 = ap_phi_reg_pp2_iter0_v2575_reg_33521.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2577_phi_fu_33560_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2577_phi_fu_33560_p20 = v6_0_Dout_A.read();
        } else {
            ap_phi_mux_v2577_phi_fu_33560_p20 = ap_phi_reg_pp2_iter0_v2577_reg_33557.read();
        }
    } else {
        ap_phi_mux_v2577_phi_fu_33560_p20 = ap_phi_reg_pp2_iter0_v2577_reg_33557.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2580_phi_fu_33596_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2580_phi_fu_33596_p20 = v5_1_Dout_A.read();
        } else {
            ap_phi_mux_v2580_phi_fu_33596_p20 = ap_phi_reg_pp2_iter0_v2580_reg_33593.read();
        }
    } else {
        ap_phi_mux_v2580_phi_fu_33596_p20 = ap_phi_reg_pp2_iter0_v2580_reg_33593.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2581_phi_fu_33632_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2581_phi_fu_33632_p20 = v3_0_1_Dout_A.read();
        } else {
            ap_phi_mux_v2581_phi_fu_33632_p20 = ap_phi_reg_pp2_iter0_v2581_reg_33629.read();
        }
    } else {
        ap_phi_mux_v2581_phi_fu_33632_p20 = ap_phi_reg_pp2_iter0_v2581_reg_33629.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2583_phi_fu_33668_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2583_phi_fu_33668_p20 = v6_1_Dout_A.read();
        } else {
            ap_phi_mux_v2583_phi_fu_33668_p20 = ap_phi_reg_pp2_iter0_v2583_reg_33665.read();
        }
    } else {
        ap_phi_mux_v2583_phi_fu_33668_p20 = ap_phi_reg_pp2_iter0_v2583_reg_33665.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2586_phi_fu_33704_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2586_phi_fu_33704_p20 = v5_2_Dout_A.read();
        } else {
            ap_phi_mux_v2586_phi_fu_33704_p20 = ap_phi_reg_pp2_iter0_v2586_reg_33701.read();
        }
    } else {
        ap_phi_mux_v2586_phi_fu_33704_p20 = ap_phi_reg_pp2_iter0_v2586_reg_33701.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2587_phi_fu_33740_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2587_phi_fu_33740_p20 = v3_0_2_Dout_A.read();
        } else {
            ap_phi_mux_v2587_phi_fu_33740_p20 = ap_phi_reg_pp2_iter0_v2587_reg_33737.read();
        }
    } else {
        ap_phi_mux_v2587_phi_fu_33740_p20 = ap_phi_reg_pp2_iter0_v2587_reg_33737.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2592_phi_fu_33776_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2592_phi_fu_33776_p20 = v5_3_Dout_A.read();
        } else {
            ap_phi_mux_v2592_phi_fu_33776_p20 = ap_phi_reg_pp2_iter0_v2592_reg_33773.read();
        }
    } else {
        ap_phi_mux_v2592_phi_fu_33776_p20 = ap_phi_reg_pp2_iter0_v2592_reg_33773.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2593_phi_fu_33812_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2593_phi_fu_33812_p20 = v3_0_3_Dout_A.read();
        } else {
            ap_phi_mux_v2593_phi_fu_33812_p20 = ap_phi_reg_pp2_iter0_v2593_reg_33809.read();
        }
    } else {
        ap_phi_mux_v2593_phi_fu_33812_p20 = ap_phi_reg_pp2_iter0_v2593_reg_33809.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2599_phi_fu_33848_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2599_phi_fu_33848_p20 = v3_1_0_Dout_A.read();
        } else {
            ap_phi_mux_v2599_phi_fu_33848_p20 = ap_phi_reg_pp2_iter0_v2599_reg_33845.read();
        }
    } else {
        ap_phi_mux_v2599_phi_fu_33848_p20 = ap_phi_reg_pp2_iter0_v2599_reg_33845.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2605_phi_fu_33884_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2605_phi_fu_33884_p20 = v3_1_1_Dout_A.read();
        } else {
            ap_phi_mux_v2605_phi_fu_33884_p20 = ap_phi_reg_pp2_iter0_v2605_reg_33881.read();
        }
    } else {
        ap_phi_mux_v2605_phi_fu_33884_p20 = ap_phi_reg_pp2_iter0_v2605_reg_33881.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2611_phi_fu_33920_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2611_phi_fu_33920_p20 = v3_1_2_Dout_A.read();
        } else {
            ap_phi_mux_v2611_phi_fu_33920_p20 = ap_phi_reg_pp2_iter0_v2611_reg_33917.read();
        }
    } else {
        ap_phi_mux_v2611_phi_fu_33920_p20 = ap_phi_reg_pp2_iter0_v2611_reg_33917.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2617_phi_fu_33956_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2617_phi_fu_33956_p20 = v3_1_3_Dout_A.read();
        } else {
            ap_phi_mux_v2617_phi_fu_33956_p20 = ap_phi_reg_pp2_iter0_v2617_reg_33953.read();
        }
    } else {
        ap_phi_mux_v2617_phi_fu_33956_p20 = ap_phi_reg_pp2_iter0_v2617_reg_33953.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2623_phi_fu_33992_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2623_phi_fu_33992_p20 = v3_2_0_Dout_A.read();
        } else {
            ap_phi_mux_v2623_phi_fu_33992_p20 = ap_phi_reg_pp2_iter0_v2623_reg_33989.read();
        }
    } else {
        ap_phi_mux_v2623_phi_fu_33992_p20 = ap_phi_reg_pp2_iter0_v2623_reg_33989.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2629_phi_fu_34028_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2629_phi_fu_34028_p20 = v3_2_1_Dout_A.read();
        } else {
            ap_phi_mux_v2629_phi_fu_34028_p20 = ap_phi_reg_pp2_iter0_v2629_reg_34025.read();
        }
    } else {
        ap_phi_mux_v2629_phi_fu_34028_p20 = ap_phi_reg_pp2_iter0_v2629_reg_34025.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2635_phi_fu_34064_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2635_phi_fu_34064_p20 = v3_2_2_Dout_A.read();
        } else {
            ap_phi_mux_v2635_phi_fu_34064_p20 = ap_phi_reg_pp2_iter0_v2635_reg_34061.read();
        }
    } else {
        ap_phi_mux_v2635_phi_fu_34064_p20 = ap_phi_reg_pp2_iter0_v2635_reg_34061.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2641_phi_fu_34100_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2641_phi_fu_34100_p20 = v3_2_3_Dout_A.read();
        } else {
            ap_phi_mux_v2641_phi_fu_34100_p20 = ap_phi_reg_pp2_iter0_v2641_reg_34097.read();
        }
    } else {
        ap_phi_mux_v2641_phi_fu_34100_p20 = ap_phi_reg_pp2_iter0_v2641_reg_34097.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2647_phi_fu_34136_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2647_phi_fu_34136_p20 = v3_3_0_Dout_A.read();
        } else {
            ap_phi_mux_v2647_phi_fu_34136_p20 = ap_phi_reg_pp2_iter0_v2647_reg_34133.read();
        }
    } else {
        ap_phi_mux_v2647_phi_fu_34136_p20 = ap_phi_reg_pp2_iter0_v2647_reg_34133.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2653_phi_fu_34172_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2653_phi_fu_34172_p20 = v3_3_1_Dout_A.read();
        } else {
            ap_phi_mux_v2653_phi_fu_34172_p20 = ap_phi_reg_pp2_iter0_v2653_reg_34169.read();
        }
    } else {
        ap_phi_mux_v2653_phi_fu_34172_p20 = ap_phi_reg_pp2_iter0_v2653_reg_34169.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2659_phi_fu_34208_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2659_phi_fu_34208_p20 = v3_3_2_Dout_A.read();
        } else {
            ap_phi_mux_v2659_phi_fu_34208_p20 = ap_phi_reg_pp2_iter0_v2659_reg_34205.read();
        }
    } else {
        ap_phi_mux_v2659_phi_fu_34208_p20 = ap_phi_reg_pp2_iter0_v2659_reg_34205.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2665_phi_fu_34244_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2665_phi_fu_34244_p20 = v3_3_3_Dout_A.read();
        } else {
            ap_phi_mux_v2665_phi_fu_34244_p20 = ap_phi_reg_pp2_iter0_v2665_reg_34241.read();
        }
    } else {
        ap_phi_mux_v2665_phi_fu_34244_p20 = ap_phi_reg_pp2_iter0_v2665_reg_34241.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2671_phi_fu_34280_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2671_phi_fu_34280_p20 = v3_4_0_Dout_A.read();
        } else {
            ap_phi_mux_v2671_phi_fu_34280_p20 = ap_phi_reg_pp2_iter0_v2671_reg_34277.read();
        }
    } else {
        ap_phi_mux_v2671_phi_fu_34280_p20 = ap_phi_reg_pp2_iter0_v2671_reg_34277.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2677_phi_fu_34316_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2677_phi_fu_34316_p20 = v3_4_1_Dout_A.read();
        } else {
            ap_phi_mux_v2677_phi_fu_34316_p20 = ap_phi_reg_pp2_iter0_v2677_reg_34313.read();
        }
    } else {
        ap_phi_mux_v2677_phi_fu_34316_p20 = ap_phi_reg_pp2_iter0_v2677_reg_34313.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2683_phi_fu_34352_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2683_phi_fu_34352_p20 = v3_4_2_Dout_A.read();
        } else {
            ap_phi_mux_v2683_phi_fu_34352_p20 = ap_phi_reg_pp2_iter0_v2683_reg_34349.read();
        }
    } else {
        ap_phi_mux_v2683_phi_fu_34352_p20 = ap_phi_reg_pp2_iter0_v2683_reg_34349.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2689_phi_fu_34388_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2689_phi_fu_34388_p20 = v3_4_3_Dout_A.read();
        } else {
            ap_phi_mux_v2689_phi_fu_34388_p20 = ap_phi_reg_pp2_iter0_v2689_reg_34385.read();
        }
    } else {
        ap_phi_mux_v2689_phi_fu_34388_p20 = ap_phi_reg_pp2_iter0_v2689_reg_34385.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2695_phi_fu_34424_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2695_phi_fu_34424_p20 = v3_5_0_Dout_A.read();
        } else {
            ap_phi_mux_v2695_phi_fu_34424_p20 = ap_phi_reg_pp2_iter0_v2695_reg_34421.read();
        }
    } else {
        ap_phi_mux_v2695_phi_fu_34424_p20 = ap_phi_reg_pp2_iter0_v2695_reg_34421.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2701_phi_fu_34460_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2701_phi_fu_34460_p20 = v3_5_1_Dout_A.read();
        } else {
            ap_phi_mux_v2701_phi_fu_34460_p20 = ap_phi_reg_pp2_iter0_v2701_reg_34457.read();
        }
    } else {
        ap_phi_mux_v2701_phi_fu_34460_p20 = ap_phi_reg_pp2_iter0_v2701_reg_34457.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2707_phi_fu_34496_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2707_phi_fu_34496_p20 = v3_5_2_Dout_A.read();
        } else {
            ap_phi_mux_v2707_phi_fu_34496_p20 = ap_phi_reg_pp2_iter0_v2707_reg_34493.read();
        }
    } else {
        ap_phi_mux_v2707_phi_fu_34496_p20 = ap_phi_reg_pp2_iter0_v2707_reg_34493.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2713_phi_fu_34532_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2713_phi_fu_34532_p20 = v3_5_3_Dout_A.read();
        } else {
            ap_phi_mux_v2713_phi_fu_34532_p20 = ap_phi_reg_pp2_iter0_v2713_reg_34529.read();
        }
    } else {
        ap_phi_mux_v2713_phi_fu_34532_p20 = ap_phi_reg_pp2_iter0_v2713_reg_34529.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2719_phi_fu_34568_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2719_phi_fu_34568_p20 = v3_6_0_Dout_A.read();
        } else {
            ap_phi_mux_v2719_phi_fu_34568_p20 = ap_phi_reg_pp2_iter0_v2719_reg_34565.read();
        }
    } else {
        ap_phi_mux_v2719_phi_fu_34568_p20 = ap_phi_reg_pp2_iter0_v2719_reg_34565.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2725_phi_fu_34604_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2725_phi_fu_34604_p20 = v3_6_1_Dout_A.read();
        } else {
            ap_phi_mux_v2725_phi_fu_34604_p20 = ap_phi_reg_pp2_iter0_v2725_reg_34601.read();
        }
    } else {
        ap_phi_mux_v2725_phi_fu_34604_p20 = ap_phi_reg_pp2_iter0_v2725_reg_34601.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2731_phi_fu_34640_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2731_phi_fu_34640_p20 = v3_6_2_Dout_A.read();
        } else {
            ap_phi_mux_v2731_phi_fu_34640_p20 = ap_phi_reg_pp2_iter0_v2731_reg_34637.read();
        }
    } else {
        ap_phi_mux_v2731_phi_fu_34640_p20 = ap_phi_reg_pp2_iter0_v2731_reg_34637.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2737_phi_fu_34676_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2737_phi_fu_34676_p20 = v3_6_3_Dout_A.read();
        } else {
            ap_phi_mux_v2737_phi_fu_34676_p20 = ap_phi_reg_pp2_iter0_v2737_reg_34673.read();
        }
    } else {
        ap_phi_mux_v2737_phi_fu_34676_p20 = ap_phi_reg_pp2_iter0_v2737_reg_34673.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2743_phi_fu_34712_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2743_phi_fu_34712_p20 = v3_7_0_Dout_A.read();
        } else {
            ap_phi_mux_v2743_phi_fu_34712_p20 = ap_phi_reg_pp2_iter0_v2743_reg_34709.read();
        }
    } else {
        ap_phi_mux_v2743_phi_fu_34712_p20 = ap_phi_reg_pp2_iter0_v2743_reg_34709.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2749_phi_fu_34748_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2749_phi_fu_34748_p20 = v3_7_1_Dout_A.read();
        } else {
            ap_phi_mux_v2749_phi_fu_34748_p20 = ap_phi_reg_pp2_iter0_v2749_reg_34745.read();
        }
    } else {
        ap_phi_mux_v2749_phi_fu_34748_p20 = ap_phi_reg_pp2_iter0_v2749_reg_34745.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2755_phi_fu_34784_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2755_phi_fu_34784_p20 = v3_7_2_Dout_A.read();
        } else {
            ap_phi_mux_v2755_phi_fu_34784_p20 = ap_phi_reg_pp2_iter0_v2755_reg_34781.read();
        }
    } else {
        ap_phi_mux_v2755_phi_fu_34784_p20 = ap_phi_reg_pp2_iter0_v2755_reg_34781.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2761_phi_fu_34820_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2761_phi_fu_34820_p20 = v3_7_3_Dout_A.read();
        } else {
            ap_phi_mux_v2761_phi_fu_34820_p20 = ap_phi_reg_pp2_iter0_v2761_reg_34817.read();
        }
    } else {
        ap_phi_mux_v2761_phi_fu_34820_p20 = ap_phi_reg_pp2_iter0_v2761_reg_34817.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2767_phi_fu_34856_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2767_phi_fu_34856_p20 = v3_8_0_Dout_A.read();
        } else {
            ap_phi_mux_v2767_phi_fu_34856_p20 = ap_phi_reg_pp2_iter0_v2767_reg_34853.read();
        }
    } else {
        ap_phi_mux_v2767_phi_fu_34856_p20 = ap_phi_reg_pp2_iter0_v2767_reg_34853.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2773_phi_fu_34892_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2773_phi_fu_34892_p20 = v3_8_1_Dout_A.read();
        } else {
            ap_phi_mux_v2773_phi_fu_34892_p20 = ap_phi_reg_pp2_iter0_v2773_reg_34889.read();
        }
    } else {
        ap_phi_mux_v2773_phi_fu_34892_p20 = ap_phi_reg_pp2_iter0_v2773_reg_34889.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2779_phi_fu_34928_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2779_phi_fu_34928_p20 = v3_8_2_Dout_A.read();
        } else {
            ap_phi_mux_v2779_phi_fu_34928_p20 = ap_phi_reg_pp2_iter0_v2779_reg_34925.read();
        }
    } else {
        ap_phi_mux_v2779_phi_fu_34928_p20 = ap_phi_reg_pp2_iter0_v2779_reg_34925.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2785_phi_fu_34964_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2785_phi_fu_34964_p20 = v3_8_3_Dout_A.read();
        } else {
            ap_phi_mux_v2785_phi_fu_34964_p20 = ap_phi_reg_pp2_iter0_v2785_reg_34961.read();
        }
    } else {
        ap_phi_mux_v2785_phi_fu_34964_p20 = ap_phi_reg_pp2_iter0_v2785_reg_34961.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2791_phi_fu_35000_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2791_phi_fu_35000_p20 = v3_9_0_Dout_A.read();
        } else {
            ap_phi_mux_v2791_phi_fu_35000_p20 = ap_phi_reg_pp2_iter0_v2791_reg_34997.read();
        }
    } else {
        ap_phi_mux_v2791_phi_fu_35000_p20 = ap_phi_reg_pp2_iter0_v2791_reg_34997.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2797_phi_fu_35036_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2797_phi_fu_35036_p20 = v3_9_1_Dout_A.read();
        } else {
            ap_phi_mux_v2797_phi_fu_35036_p20 = ap_phi_reg_pp2_iter0_v2797_reg_35033.read();
        }
    } else {
        ap_phi_mux_v2797_phi_fu_35036_p20 = ap_phi_reg_pp2_iter0_v2797_reg_35033.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2803_phi_fu_35072_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2803_phi_fu_35072_p20 = v3_9_2_Dout_A.read();
        } else {
            ap_phi_mux_v2803_phi_fu_35072_p20 = ap_phi_reg_pp2_iter0_v2803_reg_35069.read();
        }
    } else {
        ap_phi_mux_v2803_phi_fu_35072_p20 = ap_phi_reg_pp2_iter0_v2803_reg_35069.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2809_phi_fu_35108_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2809_phi_fu_35108_p20 = v3_9_3_Dout_A.read();
        } else {
            ap_phi_mux_v2809_phi_fu_35108_p20 = ap_phi_reg_pp2_iter0_v2809_reg_35105.read();
        }
    } else {
        ap_phi_mux_v2809_phi_fu_35108_p20 = ap_phi_reg_pp2_iter0_v2809_reg_35105.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2815_phi_fu_35144_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2815_phi_fu_35144_p20 = v3_10_0_Dout_A.read();
        } else {
            ap_phi_mux_v2815_phi_fu_35144_p20 = ap_phi_reg_pp2_iter0_v2815_reg_35141.read();
        }
    } else {
        ap_phi_mux_v2815_phi_fu_35144_p20 = ap_phi_reg_pp2_iter0_v2815_reg_35141.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2821_phi_fu_35180_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2821_phi_fu_35180_p20 = v3_10_1_Dout_A.read();
        } else {
            ap_phi_mux_v2821_phi_fu_35180_p20 = ap_phi_reg_pp2_iter0_v2821_reg_35177.read();
        }
    } else {
        ap_phi_mux_v2821_phi_fu_35180_p20 = ap_phi_reg_pp2_iter0_v2821_reg_35177.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2827_phi_fu_35216_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2827_phi_fu_35216_p20 = v3_10_2_Dout_A.read();
        } else {
            ap_phi_mux_v2827_phi_fu_35216_p20 = ap_phi_reg_pp2_iter0_v2827_reg_35213.read();
        }
    } else {
        ap_phi_mux_v2827_phi_fu_35216_p20 = ap_phi_reg_pp2_iter0_v2827_reg_35213.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2833_phi_fu_35252_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2833_phi_fu_35252_p20 = v3_10_3_Dout_A.read();
        } else {
            ap_phi_mux_v2833_phi_fu_35252_p20 = ap_phi_reg_pp2_iter0_v2833_reg_35249.read();
        }
    } else {
        ap_phi_mux_v2833_phi_fu_35252_p20 = ap_phi_reg_pp2_iter0_v2833_reg_35249.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2839_phi_fu_35288_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2839_phi_fu_35288_p20 = v3_11_0_Dout_A.read();
        } else {
            ap_phi_mux_v2839_phi_fu_35288_p20 = ap_phi_reg_pp2_iter0_v2839_reg_35285.read();
        }
    } else {
        ap_phi_mux_v2839_phi_fu_35288_p20 = ap_phi_reg_pp2_iter0_v2839_reg_35285.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2845_phi_fu_35324_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2845_phi_fu_35324_p20 = v3_11_1_Dout_A.read();
        } else {
            ap_phi_mux_v2845_phi_fu_35324_p20 = ap_phi_reg_pp2_iter0_v2845_reg_35321.read();
        }
    } else {
        ap_phi_mux_v2845_phi_fu_35324_p20 = ap_phi_reg_pp2_iter0_v2845_reg_35321.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2851_phi_fu_35360_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2851_phi_fu_35360_p20 = v3_11_2_Dout_A.read();
        } else {
            ap_phi_mux_v2851_phi_fu_35360_p20 = ap_phi_reg_pp2_iter0_v2851_reg_35357.read();
        }
    } else {
        ap_phi_mux_v2851_phi_fu_35360_p20 = ap_phi_reg_pp2_iter0_v2851_reg_35357.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2857_phi_fu_35396_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2857_phi_fu_35396_p20 = v3_11_3_Dout_A.read();
        } else {
            ap_phi_mux_v2857_phi_fu_35396_p20 = ap_phi_reg_pp2_iter0_v2857_reg_35393.read();
        }
    } else {
        ap_phi_mux_v2857_phi_fu_35396_p20 = ap_phi_reg_pp2_iter0_v2857_reg_35393.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2863_phi_fu_35432_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2863_phi_fu_35432_p20 = v3_12_0_Dout_A.read();
        } else {
            ap_phi_mux_v2863_phi_fu_35432_p20 = ap_phi_reg_pp2_iter0_v2863_reg_35429.read();
        }
    } else {
        ap_phi_mux_v2863_phi_fu_35432_p20 = ap_phi_reg_pp2_iter0_v2863_reg_35429.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2869_phi_fu_35468_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2869_phi_fu_35468_p20 = v3_12_1_Dout_A.read();
        } else {
            ap_phi_mux_v2869_phi_fu_35468_p20 = ap_phi_reg_pp2_iter0_v2869_reg_35465.read();
        }
    } else {
        ap_phi_mux_v2869_phi_fu_35468_p20 = ap_phi_reg_pp2_iter0_v2869_reg_35465.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2875_phi_fu_35504_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2875_phi_fu_35504_p20 = v3_12_2_Dout_A.read();
        } else {
            ap_phi_mux_v2875_phi_fu_35504_p20 = ap_phi_reg_pp2_iter0_v2875_reg_35501.read();
        }
    } else {
        ap_phi_mux_v2875_phi_fu_35504_p20 = ap_phi_reg_pp2_iter0_v2875_reg_35501.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2881_phi_fu_35540_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2881_phi_fu_35540_p20 = v3_12_3_Dout_A.read();
        } else {
            ap_phi_mux_v2881_phi_fu_35540_p20 = ap_phi_reg_pp2_iter0_v2881_reg_35537.read();
        }
    } else {
        ap_phi_mux_v2881_phi_fu_35540_p20 = ap_phi_reg_pp2_iter0_v2881_reg_35537.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2887_phi_fu_35576_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2887_phi_fu_35576_p20 = v3_13_0_Dout_A.read();
        } else {
            ap_phi_mux_v2887_phi_fu_35576_p20 = ap_phi_reg_pp2_iter0_v2887_reg_35573.read();
        }
    } else {
        ap_phi_mux_v2887_phi_fu_35576_p20 = ap_phi_reg_pp2_iter0_v2887_reg_35573.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2893_phi_fu_35612_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2893_phi_fu_35612_p20 = v3_13_1_Dout_A.read();
        } else {
            ap_phi_mux_v2893_phi_fu_35612_p20 = ap_phi_reg_pp2_iter0_v2893_reg_35609.read();
        }
    } else {
        ap_phi_mux_v2893_phi_fu_35612_p20 = ap_phi_reg_pp2_iter0_v2893_reg_35609.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2899_phi_fu_35648_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2899_phi_fu_35648_p20 = v3_13_2_Dout_A.read();
        } else {
            ap_phi_mux_v2899_phi_fu_35648_p20 = ap_phi_reg_pp2_iter0_v2899_reg_35645.read();
        }
    } else {
        ap_phi_mux_v2899_phi_fu_35648_p20 = ap_phi_reg_pp2_iter0_v2899_reg_35645.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2905_phi_fu_35684_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2905_phi_fu_35684_p20 = v3_13_3_Dout_A.read();
        } else {
            ap_phi_mux_v2905_phi_fu_35684_p20 = ap_phi_reg_pp2_iter0_v2905_reg_35681.read();
        }
    } else {
        ap_phi_mux_v2905_phi_fu_35684_p20 = ap_phi_reg_pp2_iter0_v2905_reg_35681.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2911_phi_fu_35720_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2911_phi_fu_35720_p20 = v3_14_0_Dout_A.read();
        } else {
            ap_phi_mux_v2911_phi_fu_35720_p20 = ap_phi_reg_pp2_iter0_v2911_reg_35717.read();
        }
    } else {
        ap_phi_mux_v2911_phi_fu_35720_p20 = ap_phi_reg_pp2_iter0_v2911_reg_35717.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2917_phi_fu_35756_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2917_phi_fu_35756_p20 = v3_14_1_Dout_A.read();
        } else {
            ap_phi_mux_v2917_phi_fu_35756_p20 = ap_phi_reg_pp2_iter0_v2917_reg_35753.read();
        }
    } else {
        ap_phi_mux_v2917_phi_fu_35756_p20 = ap_phi_reg_pp2_iter0_v2917_reg_35753.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2923_phi_fu_35792_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2923_phi_fu_35792_p20 = v3_14_2_Dout_A.read();
        } else {
            ap_phi_mux_v2923_phi_fu_35792_p20 = ap_phi_reg_pp2_iter0_v2923_reg_35789.read();
        }
    } else {
        ap_phi_mux_v2923_phi_fu_35792_p20 = ap_phi_reg_pp2_iter0_v2923_reg_35789.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2929_phi_fu_35828_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2929_phi_fu_35828_p20 = v3_14_3_Dout_A.read();
        } else {
            ap_phi_mux_v2929_phi_fu_35828_p20 = ap_phi_reg_pp2_iter0_v2929_reg_35825.read();
        }
    } else {
        ap_phi_mux_v2929_phi_fu_35828_p20 = ap_phi_reg_pp2_iter0_v2929_reg_35825.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2935_phi_fu_35864_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2935_phi_fu_35864_p20 = v3_15_0_Dout_A.read();
        } else {
            ap_phi_mux_v2935_phi_fu_35864_p20 = ap_phi_reg_pp2_iter0_v2935_reg_35861.read();
        }
    } else {
        ap_phi_mux_v2935_phi_fu_35864_p20 = ap_phi_reg_pp2_iter0_v2935_reg_35861.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2941_phi_fu_35900_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2941_phi_fu_35900_p20 = v3_15_1_Dout_A.read();
        } else {
            ap_phi_mux_v2941_phi_fu_35900_p20 = ap_phi_reg_pp2_iter0_v2941_reg_35897.read();
        }
    } else {
        ap_phi_mux_v2941_phi_fu_35900_p20 = ap_phi_reg_pp2_iter0_v2941_reg_35897.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2947_phi_fu_35936_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2947_phi_fu_35936_p20 = v3_15_2_Dout_A.read();
        } else {
            ap_phi_mux_v2947_phi_fu_35936_p20 = ap_phi_reg_pp2_iter0_v2947_reg_35933.read();
        }
    } else {
        ap_phi_mux_v2947_phi_fu_35936_p20 = ap_phi_reg_pp2_iter0_v2947_reg_35933.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2953_phi_fu_35972_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2953_phi_fu_35972_p20 = v3_15_3_Dout_A.read();
        } else {
            ap_phi_mux_v2953_phi_fu_35972_p20 = ap_phi_reg_pp2_iter0_v2953_reg_35969.read();
        }
    } else {
        ap_phi_mux_v2953_phi_fu_35972_p20 = ap_phi_reg_pp2_iter0_v2953_reg_35969.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2959_phi_fu_36008_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2959_phi_fu_36008_p20 = v3_16_0_Dout_A.read();
        } else {
            ap_phi_mux_v2959_phi_fu_36008_p20 = ap_phi_reg_pp2_iter0_v2959_reg_36005.read();
        }
    } else {
        ap_phi_mux_v2959_phi_fu_36008_p20 = ap_phi_reg_pp2_iter0_v2959_reg_36005.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2965_phi_fu_36044_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2965_phi_fu_36044_p20 = v3_16_1_Dout_A.read();
        } else {
            ap_phi_mux_v2965_phi_fu_36044_p20 = ap_phi_reg_pp2_iter0_v2965_reg_36041.read();
        }
    } else {
        ap_phi_mux_v2965_phi_fu_36044_p20 = ap_phi_reg_pp2_iter0_v2965_reg_36041.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2971_phi_fu_36080_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2971_phi_fu_36080_p20 = v3_16_2_Dout_A.read();
        } else {
            ap_phi_mux_v2971_phi_fu_36080_p20 = ap_phi_reg_pp2_iter0_v2971_reg_36077.read();
        }
    } else {
        ap_phi_mux_v2971_phi_fu_36080_p20 = ap_phi_reg_pp2_iter0_v2971_reg_36077.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2977_phi_fu_36116_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2977_phi_fu_36116_p20 = v3_16_3_Dout_A.read();
        } else {
            ap_phi_mux_v2977_phi_fu_36116_p20 = ap_phi_reg_pp2_iter0_v2977_reg_36113.read();
        }
    } else {
        ap_phi_mux_v2977_phi_fu_36116_p20 = ap_phi_reg_pp2_iter0_v2977_reg_36113.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2983_phi_fu_36152_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2983_phi_fu_36152_p20 = v3_17_0_Dout_A.read();
        } else {
            ap_phi_mux_v2983_phi_fu_36152_p20 = ap_phi_reg_pp2_iter0_v2983_reg_36149.read();
        }
    } else {
        ap_phi_mux_v2983_phi_fu_36152_p20 = ap_phi_reg_pp2_iter0_v2983_reg_36149.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2989_phi_fu_36188_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2989_phi_fu_36188_p20 = v3_17_1_Dout_A.read();
        } else {
            ap_phi_mux_v2989_phi_fu_36188_p20 = ap_phi_reg_pp2_iter0_v2989_reg_36185.read();
        }
    } else {
        ap_phi_mux_v2989_phi_fu_36188_p20 = ap_phi_reg_pp2_iter0_v2989_reg_36185.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v2995_phi_fu_36224_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v2995_phi_fu_36224_p20 = v3_17_2_Dout_A.read();
        } else {
            ap_phi_mux_v2995_phi_fu_36224_p20 = ap_phi_reg_pp2_iter0_v2995_reg_36221.read();
        }
    } else {
        ap_phi_mux_v2995_phi_fu_36224_p20 = ap_phi_reg_pp2_iter0_v2995_reg_36221.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3001_phi_fu_36260_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3001_phi_fu_36260_p20 = v3_17_3_Dout_A.read();
        } else {
            ap_phi_mux_v3001_phi_fu_36260_p20 = ap_phi_reg_pp2_iter0_v3001_reg_36257.read();
        }
    } else {
        ap_phi_mux_v3001_phi_fu_36260_p20 = ap_phi_reg_pp2_iter0_v3001_reg_36257.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3007_phi_fu_36296_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3007_phi_fu_36296_p20 = v3_18_0_Dout_A.read();
        } else {
            ap_phi_mux_v3007_phi_fu_36296_p20 = ap_phi_reg_pp2_iter0_v3007_reg_36293.read();
        }
    } else {
        ap_phi_mux_v3007_phi_fu_36296_p20 = ap_phi_reg_pp2_iter0_v3007_reg_36293.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3013_phi_fu_36332_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3013_phi_fu_36332_p20 = v3_18_1_Dout_A.read();
        } else {
            ap_phi_mux_v3013_phi_fu_36332_p20 = ap_phi_reg_pp2_iter0_v3013_reg_36329.read();
        }
    } else {
        ap_phi_mux_v3013_phi_fu_36332_p20 = ap_phi_reg_pp2_iter0_v3013_reg_36329.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3019_phi_fu_36368_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3019_phi_fu_36368_p20 = v3_18_2_Dout_A.read();
        } else {
            ap_phi_mux_v3019_phi_fu_36368_p20 = ap_phi_reg_pp2_iter0_v3019_reg_36365.read();
        }
    } else {
        ap_phi_mux_v3019_phi_fu_36368_p20 = ap_phi_reg_pp2_iter0_v3019_reg_36365.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3025_phi_fu_36404_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3025_phi_fu_36404_p20 = v3_18_3_Dout_A.read();
        } else {
            ap_phi_mux_v3025_phi_fu_36404_p20 = ap_phi_reg_pp2_iter0_v3025_reg_36401.read();
        }
    } else {
        ap_phi_mux_v3025_phi_fu_36404_p20 = ap_phi_reg_pp2_iter0_v3025_reg_36401.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3031_phi_fu_36440_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3031_phi_fu_36440_p20 = v3_19_0_Dout_A.read();
        } else {
            ap_phi_mux_v3031_phi_fu_36440_p20 = ap_phi_reg_pp2_iter0_v3031_reg_36437.read();
        }
    } else {
        ap_phi_mux_v3031_phi_fu_36440_p20 = ap_phi_reg_pp2_iter0_v3031_reg_36437.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3037_phi_fu_36476_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3037_phi_fu_36476_p20 = v3_19_1_Dout_A.read();
        } else {
            ap_phi_mux_v3037_phi_fu_36476_p20 = ap_phi_reg_pp2_iter0_v3037_reg_36473.read();
        }
    } else {
        ap_phi_mux_v3037_phi_fu_36476_p20 = ap_phi_reg_pp2_iter0_v3037_reg_36473.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3043_phi_fu_36512_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3043_phi_fu_36512_p20 = v3_19_2_Dout_A.read();
        } else {
            ap_phi_mux_v3043_phi_fu_36512_p20 = ap_phi_reg_pp2_iter0_v3043_reg_36509.read();
        }
    } else {
        ap_phi_mux_v3043_phi_fu_36512_p20 = ap_phi_reg_pp2_iter0_v3043_reg_36509.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3049_phi_fu_36548_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3049_phi_fu_36548_p20 = v3_19_3_Dout_A.read();
        } else {
            ap_phi_mux_v3049_phi_fu_36548_p20 = ap_phi_reg_pp2_iter0_v3049_reg_36545.read();
        }
    } else {
        ap_phi_mux_v3049_phi_fu_36548_p20 = ap_phi_reg_pp2_iter0_v3049_reg_36545.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3055_phi_fu_36584_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3055_phi_fu_36584_p20 = v3_20_0_Dout_A.read();
        } else {
            ap_phi_mux_v3055_phi_fu_36584_p20 = ap_phi_reg_pp2_iter0_v3055_reg_36581.read();
        }
    } else {
        ap_phi_mux_v3055_phi_fu_36584_p20 = ap_phi_reg_pp2_iter0_v3055_reg_36581.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3061_phi_fu_36620_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3061_phi_fu_36620_p20 = v3_20_1_Dout_A.read();
        } else {
            ap_phi_mux_v3061_phi_fu_36620_p20 = ap_phi_reg_pp2_iter0_v3061_reg_36617.read();
        }
    } else {
        ap_phi_mux_v3061_phi_fu_36620_p20 = ap_phi_reg_pp2_iter0_v3061_reg_36617.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3067_phi_fu_36656_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3067_phi_fu_36656_p20 = v3_20_2_Dout_A.read();
        } else {
            ap_phi_mux_v3067_phi_fu_36656_p20 = ap_phi_reg_pp2_iter0_v3067_reg_36653.read();
        }
    } else {
        ap_phi_mux_v3067_phi_fu_36656_p20 = ap_phi_reg_pp2_iter0_v3067_reg_36653.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3073_phi_fu_36692_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3073_phi_fu_36692_p20 = v3_20_3_Dout_A.read();
        } else {
            ap_phi_mux_v3073_phi_fu_36692_p20 = ap_phi_reg_pp2_iter0_v3073_reg_36689.read();
        }
    } else {
        ap_phi_mux_v3073_phi_fu_36692_p20 = ap_phi_reg_pp2_iter0_v3073_reg_36689.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3079_phi_fu_36728_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3079_phi_fu_36728_p20 = v3_21_0_Dout_A.read();
        } else {
            ap_phi_mux_v3079_phi_fu_36728_p20 = ap_phi_reg_pp2_iter0_v3079_reg_36725.read();
        }
    } else {
        ap_phi_mux_v3079_phi_fu_36728_p20 = ap_phi_reg_pp2_iter0_v3079_reg_36725.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3085_phi_fu_36764_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3085_phi_fu_36764_p20 = v3_21_1_Dout_A.read();
        } else {
            ap_phi_mux_v3085_phi_fu_36764_p20 = ap_phi_reg_pp2_iter0_v3085_reg_36761.read();
        }
    } else {
        ap_phi_mux_v3085_phi_fu_36764_p20 = ap_phi_reg_pp2_iter0_v3085_reg_36761.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3091_phi_fu_36800_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3091_phi_fu_36800_p20 = v3_21_2_Dout_A.read();
        } else {
            ap_phi_mux_v3091_phi_fu_36800_p20 = ap_phi_reg_pp2_iter0_v3091_reg_36797.read();
        }
    } else {
        ap_phi_mux_v3091_phi_fu_36800_p20 = ap_phi_reg_pp2_iter0_v3091_reg_36797.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3097_phi_fu_36836_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3097_phi_fu_36836_p20 = v3_21_3_Dout_A.read();
        } else {
            ap_phi_mux_v3097_phi_fu_36836_p20 = ap_phi_reg_pp2_iter0_v3097_reg_36833.read();
        }
    } else {
        ap_phi_mux_v3097_phi_fu_36836_p20 = ap_phi_reg_pp2_iter0_v3097_reg_36833.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3103_phi_fu_36872_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3103_phi_fu_36872_p20 = v3_22_0_Dout_A.read();
        } else {
            ap_phi_mux_v3103_phi_fu_36872_p20 = ap_phi_reg_pp2_iter0_v3103_reg_36869.read();
        }
    } else {
        ap_phi_mux_v3103_phi_fu_36872_p20 = ap_phi_reg_pp2_iter0_v3103_reg_36869.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3109_phi_fu_36908_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3109_phi_fu_36908_p20 = v3_22_1_Dout_A.read();
        } else {
            ap_phi_mux_v3109_phi_fu_36908_p20 = ap_phi_reg_pp2_iter0_v3109_reg_36905.read();
        }
    } else {
        ap_phi_mux_v3109_phi_fu_36908_p20 = ap_phi_reg_pp2_iter0_v3109_reg_36905.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3115_phi_fu_36944_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3115_phi_fu_36944_p20 = v3_22_2_Dout_A.read();
        } else {
            ap_phi_mux_v3115_phi_fu_36944_p20 = ap_phi_reg_pp2_iter0_v3115_reg_36941.read();
        }
    } else {
        ap_phi_mux_v3115_phi_fu_36944_p20 = ap_phi_reg_pp2_iter0_v3115_reg_36941.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3121_phi_fu_36980_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3121_phi_fu_36980_p20 = v3_22_3_Dout_A.read();
        } else {
            ap_phi_mux_v3121_phi_fu_36980_p20 = ap_phi_reg_pp2_iter0_v3121_reg_36977.read();
        }
    } else {
        ap_phi_mux_v3121_phi_fu_36980_p20 = ap_phi_reg_pp2_iter0_v3121_reg_36977.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3127_phi_fu_37016_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3127_phi_fu_37016_p20 = v3_23_0_Dout_A.read();
        } else {
            ap_phi_mux_v3127_phi_fu_37016_p20 = ap_phi_reg_pp2_iter0_v3127_reg_37013.read();
        }
    } else {
        ap_phi_mux_v3127_phi_fu_37016_p20 = ap_phi_reg_pp2_iter0_v3127_reg_37013.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3133_phi_fu_37052_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3133_phi_fu_37052_p20 = v3_23_1_Dout_A.read();
        } else {
            ap_phi_mux_v3133_phi_fu_37052_p20 = ap_phi_reg_pp2_iter0_v3133_reg_37049.read();
        }
    } else {
        ap_phi_mux_v3133_phi_fu_37052_p20 = ap_phi_reg_pp2_iter0_v3133_reg_37049.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3139_phi_fu_37088_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3139_phi_fu_37088_p20 = v3_23_2_Dout_A.read();
        } else {
            ap_phi_mux_v3139_phi_fu_37088_p20 = ap_phi_reg_pp2_iter0_v3139_reg_37085.read();
        }
    } else {
        ap_phi_mux_v3139_phi_fu_37088_p20 = ap_phi_reg_pp2_iter0_v3139_reg_37085.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3145_phi_fu_37124_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3145_phi_fu_37124_p20 = v3_23_3_Dout_A.read();
        } else {
            ap_phi_mux_v3145_phi_fu_37124_p20 = ap_phi_reg_pp2_iter0_v3145_reg_37121.read();
        }
    } else {
        ap_phi_mux_v3145_phi_fu_37124_p20 = ap_phi_reg_pp2_iter0_v3145_reg_37121.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3151_phi_fu_37160_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3151_phi_fu_37160_p20 = v3_24_0_Dout_A.read();
        } else {
            ap_phi_mux_v3151_phi_fu_37160_p20 = ap_phi_reg_pp2_iter0_v3151_reg_37157.read();
        }
    } else {
        ap_phi_mux_v3151_phi_fu_37160_p20 = ap_phi_reg_pp2_iter0_v3151_reg_37157.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3157_phi_fu_37196_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3157_phi_fu_37196_p20 = v3_24_1_Dout_A.read();
        } else {
            ap_phi_mux_v3157_phi_fu_37196_p20 = ap_phi_reg_pp2_iter0_v3157_reg_37193.read();
        }
    } else {
        ap_phi_mux_v3157_phi_fu_37196_p20 = ap_phi_reg_pp2_iter0_v3157_reg_37193.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3163_phi_fu_37232_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3163_phi_fu_37232_p20 = v3_24_2_Dout_A.read();
        } else {
            ap_phi_mux_v3163_phi_fu_37232_p20 = ap_phi_reg_pp2_iter0_v3163_reg_37229.read();
        }
    } else {
        ap_phi_mux_v3163_phi_fu_37232_p20 = ap_phi_reg_pp2_iter0_v3163_reg_37229.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3169_phi_fu_37268_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3169_phi_fu_37268_p20 = v3_24_3_Dout_A.read();
        } else {
            ap_phi_mux_v3169_phi_fu_37268_p20 = ap_phi_reg_pp2_iter0_v3169_reg_37265.read();
        }
    } else {
        ap_phi_mux_v3169_phi_fu_37268_p20 = ap_phi_reg_pp2_iter0_v3169_reg_37265.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3175_phi_fu_37304_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_36_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_32_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_28_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_24_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_20_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_16_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_12_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_8_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_4_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3175_phi_fu_37304_p20 = v3_25_0_Dout_A.read();
        } else {
            ap_phi_mux_v3175_phi_fu_37304_p20 = ap_phi_reg_pp2_iter0_v3175_reg_37301.read();
        }
    } else {
        ap_phi_mux_v3175_phi_fu_37304_p20 = ap_phi_reg_pp2_iter0_v3175_reg_37301.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3181_phi_fu_37340_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_37_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_33_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_29_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_25_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_21_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_17_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_13_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_9_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_5_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3181_phi_fu_37340_p20 = v3_25_1_Dout_A.read();
        } else {
            ap_phi_mux_v3181_phi_fu_37340_p20 = ap_phi_reg_pp2_iter0_v3181_reg_37337.read();
        }
    } else {
        ap_phi_mux_v3181_phi_fu_37340_p20 = ap_phi_reg_pp2_iter0_v3181_reg_37337.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3187_phi_fu_37376_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_38_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_34_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_30_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_26_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_22_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_18_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_14_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_10_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_6_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3187_phi_fu_37376_p20 = v3_25_2_Dout_A.read();
        } else {
            ap_phi_mux_v3187_phi_fu_37376_p20 = ap_phi_reg_pp2_iter0_v3187_reg_37373.read();
        }
    } else {
        ap_phi_mux_v3187_phi_fu_37376_p20 = ap_phi_reg_pp2_iter0_v3187_reg_37373.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3193_phi_fu_37412_p20() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln3582_reg_59475.read())) {
        if (esl_seteq<1,1,1>(ap_condition_35574.read(), ap_const_boolean_1)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_39_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_35_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_31_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_27_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_23_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_19_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_15_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_11_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_7_Dout_A.read();
        } else if (esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0)) {
            ap_phi_mux_v3193_phi_fu_37412_p20 = v3_25_3_Dout_A.read();
        } else {
            ap_phi_mux_v3193_phi_fu_37412_p20 = ap_phi_reg_pp2_iter0_v3193_reg_37409.read();
        }
    } else {
        ap_phi_mux_v3193_phi_fu_37412_p20 = ap_phi_reg_pp2_iter0_v3193_reg_37409.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3199_0_phi_fu_37558_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0))) {
        ap_phi_mux_v3199_0_phi_fu_37558_p4 = select_ln4420_2_reg_66769.read();
    } else {
        ap_phi_mux_v3199_0_phi_fu_37558_p4 = v3199_0_reg_37554.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3200_0_phi_fu_37535_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v3200_0_phi_fu_37535_p4 = select_ln4421_reg_66741.read();
    } else {
        ap_phi_mux_v3200_0_phi_fu_37535_p4 = v3200_0_reg_37531.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v3201_0_phi_fu_37547_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v3201_0_phi_fu_37547_p4 = v3201_reg_66746.read();
    } else {
        ap_phi_mux_v3201_0_phi_fu_37547_p4 = v3201_0_reg_37543.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v7_0_phi_fu_30841_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(icmp_ln51_reg_52463.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v7_0_phi_fu_30841_p4 = select_ln51_1_reg_52479.read();
    } else {
        ap_phi_mux_v7_0_phi_fu_30841_p4 = v7_0_reg_30837.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v809_0_phi_fu_32154_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1336_reg_55213.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v809_0_phi_fu_32154_p4 = select_ln1336_1_reg_55228.read();
    } else {
        ap_phi_mux_v809_0_phi_fu_32154_p4 = v809_0_reg_32150.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v810_0_phi_fu_32165_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1336_reg_55213.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v810_0_phi_fu_32165_p4 = v810_reg_55697.read();
    } else {
        ap_phi_mux_v810_0_phi_fu_32165_p4 = v810_0_reg_32161.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_mux_v8_0_phi_fu_30852_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(icmp_ln51_reg_52463.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v8_0_phi_fu_30852_p4 = v8_reg_52504.read();
    } else {
        ap_phi_mux_v8_0_phi_fu_30852_p4 = v8_0_reg_30848.read();
    }
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v609_reg_30859() {
    ap_phi_reg_pp0_iter0_v609_reg_30859 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v614_reg_30891() {
    ap_phi_reg_pp0_iter0_v614_reg_30891 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v619_reg_30923() {
    ap_phi_reg_pp0_iter0_v619_reg_30923 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v624_reg_30955() {
    ap_phi_reg_pp0_iter0_v624_reg_30955 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v629_reg_30987() {
    ap_phi_reg_pp0_iter0_v629_reg_30987 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v634_reg_31019() {
    ap_phi_reg_pp0_iter0_v634_reg_31019 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v639_reg_31051() {
    ap_phi_reg_pp0_iter0_v639_reg_31051 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v644_reg_31083() {
    ap_phi_reg_pp0_iter0_v644_reg_31083 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v649_reg_31115() {
    ap_phi_reg_pp0_iter0_v649_reg_31115 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v654_reg_31147() {
    ap_phi_reg_pp0_iter0_v654_reg_31147 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v659_reg_31179() {
    ap_phi_reg_pp0_iter0_v659_reg_31179 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v664_reg_31211() {
    ap_phi_reg_pp0_iter0_v664_reg_31211 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v669_reg_31243() {
    ap_phi_reg_pp0_iter0_v669_reg_31243 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v674_reg_31275() {
    ap_phi_reg_pp0_iter0_v674_reg_31275 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v679_reg_31307() {
    ap_phi_reg_pp0_iter0_v679_reg_31307 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v684_reg_31339() {
    ap_phi_reg_pp0_iter0_v684_reg_31339 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v689_reg_31371() {
    ap_phi_reg_pp0_iter0_v689_reg_31371 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v694_reg_31403() {
    ap_phi_reg_pp0_iter0_v694_reg_31403 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v699_reg_31435() {
    ap_phi_reg_pp0_iter0_v699_reg_31435 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v704_reg_31467() {
    ap_phi_reg_pp0_iter0_v704_reg_31467 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v709_reg_31499() {
    ap_phi_reg_pp0_iter0_v709_reg_31499 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v714_reg_31531() {
    ap_phi_reg_pp0_iter0_v714_reg_31531 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v719_reg_31563() {
    ap_phi_reg_pp0_iter0_v719_reg_31563 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v724_reg_31595() {
    ap_phi_reg_pp0_iter0_v724_reg_31595 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v729_reg_31627() {
    ap_phi_reg_pp0_iter0_v729_reg_31627 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v734_reg_31659() {
    ap_phi_reg_pp0_iter0_v734_reg_31659 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v739_reg_31691() {
    ap_phi_reg_pp0_iter0_v739_reg_31691 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v744_reg_31723() {
    ap_phi_reg_pp0_iter0_v744_reg_31723 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v749_reg_31755() {
    ap_phi_reg_pp0_iter0_v749_reg_31755 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v754_reg_31787() {
    ap_phi_reg_pp0_iter0_v754_reg_31787 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v759_reg_31819() {
    ap_phi_reg_pp0_iter0_v759_reg_31819 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v764_reg_31851() {
    ap_phi_reg_pp0_iter0_v764_reg_31851 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v769_reg_31883() {
    ap_phi_reg_pp0_iter0_v769_reg_31883 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v774_reg_31915() {
    ap_phi_reg_pp0_iter0_v774_reg_31915 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v779_reg_31947() {
    ap_phi_reg_pp0_iter0_v779_reg_31947 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v784_reg_31979() {
    ap_phi_reg_pp0_iter0_v784_reg_31979 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v789_reg_32011() {
    ap_phi_reg_pp0_iter0_v789_reg_32011 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v794_reg_32043() {
    ap_phi_reg_pp0_iter0_v794_reg_32043 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v799_reg_32075() {
    ap_phi_reg_pp0_iter0_v799_reg_32075 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp0_iter0_v804_reg_32107() {
    ap_phi_reg_pp0_iter0_v804_reg_32107 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2131_reg_32172() {
    ap_phi_reg_pp1_iter0_v2131_reg_32172 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2142_reg_32204() {
    ap_phi_reg_pp1_iter0_v2142_reg_32204 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2153_reg_32236() {
    ap_phi_reg_pp1_iter0_v2153_reg_32236 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2164_reg_32268() {
    ap_phi_reg_pp1_iter0_v2164_reg_32268 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2175_reg_32300() {
    ap_phi_reg_pp1_iter0_v2175_reg_32300 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2186_reg_32332() {
    ap_phi_reg_pp1_iter0_v2186_reg_32332 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2197_reg_32364() {
    ap_phi_reg_pp1_iter0_v2197_reg_32364 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2208_reg_32396() {
    ap_phi_reg_pp1_iter0_v2208_reg_32396 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2219_reg_32428() {
    ap_phi_reg_pp1_iter0_v2219_reg_32428 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2230_reg_32460() {
    ap_phi_reg_pp1_iter0_v2230_reg_32460 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2241_reg_32492() {
    ap_phi_reg_pp1_iter0_v2241_reg_32492 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2252_reg_32524() {
    ap_phi_reg_pp1_iter0_v2252_reg_32524 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2263_reg_32556() {
    ap_phi_reg_pp1_iter0_v2263_reg_32556 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2274_reg_32588() {
    ap_phi_reg_pp1_iter0_v2274_reg_32588 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2285_reg_32620() {
    ap_phi_reg_pp1_iter0_v2285_reg_32620 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2296_reg_32652() {
    ap_phi_reg_pp1_iter0_v2296_reg_32652 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2307_reg_32684() {
    ap_phi_reg_pp1_iter0_v2307_reg_32684 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2318_reg_32716() {
    ap_phi_reg_pp1_iter0_v2318_reg_32716 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2329_reg_32748() {
    ap_phi_reg_pp1_iter0_v2329_reg_32748 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2340_reg_32780() {
    ap_phi_reg_pp1_iter0_v2340_reg_32780 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2351_reg_32812() {
    ap_phi_reg_pp1_iter0_v2351_reg_32812 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2362_reg_32844() {
    ap_phi_reg_pp1_iter0_v2362_reg_32844 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2373_reg_32876() {
    ap_phi_reg_pp1_iter0_v2373_reg_32876 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2384_reg_32908() {
    ap_phi_reg_pp1_iter0_v2384_reg_32908 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2395_reg_32940() {
    ap_phi_reg_pp1_iter0_v2395_reg_32940 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2406_reg_32972() {
    ap_phi_reg_pp1_iter0_v2406_reg_32972 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2417_reg_33004() {
    ap_phi_reg_pp1_iter0_v2417_reg_33004 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2428_reg_33036() {
    ap_phi_reg_pp1_iter0_v2428_reg_33036 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2439_reg_33068() {
    ap_phi_reg_pp1_iter0_v2439_reg_33068 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2450_reg_33100() {
    ap_phi_reg_pp1_iter0_v2450_reg_33100 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2461_reg_33132() {
    ap_phi_reg_pp1_iter0_v2461_reg_33132 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2472_reg_33164() {
    ap_phi_reg_pp1_iter0_v2472_reg_33164 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2483_reg_33196() {
    ap_phi_reg_pp1_iter0_v2483_reg_33196 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2494_reg_33228() {
    ap_phi_reg_pp1_iter0_v2494_reg_33228 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2505_reg_33260() {
    ap_phi_reg_pp1_iter0_v2505_reg_33260 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2516_reg_33292() {
    ap_phi_reg_pp1_iter0_v2516_reg_33292 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2527_reg_33324() {
    ap_phi_reg_pp1_iter0_v2527_reg_33324 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2538_reg_33356() {
    ap_phi_reg_pp1_iter0_v2538_reg_33356 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2549_reg_33388() {
    ap_phi_reg_pp1_iter0_v2549_reg_33388 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp1_iter0_v2560_reg_33420() {
    ap_phi_reg_pp1_iter0_v2560_reg_33420 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2574_reg_33485() {
    ap_phi_reg_pp2_iter0_v2574_reg_33485 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2575_reg_33521() {
    ap_phi_reg_pp2_iter0_v2575_reg_33521 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2577_reg_33557() {
    ap_phi_reg_pp2_iter0_v2577_reg_33557 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2580_reg_33593() {
    ap_phi_reg_pp2_iter0_v2580_reg_33593 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2581_reg_33629() {
    ap_phi_reg_pp2_iter0_v2581_reg_33629 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2583_reg_33665() {
    ap_phi_reg_pp2_iter0_v2583_reg_33665 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2586_reg_33701() {
    ap_phi_reg_pp2_iter0_v2586_reg_33701 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2587_reg_33737() {
    ap_phi_reg_pp2_iter0_v2587_reg_33737 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2592_reg_33773() {
    ap_phi_reg_pp2_iter0_v2592_reg_33773 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2593_reg_33809() {
    ap_phi_reg_pp2_iter0_v2593_reg_33809 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2599_reg_33845() {
    ap_phi_reg_pp2_iter0_v2599_reg_33845 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2605_reg_33881() {
    ap_phi_reg_pp2_iter0_v2605_reg_33881 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2611_reg_33917() {
    ap_phi_reg_pp2_iter0_v2611_reg_33917 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2617_reg_33953() {
    ap_phi_reg_pp2_iter0_v2617_reg_33953 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2623_reg_33989() {
    ap_phi_reg_pp2_iter0_v2623_reg_33989 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2629_reg_34025() {
    ap_phi_reg_pp2_iter0_v2629_reg_34025 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2635_reg_34061() {
    ap_phi_reg_pp2_iter0_v2635_reg_34061 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2641_reg_34097() {
    ap_phi_reg_pp2_iter0_v2641_reg_34097 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2647_reg_34133() {
    ap_phi_reg_pp2_iter0_v2647_reg_34133 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2653_reg_34169() {
    ap_phi_reg_pp2_iter0_v2653_reg_34169 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2659_reg_34205() {
    ap_phi_reg_pp2_iter0_v2659_reg_34205 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2665_reg_34241() {
    ap_phi_reg_pp2_iter0_v2665_reg_34241 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2671_reg_34277() {
    ap_phi_reg_pp2_iter0_v2671_reg_34277 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2677_reg_34313() {
    ap_phi_reg_pp2_iter0_v2677_reg_34313 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2683_reg_34349() {
    ap_phi_reg_pp2_iter0_v2683_reg_34349 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2689_reg_34385() {
    ap_phi_reg_pp2_iter0_v2689_reg_34385 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2695_reg_34421() {
    ap_phi_reg_pp2_iter0_v2695_reg_34421 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2701_reg_34457() {
    ap_phi_reg_pp2_iter0_v2701_reg_34457 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2707_reg_34493() {
    ap_phi_reg_pp2_iter0_v2707_reg_34493 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2713_reg_34529() {
    ap_phi_reg_pp2_iter0_v2713_reg_34529 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2719_reg_34565() {
    ap_phi_reg_pp2_iter0_v2719_reg_34565 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2725_reg_34601() {
    ap_phi_reg_pp2_iter0_v2725_reg_34601 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2731_reg_34637() {
    ap_phi_reg_pp2_iter0_v2731_reg_34637 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2737_reg_34673() {
    ap_phi_reg_pp2_iter0_v2737_reg_34673 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2743_reg_34709() {
    ap_phi_reg_pp2_iter0_v2743_reg_34709 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2749_reg_34745() {
    ap_phi_reg_pp2_iter0_v2749_reg_34745 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2755_reg_34781() {
    ap_phi_reg_pp2_iter0_v2755_reg_34781 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2761_reg_34817() {
    ap_phi_reg_pp2_iter0_v2761_reg_34817 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2767_reg_34853() {
    ap_phi_reg_pp2_iter0_v2767_reg_34853 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2773_reg_34889() {
    ap_phi_reg_pp2_iter0_v2773_reg_34889 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2779_reg_34925() {
    ap_phi_reg_pp2_iter0_v2779_reg_34925 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2785_reg_34961() {
    ap_phi_reg_pp2_iter0_v2785_reg_34961 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2791_reg_34997() {
    ap_phi_reg_pp2_iter0_v2791_reg_34997 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2797_reg_35033() {
    ap_phi_reg_pp2_iter0_v2797_reg_35033 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2803_reg_35069() {
    ap_phi_reg_pp2_iter0_v2803_reg_35069 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2809_reg_35105() {
    ap_phi_reg_pp2_iter0_v2809_reg_35105 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2815_reg_35141() {
    ap_phi_reg_pp2_iter0_v2815_reg_35141 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2821_reg_35177() {
    ap_phi_reg_pp2_iter0_v2821_reg_35177 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2827_reg_35213() {
    ap_phi_reg_pp2_iter0_v2827_reg_35213 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2833_reg_35249() {
    ap_phi_reg_pp2_iter0_v2833_reg_35249 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2839_reg_35285() {
    ap_phi_reg_pp2_iter0_v2839_reg_35285 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2845_reg_35321() {
    ap_phi_reg_pp2_iter0_v2845_reg_35321 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2851_reg_35357() {
    ap_phi_reg_pp2_iter0_v2851_reg_35357 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2857_reg_35393() {
    ap_phi_reg_pp2_iter0_v2857_reg_35393 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2863_reg_35429() {
    ap_phi_reg_pp2_iter0_v2863_reg_35429 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2869_reg_35465() {
    ap_phi_reg_pp2_iter0_v2869_reg_35465 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2875_reg_35501() {
    ap_phi_reg_pp2_iter0_v2875_reg_35501 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2881_reg_35537() {
    ap_phi_reg_pp2_iter0_v2881_reg_35537 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2887_reg_35573() {
    ap_phi_reg_pp2_iter0_v2887_reg_35573 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2893_reg_35609() {
    ap_phi_reg_pp2_iter0_v2893_reg_35609 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2899_reg_35645() {
    ap_phi_reg_pp2_iter0_v2899_reg_35645 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2905_reg_35681() {
    ap_phi_reg_pp2_iter0_v2905_reg_35681 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2911_reg_35717() {
    ap_phi_reg_pp2_iter0_v2911_reg_35717 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2917_reg_35753() {
    ap_phi_reg_pp2_iter0_v2917_reg_35753 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2923_reg_35789() {
    ap_phi_reg_pp2_iter0_v2923_reg_35789 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2929_reg_35825() {
    ap_phi_reg_pp2_iter0_v2929_reg_35825 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2935_reg_35861() {
    ap_phi_reg_pp2_iter0_v2935_reg_35861 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2941_reg_35897() {
    ap_phi_reg_pp2_iter0_v2941_reg_35897 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2947_reg_35933() {
    ap_phi_reg_pp2_iter0_v2947_reg_35933 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2953_reg_35969() {
    ap_phi_reg_pp2_iter0_v2953_reg_35969 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2959_reg_36005() {
    ap_phi_reg_pp2_iter0_v2959_reg_36005 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2965_reg_36041() {
    ap_phi_reg_pp2_iter0_v2965_reg_36041 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2971_reg_36077() {
    ap_phi_reg_pp2_iter0_v2971_reg_36077 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2977_reg_36113() {
    ap_phi_reg_pp2_iter0_v2977_reg_36113 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2983_reg_36149() {
    ap_phi_reg_pp2_iter0_v2983_reg_36149 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2989_reg_36185() {
    ap_phi_reg_pp2_iter0_v2989_reg_36185 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v2995_reg_36221() {
    ap_phi_reg_pp2_iter0_v2995_reg_36221 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3001_reg_36257() {
    ap_phi_reg_pp2_iter0_v3001_reg_36257 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3007_reg_36293() {
    ap_phi_reg_pp2_iter0_v3007_reg_36293 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3013_reg_36329() {
    ap_phi_reg_pp2_iter0_v3013_reg_36329 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3019_reg_36365() {
    ap_phi_reg_pp2_iter0_v3019_reg_36365 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3025_reg_36401() {
    ap_phi_reg_pp2_iter0_v3025_reg_36401 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3031_reg_36437() {
    ap_phi_reg_pp2_iter0_v3031_reg_36437 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3037_reg_36473() {
    ap_phi_reg_pp2_iter0_v3037_reg_36473 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3043_reg_36509() {
    ap_phi_reg_pp2_iter0_v3043_reg_36509 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3049_reg_36545() {
    ap_phi_reg_pp2_iter0_v3049_reg_36545 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3055_reg_36581() {
    ap_phi_reg_pp2_iter0_v3055_reg_36581 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3061_reg_36617() {
    ap_phi_reg_pp2_iter0_v3061_reg_36617 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3067_reg_36653() {
    ap_phi_reg_pp2_iter0_v3067_reg_36653 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3073_reg_36689() {
    ap_phi_reg_pp2_iter0_v3073_reg_36689 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3079_reg_36725() {
    ap_phi_reg_pp2_iter0_v3079_reg_36725 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3085_reg_36761() {
    ap_phi_reg_pp2_iter0_v3085_reg_36761 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3091_reg_36797() {
    ap_phi_reg_pp2_iter0_v3091_reg_36797 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3097_reg_36833() {
    ap_phi_reg_pp2_iter0_v3097_reg_36833 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3103_reg_36869() {
    ap_phi_reg_pp2_iter0_v3103_reg_36869 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3109_reg_36905() {
    ap_phi_reg_pp2_iter0_v3109_reg_36905 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3115_reg_36941() {
    ap_phi_reg_pp2_iter0_v3115_reg_36941 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3121_reg_36977() {
    ap_phi_reg_pp2_iter0_v3121_reg_36977 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3127_reg_37013() {
    ap_phi_reg_pp2_iter0_v3127_reg_37013 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3133_reg_37049() {
    ap_phi_reg_pp2_iter0_v3133_reg_37049 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3139_reg_37085() {
    ap_phi_reg_pp2_iter0_v3139_reg_37085 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3145_reg_37121() {
    ap_phi_reg_pp2_iter0_v3145_reg_37121 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3151_reg_37157() {
    ap_phi_reg_pp2_iter0_v3151_reg_37157 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3157_reg_37193() {
    ap_phi_reg_pp2_iter0_v3157_reg_37193 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3163_reg_37229() {
    ap_phi_reg_pp2_iter0_v3163_reg_37229 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3169_reg_37265() {
    ap_phi_reg_pp2_iter0_v3169_reg_37265 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3175_reg_37301() {
    ap_phi_reg_pp2_iter0_v3175_reg_37301 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3181_reg_37337() {
    ap_phi_reg_pp2_iter0_v3181_reg_37337 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3187_reg_37373() {
    ap_phi_reg_pp2_iter0_v3187_reg_37373 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_phi_reg_pp2_iter0_v3193_reg_37409() {
    ap_phi_reg_pp2_iter0_v3193_reg_37409 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
}

void kernel_correlation_sdse::thread_ap_predicate_op17236_call_state143_state142() {
    ap_predicate_op17236_call_state143_state142 = (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter2_reg.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()));
}

void kernel_correlation_sdse::thread_ap_predicate_op17238_call_state145_state144() {
    ap_predicate_op17238_call_state145_state144 = (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()));
}

void kernel_correlation_sdse::thread_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state128.read()) && 
         esl_seteq<1,1,1>(icmp_ln4419_fu_51767_p2.read(), ap_const_lv1_1))) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_ap_rst_n_inv() {
    ap_rst_n_inv =  (sc_logic) (~ap_rst_n.read());
}

void kernel_correlation_sdse::thread_bitcast_ln3030_fu_48464_p1() {
    bitcast_ln3030_fu_48464_p1 = grp_fu_43096_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3044_fu_48494_p1() {
    bitcast_ln3044_fu_48494_p1 = grp_fu_43099_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3058_fu_48524_p1() {
    bitcast_ln3058_fu_48524_p1 = grp_fu_43102_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3072_fu_48554_p1() {
    bitcast_ln3072_fu_48554_p1 = grp_fu_43105_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3086_fu_48584_p1() {
    bitcast_ln3086_fu_48584_p1 = grp_fu_43108_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3100_fu_48614_p1() {
    bitcast_ln3100_fu_48614_p1 = grp_fu_43111_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3114_fu_48644_p1() {
    bitcast_ln3114_fu_48644_p1 = grp_fu_43114_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3128_fu_48674_p1() {
    bitcast_ln3128_fu_48674_p1 = grp_fu_43117_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3142_fu_48704_p1() {
    bitcast_ln3142_fu_48704_p1 = grp_fu_43120_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3156_fu_48734_p1() {
    bitcast_ln3156_fu_48734_p1 = grp_fu_43123_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3170_fu_48764_p1() {
    bitcast_ln3170_fu_48764_p1 = grp_fu_43126_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3184_fu_48794_p1() {
    bitcast_ln3184_fu_48794_p1 = grp_fu_43129_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3198_fu_48824_p1() {
    bitcast_ln3198_fu_48824_p1 = grp_fu_43132_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3212_fu_48854_p1() {
    bitcast_ln3212_fu_48854_p1 = grp_fu_43135_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3226_fu_49137_p1() {
    bitcast_ln3226_fu_49137_p1 = grp_fu_43096_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3240_fu_49167_p1() {
    bitcast_ln3240_fu_49167_p1 = grp_fu_43099_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3254_fu_49197_p1() {
    bitcast_ln3254_fu_49197_p1 = grp_fu_43102_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3268_fu_49227_p1() {
    bitcast_ln3268_fu_49227_p1 = grp_fu_43105_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3282_fu_49257_p1() {
    bitcast_ln3282_fu_49257_p1 = grp_fu_43108_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3296_fu_49287_p1() {
    bitcast_ln3296_fu_49287_p1 = grp_fu_43111_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3310_fu_49317_p1() {
    bitcast_ln3310_fu_49317_p1 = grp_fu_43114_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3324_fu_49347_p1() {
    bitcast_ln3324_fu_49347_p1 = grp_fu_43117_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3338_fu_49377_p1() {
    bitcast_ln3338_fu_49377_p1 = grp_fu_43120_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3352_fu_49407_p1() {
    bitcast_ln3352_fu_49407_p1 = grp_fu_43123_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3366_fu_49437_p1() {
    bitcast_ln3366_fu_49437_p1 = grp_fu_43126_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3380_fu_49467_p1() {
    bitcast_ln3380_fu_49467_p1 = grp_fu_43129_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3394_fu_49497_p1() {
    bitcast_ln3394_fu_49497_p1 = grp_fu_43132_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3408_fu_49527_p1() {
    bitcast_ln3408_fu_49527_p1 = grp_fu_43135_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3422_fu_49809_p1() {
    bitcast_ln3422_fu_49809_p1 = grp_fu_43096_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3436_fu_49839_p1() {
    bitcast_ln3436_fu_49839_p1 = grp_fu_43099_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3450_fu_49869_p1() {
    bitcast_ln3450_fu_49869_p1 = grp_fu_43102_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3464_fu_49899_p1() {
    bitcast_ln3464_fu_49899_p1 = grp_fu_43105_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3478_fu_49929_p1() {
    bitcast_ln3478_fu_49929_p1 = grp_fu_43108_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3492_fu_49959_p1() {
    bitcast_ln3492_fu_49959_p1 = grp_fu_43111_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3506_fu_49989_p1() {
    bitcast_ln3506_fu_49989_p1 = grp_fu_43114_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3520_fu_50019_p1() {
    bitcast_ln3520_fu_50019_p1 = grp_fu_43117_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3534_fu_50049_p1() {
    bitcast_ln3534_fu_50049_p1 = grp_fu_43120_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3548_fu_50079_p1() {
    bitcast_ln3548_fu_50079_p1 = grp_fu_43123_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3562_fu_50109_p1() {
    bitcast_ln3562_fu_50109_p1 = grp_fu_43126_p1.read();
}

void kernel_correlation_sdse::thread_bitcast_ln3576_fu_50139_p1() {
    bitcast_ln3576_fu_50139_p1 = grp_fu_43129_p1.read();
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_ap_start() {
    grp_aesl_mux_load_1040_1_fu_37566_ap_start = grp_aesl_mux_load_1040_1_fu_37566_ap_start_reg.read();
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_41819.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty = trunc_ln4428_1_mid2_reg_66812.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41815.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty = trunc_ln4427_2_reg_66797.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty = "XXX";
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty = "XXX";
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1000_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1000_Dout_A = v3_24_33_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1000_Dout_A = v3_24_32_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1000_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1000_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1001_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1001_Dout_A = v3_24_34_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1001_Dout_A = v3_24_33_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1001_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1001_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1002_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1002_Dout_A = v3_24_35_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1002_Dout_A = v3_24_34_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1002_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1002_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1003_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1003_Dout_A = v3_24_36_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1003_Dout_A = v3_24_35_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1003_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1003_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1004_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1004_Dout_A = v3_24_37_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1004_Dout_A = v3_24_36_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1004_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1004_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1005_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1005_Dout_A = v3_24_38_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1005_Dout_A = v3_24_37_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1005_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1005_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1006_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1006_Dout_A = v3_24_39_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1006_Dout_A = v3_24_38_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1006_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1006_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1007_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1007_Dout_A = v3_24_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1007_Dout_A = v3_24_39_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1007_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1007_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1008_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1008_Dout_A = v3_25_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1008_Dout_A = v3_25_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1008_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1008_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1009_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1009_Dout_A = v3_25_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1009_Dout_A = v3_25_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1009_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1009_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_100_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_100_Dout_A = v3_2_13_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_100_Dout_A = v3_2_12_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_100_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_100_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1010_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1010_Dout_A = v3_25_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1010_Dout_A = v3_25_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1010_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1010_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1011_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1011_Dout_A = v3_25_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1011_Dout_A = v3_25_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1011_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1011_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1012_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1012_Dout_A = v3_25_5_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1012_Dout_A = v3_25_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1012_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1012_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1013_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1013_Dout_A = v3_25_6_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1013_Dout_A = v3_25_5_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1013_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1013_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1014_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1014_Dout_A = v3_25_7_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1014_Dout_A = v3_25_6_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1014_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1014_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1015_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1015_Dout_A = v3_25_8_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1015_Dout_A = v3_25_7_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1015_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1015_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1016_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1016_Dout_A = v3_25_9_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1016_Dout_A = v3_25_8_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1016_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1016_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1017_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1017_Dout_A = v3_25_10_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1017_Dout_A = v3_25_9_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1017_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1017_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1018_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1018_Dout_A = v3_25_11_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1018_Dout_A = v3_25_10_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1018_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1018_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1019_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1019_Dout_A = v3_25_12_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1019_Dout_A = v3_25_11_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1019_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1019_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_101_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_101_Dout_A = v3_2_14_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_101_Dout_A = v3_2_13_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_101_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_101_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1020_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1020_Dout_A = v3_25_13_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1020_Dout_A = v3_25_12_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1020_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1020_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1021_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1021_Dout_A = v3_25_14_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1021_Dout_A = v3_25_13_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1021_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1021_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1022_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1022_Dout_A = v3_25_15_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1022_Dout_A = v3_25_14_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1022_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1022_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1023_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1023_Dout_A = v3_25_16_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1023_Dout_A = v3_25_15_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1023_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1023_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1024_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1024_Dout_A = v3_25_17_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1024_Dout_A = v3_25_16_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1024_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1024_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1025_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1025_Dout_A = v3_25_18_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1025_Dout_A = v3_25_17_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1025_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1025_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1026_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1026_Dout_A = v3_25_19_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1026_Dout_A = v3_25_18_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1026_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1026_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1027_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1027_Dout_A = v3_25_20_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1027_Dout_A = v3_25_19_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1027_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1027_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1028_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1028_Dout_A = v3_25_21_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1028_Dout_A = v3_25_20_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1028_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1028_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1029_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1029_Dout_A = v3_25_22_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1029_Dout_A = v3_25_21_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1029_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1029_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_102_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_102_Dout_A = v3_2_15_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_102_Dout_A = v3_2_14_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_102_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_102_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1030_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1030_Dout_A = v3_25_23_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1030_Dout_A = v3_25_22_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1030_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1030_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1031_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1031_Dout_A = v3_25_24_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1031_Dout_A = v3_25_23_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1031_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1031_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1032_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1032_Dout_A = v3_25_25_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1032_Dout_A = v3_25_24_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1032_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1032_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1033_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1033_Dout_A = v3_25_26_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1033_Dout_A = v3_25_25_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1033_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1033_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1034_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1034_Dout_A = v3_25_27_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1034_Dout_A = v3_25_26_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1034_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1034_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1035_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1035_Dout_A = v3_25_28_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1035_Dout_A = v3_25_27_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1035_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1035_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1036_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1036_Dout_A = v3_25_29_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1036_Dout_A = v3_25_28_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1036_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1036_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1037_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1037_Dout_A = v3_25_30_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1037_Dout_A = v3_25_29_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1037_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1037_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1038_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1038_Dout_A = v3_25_31_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1038_Dout_A = v3_25_30_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1038_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1038_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1039_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1039_Dout_A = v3_25_32_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1039_Dout_A = v3_25_31_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1039_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1039_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_103_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_103_Dout_A = v3_2_16_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_103_Dout_A = v3_2_15_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_103_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_103_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1040_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1040_Dout_A = v3_25_33_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1040_Dout_A = v3_25_32_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1040_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1040_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1041_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1041_Dout_A = v3_25_34_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1041_Dout_A = v3_25_33_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1041_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1041_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1042_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1042_Dout_A = v3_25_35_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1042_Dout_A = v3_25_34_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1042_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1042_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1043_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1043_Dout_A = v3_25_36_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1043_Dout_A = v3_25_35_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1043_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1043_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1044_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1044_Dout_A = v3_25_37_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1044_Dout_A = v3_25_36_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1044_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1044_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1045_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1045_Dout_A = v3_25_38_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1045_Dout_A = v3_25_37_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1045_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1045_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1046_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1046_Dout_A = v3_25_39_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1046_Dout_A = v3_25_38_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1046_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1046_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1047_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1047_Dout_A = v3_25_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1047_Dout_A = v3_25_39_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1047_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1047_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_1048() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_41819.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1048 = select_ln4422_1_reg_66832.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41815.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1048 = add_ln4427_reg_66827.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_1048 =  (sc_lv<11>) ("XXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_1048 =  (sc_lv<11>) ("XXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_104_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_104_Dout_A = v3_2_17_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_104_Dout_A = v3_2_16_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_104_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_104_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_105_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_105_Dout_A = v3_2_18_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_105_Dout_A = v3_2_17_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_105_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_105_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_106_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_106_Dout_A = v3_2_19_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_106_Dout_A = v3_2_18_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_106_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_106_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_107_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_107_Dout_A = v3_2_20_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_107_Dout_A = v3_2_19_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_107_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_107_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_108_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_108_Dout_A = v3_2_21_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_108_Dout_A = v3_2_20_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_108_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_108_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_109_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_109_Dout_A = v3_2_22_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_109_Dout_A = v3_2_21_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_109_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_109_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_10_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_10_Dout_A = v3_0_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_10_Dout_A = v3_0_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_10_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_10_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_110_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_110_Dout_A = v3_2_23_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_110_Dout_A = v3_2_22_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_110_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_110_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_111_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_111_Dout_A = v3_2_24_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_111_Dout_A = v3_2_23_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_111_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_111_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_112_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_112_Dout_A = v3_2_25_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_112_Dout_A = v3_2_24_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_112_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_112_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_113_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_113_Dout_A = v3_2_26_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_113_Dout_A = v3_2_25_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_113_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_113_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_114_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_114_Dout_A = v3_2_27_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_114_Dout_A = v3_2_26_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_114_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_114_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_115_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_115_Dout_A = v3_2_28_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_115_Dout_A = v3_2_27_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_115_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_115_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_116_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_116_Dout_A = v3_2_29_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_116_Dout_A = v3_2_28_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_116_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_116_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_117_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_117_Dout_A = v3_2_30_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_117_Dout_A = v3_2_29_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_117_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_117_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_118_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_118_Dout_A = v3_2_31_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_118_Dout_A = v3_2_30_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_118_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_118_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_119_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_119_Dout_A = v3_2_32_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_119_Dout_A = v3_2_31_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_119_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_119_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_11_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_11_Dout_A = v3_0_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_11_Dout_A = v3_0_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_11_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_11_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_120_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_120_Dout_A = v3_2_33_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_120_Dout_A = v3_2_32_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_120_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_120_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_121_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_121_Dout_A = v3_2_34_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_121_Dout_A = v3_2_33_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_121_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_121_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_122_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_122_Dout_A = v3_2_35_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_122_Dout_A = v3_2_34_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_122_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_122_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_123_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_123_Dout_A = v3_2_36_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_123_Dout_A = v3_2_35_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_123_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_123_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_124_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_124_Dout_A = v3_2_37_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_124_Dout_A = v3_2_36_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_124_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_124_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_125_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_125_Dout_A = v3_2_38_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_125_Dout_A = v3_2_37_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_125_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_125_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_126_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_126_Dout_A = v3_2_39_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_126_Dout_A = v3_2_38_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_126_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_126_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_127_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_127_Dout_A = v3_2_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_127_Dout_A = v3_2_39_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_127_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_127_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_128_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_128_Dout_A = v3_3_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_128_Dout_A = v3_3_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_128_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_128_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_129_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_129_Dout_A = v3_3_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_129_Dout_A = v3_3_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_129_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_129_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_12_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_12_Dout_A = v3_0_5_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_12_Dout_A = v3_0_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_12_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_12_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_130_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_130_Dout_A = v3_3_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_130_Dout_A = v3_3_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_130_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_130_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_131_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_131_Dout_A = v3_3_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_131_Dout_A = v3_3_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_131_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_131_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_132_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_132_Dout_A = v3_3_5_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_132_Dout_A = v3_3_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_132_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_132_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_133_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_133_Dout_A = v3_3_6_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_133_Dout_A = v3_3_5_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_133_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_133_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_134_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_134_Dout_A = v3_3_7_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_134_Dout_A = v3_3_6_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_134_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_134_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_135_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_135_Dout_A = v3_3_8_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_135_Dout_A = v3_3_7_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_135_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_135_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_136_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_136_Dout_A = v3_3_9_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_136_Dout_A = v3_3_8_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_136_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_136_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_137_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_137_Dout_A = v3_3_10_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_137_Dout_A = v3_3_9_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_137_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_137_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_138_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_138_Dout_A = v3_3_11_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_138_Dout_A = v3_3_10_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_138_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_138_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_139_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_139_Dout_A = v3_3_12_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_139_Dout_A = v3_3_11_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_139_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_139_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_13_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_13_Dout_A = v3_0_6_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_13_Dout_A = v3_0_5_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_13_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_13_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_140_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_140_Dout_A = v3_3_13_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_140_Dout_A = v3_3_12_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_140_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_140_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_141_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_141_Dout_A = v3_3_14_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_141_Dout_A = v3_3_13_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_141_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_141_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_142_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_142_Dout_A = v3_3_15_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_142_Dout_A = v3_3_14_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_142_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_142_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_143_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_143_Dout_A = v3_3_16_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_143_Dout_A = v3_3_15_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_143_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_143_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_144_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_144_Dout_A = v3_3_17_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_144_Dout_A = v3_3_16_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_144_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_144_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_145_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_145_Dout_A = v3_3_18_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_145_Dout_A = v3_3_17_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_145_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_145_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_146_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_146_Dout_A = v3_3_19_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_146_Dout_A = v3_3_18_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_146_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_146_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_147_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_147_Dout_A = v3_3_20_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_147_Dout_A = v3_3_19_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_147_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_147_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_148_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_148_Dout_A = v3_3_21_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_148_Dout_A = v3_3_20_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_148_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_148_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_149_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_149_Dout_A = v3_3_22_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_149_Dout_A = v3_3_21_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_149_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_149_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_14_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_14_Dout_A = v3_0_7_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_14_Dout_A = v3_0_6_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_14_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_14_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_150_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_150_Dout_A = v3_3_23_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_150_Dout_A = v3_3_22_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_150_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_150_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_151_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_151_Dout_A = v3_3_24_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_151_Dout_A = v3_3_23_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_151_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_151_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_152_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_152_Dout_A = v3_3_25_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_152_Dout_A = v3_3_24_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_152_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_152_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_153_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_153_Dout_A = v3_3_26_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_153_Dout_A = v3_3_25_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_153_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_153_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_154_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_154_Dout_A = v3_3_27_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_154_Dout_A = v3_3_26_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_154_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_154_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_155_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_155_Dout_A = v3_3_28_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_155_Dout_A = v3_3_27_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_155_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_155_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_156_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_156_Dout_A = v3_3_29_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_156_Dout_A = v3_3_28_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_156_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_156_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_157_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_157_Dout_A = v3_3_30_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_157_Dout_A = v3_3_29_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_157_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_157_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_158_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_158_Dout_A = v3_3_31_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_158_Dout_A = v3_3_30_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_158_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_158_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_159_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_159_Dout_A = v3_3_32_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_159_Dout_A = v3_3_31_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_159_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_159_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_15_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_15_Dout_A = v3_0_8_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_15_Dout_A = v3_0_7_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_15_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_15_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_160_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_160_Dout_A = v3_3_33_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_160_Dout_A = v3_3_32_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_160_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_160_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_161_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_161_Dout_A = v3_3_34_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_161_Dout_A = v3_3_33_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_161_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_161_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_162_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_162_Dout_A = v3_3_35_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_162_Dout_A = v3_3_34_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_162_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_162_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_163_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_163_Dout_A = v3_3_36_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_163_Dout_A = v3_3_35_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_163_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_163_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_164_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_164_Dout_A = v3_3_37_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_164_Dout_A = v3_3_36_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_164_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_164_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_165_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_165_Dout_A = v3_3_38_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_165_Dout_A = v3_3_37_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_165_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_165_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_166_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_166_Dout_A = v3_3_39_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_166_Dout_A = v3_3_38_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_166_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_166_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_167_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_167_Dout_A = v3_3_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_167_Dout_A = v3_3_39_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_167_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_167_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_168_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_168_Dout_A = v3_4_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_168_Dout_A = v3_4_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_168_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_168_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_169_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_169_Dout_A = v3_4_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_169_Dout_A = v3_4_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_169_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_169_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_16_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_16_Dout_A = v3_0_9_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_16_Dout_A = v3_0_8_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_16_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_16_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_170_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_170_Dout_A = v3_4_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_170_Dout_A = v3_4_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_170_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_170_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_171_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_171_Dout_A = v3_4_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_171_Dout_A = v3_4_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_171_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_171_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_172_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_172_Dout_A = v3_4_5_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_172_Dout_A = v3_4_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_172_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_172_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_173_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_173_Dout_A = v3_4_6_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_173_Dout_A = v3_4_5_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_173_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_173_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_174_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_174_Dout_A = v3_4_7_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_174_Dout_A = v3_4_6_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_174_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_174_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_175_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_175_Dout_A = v3_4_8_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_175_Dout_A = v3_4_7_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_175_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_175_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_176_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_176_Dout_A = v3_4_9_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_176_Dout_A = v3_4_8_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_176_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_176_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_177_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_177_Dout_A = v3_4_10_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_177_Dout_A = v3_4_9_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_177_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_177_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_178_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_178_Dout_A = v3_4_11_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_178_Dout_A = v3_4_10_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_178_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_178_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_179_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_179_Dout_A = v3_4_12_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_179_Dout_A = v3_4_11_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_179_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_179_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_17_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_17_Dout_A = v3_0_10_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_17_Dout_A = v3_0_9_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_17_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_17_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_180_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_180_Dout_A = v3_4_13_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_180_Dout_A = v3_4_12_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_180_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_180_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_181_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_181_Dout_A = v3_4_14_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_181_Dout_A = v3_4_13_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_181_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_181_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_182_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_182_Dout_A = v3_4_15_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_182_Dout_A = v3_4_14_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_182_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_182_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_183_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_183_Dout_A = v3_4_16_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_183_Dout_A = v3_4_15_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_183_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_183_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_184_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_184_Dout_A = v3_4_17_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_184_Dout_A = v3_4_16_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_184_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_184_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_185_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_185_Dout_A = v3_4_18_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_185_Dout_A = v3_4_17_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_185_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_185_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_186_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_186_Dout_A = v3_4_19_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_186_Dout_A = v3_4_18_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_186_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_186_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_187_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_187_Dout_A = v3_4_20_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_187_Dout_A = v3_4_19_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_187_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_187_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_188_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_188_Dout_A = v3_4_21_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_188_Dout_A = v3_4_20_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_188_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_188_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_189_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_189_Dout_A = v3_4_22_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_189_Dout_A = v3_4_21_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_189_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_189_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_18_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_18_Dout_A = v3_0_11_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_18_Dout_A = v3_0_10_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_190_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_190_Dout_A = v3_4_23_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_190_Dout_A = v3_4_22_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_190_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_190_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_191_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_191_Dout_A = v3_4_24_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_191_Dout_A = v3_4_23_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_191_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_191_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_192_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_192_Dout_A = v3_4_25_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_192_Dout_A = v3_4_24_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_192_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_192_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_193_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_193_Dout_A = v3_4_26_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_193_Dout_A = v3_4_25_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_193_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_193_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_194_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_194_Dout_A = v3_4_27_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_194_Dout_A = v3_4_26_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_194_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_194_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_195_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_195_Dout_A = v3_4_28_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_195_Dout_A = v3_4_27_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_195_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_195_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_196_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_196_Dout_A = v3_4_29_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_196_Dout_A = v3_4_28_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_196_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_196_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_197_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_197_Dout_A = v3_4_30_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_197_Dout_A = v3_4_29_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_197_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_197_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_198_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_198_Dout_A = v3_4_31_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_198_Dout_A = v3_4_30_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_198_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_198_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_199_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_199_Dout_A = v3_4_32_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_199_Dout_A = v3_4_31_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_199_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_199_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_19_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_19_Dout_A = v3_0_12_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_19_Dout_A = v3_0_11_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_200_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_200_Dout_A = v3_4_33_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_200_Dout_A = v3_4_32_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_200_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_200_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_201_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_201_Dout_A = v3_4_34_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_201_Dout_A = v3_4_33_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_201_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_201_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_202_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_202_Dout_A = v3_4_35_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_202_Dout_A = v3_4_34_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_202_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_202_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_203_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_203_Dout_A = v3_4_36_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_203_Dout_A = v3_4_35_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_203_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_203_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_204_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_204_Dout_A = v3_4_37_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_204_Dout_A = v3_4_36_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_204_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_204_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_205_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_205_Dout_A = v3_4_38_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_205_Dout_A = v3_4_37_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_205_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_205_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_206_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_206_Dout_A = v3_4_39_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_206_Dout_A = v3_4_38_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_206_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_206_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_207_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_207_Dout_A = v3_4_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_207_Dout_A = v3_4_39_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_207_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_207_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_208_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_208_Dout_A = v3_5_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_208_Dout_A = v3_5_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_208_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_208_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_209_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_209_Dout_A = v3_5_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_209_Dout_A = v3_5_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_209_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_209_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_20_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_20_Dout_A = v3_0_13_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_20_Dout_A = v3_0_12_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_210_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_210_Dout_A = v3_5_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_210_Dout_A = v3_5_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_210_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_210_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_211_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_211_Dout_A = v3_5_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_211_Dout_A = v3_5_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_211_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_211_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_212_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_212_Dout_A = v3_5_5_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_212_Dout_A = v3_5_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_212_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_212_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_213_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_213_Dout_A = v3_5_6_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_213_Dout_A = v3_5_5_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_213_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_213_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_214_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_214_Dout_A = v3_5_7_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_214_Dout_A = v3_5_6_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_214_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_214_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_215_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_215_Dout_A = v3_5_8_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_215_Dout_A = v3_5_7_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_215_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_215_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_216_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_216_Dout_A = v3_5_9_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_216_Dout_A = v3_5_8_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_216_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_216_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_217_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_217_Dout_A = v3_5_10_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_217_Dout_A = v3_5_9_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_217_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_217_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_218_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_218_Dout_A = v3_5_11_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_218_Dout_A = v3_5_10_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_218_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_218_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_219_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_219_Dout_A = v3_5_12_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_219_Dout_A = v3_5_11_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_219_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_219_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_21_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_21_Dout_A = v3_0_14_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_21_Dout_A = v3_0_13_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_220_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_220_Dout_A = v3_5_13_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_220_Dout_A = v3_5_12_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_220_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_220_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_221_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_221_Dout_A = v3_5_14_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_221_Dout_A = v3_5_13_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_221_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_221_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_222_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_222_Dout_A = v3_5_15_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_222_Dout_A = v3_5_14_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_222_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_222_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_223_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_223_Dout_A = v3_5_16_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_223_Dout_A = v3_5_15_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_223_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_223_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_224_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_224_Dout_A = v3_5_17_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_224_Dout_A = v3_5_16_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_224_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_224_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_225_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_225_Dout_A = v3_5_18_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_225_Dout_A = v3_5_17_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_225_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_225_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_226_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_226_Dout_A = v3_5_19_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_226_Dout_A = v3_5_18_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_226_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_226_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_227_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_227_Dout_A = v3_5_20_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_227_Dout_A = v3_5_19_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_227_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_227_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_228_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_228_Dout_A = v3_5_21_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_228_Dout_A = v3_5_20_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_228_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_228_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_229_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_229_Dout_A = v3_5_22_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_229_Dout_A = v3_5_21_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_229_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_229_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_22_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_22_Dout_A = v3_0_15_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_22_Dout_A = v3_0_14_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_230_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_230_Dout_A = v3_5_23_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_230_Dout_A = v3_5_22_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_230_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_230_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_231_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_231_Dout_A = v3_5_24_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_231_Dout_A = v3_5_23_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_231_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_231_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_232_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_232_Dout_A = v3_5_25_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_232_Dout_A = v3_5_24_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_232_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_232_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_233_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_233_Dout_A = v3_5_26_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_233_Dout_A = v3_5_25_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_233_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_233_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_234_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_234_Dout_A = v3_5_27_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_234_Dout_A = v3_5_26_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_234_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_234_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_235_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_235_Dout_A = v3_5_28_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_235_Dout_A = v3_5_27_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_235_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_235_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_236_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_236_Dout_A = v3_5_29_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_236_Dout_A = v3_5_28_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_236_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_236_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_237_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_237_Dout_A = v3_5_30_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_237_Dout_A = v3_5_29_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_237_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_237_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_238_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_238_Dout_A = v3_5_31_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_238_Dout_A = v3_5_30_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_238_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_238_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_239_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_239_Dout_A = v3_5_32_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_239_Dout_A = v3_5_31_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_239_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_239_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_23_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_23_Dout_A = v3_0_16_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_23_Dout_A = v3_0_15_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_23_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_23_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_240_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_240_Dout_A = v3_5_33_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_240_Dout_A = v3_5_32_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_240_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_240_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_241_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_241_Dout_A = v3_5_34_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_241_Dout_A = v3_5_33_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_241_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_241_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_242_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_242_Dout_A = v3_5_35_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_242_Dout_A = v3_5_34_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_242_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_242_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_243_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_243_Dout_A = v3_5_36_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_243_Dout_A = v3_5_35_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_243_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_243_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_244_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_244_Dout_A = v3_5_37_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_244_Dout_A = v3_5_36_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_244_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_244_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_245_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_245_Dout_A = v3_5_38_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_245_Dout_A = v3_5_37_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_245_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_245_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_246_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_246_Dout_A = v3_5_39_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_246_Dout_A = v3_5_38_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_246_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_246_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_247_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_247_Dout_A = v3_5_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_247_Dout_A = v3_5_39_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_247_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_247_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_248_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_248_Dout_A = v3_6_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_248_Dout_A = v3_6_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_248_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_248_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_249_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_249_Dout_A = v3_6_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_249_Dout_A = v3_6_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_249_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_249_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_24_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_24_Dout_A = v3_0_17_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_24_Dout_A = v3_0_16_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_24_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_24_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_250_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_250_Dout_A = v3_6_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_250_Dout_A = v3_6_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_250_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_250_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_251_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_251_Dout_A = v3_6_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_251_Dout_A = v3_6_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_251_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_251_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_252_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_252_Dout_A = v3_6_5_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_252_Dout_A = v3_6_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_252_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_252_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_253_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_253_Dout_A = v3_6_6_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_253_Dout_A = v3_6_5_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_253_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_253_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_254_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_254_Dout_A = v3_6_7_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_254_Dout_A = v3_6_6_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_254_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_254_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_255_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_255_Dout_A = v3_6_8_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_255_Dout_A = v3_6_7_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_255_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_255_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_256_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_256_Dout_A = v3_6_9_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_256_Dout_A = v3_6_8_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_256_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_256_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_257_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_257_Dout_A = v3_6_10_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_257_Dout_A = v3_6_9_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_257_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_257_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_258_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_258_Dout_A = v3_6_11_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_258_Dout_A = v3_6_10_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_258_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_258_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_259_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_259_Dout_A = v3_6_12_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_259_Dout_A = v3_6_11_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_259_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_259_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_25_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_25_Dout_A = v3_0_18_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_25_Dout_A = v3_0_17_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_260_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_260_Dout_A = v3_6_13_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_260_Dout_A = v3_6_12_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_260_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_260_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_261_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_261_Dout_A = v3_6_14_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_261_Dout_A = v3_6_13_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_261_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_261_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_262_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_262_Dout_A = v3_6_15_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_262_Dout_A = v3_6_14_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_262_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_262_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_263_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_263_Dout_A = v3_6_16_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_263_Dout_A = v3_6_15_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_263_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_263_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_264_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_264_Dout_A = v3_6_17_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_264_Dout_A = v3_6_16_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_264_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_264_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_265_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_265_Dout_A = v3_6_18_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_265_Dout_A = v3_6_17_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_265_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_265_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_266_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_266_Dout_A = v3_6_19_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_266_Dout_A = v3_6_18_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_266_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_266_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_267_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_267_Dout_A = v3_6_20_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_267_Dout_A = v3_6_19_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_267_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_267_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_268_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_268_Dout_A = v3_6_21_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_268_Dout_A = v3_6_20_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_268_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_268_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_269_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_269_Dout_A = v3_6_22_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_269_Dout_A = v3_6_21_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_269_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_269_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_26_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_26_Dout_A = v3_0_19_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_26_Dout_A = v3_0_18_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_270_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_270_Dout_A = v3_6_23_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_270_Dout_A = v3_6_22_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_270_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_270_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_271_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_271_Dout_A = v3_6_24_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_271_Dout_A = v3_6_23_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_271_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_271_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_272_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_272_Dout_A = v3_6_25_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_272_Dout_A = v3_6_24_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_272_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_272_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_273_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_273_Dout_A = v3_6_26_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_273_Dout_A = v3_6_25_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_273_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_273_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_274_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_274_Dout_A = v3_6_27_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_274_Dout_A = v3_6_26_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_274_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_274_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_275_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_275_Dout_A = v3_6_28_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_275_Dout_A = v3_6_27_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_275_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_275_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_276_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_276_Dout_A = v3_6_29_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_276_Dout_A = v3_6_28_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_276_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_276_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_277_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_277_Dout_A = v3_6_30_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_277_Dout_A = v3_6_29_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_277_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_277_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_278_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_278_Dout_A = v3_6_31_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_278_Dout_A = v3_6_30_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_278_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_278_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_279_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_279_Dout_A = v3_6_32_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_279_Dout_A = v3_6_31_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_279_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_279_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_27_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_27_Dout_A = v3_0_20_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_27_Dout_A = v3_0_19_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_280_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_280_Dout_A = v3_6_33_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_280_Dout_A = v3_6_32_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_280_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_280_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_281_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_281_Dout_A = v3_6_34_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_281_Dout_A = v3_6_33_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_281_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_281_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_282_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_282_Dout_A = v3_6_35_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_282_Dout_A = v3_6_34_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_282_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_282_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_283_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_283_Dout_A = v3_6_36_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_283_Dout_A = v3_6_35_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_283_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_283_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_284_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_284_Dout_A = v3_6_37_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_284_Dout_A = v3_6_36_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_284_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_284_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_285_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_285_Dout_A = v3_6_38_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_285_Dout_A = v3_6_37_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_285_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_285_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_286_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_286_Dout_A = v3_6_39_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_286_Dout_A = v3_6_38_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_286_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_286_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_287_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_287_Dout_A = v3_6_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_287_Dout_A = v3_6_39_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_287_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_287_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_288_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_288_Dout_A = v3_7_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_288_Dout_A = v3_7_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_288_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_288_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_289_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_289_Dout_A = v3_7_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_289_Dout_A = v3_7_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_289_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_289_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_28_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_28_Dout_A = v3_0_21_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_28_Dout_A = v3_0_20_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_290_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_290_Dout_A = v3_7_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_290_Dout_A = v3_7_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_290_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_290_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_291_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_291_Dout_A = v3_7_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_291_Dout_A = v3_7_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_291_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_291_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_292_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_292_Dout_A = v3_7_5_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_292_Dout_A = v3_7_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_292_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_292_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_293_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_293_Dout_A = v3_7_6_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_293_Dout_A = v3_7_5_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_293_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_293_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_294_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_294_Dout_A = v3_7_7_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_294_Dout_A = v3_7_6_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_294_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_294_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_295_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_295_Dout_A = v3_7_8_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_295_Dout_A = v3_7_7_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_295_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_295_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_296_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_296_Dout_A = v3_7_9_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_296_Dout_A = v3_7_8_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_296_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_296_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_297_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_297_Dout_A = v3_7_10_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_297_Dout_A = v3_7_9_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_297_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_297_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_298_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_298_Dout_A = v3_7_11_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_298_Dout_A = v3_7_10_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_298_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_298_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_299_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_299_Dout_A = v3_7_12_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_299_Dout_A = v3_7_11_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_299_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_299_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_29_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_29_Dout_A = v3_0_22_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_29_Dout_A = v3_0_21_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_300_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_300_Dout_A = v3_7_13_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_300_Dout_A = v3_7_12_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_300_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_300_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_301_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_301_Dout_A = v3_7_14_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_301_Dout_A = v3_7_13_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_301_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_301_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_302_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_302_Dout_A = v3_7_15_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_302_Dout_A = v3_7_14_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_302_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_302_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_303_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_303_Dout_A = v3_7_16_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_303_Dout_A = v3_7_15_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_303_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_303_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_304_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_304_Dout_A = v3_7_17_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_304_Dout_A = v3_7_16_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_304_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_304_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_305_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_305_Dout_A = v3_7_18_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_305_Dout_A = v3_7_17_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_305_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_305_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_306_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_306_Dout_A = v3_7_19_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_306_Dout_A = v3_7_18_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_306_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_306_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_307_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_307_Dout_A = v3_7_20_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_307_Dout_A = v3_7_19_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_307_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_307_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_308_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_308_Dout_A = v3_7_21_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_308_Dout_A = v3_7_20_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_308_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_308_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_309_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_309_Dout_A = v3_7_22_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_309_Dout_A = v3_7_21_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_309_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_309_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_30_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_30_Dout_A = v3_0_23_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_30_Dout_A = v3_0_22_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_30_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_30_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_310_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_310_Dout_A = v3_7_23_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_310_Dout_A = v3_7_22_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_310_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_310_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_311_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_311_Dout_A = v3_7_24_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_311_Dout_A = v3_7_23_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_311_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_311_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_312_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_312_Dout_A = v3_7_25_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_312_Dout_A = v3_7_24_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_312_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_312_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_313_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_313_Dout_A = v3_7_26_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_313_Dout_A = v3_7_25_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_313_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_313_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_314_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_314_Dout_A = v3_7_27_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_314_Dout_A = v3_7_26_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_314_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_314_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_315_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_315_Dout_A = v3_7_28_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_315_Dout_A = v3_7_27_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_315_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_315_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_316_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_316_Dout_A = v3_7_29_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_316_Dout_A = v3_7_28_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_316_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_316_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_317_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_317_Dout_A = v3_7_30_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_317_Dout_A = v3_7_29_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_317_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_317_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_318_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_318_Dout_A = v3_7_31_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_318_Dout_A = v3_7_30_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_318_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_318_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_319_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_319_Dout_A = v3_7_32_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_319_Dout_A = v3_7_31_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_319_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_319_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_31_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_31_Dout_A = v3_0_24_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_31_Dout_A = v3_0_23_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_31_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_31_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_320_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_320_Dout_A = v3_7_33_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_320_Dout_A = v3_7_32_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_320_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_320_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_321_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_321_Dout_A = v3_7_34_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_321_Dout_A = v3_7_33_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_321_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_321_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_322_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_322_Dout_A = v3_7_35_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_322_Dout_A = v3_7_34_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_322_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_322_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_323_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_323_Dout_A = v3_7_36_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_323_Dout_A = v3_7_35_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_323_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_323_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_324_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_324_Dout_A = v3_7_37_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_324_Dout_A = v3_7_36_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_324_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_324_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_325_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_325_Dout_A = v3_7_38_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_325_Dout_A = v3_7_37_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_325_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_325_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_326_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_326_Dout_A = v3_7_39_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_326_Dout_A = v3_7_38_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_326_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_326_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_327_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_327_Dout_A = v3_7_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_327_Dout_A = v3_7_39_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_327_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_327_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_328_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_328_Dout_A = v3_8_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_328_Dout_A = v3_8_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_328_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_328_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_329_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_329_Dout_A = v3_8_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_329_Dout_A = v3_8_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_329_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_329_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_32_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_32_Dout_A = v3_0_25_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_32_Dout_A = v3_0_24_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_32_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_32_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_330_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_330_Dout_A = v3_8_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_330_Dout_A = v3_8_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_330_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_330_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_331_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_331_Dout_A = v3_8_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_331_Dout_A = v3_8_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_331_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_331_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_332_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_332_Dout_A = v3_8_5_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_332_Dout_A = v3_8_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_332_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_332_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_333_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_333_Dout_A = v3_8_6_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_333_Dout_A = v3_8_5_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_333_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_333_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_334_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_334_Dout_A = v3_8_7_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_334_Dout_A = v3_8_6_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_334_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_334_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_grp_aesl_mux_load_1040_1_fu_37566_empty_335_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read())) {
        if (esl_seteq<1,1,1>(ap_condition_33518.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_335_Dout_A = v3_8_8_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_41824.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_1040_1_fu_37566_empty_335_Dout_A = v3_8_7_Dout_A.read();
        } else {
            grp_aesl_mux_load_1040_1_fu_37566_empty_335_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_1040_1_fu_37566_empty_335_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

}


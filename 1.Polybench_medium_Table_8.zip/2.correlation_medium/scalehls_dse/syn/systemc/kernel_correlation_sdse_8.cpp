#include "kernel_correlation_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_correlation_sdse::thread_v3_12_13_WEN_A() {
    v3_12_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_502_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_501_Addr_A.read();
    } else {
        v3_12_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_14_Addr_A_orig() {
    v3_12_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_14_Addr_B() {
    v3_12_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_14_Addr_B_orig() {
    v3_12_14_Addr_B_orig =  (sc_lv<32>) (v3_12_14_addr_reg_63590.read());
}

void kernel_correlation_sdse::thread_v3_12_14_Clk_A() {
    v3_12_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_14_Clk_B() {
    v3_12_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_14_Din_A() {
    v3_12_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_14_Din_B() {
    v3_12_14_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_502_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_501_EN_A.read();
    } else {
        v3_12_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_14_EN_B = ap_const_logic_1;
    } else {
        v3_12_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_14_Rst_A() {
    v3_12_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_14_Rst_B() {
    v3_12_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_14_WEN_A() {
    v3_12_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_503_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_502_Addr_A.read();
    } else {
        v3_12_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_15_Addr_A_orig() {
    v3_12_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_15_Addr_B() {
    v3_12_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_15_Addr_B_orig() {
    v3_12_15_Addr_B_orig =  (sc_lv<32>) (v3_12_15_addr_reg_65250.read());
}

void kernel_correlation_sdse::thread_v3_12_15_Clk_A() {
    v3_12_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_15_Clk_B() {
    v3_12_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_15_Din_A() {
    v3_12_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_15_Din_B() {
    v3_12_15_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_503_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_502_EN_A.read();
    } else {
        v3_12_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_15_EN_B = ap_const_logic_1;
    } else {
        v3_12_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_15_Rst_A() {
    v3_12_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_15_Rst_B() {
    v3_12_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_15_WEN_A() {
    v3_12_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_504_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_503_Addr_A.read();
    } else {
        v3_12_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_16_Addr_A_orig() {
    v3_12_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_16_Addr_B() {
    v3_12_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_16_Addr_B_orig() {
    v3_12_16_Addr_B_orig =  (sc_lv<32>) (v3_12_16_addr_reg_60276.read());
}

void kernel_correlation_sdse::thread_v3_12_16_Clk_A() {
    v3_12_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_16_Clk_B() {
    v3_12_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_16_Din_A() {
    v3_12_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_16_Din_B() {
    v3_12_16_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_504_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_503_EN_A.read();
    } else {
        v3_12_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_16_EN_B = ap_const_logic_1;
    } else {
        v3_12_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_16_Rst_A() {
    v3_12_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_16_Rst_B() {
    v3_12_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_16_WEN_A() {
    v3_12_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_505_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_504_Addr_A.read();
    } else {
        v3_12_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_17_Addr_A_orig() {
    v3_12_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_17_Addr_B() {
    v3_12_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_17_Addr_B_orig() {
    v3_12_17_Addr_B_orig =  (sc_lv<32>) (v3_12_17_addr_reg_61936.read());
}

void kernel_correlation_sdse::thread_v3_12_17_Clk_A() {
    v3_12_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_17_Clk_B() {
    v3_12_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_17_Din_A() {
    v3_12_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_17_Din_B() {
    v3_12_17_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_505_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_504_EN_A.read();
    } else {
        v3_12_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_17_EN_B = ap_const_logic_1;
    } else {
        v3_12_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_17_Rst_A() {
    v3_12_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_17_Rst_B() {
    v3_12_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_17_WEN_A() {
    v3_12_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_506_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_505_Addr_A.read();
    } else {
        v3_12_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_18_Addr_A_orig() {
    v3_12_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_18_Addr_B() {
    v3_12_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_18_Addr_B_orig() {
    v3_12_18_Addr_B_orig =  (sc_lv<32>) (v3_12_18_addr_reg_63596.read());
}

void kernel_correlation_sdse::thread_v3_12_18_Clk_A() {
    v3_12_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_18_Clk_B() {
    v3_12_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_18_Din_A() {
    v3_12_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_18_Din_B() {
    v3_12_18_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_506_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_505_EN_A.read();
    } else {
        v3_12_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_18_EN_B = ap_const_logic_1;
    } else {
        v3_12_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_18_Rst_A() {
    v3_12_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_18_Rst_B() {
    v3_12_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_18_WEN_A() {
    v3_12_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_507_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_506_Addr_A.read();
    } else {
        v3_12_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_19_Addr_A_orig() {
    v3_12_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_19_Addr_B() {
    v3_12_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_19_Addr_B_orig() {
    v3_12_19_Addr_B_orig =  (sc_lv<32>) (v3_12_19_addr_reg_65256.read());
}

void kernel_correlation_sdse::thread_v3_12_19_Clk_A() {
    v3_12_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_19_Clk_B() {
    v3_12_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_19_Din_A() {
    v3_12_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_19_Din_B() {
    v3_12_19_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_507_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_506_EN_A.read();
    } else {
        v3_12_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_19_EN_B = ap_const_logic_1;
    } else {
        v3_12_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_19_Rst_A() {
    v3_12_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_19_Rst_B() {
    v3_12_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_19_WEN_A() {
    v3_12_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_489_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_488_Addr_A.read();
    } else {
        v3_12_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_1_Addr_A_orig() {
    v3_12_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_1_Addr_B() {
    v3_12_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_1_Addr_B_orig() {
    v3_12_1_Addr_B_orig =  (sc_lv<32>) (v3_12_1_addr_reg_61912.read());
}

void kernel_correlation_sdse::thread_v3_12_1_Clk_A() {
    v3_12_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_1_Clk_B() {
    v3_12_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_1_Din_A() {
    v3_12_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_1_Din_B() {
    v3_12_1_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_489_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_488_EN_A.read();
    } else {
        v3_12_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_1_EN_B = ap_const_logic_1;
    } else {
        v3_12_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_1_Rst_A() {
    v3_12_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_1_Rst_B() {
    v3_12_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_1_WEN_A() {
    v3_12_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_508_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_507_Addr_A.read();
    } else {
        v3_12_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_20_Addr_A_orig() {
    v3_12_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_20_Addr_B() {
    v3_12_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_20_Addr_B_orig() {
    v3_12_20_Addr_B_orig =  (sc_lv<32>) (v3_12_20_addr_reg_60282.read());
}

void kernel_correlation_sdse::thread_v3_12_20_Clk_A() {
    v3_12_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_20_Clk_B() {
    v3_12_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_20_Din_A() {
    v3_12_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_20_Din_B() {
    v3_12_20_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_508_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_507_EN_A.read();
    } else {
        v3_12_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_20_EN_B = ap_const_logic_1;
    } else {
        v3_12_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_20_Rst_A() {
    v3_12_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_20_Rst_B() {
    v3_12_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_20_WEN_A() {
    v3_12_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_509_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_508_Addr_A.read();
    } else {
        v3_12_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_21_Addr_A_orig() {
    v3_12_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_21_Addr_B() {
    v3_12_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_21_Addr_B_orig() {
    v3_12_21_Addr_B_orig =  (sc_lv<32>) (v3_12_21_addr_reg_61942.read());
}

void kernel_correlation_sdse::thread_v3_12_21_Clk_A() {
    v3_12_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_21_Clk_B() {
    v3_12_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_21_Din_A() {
    v3_12_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_21_Din_B() {
    v3_12_21_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_509_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_508_EN_A.read();
    } else {
        v3_12_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_21_EN_B = ap_const_logic_1;
    } else {
        v3_12_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_21_Rst_A() {
    v3_12_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_21_Rst_B() {
    v3_12_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_21_WEN_A() {
    v3_12_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_510_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_509_Addr_A.read();
    } else {
        v3_12_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_22_Addr_A_orig() {
    v3_12_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_22_Addr_B() {
    v3_12_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_22_Addr_B_orig() {
    v3_12_22_Addr_B_orig =  (sc_lv<32>) (v3_12_22_addr_reg_63602.read());
}

void kernel_correlation_sdse::thread_v3_12_22_Clk_A() {
    v3_12_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_22_Clk_B() {
    v3_12_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_22_Din_A() {
    v3_12_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_22_Din_B() {
    v3_12_22_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_510_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_509_EN_A.read();
    } else {
        v3_12_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_22_EN_B = ap_const_logic_1;
    } else {
        v3_12_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_22_Rst_A() {
    v3_12_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_22_Rst_B() {
    v3_12_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_22_WEN_A() {
    v3_12_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_511_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_510_Addr_A.read();
    } else {
        v3_12_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_23_Addr_A_orig() {
    v3_12_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_23_Addr_B() {
    v3_12_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_23_Addr_B_orig() {
    v3_12_23_Addr_B_orig =  (sc_lv<32>) (v3_12_23_addr_reg_65262.read());
}

void kernel_correlation_sdse::thread_v3_12_23_Clk_A() {
    v3_12_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_23_Clk_B() {
    v3_12_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_23_Din_A() {
    v3_12_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_23_Din_B() {
    v3_12_23_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_511_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_510_EN_A.read();
    } else {
        v3_12_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_23_EN_B = ap_const_logic_1;
    } else {
        v3_12_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_23_Rst_A() {
    v3_12_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_23_Rst_B() {
    v3_12_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_23_WEN_A() {
    v3_12_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_512_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_511_Addr_A.read();
    } else {
        v3_12_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_24_Addr_A_orig() {
    v3_12_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_24_Addr_B() {
    v3_12_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_24_Addr_B_orig() {
    v3_12_24_Addr_B_orig =  (sc_lv<32>) (v3_12_24_addr_reg_60288.read());
}

void kernel_correlation_sdse::thread_v3_12_24_Clk_A() {
    v3_12_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_24_Clk_B() {
    v3_12_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_24_Din_A() {
    v3_12_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_24_Din_B() {
    v3_12_24_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_512_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_511_EN_A.read();
    } else {
        v3_12_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_24_EN_B = ap_const_logic_1;
    } else {
        v3_12_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_24_Rst_A() {
    v3_12_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_24_Rst_B() {
    v3_12_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_24_WEN_A() {
    v3_12_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_513_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_512_Addr_A.read();
    } else {
        v3_12_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_25_Addr_A_orig() {
    v3_12_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_25_Addr_B() {
    v3_12_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_25_Addr_B_orig() {
    v3_12_25_Addr_B_orig =  (sc_lv<32>) (v3_12_25_addr_reg_61948.read());
}

void kernel_correlation_sdse::thread_v3_12_25_Clk_A() {
    v3_12_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_25_Clk_B() {
    v3_12_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_25_Din_A() {
    v3_12_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_25_Din_B() {
    v3_12_25_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_513_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_512_EN_A.read();
    } else {
        v3_12_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_25_EN_B = ap_const_logic_1;
    } else {
        v3_12_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_25_Rst_A() {
    v3_12_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_25_Rst_B() {
    v3_12_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_25_WEN_A() {
    v3_12_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_514_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_513_Addr_A.read();
    } else {
        v3_12_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_26_Addr_A_orig() {
    v3_12_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_26_Addr_B() {
    v3_12_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_26_Addr_B_orig() {
    v3_12_26_Addr_B_orig =  (sc_lv<32>) (v3_12_26_addr_reg_63608.read());
}

void kernel_correlation_sdse::thread_v3_12_26_Clk_A() {
    v3_12_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_26_Clk_B() {
    v3_12_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_26_Din_A() {
    v3_12_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_26_Din_B() {
    v3_12_26_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_514_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_513_EN_A.read();
    } else {
        v3_12_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_26_EN_B = ap_const_logic_1;
    } else {
        v3_12_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_26_Rst_A() {
    v3_12_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_26_Rst_B() {
    v3_12_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_26_WEN_A() {
    v3_12_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_515_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_514_Addr_A.read();
    } else {
        v3_12_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_27_Addr_A_orig() {
    v3_12_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_27_Addr_B() {
    v3_12_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_27_Addr_B_orig() {
    v3_12_27_Addr_B_orig =  (sc_lv<32>) (v3_12_27_addr_reg_65268.read());
}

void kernel_correlation_sdse::thread_v3_12_27_Clk_A() {
    v3_12_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_27_Clk_B() {
    v3_12_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_27_Din_A() {
    v3_12_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_27_Din_B() {
    v3_12_27_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_515_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_514_EN_A.read();
    } else {
        v3_12_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_27_EN_B = ap_const_logic_1;
    } else {
        v3_12_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_27_Rst_A() {
    v3_12_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_27_Rst_B() {
    v3_12_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_27_WEN_A() {
    v3_12_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_516_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_515_Addr_A.read();
    } else {
        v3_12_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_28_Addr_A_orig() {
    v3_12_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_28_Addr_B() {
    v3_12_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_28_Addr_B_orig() {
    v3_12_28_Addr_B_orig =  (sc_lv<32>) (v3_12_28_addr_reg_60294.read());
}

void kernel_correlation_sdse::thread_v3_12_28_Clk_A() {
    v3_12_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_28_Clk_B() {
    v3_12_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_28_Din_A() {
    v3_12_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_28_Din_B() {
    v3_12_28_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_516_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_515_EN_A.read();
    } else {
        v3_12_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_28_EN_B = ap_const_logic_1;
    } else {
        v3_12_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_28_Rst_A() {
    v3_12_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_28_Rst_B() {
    v3_12_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_28_WEN_A() {
    v3_12_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_517_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_516_Addr_A.read();
    } else {
        v3_12_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_29_Addr_A_orig() {
    v3_12_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_29_Addr_B() {
    v3_12_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_29_Addr_B_orig() {
    v3_12_29_Addr_B_orig =  (sc_lv<32>) (v3_12_29_addr_reg_61954.read());
}

void kernel_correlation_sdse::thread_v3_12_29_Clk_A() {
    v3_12_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_29_Clk_B() {
    v3_12_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_29_Din_A() {
    v3_12_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_29_Din_B() {
    v3_12_29_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_517_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_516_EN_A.read();
    } else {
        v3_12_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_29_EN_B = ap_const_logic_1;
    } else {
        v3_12_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_29_Rst_A() {
    v3_12_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_29_Rst_B() {
    v3_12_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_29_WEN_A() {
    v3_12_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_490_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_489_Addr_A.read();
    } else {
        v3_12_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_2_Addr_A_orig() {
    v3_12_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_2_Addr_B() {
    v3_12_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_2_Addr_B_orig() {
    v3_12_2_Addr_B_orig =  (sc_lv<32>) (v3_12_2_addr_reg_63572.read());
}

void kernel_correlation_sdse::thread_v3_12_2_Clk_A() {
    v3_12_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_2_Clk_B() {
    v3_12_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_2_Din_A() {
    v3_12_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_2_Din_B() {
    v3_12_2_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_490_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_489_EN_A.read();
    } else {
        v3_12_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_2_EN_B = ap_const_logic_1;
    } else {
        v3_12_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_2_Rst_A() {
    v3_12_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_2_Rst_B() {
    v3_12_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_2_WEN_A() {
    v3_12_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_518_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_517_Addr_A.read();
    } else {
        v3_12_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_30_Addr_A_orig() {
    v3_12_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_30_Addr_B() {
    v3_12_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_30_Addr_B_orig() {
    v3_12_30_Addr_B_orig =  (sc_lv<32>) (v3_12_30_addr_reg_63614.read());
}

void kernel_correlation_sdse::thread_v3_12_30_Clk_A() {
    v3_12_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_30_Clk_B() {
    v3_12_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_30_Din_A() {
    v3_12_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_30_Din_B() {
    v3_12_30_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_518_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_517_EN_A.read();
    } else {
        v3_12_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_30_EN_B = ap_const_logic_1;
    } else {
        v3_12_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_30_Rst_A() {
    v3_12_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_30_Rst_B() {
    v3_12_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_30_WEN_A() {
    v3_12_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_519_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_518_Addr_A.read();
    } else {
        v3_12_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_31_Addr_A_orig() {
    v3_12_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_31_Addr_B() {
    v3_12_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_31_Addr_B_orig() {
    v3_12_31_Addr_B_orig =  (sc_lv<32>) (v3_12_31_addr_reg_65274.read());
}

void kernel_correlation_sdse::thread_v3_12_31_Clk_A() {
    v3_12_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_31_Clk_B() {
    v3_12_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_31_Din_A() {
    v3_12_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_31_Din_B() {
    v3_12_31_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_519_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_518_EN_A.read();
    } else {
        v3_12_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_31_EN_B = ap_const_logic_1;
    } else {
        v3_12_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_31_Rst_A() {
    v3_12_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_31_Rst_B() {
    v3_12_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_31_WEN_A() {
    v3_12_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_31_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_32_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_520_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_519_Addr_A.read();
    } else {
        v3_12_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_32_Addr_A_orig() {
    v3_12_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_32_Addr_B() {
    v3_12_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_32_Addr_B_orig() {
    v3_12_32_Addr_B_orig =  (sc_lv<32>) (v3_12_32_addr_reg_60300.read());
}

void kernel_correlation_sdse::thread_v3_12_32_Clk_A() {
    v3_12_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_32_Clk_B() {
    v3_12_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_32_Din_A() {
    v3_12_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_32_Din_B() {
    v3_12_32_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_32_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_520_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_519_EN_A.read();
    } else {
        v3_12_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_32_EN_B = ap_const_logic_1;
    } else {
        v3_12_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_32_Rst_A() {
    v3_12_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_32_Rst_B() {
    v3_12_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_32_WEN_A() {
    v3_12_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_32_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_33_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_521_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_520_Addr_A.read();
    } else {
        v3_12_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_33_Addr_A_orig() {
    v3_12_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_33_Addr_B() {
    v3_12_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_33_Addr_B_orig() {
    v3_12_33_Addr_B_orig =  (sc_lv<32>) (v3_12_33_addr_reg_61960.read());
}

void kernel_correlation_sdse::thread_v3_12_33_Clk_A() {
    v3_12_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_33_Clk_B() {
    v3_12_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_33_Din_A() {
    v3_12_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_33_Din_B() {
    v3_12_33_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_33_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_521_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_520_EN_A.read();
    } else {
        v3_12_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_33_EN_B = ap_const_logic_1;
    } else {
        v3_12_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_33_Rst_A() {
    v3_12_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_33_Rst_B() {
    v3_12_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_33_WEN_A() {
    v3_12_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_33_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_34_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_522_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_521_Addr_A.read();
    } else {
        v3_12_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_34_Addr_A_orig() {
    v3_12_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_34_Addr_B() {
    v3_12_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_34_Addr_B_orig() {
    v3_12_34_Addr_B_orig =  (sc_lv<32>) (v3_12_34_addr_reg_63620.read());
}

void kernel_correlation_sdse::thread_v3_12_34_Clk_A() {
    v3_12_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_34_Clk_B() {
    v3_12_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_34_Din_A() {
    v3_12_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_34_Din_B() {
    v3_12_34_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_34_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_522_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_521_EN_A.read();
    } else {
        v3_12_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_34_EN_B = ap_const_logic_1;
    } else {
        v3_12_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_34_Rst_A() {
    v3_12_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_34_Rst_B() {
    v3_12_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_34_WEN_A() {
    v3_12_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_34_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_35_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_523_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_522_Addr_A.read();
    } else {
        v3_12_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_35_Addr_A_orig() {
    v3_12_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_35_Addr_B() {
    v3_12_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_35_Addr_B_orig() {
    v3_12_35_Addr_B_orig =  (sc_lv<32>) (v3_12_35_addr_reg_65280.read());
}

void kernel_correlation_sdse::thread_v3_12_35_Clk_A() {
    v3_12_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_35_Clk_B() {
    v3_12_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_35_Din_A() {
    v3_12_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_35_Din_B() {
    v3_12_35_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_35_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_523_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_522_EN_A.read();
    } else {
        v3_12_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_35_EN_B = ap_const_logic_1;
    } else {
        v3_12_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_35_Rst_A() {
    v3_12_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_35_Rst_B() {
    v3_12_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_35_WEN_A() {
    v3_12_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_35_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_36_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_524_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_523_Addr_A.read();
    } else {
        v3_12_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_36_Addr_A_orig() {
    v3_12_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_36_Addr_B() {
    v3_12_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_36_Addr_B_orig() {
    v3_12_36_Addr_B_orig =  (sc_lv<32>) (v3_12_36_addr_reg_60306.read());
}

void kernel_correlation_sdse::thread_v3_12_36_Clk_A() {
    v3_12_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_36_Clk_B() {
    v3_12_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_36_Din_A() {
    v3_12_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_36_Din_B() {
    v3_12_36_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_36_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_524_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_523_EN_A.read();
    } else {
        v3_12_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_36_EN_B = ap_const_logic_1;
    } else {
        v3_12_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_36_Rst_A() {
    v3_12_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_36_Rst_B() {
    v3_12_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_36_WEN_A() {
    v3_12_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_36_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_37_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_525_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_524_Addr_A.read();
    } else {
        v3_12_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_37_Addr_A_orig() {
    v3_12_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_37_Addr_B() {
    v3_12_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_37_Addr_B_orig() {
    v3_12_37_Addr_B_orig =  (sc_lv<32>) (v3_12_37_addr_reg_61966.read());
}

void kernel_correlation_sdse::thread_v3_12_37_Clk_A() {
    v3_12_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_37_Clk_B() {
    v3_12_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_37_Din_A() {
    v3_12_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_37_Din_B() {
    v3_12_37_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_525_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_524_EN_A.read();
    } else {
        v3_12_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_37_EN_B = ap_const_logic_1;
    } else {
        v3_12_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_37_Rst_A() {
    v3_12_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_37_Rst_B() {
    v3_12_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_37_WEN_A() {
    v3_12_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_526_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_525_Addr_A.read();
    } else {
        v3_12_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_38_Addr_A_orig() {
    v3_12_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_38_Addr_B() {
    v3_12_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_38_Addr_B_orig() {
    v3_12_38_Addr_B_orig =  (sc_lv<32>) (v3_12_38_addr_reg_63626.read());
}

void kernel_correlation_sdse::thread_v3_12_38_Clk_A() {
    v3_12_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_38_Clk_B() {
    v3_12_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_38_Din_A() {
    v3_12_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_38_Din_B() {
    v3_12_38_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_526_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_525_EN_A.read();
    } else {
        v3_12_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_38_EN_B = ap_const_logic_1;
    } else {
        v3_12_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_38_Rst_A() {
    v3_12_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_38_Rst_B() {
    v3_12_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_38_WEN_A() {
    v3_12_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_527_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_526_Addr_A.read();
    } else {
        v3_12_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_39_Addr_A_orig() {
    v3_12_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_39_Addr_B() {
    v3_12_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_39_Addr_B_orig() {
    v3_12_39_Addr_B_orig =  (sc_lv<32>) (v3_12_39_addr_reg_65286.read());
}

void kernel_correlation_sdse::thread_v3_12_39_Clk_A() {
    v3_12_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_39_Clk_B() {
    v3_12_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_39_Din_A() {
    v3_12_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_39_Din_B() {
    v3_12_39_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_527_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_526_EN_A.read();
    } else {
        v3_12_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_39_EN_B = ap_const_logic_1;
    } else {
        v3_12_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_39_Rst_A() {
    v3_12_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_39_Rst_B() {
    v3_12_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_39_WEN_A() {
    v3_12_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_491_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_490_Addr_A.read();
    } else {
        v3_12_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_3_Addr_A_orig() {
    v3_12_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_3_Addr_B() {
    v3_12_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_3_Addr_B_orig() {
    v3_12_3_Addr_B_orig =  (sc_lv<32>) (v3_12_3_addr_reg_65232.read());
}

void kernel_correlation_sdse::thread_v3_12_3_Clk_A() {
    v3_12_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_3_Clk_B() {
    v3_12_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_3_Din_A() {
    v3_12_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_3_Din_B() {
    v3_12_3_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_491_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_490_EN_A.read();
    } else {
        v3_12_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_3_EN_B = ap_const_logic_1;
    } else {
        v3_12_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_3_Rst_A() {
    v3_12_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_3_Rst_B() {
    v3_12_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_3_WEN_A() {
    v3_12_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_492_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_491_Addr_A.read();
    } else {
        v3_12_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_4_Addr_A_orig() {
    v3_12_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_4_Addr_B() {
    v3_12_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_4_Addr_B_orig() {
    v3_12_4_Addr_B_orig =  (sc_lv<32>) (v3_12_4_addr_reg_60258.read());
}

void kernel_correlation_sdse::thread_v3_12_4_Clk_A() {
    v3_12_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_4_Clk_B() {
    v3_12_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_4_Din_A() {
    v3_12_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_4_Din_B() {
    v3_12_4_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_492_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_491_EN_A.read();
    } else {
        v3_12_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_4_EN_B = ap_const_logic_1;
    } else {
        v3_12_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_4_Rst_A() {
    v3_12_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_4_Rst_B() {
    v3_12_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_4_WEN_A() {
    v3_12_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_493_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_492_Addr_A.read();
    } else {
        v3_12_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_5_Addr_A_orig() {
    v3_12_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_5_Addr_B() {
    v3_12_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_5_Addr_B_orig() {
    v3_12_5_Addr_B_orig =  (sc_lv<32>) (v3_12_5_addr_reg_61918.read());
}

void kernel_correlation_sdse::thread_v3_12_5_Clk_A() {
    v3_12_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_5_Clk_B() {
    v3_12_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_5_Din_A() {
    v3_12_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_5_Din_B() {
    v3_12_5_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_493_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_492_EN_A.read();
    } else {
        v3_12_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_5_EN_B = ap_const_logic_1;
    } else {
        v3_12_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_5_Rst_A() {
    v3_12_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_5_Rst_B() {
    v3_12_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_5_WEN_A() {
    v3_12_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_494_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_493_Addr_A.read();
    } else {
        v3_12_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_6_Addr_A_orig() {
    v3_12_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_6_Addr_B() {
    v3_12_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_6_Addr_B_orig() {
    v3_12_6_Addr_B_orig =  (sc_lv<32>) (v3_12_6_addr_reg_63578.read());
}

void kernel_correlation_sdse::thread_v3_12_6_Clk_A() {
    v3_12_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_6_Clk_B() {
    v3_12_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_6_Din_A() {
    v3_12_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_6_Din_B() {
    v3_12_6_Din_B = grp_fu_42258_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_494_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_493_EN_A.read();
    } else {
        v3_12_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_6_EN_B = ap_const_logic_1;
    } else {
        v3_12_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_6_Rst_A() {
    v3_12_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_6_Rst_B() {
    v3_12_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_6_WEN_A() {
    v3_12_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_6_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_495_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_494_Addr_A.read();
    } else {
        v3_12_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_7_Addr_A_orig() {
    v3_12_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_7_Addr_B() {
    v3_12_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_7_Addr_B_orig() {
    v3_12_7_Addr_B_orig =  (sc_lv<32>) (v3_12_7_addr_reg_65238.read());
}

void kernel_correlation_sdse::thread_v3_12_7_Clk_A() {
    v3_12_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_7_Clk_B() {
    v3_12_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_7_Din_A() {
    v3_12_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_7_Din_B() {
    v3_12_7_Din_B = grp_fu_42274_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_495_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_494_EN_A.read();
    } else {
        v3_12_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_7_EN_B = ap_const_logic_1;
    } else {
        v3_12_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_7_Rst_A() {
    v3_12_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_7_Rst_B() {
    v3_12_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_7_WEN_A() {
    v3_12_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_7_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_496_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_495_Addr_A.read();
    } else {
        v3_12_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_8_Addr_A_orig() {
    v3_12_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_8_Addr_B() {
    v3_12_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_8_Addr_B_orig() {
    v3_12_8_Addr_B_orig =  (sc_lv<32>) (v3_12_8_addr_reg_60264.read());
}

void kernel_correlation_sdse::thread_v3_12_8_Clk_A() {
    v3_12_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_8_Clk_B() {
    v3_12_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_8_Din_A() {
    v3_12_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_8_Din_B() {
    v3_12_8_Din_B = grp_fu_42228_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_496_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_495_EN_A.read();
    } else {
        v3_12_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_8_EN_B = ap_const_logic_1;
    } else {
        v3_12_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_8_Rst_A() {
    v3_12_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_8_Rst_B() {
    v3_12_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_8_WEN_A() {
    v3_12_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_8_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_497_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_496_Addr_A.read();
    } else {
        v3_12_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_12_9_Addr_A_orig() {
    v3_12_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_12_9_Addr_B() {
    v3_12_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_12_9_Addr_B_orig() {
    v3_12_9_Addr_B_orig =  (sc_lv<32>) (v3_12_9_addr_reg_61924.read());
}

void kernel_correlation_sdse::thread_v3_12_9_Clk_A() {
    v3_12_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_9_Clk_B() {
    v3_12_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_12_9_Din_A() {
    v3_12_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_12_9_Din_B() {
    v3_12_9_Din_B = grp_fu_42243_p2.read();
}

void kernel_correlation_sdse::thread_v3_12_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_12_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_12_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_497_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_12_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_496_EN_A.read();
    } else {
        v3_12_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_9_EN_B = ap_const_logic_1;
    } else {
        v3_12_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_12_9_Rst_A() {
    v3_12_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_9_Rst_B() {
    v3_12_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_12_9_WEN_A() {
    v3_12_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_12_9_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_12_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_567_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_528_Addr_A.read();
    } else {
        v3_13_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_0_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_0_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_0_Addr_B() {
    v3_13_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_0_Addr_B_orig() {
    v3_13_0_Addr_B_orig =  (sc_lv<32>) (v3_13_0_addr_2_reg_60312.read());
}

void kernel_correlation_sdse::thread_v3_13_0_Clk_A() {
    v3_13_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_0_Clk_B() {
    v3_13_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_0_Din_A() {
    v3_13_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_0_Din_B() {
    v3_13_0_Din_B = grp_fu_42290_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_567_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_528_EN_A.read();
    } else {
        v3_13_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_0_EN_B = ap_const_logic_1;
    } else {
        v3_13_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_0_Rst_A() {
    v3_13_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_0_Rst_B() {
    v3_13_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_0_WEN_A() {
    v3_13_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_538_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_537_Addr_A.read();
    } else {
        v3_13_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_10_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_10_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_10_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_10_Addr_B() {
    v3_13_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_10_Addr_B_orig() {
    v3_13_10_Addr_B_orig =  (sc_lv<32>) (v3_13_10_addr_2_reg_63644.read());
}

void kernel_correlation_sdse::thread_v3_13_10_Clk_A() {
    v3_13_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_10_Clk_B() {
    v3_13_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_10_Din_A() {
    v3_13_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_10_Din_B() {
    v3_13_10_Din_B = grp_fu_42320_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_10_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_538_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_537_EN_A.read();
    } else {
        v3_13_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_10_EN_B = ap_const_logic_1;
    } else {
        v3_13_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_10_Rst_A() {
    v3_13_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_10_Rst_B() {
    v3_13_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_10_WEN_A() {
    v3_13_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_539_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_538_Addr_A.read();
    } else {
        v3_13_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_11_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_11_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_11_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_11_Addr_B() {
    v3_13_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_11_Addr_B_orig() {
    v3_13_11_Addr_B_orig =  (sc_lv<32>) (v3_13_11_addr_2_reg_65304.read());
}

void kernel_correlation_sdse::thread_v3_13_11_Clk_A() {
    v3_13_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_11_Clk_B() {
    v3_13_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_11_Din_A() {
    v3_13_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_11_Din_B() {
    v3_13_11_Din_B = grp_fu_42336_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_11_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_539_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_538_EN_A.read();
    } else {
        v3_13_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_11_EN_B = ap_const_logic_1;
    } else {
        v3_13_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_11_Rst_A() {
    v3_13_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_11_Rst_B() {
    v3_13_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_11_WEN_A() {
    v3_13_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_540_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_539_Addr_A.read();
    } else {
        v3_13_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_12_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_12_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_12_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_12_Addr_B() {
    v3_13_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_12_Addr_B_orig() {
    v3_13_12_Addr_B_orig =  (sc_lv<32>) (v3_13_12_addr_2_reg_60330.read());
}

void kernel_correlation_sdse::thread_v3_13_12_Clk_A() {
    v3_13_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_12_Clk_B() {
    v3_13_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_12_Din_A() {
    v3_13_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_12_Din_B() {
    v3_13_12_Din_B = grp_fu_42290_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_12_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_540_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_539_EN_A.read();
    } else {
        v3_13_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_12_EN_B = ap_const_logic_1;
    } else {
        v3_13_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_12_Rst_A() {
    v3_13_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_12_Rst_B() {
    v3_13_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_12_WEN_A() {
    v3_13_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_541_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_540_Addr_A.read();
    } else {
        v3_13_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_13_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_13_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_13_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_13_Addr_B() {
    v3_13_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_13_Addr_B_orig() {
    v3_13_13_Addr_B_orig =  (sc_lv<32>) (v3_13_13_addr_2_reg_61990.read());
}

void kernel_correlation_sdse::thread_v3_13_13_Clk_A() {
    v3_13_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_13_Clk_B() {
    v3_13_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_13_Din_A() {
    v3_13_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_13_Din_B() {
    v3_13_13_Din_B = grp_fu_42305_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_13_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_541_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_540_EN_A.read();
    } else {
        v3_13_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_13_EN_B = ap_const_logic_1;
    } else {
        v3_13_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_13_Rst_A() {
    v3_13_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_13_Rst_B() {
    v3_13_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_13_WEN_A() {
    v3_13_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_542_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_541_Addr_A.read();
    } else {
        v3_13_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_14_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_14_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_14_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_14_Addr_B() {
    v3_13_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_14_Addr_B_orig() {
    v3_13_14_Addr_B_orig =  (sc_lv<32>) (v3_13_14_addr_2_reg_63650.read());
}

void kernel_correlation_sdse::thread_v3_13_14_Clk_A() {
    v3_13_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_14_Clk_B() {
    v3_13_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_14_Din_A() {
    v3_13_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_14_Din_B() {
    v3_13_14_Din_B = grp_fu_42320_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_14_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_542_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_541_EN_A.read();
    } else {
        v3_13_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_14_EN_B = ap_const_logic_1;
    } else {
        v3_13_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_14_Rst_A() {
    v3_13_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_14_Rst_B() {
    v3_13_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_14_WEN_A() {
    v3_13_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_543_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_542_Addr_A.read();
    } else {
        v3_13_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_15_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_15_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_15_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_15_Addr_B() {
    v3_13_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_15_Addr_B_orig() {
    v3_13_15_Addr_B_orig =  (sc_lv<32>) (v3_13_15_addr_2_reg_65310.read());
}

void kernel_correlation_sdse::thread_v3_13_15_Clk_A() {
    v3_13_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_15_Clk_B() {
    v3_13_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_15_Din_A() {
    v3_13_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_15_Din_B() {
    v3_13_15_Din_B = grp_fu_42336_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_15_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_543_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_542_EN_A.read();
    } else {
        v3_13_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_15_EN_B = ap_const_logic_1;
    } else {
        v3_13_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_15_Rst_A() {
    v3_13_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_15_Rst_B() {
    v3_13_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_15_WEN_A() {
    v3_13_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_544_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_543_Addr_A.read();
    } else {
        v3_13_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_16_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_16_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_16_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_16_Addr_B() {
    v3_13_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_16_Addr_B_orig() {
    v3_13_16_Addr_B_orig =  (sc_lv<32>) (v3_13_16_addr_2_reg_60336.read());
}

void kernel_correlation_sdse::thread_v3_13_16_Clk_A() {
    v3_13_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_16_Clk_B() {
    v3_13_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_16_Din_A() {
    v3_13_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_16_Din_B() {
    v3_13_16_Din_B = grp_fu_42290_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_16_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_544_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_543_EN_A.read();
    } else {
        v3_13_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_16_EN_B = ap_const_logic_1;
    } else {
        v3_13_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_16_Rst_A() {
    v3_13_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_16_Rst_B() {
    v3_13_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_16_WEN_A() {
    v3_13_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_545_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_544_Addr_A.read();
    } else {
        v3_13_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_17_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_17_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_17_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_17_Addr_B() {
    v3_13_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_17_Addr_B_orig() {
    v3_13_17_Addr_B_orig =  (sc_lv<32>) (v3_13_17_addr_2_reg_61996.read());
}

void kernel_correlation_sdse::thread_v3_13_17_Clk_A() {
    v3_13_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_17_Clk_B() {
    v3_13_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_17_Din_A() {
    v3_13_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_17_Din_B() {
    v3_13_17_Din_B = grp_fu_42305_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_17_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_545_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_544_EN_A.read();
    } else {
        v3_13_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_17_EN_B = ap_const_logic_1;
    } else {
        v3_13_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_17_Rst_A() {
    v3_13_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_17_Rst_B() {
    v3_13_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_17_WEN_A() {
    v3_13_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_546_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_545_Addr_A.read();
    } else {
        v3_13_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_18_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_18_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_18_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_18_Addr_B() {
    v3_13_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_18_Addr_B_orig() {
    v3_13_18_Addr_B_orig =  (sc_lv<32>) (v3_13_18_addr_2_reg_63656.read());
}

void kernel_correlation_sdse::thread_v3_13_18_Clk_A() {
    v3_13_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_18_Clk_B() {
    v3_13_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_18_Din_A() {
    v3_13_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_18_Din_B() {
    v3_13_18_Din_B = grp_fu_42320_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_18_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_546_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_545_EN_A.read();
    } else {
        v3_13_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_18_EN_B = ap_const_logic_1;
    } else {
        v3_13_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_18_Rst_A() {
    v3_13_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_18_Rst_B() {
    v3_13_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_18_WEN_A() {
    v3_13_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_547_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_546_Addr_A.read();
    } else {
        v3_13_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_19_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_19_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_19_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_19_Addr_B() {
    v3_13_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_19_Addr_B_orig() {
    v3_13_19_Addr_B_orig =  (sc_lv<32>) (v3_13_19_addr_2_reg_65316.read());
}

void kernel_correlation_sdse::thread_v3_13_19_Clk_A() {
    v3_13_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_19_Clk_B() {
    v3_13_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_19_Din_A() {
    v3_13_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_19_Din_B() {
    v3_13_19_Din_B = grp_fu_42336_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_19_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_547_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_546_EN_A.read();
    } else {
        v3_13_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_19_EN_B = ap_const_logic_1;
    } else {
        v3_13_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_19_Rst_A() {
    v3_13_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_19_Rst_B() {
    v3_13_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_19_WEN_A() {
    v3_13_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_529_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_528_Addr_A.read();
    } else {
        v3_13_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_1_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_1_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_1_Addr_B() {
    v3_13_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_1_Addr_B_orig() {
    v3_13_1_Addr_B_orig =  (sc_lv<32>) (v3_13_1_addr_2_reg_61972.read());
}

void kernel_correlation_sdse::thread_v3_13_1_Clk_A() {
    v3_13_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_1_Clk_B() {
    v3_13_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_1_Din_A() {
    v3_13_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_1_Din_B() {
    v3_13_1_Din_B = grp_fu_42305_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_529_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_528_EN_A.read();
    } else {
        v3_13_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_1_EN_B = ap_const_logic_1;
    } else {
        v3_13_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_1_Rst_A() {
    v3_13_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_1_Rst_B() {
    v3_13_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_1_WEN_A() {
    v3_13_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_548_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_547_Addr_A.read();
    } else {
        v3_13_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_20_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_20_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_20_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_20_Addr_B() {
    v3_13_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_20_Addr_B_orig() {
    v3_13_20_Addr_B_orig =  (sc_lv<32>) (v3_13_20_addr_2_reg_60342.read());
}

void kernel_correlation_sdse::thread_v3_13_20_Clk_A() {
    v3_13_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_20_Clk_B() {
    v3_13_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_20_Din_A() {
    v3_13_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_20_Din_B() {
    v3_13_20_Din_B = grp_fu_42290_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_20_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_548_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_547_EN_A.read();
    } else {
        v3_13_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_20_EN_B = ap_const_logic_1;
    } else {
        v3_13_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_20_Rst_A() {
    v3_13_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_20_Rst_B() {
    v3_13_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_20_WEN_A() {
    v3_13_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_549_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_548_Addr_A.read();
    } else {
        v3_13_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_21_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_21_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_21_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_21_Addr_B() {
    v3_13_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_21_Addr_B_orig() {
    v3_13_21_Addr_B_orig =  (sc_lv<32>) (v3_13_21_addr_2_reg_62002.read());
}

void kernel_correlation_sdse::thread_v3_13_21_Clk_A() {
    v3_13_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_21_Clk_B() {
    v3_13_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_21_Din_A() {
    v3_13_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_21_Din_B() {
    v3_13_21_Din_B = grp_fu_42305_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_21_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_549_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_548_EN_A.read();
    } else {
        v3_13_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_21_EN_B = ap_const_logic_1;
    } else {
        v3_13_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_21_Rst_A() {
    v3_13_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_21_Rst_B() {
    v3_13_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_21_WEN_A() {
    v3_13_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_550_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_549_Addr_A.read();
    } else {
        v3_13_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_22_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_22_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_22_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_22_Addr_B() {
    v3_13_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_22_Addr_B_orig() {
    v3_13_22_Addr_B_orig =  (sc_lv<32>) (v3_13_22_addr_2_reg_63662.read());
}

void kernel_correlation_sdse::thread_v3_13_22_Clk_A() {
    v3_13_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_22_Clk_B() {
    v3_13_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_22_Din_A() {
    v3_13_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_22_Din_B() {
    v3_13_22_Din_B = grp_fu_42320_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_22_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_550_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_549_EN_A.read();
    } else {
        v3_13_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_22_EN_B = ap_const_logic_1;
    } else {
        v3_13_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_22_Rst_A() {
    v3_13_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_22_Rst_B() {
    v3_13_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_22_WEN_A() {
    v3_13_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_551_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_550_Addr_A.read();
    } else {
        v3_13_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_23_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_23_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_23_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_23_Addr_B() {
    v3_13_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_23_Addr_B_orig() {
    v3_13_23_Addr_B_orig =  (sc_lv<32>) (v3_13_23_addr_2_reg_65322.read());
}

void kernel_correlation_sdse::thread_v3_13_23_Clk_A() {
    v3_13_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_23_Clk_B() {
    v3_13_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_23_Din_A() {
    v3_13_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_23_Din_B() {
    v3_13_23_Din_B = grp_fu_42336_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_23_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_551_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_550_EN_A.read();
    } else {
        v3_13_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_23_EN_B = ap_const_logic_1;
    } else {
        v3_13_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_23_Rst_A() {
    v3_13_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_23_Rst_B() {
    v3_13_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_23_WEN_A() {
    v3_13_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_552_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_551_Addr_A.read();
    } else {
        v3_13_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_24_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_24_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_24_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_24_Addr_B() {
    v3_13_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_24_Addr_B_orig() {
    v3_13_24_Addr_B_orig =  (sc_lv<32>) (v3_13_24_addr_2_reg_60348.read());
}

void kernel_correlation_sdse::thread_v3_13_24_Clk_A() {
    v3_13_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_24_Clk_B() {
    v3_13_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_24_Din_A() {
    v3_13_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_24_Din_B() {
    v3_13_24_Din_B = grp_fu_42290_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_24_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_552_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_551_EN_A.read();
    } else {
        v3_13_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_24_EN_B = ap_const_logic_1;
    } else {
        v3_13_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_24_Rst_A() {
    v3_13_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_24_Rst_B() {
    v3_13_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_24_WEN_A() {
    v3_13_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_553_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_552_Addr_A.read();
    } else {
        v3_13_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_25_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_25_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_25_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_25_Addr_B() {
    v3_13_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_25_Addr_B_orig() {
    v3_13_25_Addr_B_orig =  (sc_lv<32>) (v3_13_25_addr_2_reg_62008.read());
}

void kernel_correlation_sdse::thread_v3_13_25_Clk_A() {
    v3_13_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_25_Clk_B() {
    v3_13_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_25_Din_A() {
    v3_13_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_25_Din_B() {
    v3_13_25_Din_B = grp_fu_42305_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_25_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_553_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_552_EN_A.read();
    } else {
        v3_13_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_25_EN_B = ap_const_logic_1;
    } else {
        v3_13_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_25_Rst_A() {
    v3_13_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_25_Rst_B() {
    v3_13_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_25_WEN_A() {
    v3_13_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_554_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_553_Addr_A.read();
    } else {
        v3_13_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_26_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_26_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_26_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_26_Addr_B() {
    v3_13_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_26_Addr_B_orig() {
    v3_13_26_Addr_B_orig =  (sc_lv<32>) (v3_13_26_addr_2_reg_63668.read());
}

void kernel_correlation_sdse::thread_v3_13_26_Clk_A() {
    v3_13_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_26_Clk_B() {
    v3_13_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_26_Din_A() {
    v3_13_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_26_Din_B() {
    v3_13_26_Din_B = grp_fu_42320_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_26_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_554_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_553_EN_A.read();
    } else {
        v3_13_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_26_EN_B = ap_const_logic_1;
    } else {
        v3_13_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_26_Rst_A() {
    v3_13_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_26_Rst_B() {
    v3_13_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_26_WEN_A() {
    v3_13_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_555_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_554_Addr_A.read();
    } else {
        v3_13_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_27_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_27_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_27_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_27_Addr_B() {
    v3_13_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_27_Addr_B_orig() {
    v3_13_27_Addr_B_orig =  (sc_lv<32>) (v3_13_27_addr_2_reg_65328.read());
}

void kernel_correlation_sdse::thread_v3_13_27_Clk_A() {
    v3_13_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_27_Clk_B() {
    v3_13_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_27_Din_A() {
    v3_13_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_27_Din_B() {
    v3_13_27_Din_B = grp_fu_42336_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_27_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_555_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_554_EN_A.read();
    } else {
        v3_13_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_27_EN_B = ap_const_logic_1;
    } else {
        v3_13_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_27_Rst_A() {
    v3_13_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_27_Rst_B() {
    v3_13_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_27_WEN_A() {
    v3_13_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_556_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_555_Addr_A.read();
    } else {
        v3_13_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_28_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_28_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_28_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_28_Addr_B() {
    v3_13_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_28_Addr_B_orig() {
    v3_13_28_Addr_B_orig =  (sc_lv<32>) (v3_13_28_addr_2_reg_60354.read());
}

void kernel_correlation_sdse::thread_v3_13_28_Clk_A() {
    v3_13_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_28_Clk_B() {
    v3_13_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_28_Din_A() {
    v3_13_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_28_Din_B() {
    v3_13_28_Din_B = grp_fu_42290_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_28_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_556_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_555_EN_A.read();
    } else {
        v3_13_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_28_EN_B = ap_const_logic_1;
    } else {
        v3_13_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_28_Rst_A() {
    v3_13_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_28_Rst_B() {
    v3_13_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_28_WEN_A() {
    v3_13_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_557_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_556_Addr_A.read();
    } else {
        v3_13_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_29_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_29_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_29_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_29_Addr_B() {
    v3_13_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_29_Addr_B_orig() {
    v3_13_29_Addr_B_orig =  (sc_lv<32>) (v3_13_29_addr_2_reg_62014.read());
}

void kernel_correlation_sdse::thread_v3_13_29_Clk_A() {
    v3_13_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_29_Clk_B() {
    v3_13_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_29_Din_A() {
    v3_13_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_29_Din_B() {
    v3_13_29_Din_B = grp_fu_42305_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_29_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_557_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_556_EN_A.read();
    } else {
        v3_13_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_29_EN_B = ap_const_logic_1;
    } else {
        v3_13_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_29_Rst_A() {
    v3_13_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_29_Rst_B() {
    v3_13_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_29_WEN_A() {
    v3_13_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_530_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_529_Addr_A.read();
    } else {
        v3_13_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_2_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_2_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_2_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_2_Addr_B() {
    v3_13_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_2_Addr_B_orig() {
    v3_13_2_Addr_B_orig =  (sc_lv<32>) (v3_13_2_addr_2_reg_63632.read());
}

void kernel_correlation_sdse::thread_v3_13_2_Clk_A() {
    v3_13_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_2_Clk_B() {
    v3_13_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_2_Din_A() {
    v3_13_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_2_Din_B() {
    v3_13_2_Din_B = grp_fu_42320_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_530_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_529_EN_A.read();
    } else {
        v3_13_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_2_EN_B = ap_const_logic_1;
    } else {
        v3_13_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_2_Rst_A() {
    v3_13_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_2_Rst_B() {
    v3_13_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_2_WEN_A() {
    v3_13_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_558_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_557_Addr_A.read();
    } else {
        v3_13_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_30_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_30_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_30_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_30_Addr_B() {
    v3_13_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_30_Addr_B_orig() {
    v3_13_30_Addr_B_orig =  (sc_lv<32>) (v3_13_30_addr_2_reg_63674.read());
}

void kernel_correlation_sdse::thread_v3_13_30_Clk_A() {
    v3_13_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_30_Clk_B() {
    v3_13_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_30_Din_A() {
    v3_13_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_30_Din_B() {
    v3_13_30_Din_B = grp_fu_42320_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_30_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_558_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_557_EN_A.read();
    } else {
        v3_13_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_30_EN_B = ap_const_logic_1;
    } else {
        v3_13_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_30_Rst_A() {
    v3_13_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_30_Rst_B() {
    v3_13_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_30_WEN_A() {
    v3_13_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_559_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_558_Addr_A.read();
    } else {
        v3_13_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_31_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_31_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_31_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_31_Addr_B() {
    v3_13_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_31_Addr_B_orig() {
    v3_13_31_Addr_B_orig =  (sc_lv<32>) (v3_13_31_addr_2_reg_65334.read());
}

void kernel_correlation_sdse::thread_v3_13_31_Clk_A() {
    v3_13_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_31_Clk_B() {
    v3_13_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_31_Din_A() {
    v3_13_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_31_Din_B() {
    v3_13_31_Din_B = grp_fu_42336_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_31_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_559_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_558_EN_A.read();
    } else {
        v3_13_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_31_EN_B = ap_const_logic_1;
    } else {
        v3_13_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_31_Rst_A() {
    v3_13_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_31_Rst_B() {
    v3_13_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_31_WEN_A() {
    v3_13_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_31_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_32_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_560_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_559_Addr_A.read();
    } else {
        v3_13_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_32_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_32_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_32_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_32_Addr_B() {
    v3_13_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_32_Addr_B_orig() {
    v3_13_32_Addr_B_orig =  (sc_lv<32>) (v3_13_32_addr_2_reg_60360.read());
}

void kernel_correlation_sdse::thread_v3_13_32_Clk_A() {
    v3_13_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_32_Clk_B() {
    v3_13_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_32_Din_A() {
    v3_13_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_32_Din_B() {
    v3_13_32_Din_B = grp_fu_42290_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_32_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_32_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_560_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_559_EN_A.read();
    } else {
        v3_13_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_32_EN_B = ap_const_logic_1;
    } else {
        v3_13_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_32_Rst_A() {
    v3_13_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_32_Rst_B() {
    v3_13_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_32_WEN_A() {
    v3_13_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_32_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_33_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_561_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_560_Addr_A.read();
    } else {
        v3_13_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_33_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_33_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_33_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_33_Addr_B() {
    v3_13_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_33_Addr_B_orig() {
    v3_13_33_Addr_B_orig =  (sc_lv<32>) (v3_13_33_addr_2_reg_62020.read());
}

void kernel_correlation_sdse::thread_v3_13_33_Clk_A() {
    v3_13_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_33_Clk_B() {
    v3_13_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_33_Din_A() {
    v3_13_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_33_Din_B() {
    v3_13_33_Din_B = grp_fu_42305_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_33_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_33_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_561_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_560_EN_A.read();
    } else {
        v3_13_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_33_EN_B = ap_const_logic_1;
    } else {
        v3_13_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_33_Rst_A() {
    v3_13_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_33_Rst_B() {
    v3_13_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_33_WEN_A() {
    v3_13_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_33_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_34_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_562_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_561_Addr_A.read();
    } else {
        v3_13_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_34_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_34_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_34_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_34_Addr_B() {
    v3_13_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_34_Addr_B_orig() {
    v3_13_34_Addr_B_orig =  (sc_lv<32>) (v3_13_34_addr_2_reg_63680.read());
}

void kernel_correlation_sdse::thread_v3_13_34_Clk_A() {
    v3_13_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_34_Clk_B() {
    v3_13_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_34_Din_A() {
    v3_13_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_34_Din_B() {
    v3_13_34_Din_B = grp_fu_42320_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_34_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_34_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_562_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_561_EN_A.read();
    } else {
        v3_13_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_34_EN_B = ap_const_logic_1;
    } else {
        v3_13_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_34_Rst_A() {
    v3_13_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_34_Rst_B() {
    v3_13_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_34_WEN_A() {
    v3_13_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_34_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_35_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_563_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_562_Addr_A.read();
    } else {
        v3_13_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_35_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_35_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_35_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_35_Addr_B() {
    v3_13_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_35_Addr_B_orig() {
    v3_13_35_Addr_B_orig =  (sc_lv<32>) (v3_13_35_addr_2_reg_65340.read());
}

void kernel_correlation_sdse::thread_v3_13_35_Clk_A() {
    v3_13_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_35_Clk_B() {
    v3_13_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_35_Din_A() {
    v3_13_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_35_Din_B() {
    v3_13_35_Din_B = grp_fu_42336_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_35_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_35_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_563_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_562_EN_A.read();
    } else {
        v3_13_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_35_EN_B = ap_const_logic_1;
    } else {
        v3_13_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_35_Rst_A() {
    v3_13_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_35_Rst_B() {
    v3_13_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_35_WEN_A() {
    v3_13_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_35_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_36_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_564_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_563_Addr_A.read();
    } else {
        v3_13_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_36_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_36_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_36_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_36_Addr_B() {
    v3_13_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_36_Addr_B_orig() {
    v3_13_36_Addr_B_orig =  (sc_lv<32>) (v3_13_36_addr_2_reg_60366.read());
}

void kernel_correlation_sdse::thread_v3_13_36_Clk_A() {
    v3_13_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_36_Clk_B() {
    v3_13_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_36_Din_A() {
    v3_13_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_36_Din_B() {
    v3_13_36_Din_B = grp_fu_42290_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_36_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_36_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_564_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_563_EN_A.read();
    } else {
        v3_13_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_36_EN_B = ap_const_logic_1;
    } else {
        v3_13_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_36_Rst_A() {
    v3_13_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_36_Rst_B() {
    v3_13_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_36_WEN_A() {
    v3_13_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_36_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_37_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_565_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_564_Addr_A.read();
    } else {
        v3_13_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_37_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_37_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_37_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_37_Addr_B() {
    v3_13_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_37_Addr_B_orig() {
    v3_13_37_Addr_B_orig =  (sc_lv<32>) (v3_13_37_addr_2_reg_62026.read());
}

void kernel_correlation_sdse::thread_v3_13_37_Clk_A() {
    v3_13_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_37_Clk_B() {
    v3_13_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_37_Din_A() {
    v3_13_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_37_Din_B() {
    v3_13_37_Din_B = grp_fu_42305_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_37_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_565_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_564_EN_A.read();
    } else {
        v3_13_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_37_EN_B = ap_const_logic_1;
    } else {
        v3_13_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_37_Rst_A() {
    v3_13_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_37_Rst_B() {
    v3_13_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_37_WEN_A() {
    v3_13_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_566_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_565_Addr_A.read();
    } else {
        v3_13_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_38_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_38_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_38_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_38_Addr_B() {
    v3_13_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_38_Addr_B_orig() {
    v3_13_38_Addr_B_orig =  (sc_lv<32>) (v3_13_38_addr_2_reg_63686.read());
}

void kernel_correlation_sdse::thread_v3_13_38_Clk_A() {
    v3_13_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_38_Clk_B() {
    v3_13_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_38_Din_A() {
    v3_13_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_38_Din_B() {
    v3_13_38_Din_B = grp_fu_42320_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_38_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_566_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_565_EN_A.read();
    } else {
        v3_13_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_38_EN_B = ap_const_logic_1;
    } else {
        v3_13_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_38_Rst_A() {
    v3_13_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_38_Rst_B() {
    v3_13_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_38_WEN_A() {
    v3_13_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_567_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_566_Addr_A.read();
    } else {
        v3_13_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_39_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_39_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_39_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_39_Addr_B() {
    v3_13_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_39_Addr_B_orig() {
    v3_13_39_Addr_B_orig =  (sc_lv<32>) (v3_13_39_addr_2_reg_65346.read());
}

void kernel_correlation_sdse::thread_v3_13_39_Clk_A() {
    v3_13_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_39_Clk_B() {
    v3_13_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_39_Din_A() {
    v3_13_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_39_Din_B() {
    v3_13_39_Din_B = grp_fu_42336_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_39_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_567_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_566_EN_A.read();
    } else {
        v3_13_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_39_EN_B = ap_const_logic_1;
    } else {
        v3_13_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_39_Rst_A() {
    v3_13_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_39_Rst_B() {
    v3_13_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_39_WEN_A() {
    v3_13_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_531_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_530_Addr_A.read();
    } else {
        v3_13_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_3_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_3_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_3_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_3_Addr_B() {
    v3_13_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_3_Addr_B_orig() {
    v3_13_3_Addr_B_orig =  (sc_lv<32>) (v3_13_3_addr_2_reg_65292.read());
}

void kernel_correlation_sdse::thread_v3_13_3_Clk_A() {
    v3_13_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_3_Clk_B() {
    v3_13_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_3_Din_A() {
    v3_13_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_3_Din_B() {
    v3_13_3_Din_B = grp_fu_42336_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_531_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_530_EN_A.read();
    } else {
        v3_13_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_3_EN_B = ap_const_logic_1;
    } else {
        v3_13_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_3_Rst_A() {
    v3_13_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_3_Rst_B() {
    v3_13_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_3_WEN_A() {
    v3_13_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_532_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_531_Addr_A.read();
    } else {
        v3_13_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_4_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_4_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_4_Addr_B() {
    v3_13_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_4_Addr_B_orig() {
    v3_13_4_Addr_B_orig =  (sc_lv<32>) (v3_13_4_addr_2_reg_60318.read());
}

void kernel_correlation_sdse::thread_v3_13_4_Clk_A() {
    v3_13_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_4_Clk_B() {
    v3_13_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_4_Din_A() {
    v3_13_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_4_Din_B() {
    v3_13_4_Din_B = grp_fu_42290_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_532_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_531_EN_A.read();
    } else {
        v3_13_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_4_EN_B = ap_const_logic_1;
    } else {
        v3_13_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_4_Rst_A() {
    v3_13_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_4_Rst_B() {
    v3_13_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_4_WEN_A() {
    v3_13_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_533_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_532_Addr_A.read();
    } else {
        v3_13_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_5_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_5_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_5_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_5_Addr_B() {
    v3_13_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_5_Addr_B_orig() {
    v3_13_5_Addr_B_orig =  (sc_lv<32>) (v3_13_5_addr_2_reg_61978.read());
}

void kernel_correlation_sdse::thread_v3_13_5_Clk_A() {
    v3_13_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_5_Clk_B() {
    v3_13_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_13_5_Din_A() {
    v3_13_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_13_5_Din_B() {
    v3_13_5_Din_B = grp_fu_42305_p2.read();
}

void kernel_correlation_sdse::thread_v3_13_5_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_13_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_533_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_532_EN_A.read();
    } else {
        v3_13_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_5_EN_B = ap_const_logic_1;
    } else {
        v3_13_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_5_Rst_A() {
    v3_13_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_5_Rst_B() {
    v3_13_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_13_5_WEN_A() {
    v3_13_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_13_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_13_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_13_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_13_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_534_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_13_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_533_Addr_A.read();
    } else {
        v3_13_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_13_6_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_13_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_13_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_13_6_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_13_6_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_13_6_Addr_B() {
    v3_13_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_13_6_Addr_B_orig() {
    v3_13_6_Addr_B_orig =  (sc_lv<32>) (v3_13_6_addr_2_reg_63638.read());
}

}


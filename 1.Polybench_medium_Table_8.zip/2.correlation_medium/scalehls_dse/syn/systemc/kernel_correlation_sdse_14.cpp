#include "kernel_correlation_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_correlation_sdse::thread_v3_21_3_Din_A() {
    v3_21_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_3_Din_B() {
    v3_21_3_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_851_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_850_EN_A.read();
    } else {
        v3_21_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_3_EN_B = ap_const_logic_1;
    } else {
        v3_21_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_3_Rst_A() {
    v3_21_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_3_Rst_B() {
    v3_21_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_3_WEN_A() {
    v3_21_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_852_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_851_Addr_A.read();
    } else {
        v3_21_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_4_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_4_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_4_Addr_B() {
    v3_21_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_4_Addr_B_orig() {
    v3_21_4_Addr_B_orig =  (sc_lv<32>) (v3_21_4_addr_2_reg_60798.read());
}

void kernel_correlation_sdse::thread_v3_21_4_Clk_A() {
    v3_21_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_4_Clk_B() {
    v3_21_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_4_Din_A() {
    v3_21_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_4_Din_B() {
    v3_21_4_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_852_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_851_EN_A.read();
    } else {
        v3_21_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_4_EN_B = ap_const_logic_1;
    } else {
        v3_21_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_4_Rst_A() {
    v3_21_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_4_Rst_B() {
    v3_21_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_4_WEN_A() {
    v3_21_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_853_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_852_Addr_A.read();
    } else {
        v3_21_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_5_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_5_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_5_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_5_Addr_B() {
    v3_21_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_5_Addr_B_orig() {
    v3_21_5_Addr_B_orig =  (sc_lv<32>) (v3_21_5_addr_2_reg_62458.read());
}

void kernel_correlation_sdse::thread_v3_21_5_Clk_A() {
    v3_21_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_5_Clk_B() {
    v3_21_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_5_Din_A() {
    v3_21_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_5_Din_B() {
    v3_21_5_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_5_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_853_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_852_EN_A.read();
    } else {
        v3_21_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_5_EN_B = ap_const_logic_1;
    } else {
        v3_21_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_5_Rst_A() {
    v3_21_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_5_Rst_B() {
    v3_21_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_5_WEN_A() {
    v3_21_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_854_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_853_Addr_A.read();
    } else {
        v3_21_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_6_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_6_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_6_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_6_Addr_B() {
    v3_21_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_6_Addr_B_orig() {
    v3_21_6_Addr_B_orig =  (sc_lv<32>) (v3_21_6_addr_2_reg_64118.read());
}

void kernel_correlation_sdse::thread_v3_21_6_Clk_A() {
    v3_21_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_6_Clk_B() {
    v3_21_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_6_Din_A() {
    v3_21_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_6_Din_B() {
    v3_21_6_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_6_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_854_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_853_EN_A.read();
    } else {
        v3_21_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_6_EN_B = ap_const_logic_1;
    } else {
        v3_21_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_6_Rst_A() {
    v3_21_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_6_Rst_B() {
    v3_21_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_6_WEN_A() {
    v3_21_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_6_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_855_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_854_Addr_A.read();
    } else {
        v3_21_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_7_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_7_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_7_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_7_Addr_B() {
    v3_21_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_7_Addr_B_orig() {
    v3_21_7_Addr_B_orig =  (sc_lv<32>) (v3_21_7_addr_2_reg_65778.read());
}

void kernel_correlation_sdse::thread_v3_21_7_Clk_A() {
    v3_21_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_7_Clk_B() {
    v3_21_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_7_Din_A() {
    v3_21_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_7_Din_B() {
    v3_21_7_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_7_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_855_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_854_EN_A.read();
    } else {
        v3_21_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_7_EN_B = ap_const_logic_1;
    } else {
        v3_21_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_7_Rst_A() {
    v3_21_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_7_Rst_B() {
    v3_21_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_7_WEN_A() {
    v3_21_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_7_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_856_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_855_Addr_A.read();
    } else {
        v3_21_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_8_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_8_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_8_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_8_Addr_B() {
    v3_21_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_8_Addr_B_orig() {
    v3_21_8_Addr_B_orig =  (sc_lv<32>) (v3_21_8_addr_2_reg_60804.read());
}

void kernel_correlation_sdse::thread_v3_21_8_Clk_A() {
    v3_21_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_8_Clk_B() {
    v3_21_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_8_Din_A() {
    v3_21_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_8_Din_B() {
    v3_21_8_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_8_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_856_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_855_EN_A.read();
    } else {
        v3_21_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_8_EN_B = ap_const_logic_1;
    } else {
        v3_21_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_8_Rst_A() {
    v3_21_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_8_Rst_B() {
    v3_21_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_8_WEN_A() {
    v3_21_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_8_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_857_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_856_Addr_A.read();
    } else {
        v3_21_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_9_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_9_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_9_Addr_B() {
    v3_21_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_9_Addr_B_orig() {
    v3_21_9_Addr_B_orig =  (sc_lv<32>) (v3_21_9_addr_2_reg_62464.read());
}

void kernel_correlation_sdse::thread_v3_21_9_Clk_A() {
    v3_21_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_9_Clk_B() {
    v3_21_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_9_Din_A() {
    v3_21_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_9_Din_B() {
    v3_21_9_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_9_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_857_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_856_EN_A.read();
    } else {
        v3_21_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_9_EN_B = ap_const_logic_1;
    } else {
        v3_21_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_9_Rst_A() {
    v3_21_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_9_Rst_B() {
    v3_21_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_9_WEN_A() {
    v3_21_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_9_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_927_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_888_Addr_A.read();
    } else {
        v3_22_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_0_Addr_A_orig() {
    v3_22_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_0_Addr_B() {
    v3_22_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_0_Addr_B_orig() {
    v3_22_0_Addr_B_orig =  (sc_lv<32>) (v3_22_0_addr_reg_60852.read());
}

void kernel_correlation_sdse::thread_v3_22_0_Clk_A() {
    v3_22_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_0_Clk_B() {
    v3_22_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_0_Din_A() {
    v3_22_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_0_Din_B() {
    v3_22_0_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_927_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_888_EN_A.read();
    } else {
        v3_22_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_0_EN_B = ap_const_logic_1;
    } else {
        v3_22_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_0_Rst_A() {
    v3_22_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_0_Rst_B() {
    v3_22_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_0_WEN_A() {
    v3_22_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_898_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_897_Addr_A.read();
    } else {
        v3_22_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_10_Addr_A_orig() {
    v3_22_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_10_Addr_B() {
    v3_22_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_10_Addr_B_orig() {
    v3_22_10_Addr_B_orig =  (sc_lv<32>) (v3_22_10_addr_reg_64184.read());
}

void kernel_correlation_sdse::thread_v3_22_10_Clk_A() {
    v3_22_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_10_Clk_B() {
    v3_22_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_10_Din_A() {
    v3_22_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_10_Din_B() {
    v3_22_10_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_898_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_897_EN_A.read();
    } else {
        v3_22_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_10_EN_B = ap_const_logic_1;
    } else {
        v3_22_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_10_Rst_A() {
    v3_22_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_10_Rst_B() {
    v3_22_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_10_WEN_A() {
    v3_22_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_899_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_898_Addr_A.read();
    } else {
        v3_22_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_11_Addr_A_orig() {
    v3_22_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_11_Addr_B() {
    v3_22_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_11_Addr_B_orig() {
    v3_22_11_Addr_B_orig =  (sc_lv<32>) (v3_22_11_addr_reg_65844.read());
}

void kernel_correlation_sdse::thread_v3_22_11_Clk_A() {
    v3_22_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_11_Clk_B() {
    v3_22_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_11_Din_A() {
    v3_22_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_11_Din_B() {
    v3_22_11_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_899_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_898_EN_A.read();
    } else {
        v3_22_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_11_EN_B = ap_const_logic_1;
    } else {
        v3_22_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_11_Rst_A() {
    v3_22_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_11_Rst_B() {
    v3_22_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_11_WEN_A() {
    v3_22_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_900_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_899_Addr_A.read();
    } else {
        v3_22_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_12_Addr_A_orig() {
    v3_22_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_12_Addr_B() {
    v3_22_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_12_Addr_B_orig() {
    v3_22_12_Addr_B_orig =  (sc_lv<32>) (v3_22_12_addr_reg_60870.read());
}

void kernel_correlation_sdse::thread_v3_22_12_Clk_A() {
    v3_22_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_12_Clk_B() {
    v3_22_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_12_Din_A() {
    v3_22_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_12_Din_B() {
    v3_22_12_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_900_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_899_EN_A.read();
    } else {
        v3_22_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_12_EN_B = ap_const_logic_1;
    } else {
        v3_22_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_12_Rst_A() {
    v3_22_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_12_Rst_B() {
    v3_22_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_12_WEN_A() {
    v3_22_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_901_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_900_Addr_A.read();
    } else {
        v3_22_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_13_Addr_A_orig() {
    v3_22_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_13_Addr_B() {
    v3_22_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_13_Addr_B_orig() {
    v3_22_13_Addr_B_orig =  (sc_lv<32>) (v3_22_13_addr_reg_62530.read());
}

void kernel_correlation_sdse::thread_v3_22_13_Clk_A() {
    v3_22_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_13_Clk_B() {
    v3_22_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_13_Din_A() {
    v3_22_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_13_Din_B() {
    v3_22_13_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_901_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_900_EN_A.read();
    } else {
        v3_22_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_13_EN_B = ap_const_logic_1;
    } else {
        v3_22_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_13_Rst_A() {
    v3_22_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_13_Rst_B() {
    v3_22_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_13_WEN_A() {
    v3_22_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_902_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_901_Addr_A.read();
    } else {
        v3_22_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_14_Addr_A_orig() {
    v3_22_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_14_Addr_B() {
    v3_22_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_14_Addr_B_orig() {
    v3_22_14_Addr_B_orig =  (sc_lv<32>) (v3_22_14_addr_reg_64190.read());
}

void kernel_correlation_sdse::thread_v3_22_14_Clk_A() {
    v3_22_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_14_Clk_B() {
    v3_22_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_14_Din_A() {
    v3_22_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_14_Din_B() {
    v3_22_14_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_902_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_901_EN_A.read();
    } else {
        v3_22_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_14_EN_B = ap_const_logic_1;
    } else {
        v3_22_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_14_Rst_A() {
    v3_22_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_14_Rst_B() {
    v3_22_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_14_WEN_A() {
    v3_22_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_903_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_902_Addr_A.read();
    } else {
        v3_22_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_15_Addr_A_orig() {
    v3_22_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_15_Addr_B() {
    v3_22_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_15_Addr_B_orig() {
    v3_22_15_Addr_B_orig =  (sc_lv<32>) (v3_22_15_addr_reg_65850.read());
}

void kernel_correlation_sdse::thread_v3_22_15_Clk_A() {
    v3_22_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_15_Clk_B() {
    v3_22_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_15_Din_A() {
    v3_22_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_15_Din_B() {
    v3_22_15_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_903_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_902_EN_A.read();
    } else {
        v3_22_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_15_EN_B = ap_const_logic_1;
    } else {
        v3_22_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_15_Rst_A() {
    v3_22_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_15_Rst_B() {
    v3_22_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_15_WEN_A() {
    v3_22_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_904_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_903_Addr_A.read();
    } else {
        v3_22_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_16_Addr_A_orig() {
    v3_22_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_16_Addr_B() {
    v3_22_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_16_Addr_B_orig() {
    v3_22_16_Addr_B_orig =  (sc_lv<32>) (v3_22_16_addr_reg_60876.read());
}

void kernel_correlation_sdse::thread_v3_22_16_Clk_A() {
    v3_22_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_16_Clk_B() {
    v3_22_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_16_Din_A() {
    v3_22_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_16_Din_B() {
    v3_22_16_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_904_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_903_EN_A.read();
    } else {
        v3_22_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_16_EN_B = ap_const_logic_1;
    } else {
        v3_22_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_16_Rst_A() {
    v3_22_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_16_Rst_B() {
    v3_22_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_16_WEN_A() {
    v3_22_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_905_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_904_Addr_A.read();
    } else {
        v3_22_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_17_Addr_A_orig() {
    v3_22_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_17_Addr_B() {
    v3_22_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_17_Addr_B_orig() {
    v3_22_17_Addr_B_orig =  (sc_lv<32>) (v3_22_17_addr_reg_62536.read());
}

void kernel_correlation_sdse::thread_v3_22_17_Clk_A() {
    v3_22_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_17_Clk_B() {
    v3_22_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_17_Din_A() {
    v3_22_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_17_Din_B() {
    v3_22_17_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_905_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_904_EN_A.read();
    } else {
        v3_22_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_17_EN_B = ap_const_logic_1;
    } else {
        v3_22_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_17_Rst_A() {
    v3_22_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_17_Rst_B() {
    v3_22_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_17_WEN_A() {
    v3_22_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_906_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_905_Addr_A.read();
    } else {
        v3_22_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_18_Addr_A_orig() {
    v3_22_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_18_Addr_B() {
    v3_22_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_18_Addr_B_orig() {
    v3_22_18_Addr_B_orig =  (sc_lv<32>) (v3_22_18_addr_reg_64196.read());
}

void kernel_correlation_sdse::thread_v3_22_18_Clk_A() {
    v3_22_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_18_Clk_B() {
    v3_22_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_18_Din_A() {
    v3_22_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_18_Din_B() {
    v3_22_18_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_906_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_905_EN_A.read();
    } else {
        v3_22_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_18_EN_B = ap_const_logic_1;
    } else {
        v3_22_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_18_Rst_A() {
    v3_22_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_18_Rst_B() {
    v3_22_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_18_WEN_A() {
    v3_22_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_907_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_906_Addr_A.read();
    } else {
        v3_22_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_19_Addr_A_orig() {
    v3_22_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_19_Addr_B() {
    v3_22_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_19_Addr_B_orig() {
    v3_22_19_Addr_B_orig =  (sc_lv<32>) (v3_22_19_addr_reg_65856.read());
}

void kernel_correlation_sdse::thread_v3_22_19_Clk_A() {
    v3_22_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_19_Clk_B() {
    v3_22_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_19_Din_A() {
    v3_22_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_19_Din_B() {
    v3_22_19_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_907_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_906_EN_A.read();
    } else {
        v3_22_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_19_EN_B = ap_const_logic_1;
    } else {
        v3_22_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_19_Rst_A() {
    v3_22_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_19_Rst_B() {
    v3_22_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_19_WEN_A() {
    v3_22_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_889_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_888_Addr_A.read();
    } else {
        v3_22_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_1_Addr_A_orig() {
    v3_22_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_1_Addr_B() {
    v3_22_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_1_Addr_B_orig() {
    v3_22_1_Addr_B_orig =  (sc_lv<32>) (v3_22_1_addr_reg_62512.read());
}

void kernel_correlation_sdse::thread_v3_22_1_Clk_A() {
    v3_22_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_1_Clk_B() {
    v3_22_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_1_Din_A() {
    v3_22_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_1_Din_B() {
    v3_22_1_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_889_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_888_EN_A.read();
    } else {
        v3_22_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_1_EN_B = ap_const_logic_1;
    } else {
        v3_22_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_1_Rst_A() {
    v3_22_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_1_Rst_B() {
    v3_22_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_1_WEN_A() {
    v3_22_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_908_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_907_Addr_A.read();
    } else {
        v3_22_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_20_Addr_A_orig() {
    v3_22_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_20_Addr_B() {
    v3_22_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_20_Addr_B_orig() {
    v3_22_20_Addr_B_orig =  (sc_lv<32>) (v3_22_20_addr_reg_60882.read());
}

void kernel_correlation_sdse::thread_v3_22_20_Clk_A() {
    v3_22_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_20_Clk_B() {
    v3_22_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_20_Din_A() {
    v3_22_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_20_Din_B() {
    v3_22_20_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_908_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_907_EN_A.read();
    } else {
        v3_22_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_20_EN_B = ap_const_logic_1;
    } else {
        v3_22_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_20_Rst_A() {
    v3_22_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_20_Rst_B() {
    v3_22_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_20_WEN_A() {
    v3_22_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_909_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_908_Addr_A.read();
    } else {
        v3_22_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_21_Addr_A_orig() {
    v3_22_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_21_Addr_B() {
    v3_22_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_21_Addr_B_orig() {
    v3_22_21_Addr_B_orig =  (sc_lv<32>) (v3_22_21_addr_reg_62542.read());
}

void kernel_correlation_sdse::thread_v3_22_21_Clk_A() {
    v3_22_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_21_Clk_B() {
    v3_22_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_21_Din_A() {
    v3_22_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_21_Din_B() {
    v3_22_21_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_909_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_908_EN_A.read();
    } else {
        v3_22_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_21_EN_B = ap_const_logic_1;
    } else {
        v3_22_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_21_Rst_A() {
    v3_22_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_21_Rst_B() {
    v3_22_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_21_WEN_A() {
    v3_22_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_910_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_909_Addr_A.read();
    } else {
        v3_22_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_22_Addr_A_orig() {
    v3_22_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_22_Addr_B() {
    v3_22_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_22_Addr_B_orig() {
    v3_22_22_Addr_B_orig =  (sc_lv<32>) (v3_22_22_addr_reg_64202.read());
}

void kernel_correlation_sdse::thread_v3_22_22_Clk_A() {
    v3_22_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_22_Clk_B() {
    v3_22_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_22_Din_A() {
    v3_22_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_22_Din_B() {
    v3_22_22_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_910_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_909_EN_A.read();
    } else {
        v3_22_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_22_EN_B = ap_const_logic_1;
    } else {
        v3_22_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_22_Rst_A() {
    v3_22_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_22_Rst_B() {
    v3_22_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_22_WEN_A() {
    v3_22_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_911_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_910_Addr_A.read();
    } else {
        v3_22_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_23_Addr_A_orig() {
    v3_22_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_23_Addr_B() {
    v3_22_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_23_Addr_B_orig() {
    v3_22_23_Addr_B_orig =  (sc_lv<32>) (v3_22_23_addr_reg_65862.read());
}

void kernel_correlation_sdse::thread_v3_22_23_Clk_A() {
    v3_22_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_23_Clk_B() {
    v3_22_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_23_Din_A() {
    v3_22_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_23_Din_B() {
    v3_22_23_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_911_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_910_EN_A.read();
    } else {
        v3_22_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_23_EN_B = ap_const_logic_1;
    } else {
        v3_22_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_23_Rst_A() {
    v3_22_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_23_Rst_B() {
    v3_22_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_23_WEN_A() {
    v3_22_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_912_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_911_Addr_A.read();
    } else {
        v3_22_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_24_Addr_A_orig() {
    v3_22_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_24_Addr_B() {
    v3_22_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_24_Addr_B_orig() {
    v3_22_24_Addr_B_orig =  (sc_lv<32>) (v3_22_24_addr_reg_60888.read());
}

void kernel_correlation_sdse::thread_v3_22_24_Clk_A() {
    v3_22_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_24_Clk_B() {
    v3_22_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_24_Din_A() {
    v3_22_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_24_Din_B() {
    v3_22_24_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_912_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_911_EN_A.read();
    } else {
        v3_22_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_24_EN_B = ap_const_logic_1;
    } else {
        v3_22_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_24_Rst_A() {
    v3_22_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_24_Rst_B() {
    v3_22_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_24_WEN_A() {
    v3_22_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_913_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_912_Addr_A.read();
    } else {
        v3_22_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_25_Addr_A_orig() {
    v3_22_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_25_Addr_B() {
    v3_22_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_25_Addr_B_orig() {
    v3_22_25_Addr_B_orig =  (sc_lv<32>) (v3_22_25_addr_reg_62548.read());
}

void kernel_correlation_sdse::thread_v3_22_25_Clk_A() {
    v3_22_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_25_Clk_B() {
    v3_22_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_25_Din_A() {
    v3_22_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_25_Din_B() {
    v3_22_25_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_913_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_912_EN_A.read();
    } else {
        v3_22_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_25_EN_B = ap_const_logic_1;
    } else {
        v3_22_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_25_Rst_A() {
    v3_22_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_25_Rst_B() {
    v3_22_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_25_WEN_A() {
    v3_22_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_914_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_913_Addr_A.read();
    } else {
        v3_22_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_26_Addr_A_orig() {
    v3_22_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_26_Addr_B() {
    v3_22_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_26_Addr_B_orig() {
    v3_22_26_Addr_B_orig =  (sc_lv<32>) (v3_22_26_addr_reg_64208.read());
}

void kernel_correlation_sdse::thread_v3_22_26_Clk_A() {
    v3_22_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_26_Clk_B() {
    v3_22_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_26_Din_A() {
    v3_22_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_26_Din_B() {
    v3_22_26_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_914_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_913_EN_A.read();
    } else {
        v3_22_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_26_EN_B = ap_const_logic_1;
    } else {
        v3_22_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_26_Rst_A() {
    v3_22_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_26_Rst_B() {
    v3_22_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_26_WEN_A() {
    v3_22_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_915_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_914_Addr_A.read();
    } else {
        v3_22_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_27_Addr_A_orig() {
    v3_22_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_27_Addr_B() {
    v3_22_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_27_Addr_B_orig() {
    v3_22_27_Addr_B_orig =  (sc_lv<32>) (v3_22_27_addr_reg_65868.read());
}

void kernel_correlation_sdse::thread_v3_22_27_Clk_A() {
    v3_22_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_27_Clk_B() {
    v3_22_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_27_Din_A() {
    v3_22_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_27_Din_B() {
    v3_22_27_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_915_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_914_EN_A.read();
    } else {
        v3_22_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_27_EN_B = ap_const_logic_1;
    } else {
        v3_22_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_27_Rst_A() {
    v3_22_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_27_Rst_B() {
    v3_22_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_27_WEN_A() {
    v3_22_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_916_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_915_Addr_A.read();
    } else {
        v3_22_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_28_Addr_A_orig() {
    v3_22_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_28_Addr_B() {
    v3_22_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_28_Addr_B_orig() {
    v3_22_28_Addr_B_orig =  (sc_lv<32>) (v3_22_28_addr_reg_60894.read());
}

void kernel_correlation_sdse::thread_v3_22_28_Clk_A() {
    v3_22_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_28_Clk_B() {
    v3_22_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_28_Din_A() {
    v3_22_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_28_Din_B() {
    v3_22_28_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_916_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_915_EN_A.read();
    } else {
        v3_22_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_28_EN_B = ap_const_logic_1;
    } else {
        v3_22_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_28_Rst_A() {
    v3_22_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_28_Rst_B() {
    v3_22_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_28_WEN_A() {
    v3_22_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_917_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_916_Addr_A.read();
    } else {
        v3_22_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_29_Addr_A_orig() {
    v3_22_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_29_Addr_B() {
    v3_22_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_29_Addr_B_orig() {
    v3_22_29_Addr_B_orig =  (sc_lv<32>) (v3_22_29_addr_reg_62554.read());
}

void kernel_correlation_sdse::thread_v3_22_29_Clk_A() {
    v3_22_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_29_Clk_B() {
    v3_22_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_29_Din_A() {
    v3_22_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_29_Din_B() {
    v3_22_29_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_917_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_916_EN_A.read();
    } else {
        v3_22_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_29_EN_B = ap_const_logic_1;
    } else {
        v3_22_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_29_Rst_A() {
    v3_22_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_29_Rst_B() {
    v3_22_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_29_WEN_A() {
    v3_22_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_890_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_889_Addr_A.read();
    } else {
        v3_22_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_2_Addr_A_orig() {
    v3_22_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_2_Addr_B() {
    v3_22_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_2_Addr_B_orig() {
    v3_22_2_Addr_B_orig =  (sc_lv<32>) (v3_22_2_addr_reg_64172.read());
}

void kernel_correlation_sdse::thread_v3_22_2_Clk_A() {
    v3_22_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_2_Clk_B() {
    v3_22_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_2_Din_A() {
    v3_22_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_2_Din_B() {
    v3_22_2_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_890_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_889_EN_A.read();
    } else {
        v3_22_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_2_EN_B = ap_const_logic_1;
    } else {
        v3_22_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_2_Rst_A() {
    v3_22_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_2_Rst_B() {
    v3_22_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_2_WEN_A() {
    v3_22_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_918_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_917_Addr_A.read();
    } else {
        v3_22_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_30_Addr_A_orig() {
    v3_22_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_30_Addr_B() {
    v3_22_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_30_Addr_B_orig() {
    v3_22_30_Addr_B_orig =  (sc_lv<32>) (v3_22_30_addr_reg_64214.read());
}

void kernel_correlation_sdse::thread_v3_22_30_Clk_A() {
    v3_22_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_30_Clk_B() {
    v3_22_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_30_Din_A() {
    v3_22_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_30_Din_B() {
    v3_22_30_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_918_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_917_EN_A.read();
    } else {
        v3_22_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_30_EN_B = ap_const_logic_1;
    } else {
        v3_22_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_30_Rst_A() {
    v3_22_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_30_Rst_B() {
    v3_22_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_30_WEN_A() {
    v3_22_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_919_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_918_Addr_A.read();
    } else {
        v3_22_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_31_Addr_A_orig() {
    v3_22_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_31_Addr_B() {
    v3_22_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_31_Addr_B_orig() {
    v3_22_31_Addr_B_orig =  (sc_lv<32>) (v3_22_31_addr_reg_65874.read());
}

void kernel_correlation_sdse::thread_v3_22_31_Clk_A() {
    v3_22_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_31_Clk_B() {
    v3_22_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_31_Din_A() {
    v3_22_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_31_Din_B() {
    v3_22_31_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_919_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_918_EN_A.read();
    } else {
        v3_22_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_31_EN_B = ap_const_logic_1;
    } else {
        v3_22_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_31_Rst_A() {
    v3_22_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_31_Rst_B() {
    v3_22_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_31_WEN_A() {
    v3_22_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_31_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_32_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_920_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_919_Addr_A.read();
    } else {
        v3_22_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_32_Addr_A_orig() {
    v3_22_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_32_Addr_B() {
    v3_22_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_32_Addr_B_orig() {
    v3_22_32_Addr_B_orig =  (sc_lv<32>) (v3_22_32_addr_reg_60900.read());
}

void kernel_correlation_sdse::thread_v3_22_32_Clk_A() {
    v3_22_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_32_Clk_B() {
    v3_22_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_32_Din_A() {
    v3_22_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_32_Din_B() {
    v3_22_32_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_32_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_920_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_919_EN_A.read();
    } else {
        v3_22_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_32_EN_B = ap_const_logic_1;
    } else {
        v3_22_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_32_Rst_A() {
    v3_22_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_32_Rst_B() {
    v3_22_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_32_WEN_A() {
    v3_22_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_32_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_33_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_921_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_920_Addr_A.read();
    } else {
        v3_22_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_33_Addr_A_orig() {
    v3_22_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_33_Addr_B() {
    v3_22_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_33_Addr_B_orig() {
    v3_22_33_Addr_B_orig =  (sc_lv<32>) (v3_22_33_addr_reg_62560.read());
}

void kernel_correlation_sdse::thread_v3_22_33_Clk_A() {
    v3_22_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_33_Clk_B() {
    v3_22_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_33_Din_A() {
    v3_22_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_33_Din_B() {
    v3_22_33_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_33_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_921_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_920_EN_A.read();
    } else {
        v3_22_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_33_EN_B = ap_const_logic_1;
    } else {
        v3_22_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_33_Rst_A() {
    v3_22_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_33_Rst_B() {
    v3_22_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_33_WEN_A() {
    v3_22_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_33_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_34_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_922_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_921_Addr_A.read();
    } else {
        v3_22_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_34_Addr_A_orig() {
    v3_22_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_34_Addr_B() {
    v3_22_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_34_Addr_B_orig() {
    v3_22_34_Addr_B_orig =  (sc_lv<32>) (v3_22_34_addr_reg_64220.read());
}

void kernel_correlation_sdse::thread_v3_22_34_Clk_A() {
    v3_22_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_34_Clk_B() {
    v3_22_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_34_Din_A() {
    v3_22_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_34_Din_B() {
    v3_22_34_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_34_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_922_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_921_EN_A.read();
    } else {
        v3_22_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_34_EN_B = ap_const_logic_1;
    } else {
        v3_22_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_34_Rst_A() {
    v3_22_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_34_Rst_B() {
    v3_22_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_34_WEN_A() {
    v3_22_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_34_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_35_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_923_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_922_Addr_A.read();
    } else {
        v3_22_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_35_Addr_A_orig() {
    v3_22_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_35_Addr_B() {
    v3_22_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_35_Addr_B_orig() {
    v3_22_35_Addr_B_orig =  (sc_lv<32>) (v3_22_35_addr_reg_65880.read());
}

void kernel_correlation_sdse::thread_v3_22_35_Clk_A() {
    v3_22_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_35_Clk_B() {
    v3_22_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_35_Din_A() {
    v3_22_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_35_Din_B() {
    v3_22_35_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_35_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_923_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_922_EN_A.read();
    } else {
        v3_22_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_35_EN_B = ap_const_logic_1;
    } else {
        v3_22_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_35_Rst_A() {
    v3_22_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_35_Rst_B() {
    v3_22_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_35_WEN_A() {
    v3_22_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_35_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_36_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_924_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_923_Addr_A.read();
    } else {
        v3_22_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_36_Addr_A_orig() {
    v3_22_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_36_Addr_B() {
    v3_22_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_36_Addr_B_orig() {
    v3_22_36_Addr_B_orig =  (sc_lv<32>) (v3_22_36_addr_reg_60906.read());
}

void kernel_correlation_sdse::thread_v3_22_36_Clk_A() {
    v3_22_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_36_Clk_B() {
    v3_22_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_36_Din_A() {
    v3_22_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_36_Din_B() {
    v3_22_36_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_36_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_924_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_923_EN_A.read();
    } else {
        v3_22_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_36_EN_B = ap_const_logic_1;
    } else {
        v3_22_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_36_Rst_A() {
    v3_22_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_36_Rst_B() {
    v3_22_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_36_WEN_A() {
    v3_22_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_36_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_37_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_925_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_924_Addr_A.read();
    } else {
        v3_22_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_37_Addr_A_orig() {
    v3_22_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_37_Addr_B() {
    v3_22_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_37_Addr_B_orig() {
    v3_22_37_Addr_B_orig =  (sc_lv<32>) (v3_22_37_addr_reg_62566.read());
}

void kernel_correlation_sdse::thread_v3_22_37_Clk_A() {
    v3_22_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_37_Clk_B() {
    v3_22_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_37_Din_A() {
    v3_22_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_37_Din_B() {
    v3_22_37_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_925_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_924_EN_A.read();
    } else {
        v3_22_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_37_EN_B = ap_const_logic_1;
    } else {
        v3_22_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_37_Rst_A() {
    v3_22_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_37_Rst_B() {
    v3_22_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_37_WEN_A() {
    v3_22_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_926_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_925_Addr_A.read();
    } else {
        v3_22_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_38_Addr_A_orig() {
    v3_22_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_38_Addr_B() {
    v3_22_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_38_Addr_B_orig() {
    v3_22_38_Addr_B_orig =  (sc_lv<32>) (v3_22_38_addr_reg_64226.read());
}

void kernel_correlation_sdse::thread_v3_22_38_Clk_A() {
    v3_22_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_38_Clk_B() {
    v3_22_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_38_Din_A() {
    v3_22_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_38_Din_B() {
    v3_22_38_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_926_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_925_EN_A.read();
    } else {
        v3_22_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_38_EN_B = ap_const_logic_1;
    } else {
        v3_22_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_38_Rst_A() {
    v3_22_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_38_Rst_B() {
    v3_22_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_38_WEN_A() {
    v3_22_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_927_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_926_Addr_A.read();
    } else {
        v3_22_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_39_Addr_A_orig() {
    v3_22_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_39_Addr_B() {
    v3_22_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_39_Addr_B_orig() {
    v3_22_39_Addr_B_orig =  (sc_lv<32>) (v3_22_39_addr_reg_65886.read());
}

void kernel_correlation_sdse::thread_v3_22_39_Clk_A() {
    v3_22_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_39_Clk_B() {
    v3_22_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_39_Din_A() {
    v3_22_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_39_Din_B() {
    v3_22_39_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_927_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_926_EN_A.read();
    } else {
        v3_22_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_39_EN_B = ap_const_logic_1;
    } else {
        v3_22_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_39_Rst_A() {
    v3_22_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_39_Rst_B() {
    v3_22_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_39_WEN_A() {
    v3_22_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_891_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_890_Addr_A.read();
    } else {
        v3_22_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_3_Addr_A_orig() {
    v3_22_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_3_Addr_B() {
    v3_22_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_3_Addr_B_orig() {
    v3_22_3_Addr_B_orig =  (sc_lv<32>) (v3_22_3_addr_reg_65832.read());
}

void kernel_correlation_sdse::thread_v3_22_3_Clk_A() {
    v3_22_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_3_Clk_B() {
    v3_22_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_3_Din_A() {
    v3_22_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_3_Din_B() {
    v3_22_3_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_891_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_890_EN_A.read();
    } else {
        v3_22_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_3_EN_B = ap_const_logic_1;
    } else {
        v3_22_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_3_Rst_A() {
    v3_22_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_3_Rst_B() {
    v3_22_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_3_WEN_A() {
    v3_22_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_892_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_891_Addr_A.read();
    } else {
        v3_22_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_4_Addr_A_orig() {
    v3_22_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_4_Addr_B() {
    v3_22_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_4_Addr_B_orig() {
    v3_22_4_Addr_B_orig =  (sc_lv<32>) (v3_22_4_addr_reg_60858.read());
}

void kernel_correlation_sdse::thread_v3_22_4_Clk_A() {
    v3_22_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_4_Clk_B() {
    v3_22_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_4_Din_A() {
    v3_22_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_4_Din_B() {
    v3_22_4_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_892_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_891_EN_A.read();
    } else {
        v3_22_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_4_EN_B = ap_const_logic_1;
    } else {
        v3_22_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_4_Rst_A() {
    v3_22_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_4_Rst_B() {
    v3_22_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_4_WEN_A() {
    v3_22_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_893_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_892_Addr_A.read();
    } else {
        v3_22_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_5_Addr_A_orig() {
    v3_22_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_5_Addr_B() {
    v3_22_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_5_Addr_B_orig() {
    v3_22_5_Addr_B_orig =  (sc_lv<32>) (v3_22_5_addr_reg_62518.read());
}

void kernel_correlation_sdse::thread_v3_22_5_Clk_A() {
    v3_22_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_5_Clk_B() {
    v3_22_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_5_Din_A() {
    v3_22_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_5_Din_B() {
    v3_22_5_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_893_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_892_EN_A.read();
    } else {
        v3_22_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_5_EN_B = ap_const_logic_1;
    } else {
        v3_22_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_5_Rst_A() {
    v3_22_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_5_Rst_B() {
    v3_22_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_5_WEN_A() {
    v3_22_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_894_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_893_Addr_A.read();
    } else {
        v3_22_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_6_Addr_A_orig() {
    v3_22_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_6_Addr_B() {
    v3_22_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_6_Addr_B_orig() {
    v3_22_6_Addr_B_orig =  (sc_lv<32>) (v3_22_6_addr_reg_64178.read());
}

void kernel_correlation_sdse::thread_v3_22_6_Clk_A() {
    v3_22_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_6_Clk_B() {
    v3_22_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_6_Din_A() {
    v3_22_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_6_Din_B() {
    v3_22_6_Din_B = grp_fu_42878_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_894_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_893_EN_A.read();
    } else {
        v3_22_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_6_EN_B = ap_const_logic_1;
    } else {
        v3_22_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_6_Rst_A() {
    v3_22_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_6_Rst_B() {
    v3_22_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_6_WEN_A() {
    v3_22_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_6_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_895_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_894_Addr_A.read();
    } else {
        v3_22_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_7_Addr_A_orig() {
    v3_22_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_7_Addr_B() {
    v3_22_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_7_Addr_B_orig() {
    v3_22_7_Addr_B_orig =  (sc_lv<32>) (v3_22_7_addr_reg_65838.read());
}

void kernel_correlation_sdse::thread_v3_22_7_Clk_A() {
    v3_22_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_7_Clk_B() {
    v3_22_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_7_Din_A() {
    v3_22_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_7_Din_B() {
    v3_22_7_Din_B = grp_fu_42894_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_895_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_894_EN_A.read();
    } else {
        v3_22_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_7_EN_B = ap_const_logic_1;
    } else {
        v3_22_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_7_Rst_A() {
    v3_22_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_7_Rst_B() {
    v3_22_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_7_WEN_A() {
    v3_22_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_7_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_896_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_895_Addr_A.read();
    } else {
        v3_22_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_8_Addr_A_orig() {
    v3_22_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_8_Addr_B() {
    v3_22_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_8_Addr_B_orig() {
    v3_22_8_Addr_B_orig =  (sc_lv<32>) (v3_22_8_addr_reg_60864.read());
}

void kernel_correlation_sdse::thread_v3_22_8_Clk_A() {
    v3_22_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_8_Clk_B() {
    v3_22_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_8_Din_A() {
    v3_22_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_8_Din_B() {
    v3_22_8_Din_B = grp_fu_42848_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_896_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_895_EN_A.read();
    } else {
        v3_22_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_8_EN_B = ap_const_logic_1;
    } else {
        v3_22_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_8_Rst_A() {
    v3_22_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_8_Rst_B() {
    v3_22_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_8_WEN_A() {
    v3_22_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_8_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_897_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_896_Addr_A.read();
    } else {
        v3_22_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_22_9_Addr_A_orig() {
    v3_22_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_22_9_Addr_B() {
    v3_22_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_22_9_Addr_B_orig() {
    v3_22_9_Addr_B_orig =  (sc_lv<32>) (v3_22_9_addr_reg_62524.read());
}

void kernel_correlation_sdse::thread_v3_22_9_Clk_A() {
    v3_22_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_9_Clk_B() {
    v3_22_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_22_9_Din_A() {
    v3_22_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_22_9_Din_B() {
    v3_22_9_Din_B = grp_fu_42863_p2.read();
}

void kernel_correlation_sdse::thread_v3_22_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_22_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_22_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_897_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_22_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_896_EN_A.read();
    } else {
        v3_22_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_9_EN_B = ap_const_logic_1;
    } else {
        v3_22_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_22_9_Rst_A() {
    v3_22_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_9_Rst_B() {
    v3_22_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_22_9_WEN_A() {
    v3_22_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_22_9_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_22_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_967_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_928_Addr_A.read();
    } else {
        v3_23_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_0_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_0_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_0_Addr_B() {
    v3_23_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_0_Addr_B_orig() {
    v3_23_0_Addr_B_orig =  (sc_lv<32>) (v3_23_0_addr_2_reg_60912.read());
}

void kernel_correlation_sdse::thread_v3_23_0_Clk_A() {
    v3_23_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_0_Clk_B() {
    v3_23_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_0_Din_A() {
    v3_23_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_0_Din_B() {
    v3_23_0_Din_B = grp_fu_42910_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_967_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_928_EN_A.read();
    } else {
        v3_23_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_0_EN_B = ap_const_logic_1;
    } else {
        v3_23_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_0_Rst_A() {
    v3_23_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_0_Rst_B() {
    v3_23_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_0_WEN_A() {
    v3_23_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_938_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_937_Addr_A.read();
    } else {
        v3_23_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_10_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_10_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_10_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_10_Addr_B() {
    v3_23_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_10_Addr_B_orig() {
    v3_23_10_Addr_B_orig =  (sc_lv<32>) (v3_23_10_addr_2_reg_64244.read());
}

void kernel_correlation_sdse::thread_v3_23_10_Clk_A() {
    v3_23_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_10_Clk_B() {
    v3_23_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_10_Din_A() {
    v3_23_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_10_Din_B() {
    v3_23_10_Din_B = grp_fu_42940_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_10_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_938_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_937_EN_A.read();
    } else {
        v3_23_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_10_EN_B = ap_const_logic_1;
    } else {
        v3_23_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_10_Rst_A() {
    v3_23_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_10_Rst_B() {
    v3_23_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_10_WEN_A() {
    v3_23_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_939_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_938_Addr_A.read();
    } else {
        v3_23_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_11_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_11_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_11_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_11_Addr_B() {
    v3_23_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_11_Addr_B_orig() {
    v3_23_11_Addr_B_orig =  (sc_lv<32>) (v3_23_11_addr_2_reg_65904.read());
}

void kernel_correlation_sdse::thread_v3_23_11_Clk_A() {
    v3_23_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_11_Clk_B() {
    v3_23_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_11_Din_A() {
    v3_23_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_11_Din_B() {
    v3_23_11_Din_B = grp_fu_42956_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_11_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_939_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_938_EN_A.read();
    } else {
        v3_23_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_11_EN_B = ap_const_logic_1;
    } else {
        v3_23_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_11_Rst_A() {
    v3_23_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_11_Rst_B() {
    v3_23_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_11_WEN_A() {
    v3_23_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_940_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_939_Addr_A.read();
    } else {
        v3_23_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_12_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_12_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_12_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_12_Addr_B() {
    v3_23_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_12_Addr_B_orig() {
    v3_23_12_Addr_B_orig =  (sc_lv<32>) (v3_23_12_addr_2_reg_60930.read());
}

void kernel_correlation_sdse::thread_v3_23_12_Clk_A() {
    v3_23_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_12_Clk_B() {
    v3_23_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_12_Din_A() {
    v3_23_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_12_Din_B() {
    v3_23_12_Din_B = grp_fu_42910_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_12_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_940_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_939_EN_A.read();
    } else {
        v3_23_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_12_EN_B = ap_const_logic_1;
    } else {
        v3_23_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_12_Rst_A() {
    v3_23_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_12_Rst_B() {
    v3_23_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_12_WEN_A() {
    v3_23_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_941_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_940_Addr_A.read();
    } else {
        v3_23_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_13_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_13_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_13_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_13_Addr_B() {
    v3_23_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_13_Addr_B_orig() {
    v3_23_13_Addr_B_orig =  (sc_lv<32>) (v3_23_13_addr_2_reg_62590.read());
}

void kernel_correlation_sdse::thread_v3_23_13_Clk_A() {
    v3_23_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_13_Clk_B() {
    v3_23_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_13_Din_A() {
    v3_23_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_13_Din_B() {
    v3_23_13_Din_B = grp_fu_42925_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_13_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_941_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_940_EN_A.read();
    } else {
        v3_23_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_13_EN_B = ap_const_logic_1;
    } else {
        v3_23_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_13_Rst_A() {
    v3_23_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_13_Rst_B() {
    v3_23_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_13_WEN_A() {
    v3_23_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_942_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_941_Addr_A.read();
    } else {
        v3_23_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_14_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_14_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_14_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_14_Addr_B() {
    v3_23_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_14_Addr_B_orig() {
    v3_23_14_Addr_B_orig =  (sc_lv<32>) (v3_23_14_addr_2_reg_64250.read());
}

void kernel_correlation_sdse::thread_v3_23_14_Clk_A() {
    v3_23_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_14_Clk_B() {
    v3_23_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_14_Din_A() {
    v3_23_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_14_Din_B() {
    v3_23_14_Din_B = grp_fu_42940_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_14_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_942_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_941_EN_A.read();
    } else {
        v3_23_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_14_EN_B = ap_const_logic_1;
    } else {
        v3_23_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_14_Rst_A() {
    v3_23_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_14_Rst_B() {
    v3_23_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_14_WEN_A() {
    v3_23_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_943_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_942_Addr_A.read();
    } else {
        v3_23_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_15_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_15_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_15_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_15_Addr_B() {
    v3_23_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_15_Addr_B_orig() {
    v3_23_15_Addr_B_orig =  (sc_lv<32>) (v3_23_15_addr_2_reg_65910.read());
}

void kernel_correlation_sdse::thread_v3_23_15_Clk_A() {
    v3_23_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_15_Clk_B() {
    v3_23_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_15_Din_A() {
    v3_23_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_15_Din_B() {
    v3_23_15_Din_B = grp_fu_42956_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_15_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_943_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_942_EN_A.read();
    } else {
        v3_23_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_15_EN_B = ap_const_logic_1;
    } else {
        v3_23_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_15_Rst_A() {
    v3_23_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_15_Rst_B() {
    v3_23_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_15_WEN_A() {
    v3_23_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_944_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_943_Addr_A.read();
    } else {
        v3_23_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_16_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_16_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_16_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_16_Addr_B() {
    v3_23_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_16_Addr_B_orig() {
    v3_23_16_Addr_B_orig =  (sc_lv<32>) (v3_23_16_addr_2_reg_60936.read());
}

void kernel_correlation_sdse::thread_v3_23_16_Clk_A() {
    v3_23_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_16_Clk_B() {
    v3_23_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_16_Din_A() {
    v3_23_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_16_Din_B() {
    v3_23_16_Din_B = grp_fu_42910_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_16_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_944_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_943_EN_A.read();
    } else {
        v3_23_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_16_EN_B = ap_const_logic_1;
    } else {
        v3_23_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_16_Rst_A() {
    v3_23_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_16_Rst_B() {
    v3_23_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_16_WEN_A() {
    v3_23_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_945_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_944_Addr_A.read();
    } else {
        v3_23_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_17_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_17_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_17_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_17_Addr_B() {
    v3_23_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_17_Addr_B_orig() {
    v3_23_17_Addr_B_orig =  (sc_lv<32>) (v3_23_17_addr_2_reg_62596.read());
}

void kernel_correlation_sdse::thread_v3_23_17_Clk_A() {
    v3_23_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_17_Clk_B() {
    v3_23_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_17_Din_A() {
    v3_23_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_17_Din_B() {
    v3_23_17_Din_B = grp_fu_42925_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_17_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_945_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_944_EN_A.read();
    } else {
        v3_23_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_17_EN_B = ap_const_logic_1;
    } else {
        v3_23_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_17_Rst_A() {
    v3_23_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_17_Rst_B() {
    v3_23_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_17_WEN_A() {
    v3_23_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_946_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_945_Addr_A.read();
    } else {
        v3_23_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_18_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_18_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_18_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_18_Addr_B() {
    v3_23_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_18_Addr_B_orig() {
    v3_23_18_Addr_B_orig =  (sc_lv<32>) (v3_23_18_addr_2_reg_64256.read());
}

void kernel_correlation_sdse::thread_v3_23_18_Clk_A() {
    v3_23_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_18_Clk_B() {
    v3_23_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_18_Din_A() {
    v3_23_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_18_Din_B() {
    v3_23_18_Din_B = grp_fu_42940_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_18_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_946_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_945_EN_A.read();
    } else {
        v3_23_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_18_EN_B = ap_const_logic_1;
    } else {
        v3_23_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_18_Rst_A() {
    v3_23_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_18_Rst_B() {
    v3_23_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_18_WEN_A() {
    v3_23_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_947_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_946_Addr_A.read();
    } else {
        v3_23_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_19_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_19_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_19_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_19_Addr_B() {
    v3_23_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_19_Addr_B_orig() {
    v3_23_19_Addr_B_orig =  (sc_lv<32>) (v3_23_19_addr_2_reg_65916.read());
}

void kernel_correlation_sdse::thread_v3_23_19_Clk_A() {
    v3_23_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_19_Clk_B() {
    v3_23_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_19_Din_A() {
    v3_23_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_19_Din_B() {
    v3_23_19_Din_B = grp_fu_42956_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_19_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_947_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_946_EN_A.read();
    } else {
        v3_23_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_19_EN_B = ap_const_logic_1;
    } else {
        v3_23_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_19_Rst_A() {
    v3_23_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_19_Rst_B() {
    v3_23_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_19_WEN_A() {
    v3_23_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_929_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_928_Addr_A.read();
    } else {
        v3_23_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_1_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_1_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_1_Addr_B() {
    v3_23_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_1_Addr_B_orig() {
    v3_23_1_Addr_B_orig =  (sc_lv<32>) (v3_23_1_addr_2_reg_62572.read());
}

void kernel_correlation_sdse::thread_v3_23_1_Clk_A() {
    v3_23_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_1_Clk_B() {
    v3_23_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_1_Din_A() {
    v3_23_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_1_Din_B() {
    v3_23_1_Din_B = grp_fu_42925_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_929_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_928_EN_A.read();
    } else {
        v3_23_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_1_EN_B = ap_const_logic_1;
    } else {
        v3_23_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_1_Rst_A() {
    v3_23_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_1_Rst_B() {
    v3_23_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_1_WEN_A() {
    v3_23_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_948_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_947_Addr_A.read();
    } else {
        v3_23_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_20_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_20_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_20_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_20_Addr_B() {
    v3_23_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_20_Addr_B_orig() {
    v3_23_20_Addr_B_orig =  (sc_lv<32>) (v3_23_20_addr_2_reg_60942.read());
}

void kernel_correlation_sdse::thread_v3_23_20_Clk_A() {
    v3_23_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_20_Clk_B() {
    v3_23_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_20_Din_A() {
    v3_23_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_20_Din_B() {
    v3_23_20_Din_B = grp_fu_42910_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_20_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_948_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_947_EN_A.read();
    } else {
        v3_23_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_20_EN_B = ap_const_logic_1;
    } else {
        v3_23_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_20_Rst_A() {
    v3_23_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_20_Rst_B() {
    v3_23_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_20_WEN_A() {
    v3_23_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_949_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_948_Addr_A.read();
    } else {
        v3_23_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_21_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_21_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_21_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_21_Addr_B() {
    v3_23_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_21_Addr_B_orig() {
    v3_23_21_Addr_B_orig =  (sc_lv<32>) (v3_23_21_addr_2_reg_62602.read());
}

void kernel_correlation_sdse::thread_v3_23_21_Clk_A() {
    v3_23_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_21_Clk_B() {
    v3_23_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_21_Din_A() {
    v3_23_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_21_Din_B() {
    v3_23_21_Din_B = grp_fu_42925_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_21_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_949_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_948_EN_A.read();
    } else {
        v3_23_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_21_EN_B = ap_const_logic_1;
    } else {
        v3_23_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_21_Rst_A() {
    v3_23_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_21_Rst_B() {
    v3_23_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_21_WEN_A() {
    v3_23_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_950_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_949_Addr_A.read();
    } else {
        v3_23_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_22_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_22_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_22_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_22_Addr_B() {
    v3_23_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_22_Addr_B_orig() {
    v3_23_22_Addr_B_orig =  (sc_lv<32>) (v3_23_22_addr_2_reg_64262.read());
}

void kernel_correlation_sdse::thread_v3_23_22_Clk_A() {
    v3_23_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_22_Clk_B() {
    v3_23_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_22_Din_A() {
    v3_23_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_22_Din_B() {
    v3_23_22_Din_B = grp_fu_42940_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_22_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_950_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_949_EN_A.read();
    } else {
        v3_23_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_22_EN_B = ap_const_logic_1;
    } else {
        v3_23_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_22_Rst_A() {
    v3_23_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_22_Rst_B() {
    v3_23_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_22_WEN_A() {
    v3_23_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_951_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_950_Addr_A.read();
    } else {
        v3_23_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_23_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_23_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_23_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_23_Addr_B() {
    v3_23_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_23_Addr_B_orig() {
    v3_23_23_Addr_B_orig =  (sc_lv<32>) (v3_23_23_addr_2_reg_65922.read());
}

void kernel_correlation_sdse::thread_v3_23_23_Clk_A() {
    v3_23_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_23_Clk_B() {
    v3_23_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_23_Din_A() {
    v3_23_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_23_Din_B() {
    v3_23_23_Din_B = grp_fu_42956_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_23_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_951_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_950_EN_A.read();
    } else {
        v3_23_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_23_EN_B = ap_const_logic_1;
    } else {
        v3_23_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_23_Rst_A() {
    v3_23_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_23_Rst_B() {
    v3_23_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_23_WEN_A() {
    v3_23_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_952_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_951_Addr_A.read();
    } else {
        v3_23_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_24_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_24_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_24_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_24_Addr_B() {
    v3_23_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_24_Addr_B_orig() {
    v3_23_24_Addr_B_orig =  (sc_lv<32>) (v3_23_24_addr_2_reg_60948.read());
}

void kernel_correlation_sdse::thread_v3_23_24_Clk_A() {
    v3_23_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_24_Clk_B() {
    v3_23_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_24_Din_A() {
    v3_23_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_24_Din_B() {
    v3_23_24_Din_B = grp_fu_42910_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_24_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_952_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_951_EN_A.read();
    } else {
        v3_23_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_24_EN_B = ap_const_logic_1;
    } else {
        v3_23_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_24_Rst_A() {
    v3_23_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_24_Rst_B() {
    v3_23_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_24_WEN_A() {
    v3_23_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_953_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_952_Addr_A.read();
    } else {
        v3_23_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_25_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_25_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_25_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_25_Addr_B() {
    v3_23_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_25_Addr_B_orig() {
    v3_23_25_Addr_B_orig =  (sc_lv<32>) (v3_23_25_addr_2_reg_62608.read());
}

void kernel_correlation_sdse::thread_v3_23_25_Clk_A() {
    v3_23_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_25_Clk_B() {
    v3_23_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_25_Din_A() {
    v3_23_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_25_Din_B() {
    v3_23_25_Din_B = grp_fu_42925_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_25_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_953_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_952_EN_A.read();
    } else {
        v3_23_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_25_EN_B = ap_const_logic_1;
    } else {
        v3_23_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_25_Rst_A() {
    v3_23_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_25_Rst_B() {
    v3_23_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_25_WEN_A() {
    v3_23_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_954_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_953_Addr_A.read();
    } else {
        v3_23_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_26_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_26_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_26_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_26_Addr_B() {
    v3_23_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_26_Addr_B_orig() {
    v3_23_26_Addr_B_orig =  (sc_lv<32>) (v3_23_26_addr_2_reg_64268.read());
}

void kernel_correlation_sdse::thread_v3_23_26_Clk_A() {
    v3_23_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_26_Clk_B() {
    v3_23_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_26_Din_A() {
    v3_23_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_26_Din_B() {
    v3_23_26_Din_B = grp_fu_42940_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_26_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_954_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_953_EN_A.read();
    } else {
        v3_23_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_26_EN_B = ap_const_logic_1;
    } else {
        v3_23_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_26_Rst_A() {
    v3_23_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_26_Rst_B() {
    v3_23_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_26_WEN_A() {
    v3_23_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_955_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_954_Addr_A.read();
    } else {
        v3_23_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_27_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_27_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_27_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_27_Addr_B() {
    v3_23_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_27_Addr_B_orig() {
    v3_23_27_Addr_B_orig =  (sc_lv<32>) (v3_23_27_addr_2_reg_65928.read());
}

void kernel_correlation_sdse::thread_v3_23_27_Clk_A() {
    v3_23_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_27_Clk_B() {
    v3_23_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_27_Din_A() {
    v3_23_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_27_Din_B() {
    v3_23_27_Din_B = grp_fu_42956_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_27_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_955_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_954_EN_A.read();
    } else {
        v3_23_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_27_EN_B = ap_const_logic_1;
    } else {
        v3_23_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_27_Rst_A() {
    v3_23_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_27_Rst_B() {
    v3_23_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_27_WEN_A() {
    v3_23_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_956_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_955_Addr_A.read();
    } else {
        v3_23_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_28_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_28_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_28_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_28_Addr_B() {
    v3_23_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_28_Addr_B_orig() {
    v3_23_28_Addr_B_orig =  (sc_lv<32>) (v3_23_28_addr_2_reg_60954.read());
}

void kernel_correlation_sdse::thread_v3_23_28_Clk_A() {
    v3_23_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_28_Clk_B() {
    v3_23_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_28_Din_A() {
    v3_23_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_28_Din_B() {
    v3_23_28_Din_B = grp_fu_42910_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_28_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_956_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_955_EN_A.read();
    } else {
        v3_23_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_28_EN_B = ap_const_logic_1;
    } else {
        v3_23_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_28_Rst_A() {
    v3_23_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_28_Rst_B() {
    v3_23_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_28_WEN_A() {
    v3_23_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_957_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_956_Addr_A.read();
    } else {
        v3_23_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_29_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_29_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_29_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_29_Addr_B() {
    v3_23_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_29_Addr_B_orig() {
    v3_23_29_Addr_B_orig =  (sc_lv<32>) (v3_23_29_addr_2_reg_62614.read());
}

void kernel_correlation_sdse::thread_v3_23_29_Clk_A() {
    v3_23_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_29_Clk_B() {
    v3_23_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_29_Din_A() {
    v3_23_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_29_Din_B() {
    v3_23_29_Din_B = grp_fu_42925_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_29_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_957_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_956_EN_A.read();
    } else {
        v3_23_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_29_EN_B = ap_const_logic_1;
    } else {
        v3_23_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_29_Rst_A() {
    v3_23_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_29_Rst_B() {
    v3_23_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_29_WEN_A() {
    v3_23_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_930_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_929_Addr_A.read();
    } else {
        v3_23_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_2_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_2_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_2_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_2_Addr_B() {
    v3_23_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_2_Addr_B_orig() {
    v3_23_2_Addr_B_orig =  (sc_lv<32>) (v3_23_2_addr_2_reg_64232.read());
}

void kernel_correlation_sdse::thread_v3_23_2_Clk_A() {
    v3_23_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_2_Clk_B() {
    v3_23_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_2_Din_A() {
    v3_23_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_2_Din_B() {
    v3_23_2_Din_B = grp_fu_42940_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_930_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_929_EN_A.read();
    } else {
        v3_23_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_2_EN_B = ap_const_logic_1;
    } else {
        v3_23_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_2_Rst_A() {
    v3_23_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_2_Rst_B() {
    v3_23_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_2_WEN_A() {
    v3_23_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_958_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_957_Addr_A.read();
    } else {
        v3_23_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_30_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_30_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_30_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_30_Addr_B() {
    v3_23_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_30_Addr_B_orig() {
    v3_23_30_Addr_B_orig =  (sc_lv<32>) (v3_23_30_addr_2_reg_64274.read());
}

void kernel_correlation_sdse::thread_v3_23_30_Clk_A() {
    v3_23_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_30_Clk_B() {
    v3_23_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_30_Din_A() {
    v3_23_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_30_Din_B() {
    v3_23_30_Din_B = grp_fu_42940_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_30_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_958_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_957_EN_A.read();
    } else {
        v3_23_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_30_EN_B = ap_const_logic_1;
    } else {
        v3_23_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_30_Rst_A() {
    v3_23_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_30_Rst_B() {
    v3_23_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_30_WEN_A() {
    v3_23_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_23_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_959_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_958_Addr_A.read();
    } else {
        v3_23_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_23_31_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_23_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_23_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_23_31_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_23_31_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_23_31_Addr_B() {
    v3_23_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_23_31_Addr_B_orig() {
    v3_23_31_Addr_B_orig =  (sc_lv<32>) (v3_23_31_addr_2_reg_65934.read());
}

void kernel_correlation_sdse::thread_v3_23_31_Clk_A() {
    v3_23_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_31_Clk_B() {
    v3_23_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_23_31_Din_A() {
    v3_23_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_23_31_Din_B() {
    v3_23_31_Din_B = grp_fu_42956_p2.read();
}

void kernel_correlation_sdse::thread_v3_23_31_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_23_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_23_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_959_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_23_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_958_EN_A.read();
    } else {
        v3_23_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_23_31_EN_B = ap_const_logic_1;
    } else {
        v3_23_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_23_31_Rst_A() {
    v3_23_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_23_31_Rst_B() {
    v3_23_31_Rst_B = ap_rst_n_inv.read();
}

}


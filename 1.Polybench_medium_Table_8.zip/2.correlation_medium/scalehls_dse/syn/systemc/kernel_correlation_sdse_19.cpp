#include "kernel_correlation_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_correlation_sdse::thread_v3_6_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_285_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_284_EN_A.read();
    } else {
        v3_6_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_37_EN_B = ap_const_logic_1;
    } else {
        v3_6_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_37_Rst_A() {
    v3_6_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_37_Rst_B() {
    v3_6_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_37_WEN_A() {
    v3_6_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_286_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_285_Addr_A.read();
    } else {
        v3_6_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_6_38_Addr_A_orig() {
    v3_6_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_6_38_Addr_B() {
    v3_6_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_6_38_Addr_B_orig() {
    v3_6_38_Addr_B_orig =  (sc_lv<32>) (v3_6_38_addr_reg_63266.read());
}

void kernel_correlation_sdse::thread_v3_6_38_Clk_A() {
    v3_6_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_38_Clk_B() {
    v3_6_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_38_Din_A() {
    v3_6_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_6_38_Din_B() {
    v3_6_38_Din_B = grp_fu_41886_p2.read();
}

void kernel_correlation_sdse::thread_v3_6_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_286_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_285_EN_A.read();
    } else {
        v3_6_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_38_EN_B = ap_const_logic_1;
    } else {
        v3_6_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_38_Rst_A() {
    v3_6_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_38_Rst_B() {
    v3_6_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_38_WEN_A() {
    v3_6_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_287_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_286_Addr_A.read();
    } else {
        v3_6_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_6_39_Addr_A_orig() {
    v3_6_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_6_39_Addr_B() {
    v3_6_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_6_39_Addr_B_orig() {
    v3_6_39_Addr_B_orig =  (sc_lv<32>) (v3_6_39_addr_reg_64926.read());
}

void kernel_correlation_sdse::thread_v3_6_39_Clk_A() {
    v3_6_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_39_Clk_B() {
    v3_6_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_39_Din_A() {
    v3_6_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_6_39_Din_B() {
    v3_6_39_Din_B = grp_fu_41902_p2.read();
}

void kernel_correlation_sdse::thread_v3_6_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_287_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_286_EN_A.read();
    } else {
        v3_6_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_39_EN_B = ap_const_logic_1;
    } else {
        v3_6_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_39_Rst_A() {
    v3_6_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_39_Rst_B() {
    v3_6_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_39_WEN_A() {
    v3_6_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_251_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_250_Addr_A.read();
    } else {
        v3_6_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_6_3_Addr_A_orig() {
    v3_6_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_6_3_Addr_B() {
    v3_6_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_6_3_Addr_B_orig() {
    v3_6_3_Addr_B_orig =  (sc_lv<32>) (v3_6_3_addr_reg_64872.read());
}

void kernel_correlation_sdse::thread_v3_6_3_Clk_A() {
    v3_6_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_3_Clk_B() {
    v3_6_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_3_Din_A() {
    v3_6_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_6_3_Din_B() {
    v3_6_3_Din_B = grp_fu_41902_p2.read();
}

void kernel_correlation_sdse::thread_v3_6_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_251_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_250_EN_A.read();
    } else {
        v3_6_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_3_EN_B = ap_const_logic_1;
    } else {
        v3_6_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_3_Rst_A() {
    v3_6_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_3_Rst_B() {
    v3_6_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_3_WEN_A() {
    v3_6_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_252_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_251_Addr_A.read();
    } else {
        v3_6_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_6_4_Addr_A_orig() {
    v3_6_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_6_4_Addr_B() {
    v3_6_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_6_4_Addr_B_orig() {
    v3_6_4_Addr_B_orig =  (sc_lv<32>) (v3_6_4_addr_reg_59898.read());
}

void kernel_correlation_sdse::thread_v3_6_4_Clk_A() {
    v3_6_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_4_Clk_B() {
    v3_6_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_4_Din_A() {
    v3_6_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_6_4_Din_B() {
    v3_6_4_Din_B = grp_fu_41856_p2.read();
}

void kernel_correlation_sdse::thread_v3_6_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_252_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_251_EN_A.read();
    } else {
        v3_6_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_4_EN_B = ap_const_logic_1;
    } else {
        v3_6_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_4_Rst_A() {
    v3_6_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_4_Rst_B() {
    v3_6_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_4_WEN_A() {
    v3_6_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_253_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_252_Addr_A.read();
    } else {
        v3_6_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_6_5_Addr_A_orig() {
    v3_6_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_6_5_Addr_B() {
    v3_6_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_6_5_Addr_B_orig() {
    v3_6_5_Addr_B_orig =  (sc_lv<32>) (v3_6_5_addr_reg_61558.read());
}

void kernel_correlation_sdse::thread_v3_6_5_Clk_A() {
    v3_6_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_5_Clk_B() {
    v3_6_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_5_Din_A() {
    v3_6_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_6_5_Din_B() {
    v3_6_5_Din_B = grp_fu_41871_p2.read();
}

void kernel_correlation_sdse::thread_v3_6_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_253_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_252_EN_A.read();
    } else {
        v3_6_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_5_EN_B = ap_const_logic_1;
    } else {
        v3_6_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_5_Rst_A() {
    v3_6_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_5_Rst_B() {
    v3_6_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_5_WEN_A() {
    v3_6_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_254_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_253_Addr_A.read();
    } else {
        v3_6_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_6_6_Addr_A_orig() {
    v3_6_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_6_6_Addr_B() {
    v3_6_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_6_6_Addr_B_orig() {
    v3_6_6_Addr_B_orig =  (sc_lv<32>) (v3_6_6_addr_reg_63218.read());
}

void kernel_correlation_sdse::thread_v3_6_6_Clk_A() {
    v3_6_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_6_Clk_B() {
    v3_6_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_6_Din_A() {
    v3_6_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_6_6_Din_B() {
    v3_6_6_Din_B = grp_fu_41886_p2.read();
}

void kernel_correlation_sdse::thread_v3_6_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_254_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_253_EN_A.read();
    } else {
        v3_6_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_6_EN_B = ap_const_logic_1;
    } else {
        v3_6_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_6_Rst_A() {
    v3_6_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_6_Rst_B() {
    v3_6_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_6_WEN_A() {
    v3_6_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_6_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_255_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_254_Addr_A.read();
    } else {
        v3_6_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_6_7_Addr_A_orig() {
    v3_6_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_6_7_Addr_B() {
    v3_6_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_6_7_Addr_B_orig() {
    v3_6_7_Addr_B_orig =  (sc_lv<32>) (v3_6_7_addr_reg_64878.read());
}

void kernel_correlation_sdse::thread_v3_6_7_Clk_A() {
    v3_6_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_7_Clk_B() {
    v3_6_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_7_Din_A() {
    v3_6_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_6_7_Din_B() {
    v3_6_7_Din_B = grp_fu_41902_p2.read();
}

void kernel_correlation_sdse::thread_v3_6_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_255_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_254_EN_A.read();
    } else {
        v3_6_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_7_EN_B = ap_const_logic_1;
    } else {
        v3_6_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_7_Rst_A() {
    v3_6_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_7_Rst_B() {
    v3_6_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_7_WEN_A() {
    v3_6_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_7_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_256_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_255_Addr_A.read();
    } else {
        v3_6_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_6_8_Addr_A_orig() {
    v3_6_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_6_8_Addr_B() {
    v3_6_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_6_8_Addr_B_orig() {
    v3_6_8_Addr_B_orig =  (sc_lv<32>) (v3_6_8_addr_reg_59904.read());
}

void kernel_correlation_sdse::thread_v3_6_8_Clk_A() {
    v3_6_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_8_Clk_B() {
    v3_6_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_8_Din_A() {
    v3_6_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_6_8_Din_B() {
    v3_6_8_Din_B = grp_fu_41856_p2.read();
}

void kernel_correlation_sdse::thread_v3_6_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_256_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_255_EN_A.read();
    } else {
        v3_6_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_8_EN_B = ap_const_logic_1;
    } else {
        v3_6_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_8_Rst_A() {
    v3_6_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_8_Rst_B() {
    v3_6_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_8_WEN_A() {
    v3_6_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_8_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_257_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_256_Addr_A.read();
    } else {
        v3_6_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_6_9_Addr_A_orig() {
    v3_6_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_6_9_Addr_B() {
    v3_6_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_6_9_Addr_B_orig() {
    v3_6_9_Addr_B_orig =  (sc_lv<32>) (v3_6_9_addr_reg_61564.read());
}

void kernel_correlation_sdse::thread_v3_6_9_Clk_A() {
    v3_6_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_9_Clk_B() {
    v3_6_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_6_9_Din_A() {
    v3_6_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_6_9_Din_B() {
    v3_6_9_Din_B = grp_fu_41871_p2.read();
}

void kernel_correlation_sdse::thread_v3_6_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_6_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_6_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_257_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_6_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_256_EN_A.read();
    } else {
        v3_6_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_9_EN_B = ap_const_logic_1;
    } else {
        v3_6_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_6_9_Rst_A() {
    v3_6_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_9_Rst_B() {
    v3_6_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_6_9_WEN_A() {
    v3_6_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_6_9_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_6_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_327_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_288_Addr_A.read();
    } else {
        v3_7_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_0_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_0_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_0_Addr_B() {
    v3_7_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_0_Addr_B_orig() {
    v3_7_0_Addr_B_orig =  (sc_lv<32>) (v3_7_0_addr_2_reg_59952.read());
}

void kernel_correlation_sdse::thread_v3_7_0_Clk_A() {
    v3_7_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_0_Clk_B() {
    v3_7_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_0_Din_A() {
    v3_7_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_0_Din_B() {
    v3_7_0_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_327_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_288_EN_A.read();
    } else {
        v3_7_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_0_EN_B = ap_const_logic_1;
    } else {
        v3_7_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_0_Rst_A() {
    v3_7_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_0_Rst_B() {
    v3_7_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_0_WEN_A() {
    v3_7_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_298_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_297_Addr_A.read();
    } else {
        v3_7_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_10_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_10_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_10_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_10_Addr_B() {
    v3_7_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_10_Addr_B_orig() {
    v3_7_10_Addr_B_orig =  (sc_lv<32>) (v3_7_10_addr_2_reg_63284.read());
}

void kernel_correlation_sdse::thread_v3_7_10_Clk_A() {
    v3_7_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_10_Clk_B() {
    v3_7_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_10_Din_A() {
    v3_7_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_10_Din_B() {
    v3_7_10_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_10_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_298_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_297_EN_A.read();
    } else {
        v3_7_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_10_EN_B = ap_const_logic_1;
    } else {
        v3_7_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_10_Rst_A() {
    v3_7_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_10_Rst_B() {
    v3_7_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_10_WEN_A() {
    v3_7_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_299_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_298_Addr_A.read();
    } else {
        v3_7_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_11_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_11_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_11_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_11_Addr_B() {
    v3_7_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_11_Addr_B_orig() {
    v3_7_11_Addr_B_orig =  (sc_lv<32>) (v3_7_11_addr_2_reg_64944.read());
}

void kernel_correlation_sdse::thread_v3_7_11_Clk_A() {
    v3_7_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_11_Clk_B() {
    v3_7_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_11_Din_A() {
    v3_7_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_11_Din_B() {
    v3_7_11_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_11_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_299_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_298_EN_A.read();
    } else {
        v3_7_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_11_EN_B = ap_const_logic_1;
    } else {
        v3_7_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_11_Rst_A() {
    v3_7_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_11_Rst_B() {
    v3_7_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_11_WEN_A() {
    v3_7_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_300_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_299_Addr_A.read();
    } else {
        v3_7_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_12_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_12_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_12_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_12_Addr_B() {
    v3_7_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_12_Addr_B_orig() {
    v3_7_12_Addr_B_orig =  (sc_lv<32>) (v3_7_12_addr_2_reg_59970.read());
}

void kernel_correlation_sdse::thread_v3_7_12_Clk_A() {
    v3_7_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_12_Clk_B() {
    v3_7_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_12_Din_A() {
    v3_7_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_12_Din_B() {
    v3_7_12_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_12_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_300_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_299_EN_A.read();
    } else {
        v3_7_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_12_EN_B = ap_const_logic_1;
    } else {
        v3_7_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_12_Rst_A() {
    v3_7_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_12_Rst_B() {
    v3_7_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_12_WEN_A() {
    v3_7_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_301_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_300_Addr_A.read();
    } else {
        v3_7_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_13_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_13_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_13_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_13_Addr_B() {
    v3_7_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_13_Addr_B_orig() {
    v3_7_13_Addr_B_orig =  (sc_lv<32>) (v3_7_13_addr_2_reg_61630.read());
}

void kernel_correlation_sdse::thread_v3_7_13_Clk_A() {
    v3_7_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_13_Clk_B() {
    v3_7_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_13_Din_A() {
    v3_7_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_13_Din_B() {
    v3_7_13_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_13_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_301_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_300_EN_A.read();
    } else {
        v3_7_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_13_EN_B = ap_const_logic_1;
    } else {
        v3_7_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_13_Rst_A() {
    v3_7_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_13_Rst_B() {
    v3_7_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_13_WEN_A() {
    v3_7_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_302_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_301_Addr_A.read();
    } else {
        v3_7_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_14_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_14_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_14_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_14_Addr_B() {
    v3_7_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_14_Addr_B_orig() {
    v3_7_14_Addr_B_orig =  (sc_lv<32>) (v3_7_14_addr_2_reg_63290.read());
}

void kernel_correlation_sdse::thread_v3_7_14_Clk_A() {
    v3_7_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_14_Clk_B() {
    v3_7_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_14_Din_A() {
    v3_7_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_14_Din_B() {
    v3_7_14_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_14_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_302_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_301_EN_A.read();
    } else {
        v3_7_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_14_EN_B = ap_const_logic_1;
    } else {
        v3_7_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_14_Rst_A() {
    v3_7_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_14_Rst_B() {
    v3_7_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_14_WEN_A() {
    v3_7_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_303_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_302_Addr_A.read();
    } else {
        v3_7_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_15_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_15_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_15_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_15_Addr_B() {
    v3_7_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_15_Addr_B_orig() {
    v3_7_15_Addr_B_orig =  (sc_lv<32>) (v3_7_15_addr_2_reg_64950.read());
}

void kernel_correlation_sdse::thread_v3_7_15_Clk_A() {
    v3_7_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_15_Clk_B() {
    v3_7_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_15_Din_A() {
    v3_7_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_15_Din_B() {
    v3_7_15_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_15_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_303_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_302_EN_A.read();
    } else {
        v3_7_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_15_EN_B = ap_const_logic_1;
    } else {
        v3_7_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_15_Rst_A() {
    v3_7_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_15_Rst_B() {
    v3_7_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_15_WEN_A() {
    v3_7_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_304_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_303_Addr_A.read();
    } else {
        v3_7_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_16_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_16_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_16_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_16_Addr_B() {
    v3_7_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_16_Addr_B_orig() {
    v3_7_16_Addr_B_orig =  (sc_lv<32>) (v3_7_16_addr_2_reg_59976.read());
}

void kernel_correlation_sdse::thread_v3_7_16_Clk_A() {
    v3_7_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_16_Clk_B() {
    v3_7_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_16_Din_A() {
    v3_7_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_16_Din_B() {
    v3_7_16_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_16_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_304_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_303_EN_A.read();
    } else {
        v3_7_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_16_EN_B = ap_const_logic_1;
    } else {
        v3_7_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_16_Rst_A() {
    v3_7_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_16_Rst_B() {
    v3_7_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_16_WEN_A() {
    v3_7_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_305_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_304_Addr_A.read();
    } else {
        v3_7_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_17_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_17_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_17_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_17_Addr_B() {
    v3_7_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_17_Addr_B_orig() {
    v3_7_17_Addr_B_orig =  (sc_lv<32>) (v3_7_17_addr_2_reg_61636.read());
}

void kernel_correlation_sdse::thread_v3_7_17_Clk_A() {
    v3_7_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_17_Clk_B() {
    v3_7_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_17_Din_A() {
    v3_7_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_17_Din_B() {
    v3_7_17_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_17_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_305_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_304_EN_A.read();
    } else {
        v3_7_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_17_EN_B = ap_const_logic_1;
    } else {
        v3_7_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_17_Rst_A() {
    v3_7_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_17_Rst_B() {
    v3_7_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_17_WEN_A() {
    v3_7_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_306_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_305_Addr_A.read();
    } else {
        v3_7_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_18_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_18_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_18_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_18_Addr_B() {
    v3_7_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_18_Addr_B_orig() {
    v3_7_18_Addr_B_orig =  (sc_lv<32>) (v3_7_18_addr_2_reg_63296.read());
}

void kernel_correlation_sdse::thread_v3_7_18_Clk_A() {
    v3_7_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_18_Clk_B() {
    v3_7_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_18_Din_A() {
    v3_7_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_18_Din_B() {
    v3_7_18_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_18_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_306_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_305_EN_A.read();
    } else {
        v3_7_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_18_EN_B = ap_const_logic_1;
    } else {
        v3_7_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_18_Rst_A() {
    v3_7_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_18_Rst_B() {
    v3_7_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_18_WEN_A() {
    v3_7_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_307_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_306_Addr_A.read();
    } else {
        v3_7_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_19_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_19_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_19_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_19_Addr_B() {
    v3_7_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_19_Addr_B_orig() {
    v3_7_19_Addr_B_orig =  (sc_lv<32>) (v3_7_19_addr_2_reg_64956.read());
}

void kernel_correlation_sdse::thread_v3_7_19_Clk_A() {
    v3_7_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_19_Clk_B() {
    v3_7_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_19_Din_A() {
    v3_7_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_19_Din_B() {
    v3_7_19_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_19_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_307_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_306_EN_A.read();
    } else {
        v3_7_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_19_EN_B = ap_const_logic_1;
    } else {
        v3_7_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_19_Rst_A() {
    v3_7_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_19_Rst_B() {
    v3_7_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_19_WEN_A() {
    v3_7_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_289_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_288_Addr_A.read();
    } else {
        v3_7_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_1_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_1_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_1_Addr_B() {
    v3_7_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_1_Addr_B_orig() {
    v3_7_1_Addr_B_orig =  (sc_lv<32>) (v3_7_1_addr_2_reg_61612.read());
}

void kernel_correlation_sdse::thread_v3_7_1_Clk_A() {
    v3_7_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_1_Clk_B() {
    v3_7_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_1_Din_A() {
    v3_7_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_1_Din_B() {
    v3_7_1_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_289_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_288_EN_A.read();
    } else {
        v3_7_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_1_EN_B = ap_const_logic_1;
    } else {
        v3_7_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_1_Rst_A() {
    v3_7_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_1_Rst_B() {
    v3_7_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_1_WEN_A() {
    v3_7_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_308_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_307_Addr_A.read();
    } else {
        v3_7_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_20_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_20_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_20_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_20_Addr_B() {
    v3_7_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_20_Addr_B_orig() {
    v3_7_20_Addr_B_orig =  (sc_lv<32>) (v3_7_20_addr_2_reg_59982.read());
}

void kernel_correlation_sdse::thread_v3_7_20_Clk_A() {
    v3_7_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_20_Clk_B() {
    v3_7_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_20_Din_A() {
    v3_7_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_20_Din_B() {
    v3_7_20_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_20_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_308_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_307_EN_A.read();
    } else {
        v3_7_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_20_EN_B = ap_const_logic_1;
    } else {
        v3_7_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_20_Rst_A() {
    v3_7_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_20_Rst_B() {
    v3_7_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_20_WEN_A() {
    v3_7_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_309_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_308_Addr_A.read();
    } else {
        v3_7_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_21_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_21_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_21_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_21_Addr_B() {
    v3_7_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_21_Addr_B_orig() {
    v3_7_21_Addr_B_orig =  (sc_lv<32>) (v3_7_21_addr_2_reg_61642.read());
}

void kernel_correlation_sdse::thread_v3_7_21_Clk_A() {
    v3_7_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_21_Clk_B() {
    v3_7_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_21_Din_A() {
    v3_7_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_21_Din_B() {
    v3_7_21_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_21_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_309_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_308_EN_A.read();
    } else {
        v3_7_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_21_EN_B = ap_const_logic_1;
    } else {
        v3_7_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_21_Rst_A() {
    v3_7_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_21_Rst_B() {
    v3_7_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_21_WEN_A() {
    v3_7_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_310_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_309_Addr_A.read();
    } else {
        v3_7_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_22_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_22_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_22_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_22_Addr_B() {
    v3_7_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_22_Addr_B_orig() {
    v3_7_22_Addr_B_orig =  (sc_lv<32>) (v3_7_22_addr_2_reg_63302.read());
}

void kernel_correlation_sdse::thread_v3_7_22_Clk_A() {
    v3_7_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_22_Clk_B() {
    v3_7_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_22_Din_A() {
    v3_7_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_22_Din_B() {
    v3_7_22_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_22_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_310_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_309_EN_A.read();
    } else {
        v3_7_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_22_EN_B = ap_const_logic_1;
    } else {
        v3_7_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_22_Rst_A() {
    v3_7_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_22_Rst_B() {
    v3_7_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_22_WEN_A() {
    v3_7_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_311_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_310_Addr_A.read();
    } else {
        v3_7_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_23_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_23_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_23_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_23_Addr_B() {
    v3_7_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_23_Addr_B_orig() {
    v3_7_23_Addr_B_orig =  (sc_lv<32>) (v3_7_23_addr_2_reg_64962.read());
}

void kernel_correlation_sdse::thread_v3_7_23_Clk_A() {
    v3_7_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_23_Clk_B() {
    v3_7_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_23_Din_A() {
    v3_7_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_23_Din_B() {
    v3_7_23_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_23_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_311_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_310_EN_A.read();
    } else {
        v3_7_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_23_EN_B = ap_const_logic_1;
    } else {
        v3_7_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_23_Rst_A() {
    v3_7_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_23_Rst_B() {
    v3_7_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_23_WEN_A() {
    v3_7_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_312_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_311_Addr_A.read();
    } else {
        v3_7_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_24_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_24_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_24_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_24_Addr_B() {
    v3_7_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_24_Addr_B_orig() {
    v3_7_24_Addr_B_orig =  (sc_lv<32>) (v3_7_24_addr_2_reg_59988.read());
}

void kernel_correlation_sdse::thread_v3_7_24_Clk_A() {
    v3_7_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_24_Clk_B() {
    v3_7_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_24_Din_A() {
    v3_7_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_24_Din_B() {
    v3_7_24_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_24_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_312_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_311_EN_A.read();
    } else {
        v3_7_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_24_EN_B = ap_const_logic_1;
    } else {
        v3_7_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_24_Rst_A() {
    v3_7_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_24_Rst_B() {
    v3_7_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_24_WEN_A() {
    v3_7_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_313_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_312_Addr_A.read();
    } else {
        v3_7_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_25_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_25_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_25_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_25_Addr_B() {
    v3_7_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_25_Addr_B_orig() {
    v3_7_25_Addr_B_orig =  (sc_lv<32>) (v3_7_25_addr_2_reg_61648.read());
}

void kernel_correlation_sdse::thread_v3_7_25_Clk_A() {
    v3_7_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_25_Clk_B() {
    v3_7_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_25_Din_A() {
    v3_7_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_25_Din_B() {
    v3_7_25_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_25_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_313_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_312_EN_A.read();
    } else {
        v3_7_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_25_EN_B = ap_const_logic_1;
    } else {
        v3_7_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_25_Rst_A() {
    v3_7_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_25_Rst_B() {
    v3_7_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_25_WEN_A() {
    v3_7_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_314_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_313_Addr_A.read();
    } else {
        v3_7_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_26_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_26_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_26_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_26_Addr_B() {
    v3_7_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_26_Addr_B_orig() {
    v3_7_26_Addr_B_orig =  (sc_lv<32>) (v3_7_26_addr_2_reg_63308.read());
}

void kernel_correlation_sdse::thread_v3_7_26_Clk_A() {
    v3_7_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_26_Clk_B() {
    v3_7_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_26_Din_A() {
    v3_7_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_26_Din_B() {
    v3_7_26_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_26_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_314_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_313_EN_A.read();
    } else {
        v3_7_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_26_EN_B = ap_const_logic_1;
    } else {
        v3_7_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_26_Rst_A() {
    v3_7_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_26_Rst_B() {
    v3_7_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_26_WEN_A() {
    v3_7_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_315_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_314_Addr_A.read();
    } else {
        v3_7_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_27_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_27_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_27_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_27_Addr_B() {
    v3_7_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_27_Addr_B_orig() {
    v3_7_27_Addr_B_orig =  (sc_lv<32>) (v3_7_27_addr_2_reg_64968.read());
}

void kernel_correlation_sdse::thread_v3_7_27_Clk_A() {
    v3_7_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_27_Clk_B() {
    v3_7_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_27_Din_A() {
    v3_7_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_27_Din_B() {
    v3_7_27_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_27_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_315_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_314_EN_A.read();
    } else {
        v3_7_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_27_EN_B = ap_const_logic_1;
    } else {
        v3_7_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_27_Rst_A() {
    v3_7_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_27_Rst_B() {
    v3_7_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_27_WEN_A() {
    v3_7_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_316_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_315_Addr_A.read();
    } else {
        v3_7_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_28_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_28_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_28_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_28_Addr_B() {
    v3_7_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_28_Addr_B_orig() {
    v3_7_28_Addr_B_orig =  (sc_lv<32>) (v3_7_28_addr_1_reg_59994.read());
}

void kernel_correlation_sdse::thread_v3_7_28_Clk_A() {
    v3_7_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_28_Clk_B() {
    v3_7_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_28_Din_A() {
    v3_7_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_28_Din_B() {
    v3_7_28_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_28_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_316_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_315_EN_A.read();
    } else {
        v3_7_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_28_EN_B = ap_const_logic_1;
    } else {
        v3_7_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_28_Rst_A() {
    v3_7_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_28_Rst_B() {
    v3_7_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_28_WEN_A() {
    v3_7_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_317_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_316_Addr_A.read();
    } else {
        v3_7_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_29_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_29_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_29_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_29_Addr_B() {
    v3_7_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_29_Addr_B_orig() {
    v3_7_29_Addr_B_orig =  (sc_lv<32>) (v3_7_29_addr_1_reg_61654.read());
}

void kernel_correlation_sdse::thread_v3_7_29_Clk_A() {
    v3_7_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_29_Clk_B() {
    v3_7_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_29_Din_A() {
    v3_7_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_29_Din_B() {
    v3_7_29_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_29_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_317_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_316_EN_A.read();
    } else {
        v3_7_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_29_EN_B = ap_const_logic_1;
    } else {
        v3_7_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_29_Rst_A() {
    v3_7_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_29_Rst_B() {
    v3_7_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_29_WEN_A() {
    v3_7_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_290_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_289_Addr_A.read();
    } else {
        v3_7_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_2_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_2_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_2_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_2_Addr_B() {
    v3_7_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_2_Addr_B_orig() {
    v3_7_2_Addr_B_orig =  (sc_lv<32>) (v3_7_2_addr_2_reg_63272.read());
}

void kernel_correlation_sdse::thread_v3_7_2_Clk_A() {
    v3_7_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_2_Clk_B() {
    v3_7_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_2_Din_A() {
    v3_7_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_2_Din_B() {
    v3_7_2_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_290_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_289_EN_A.read();
    } else {
        v3_7_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_2_EN_B = ap_const_logic_1;
    } else {
        v3_7_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_2_Rst_A() {
    v3_7_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_2_Rst_B() {
    v3_7_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_2_WEN_A() {
    v3_7_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_318_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_317_Addr_A.read();
    } else {
        v3_7_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_30_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_30_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_30_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_30_Addr_B() {
    v3_7_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_30_Addr_B_orig() {
    v3_7_30_Addr_B_orig =  (sc_lv<32>) (v3_7_30_addr_1_reg_63314.read());
}

void kernel_correlation_sdse::thread_v3_7_30_Clk_A() {
    v3_7_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_30_Clk_B() {
    v3_7_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_30_Din_A() {
    v3_7_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_30_Din_B() {
    v3_7_30_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_30_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_318_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_317_EN_A.read();
    } else {
        v3_7_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_30_EN_B = ap_const_logic_1;
    } else {
        v3_7_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_30_Rst_A() {
    v3_7_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_30_Rst_B() {
    v3_7_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_30_WEN_A() {
    v3_7_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_319_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_318_Addr_A.read();
    } else {
        v3_7_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_31_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_31_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_31_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_31_Addr_B() {
    v3_7_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_31_Addr_B_orig() {
    v3_7_31_Addr_B_orig =  (sc_lv<32>) (v3_7_31_addr_1_reg_64974.read());
}

void kernel_correlation_sdse::thread_v3_7_31_Clk_A() {
    v3_7_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_31_Clk_B() {
    v3_7_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_31_Din_A() {
    v3_7_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_31_Din_B() {
    v3_7_31_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_31_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_319_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_318_EN_A.read();
    } else {
        v3_7_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_31_EN_B = ap_const_logic_1;
    } else {
        v3_7_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_31_Rst_A() {
    v3_7_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_31_Rst_B() {
    v3_7_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_31_WEN_A() {
    v3_7_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_31_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_32_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_320_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_319_Addr_A.read();
    } else {
        v3_7_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_32_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_32_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_32_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_32_Addr_B() {
    v3_7_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_32_Addr_B_orig() {
    v3_7_32_Addr_B_orig =  (sc_lv<32>) (v3_7_32_addr_1_reg_60000.read());
}

void kernel_correlation_sdse::thread_v3_7_32_Clk_A() {
    v3_7_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_32_Clk_B() {
    v3_7_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_32_Din_A() {
    v3_7_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_32_Din_B() {
    v3_7_32_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_32_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_32_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_320_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_319_EN_A.read();
    } else {
        v3_7_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_32_EN_B = ap_const_logic_1;
    } else {
        v3_7_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_32_Rst_A() {
    v3_7_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_32_Rst_B() {
    v3_7_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_32_WEN_A() {
    v3_7_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_32_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_33_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_321_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_320_Addr_A.read();
    } else {
        v3_7_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_33_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_33_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_33_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_33_Addr_B() {
    v3_7_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_33_Addr_B_orig() {
    v3_7_33_Addr_B_orig =  (sc_lv<32>) (v3_7_33_addr_1_reg_61660.read());
}

void kernel_correlation_sdse::thread_v3_7_33_Clk_A() {
    v3_7_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_33_Clk_B() {
    v3_7_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_33_Din_A() {
    v3_7_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_33_Din_B() {
    v3_7_33_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_33_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_33_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_321_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_320_EN_A.read();
    } else {
        v3_7_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_33_EN_B = ap_const_logic_1;
    } else {
        v3_7_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_33_Rst_A() {
    v3_7_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_33_Rst_B() {
    v3_7_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_33_WEN_A() {
    v3_7_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_33_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_34_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_322_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_321_Addr_A.read();
    } else {
        v3_7_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_34_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_34_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_34_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_34_Addr_B() {
    v3_7_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_34_Addr_B_orig() {
    v3_7_34_Addr_B_orig =  (sc_lv<32>) (v3_7_34_addr_1_reg_63320.read());
}

void kernel_correlation_sdse::thread_v3_7_34_Clk_A() {
    v3_7_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_34_Clk_B() {
    v3_7_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_34_Din_A() {
    v3_7_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_34_Din_B() {
    v3_7_34_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_34_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_34_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_322_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_321_EN_A.read();
    } else {
        v3_7_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_34_EN_B = ap_const_logic_1;
    } else {
        v3_7_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_34_Rst_A() {
    v3_7_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_34_Rst_B() {
    v3_7_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_34_WEN_A() {
    v3_7_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_34_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_35_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_323_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_322_Addr_A.read();
    } else {
        v3_7_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_35_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_35_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_35_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_35_Addr_B() {
    v3_7_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_35_Addr_B_orig() {
    v3_7_35_Addr_B_orig =  (sc_lv<32>) (v3_7_35_addr_1_reg_64980.read());
}

void kernel_correlation_sdse::thread_v3_7_35_Clk_A() {
    v3_7_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_35_Clk_B() {
    v3_7_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_35_Din_A() {
    v3_7_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_35_Din_B() {
    v3_7_35_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_35_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_35_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_323_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_322_EN_A.read();
    } else {
        v3_7_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_35_EN_B = ap_const_logic_1;
    } else {
        v3_7_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_35_Rst_A() {
    v3_7_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_35_Rst_B() {
    v3_7_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_35_WEN_A() {
    v3_7_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_35_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_36_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_324_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_323_Addr_A.read();
    } else {
        v3_7_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_36_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_36_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_36_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_36_Addr_B() {
    v3_7_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_36_Addr_B_orig() {
    v3_7_36_Addr_B_orig =  (sc_lv<32>) (v3_7_36_addr_1_reg_60006.read());
}

void kernel_correlation_sdse::thread_v3_7_36_Clk_A() {
    v3_7_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_36_Clk_B() {
    v3_7_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_36_Din_A() {
    v3_7_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_36_Din_B() {
    v3_7_36_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_36_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_36_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_324_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_323_EN_A.read();
    } else {
        v3_7_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_36_EN_B = ap_const_logic_1;
    } else {
        v3_7_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_36_Rst_A() {
    v3_7_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_36_Rst_B() {
    v3_7_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_36_WEN_A() {
    v3_7_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_36_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_37_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_325_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_324_Addr_A.read();
    } else {
        v3_7_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_37_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_37_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_37_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_37_Addr_B() {
    v3_7_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_37_Addr_B_orig() {
    v3_7_37_Addr_B_orig =  (sc_lv<32>) (v3_7_37_addr_1_reg_61666.read());
}

void kernel_correlation_sdse::thread_v3_7_37_Clk_A() {
    v3_7_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_37_Clk_B() {
    v3_7_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_37_Din_A() {
    v3_7_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_37_Din_B() {
    v3_7_37_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_37_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_325_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_324_EN_A.read();
    } else {
        v3_7_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_37_EN_B = ap_const_logic_1;
    } else {
        v3_7_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_37_Rst_A() {
    v3_7_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_37_Rst_B() {
    v3_7_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_37_WEN_A() {
    v3_7_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_326_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_325_Addr_A.read();
    } else {
        v3_7_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_38_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_38_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_38_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_38_Addr_B() {
    v3_7_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_38_Addr_B_orig() {
    v3_7_38_Addr_B_orig =  (sc_lv<32>) (v3_7_38_addr_1_reg_63326.read());
}

void kernel_correlation_sdse::thread_v3_7_38_Clk_A() {
    v3_7_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_38_Clk_B() {
    v3_7_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_38_Din_A() {
    v3_7_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_38_Din_B() {
    v3_7_38_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_38_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_326_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_325_EN_A.read();
    } else {
        v3_7_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_38_EN_B = ap_const_logic_1;
    } else {
        v3_7_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_38_Rst_A() {
    v3_7_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_38_Rst_B() {
    v3_7_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_38_WEN_A() {
    v3_7_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_327_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_326_Addr_A.read();
    } else {
        v3_7_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_39_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_39_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_39_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_39_Addr_B() {
    v3_7_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_39_Addr_B_orig() {
    v3_7_39_Addr_B_orig =  (sc_lv<32>) (v3_7_39_addr_1_reg_64986.read());
}

void kernel_correlation_sdse::thread_v3_7_39_Clk_A() {
    v3_7_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_39_Clk_B() {
    v3_7_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_39_Din_A() {
    v3_7_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_39_Din_B() {
    v3_7_39_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_39_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_327_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_326_EN_A.read();
    } else {
        v3_7_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_39_EN_B = ap_const_logic_1;
    } else {
        v3_7_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_39_Rst_A() {
    v3_7_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_39_Rst_B() {
    v3_7_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_39_WEN_A() {
    v3_7_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_291_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_290_Addr_A.read();
    } else {
        v3_7_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_3_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_3_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_3_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_3_Addr_B() {
    v3_7_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_3_Addr_B_orig() {
    v3_7_3_Addr_B_orig =  (sc_lv<32>) (v3_7_3_addr_2_reg_64932.read());
}

void kernel_correlation_sdse::thread_v3_7_3_Clk_A() {
    v3_7_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_3_Clk_B() {
    v3_7_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_3_Din_A() {
    v3_7_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_3_Din_B() {
    v3_7_3_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_291_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_290_EN_A.read();
    } else {
        v3_7_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_3_EN_B = ap_const_logic_1;
    } else {
        v3_7_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_3_Rst_A() {
    v3_7_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_3_Rst_B() {
    v3_7_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_3_WEN_A() {
    v3_7_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_292_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_291_Addr_A.read();
    } else {
        v3_7_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_4_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_4_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_4_Addr_B() {
    v3_7_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_4_Addr_B_orig() {
    v3_7_4_Addr_B_orig =  (sc_lv<32>) (v3_7_4_addr_2_reg_59958.read());
}

void kernel_correlation_sdse::thread_v3_7_4_Clk_A() {
    v3_7_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_4_Clk_B() {
    v3_7_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_4_Din_A() {
    v3_7_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_4_Din_B() {
    v3_7_4_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_292_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_291_EN_A.read();
    } else {
        v3_7_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_4_EN_B = ap_const_logic_1;
    } else {
        v3_7_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_4_Rst_A() {
    v3_7_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_4_Rst_B() {
    v3_7_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_4_WEN_A() {
    v3_7_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_293_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_292_Addr_A.read();
    } else {
        v3_7_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_5_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_5_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_5_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_5_Addr_B() {
    v3_7_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_5_Addr_B_orig() {
    v3_7_5_Addr_B_orig =  (sc_lv<32>) (v3_7_5_addr_2_reg_61618.read());
}

void kernel_correlation_sdse::thread_v3_7_5_Clk_A() {
    v3_7_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_5_Clk_B() {
    v3_7_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_5_Din_A() {
    v3_7_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_5_Din_B() {
    v3_7_5_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_5_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_293_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_292_EN_A.read();
    } else {
        v3_7_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_5_EN_B = ap_const_logic_1;
    } else {
        v3_7_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_5_Rst_A() {
    v3_7_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_5_Rst_B() {
    v3_7_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_5_WEN_A() {
    v3_7_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_294_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_293_Addr_A.read();
    } else {
        v3_7_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_6_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_6_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_6_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_6_Addr_B() {
    v3_7_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_6_Addr_B_orig() {
    v3_7_6_Addr_B_orig =  (sc_lv<32>) (v3_7_6_addr_2_reg_63278.read());
}

void kernel_correlation_sdse::thread_v3_7_6_Clk_A() {
    v3_7_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_6_Clk_B() {
    v3_7_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_6_Din_A() {
    v3_7_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_6_Din_B() {
    v3_7_6_Din_B = grp_fu_41948_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_6_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_294_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_293_EN_A.read();
    } else {
        v3_7_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_6_EN_B = ap_const_logic_1;
    } else {
        v3_7_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_6_Rst_A() {
    v3_7_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_6_Rst_B() {
    v3_7_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_6_WEN_A() {
    v3_7_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_6_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_295_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_294_Addr_A.read();
    } else {
        v3_7_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_7_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_7_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_7_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_7_Addr_B() {
    v3_7_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_7_Addr_B_orig() {
    v3_7_7_Addr_B_orig =  (sc_lv<32>) (v3_7_7_addr_2_reg_64938.read());
}

void kernel_correlation_sdse::thread_v3_7_7_Clk_A() {
    v3_7_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_7_Clk_B() {
    v3_7_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_7_Din_A() {
    v3_7_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_7_Din_B() {
    v3_7_7_Din_B = grp_fu_41964_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_7_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_295_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_294_EN_A.read();
    } else {
        v3_7_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_7_EN_B = ap_const_logic_1;
    } else {
        v3_7_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_7_Rst_A() {
    v3_7_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_7_Rst_B() {
    v3_7_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_7_WEN_A() {
    v3_7_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_7_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_296_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_295_Addr_A.read();
    } else {
        v3_7_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_8_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_8_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_8_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_8_Addr_B() {
    v3_7_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_8_Addr_B_orig() {
    v3_7_8_Addr_B_orig =  (sc_lv<32>) (v3_7_8_addr_2_reg_59964.read());
}

void kernel_correlation_sdse::thread_v3_7_8_Clk_A() {
    v3_7_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_8_Clk_B() {
    v3_7_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_8_Din_A() {
    v3_7_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_8_Din_B() {
    v3_7_8_Din_B = grp_fu_41918_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_8_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_296_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_295_EN_A.read();
    } else {
        v3_7_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_8_EN_B = ap_const_logic_1;
    } else {
        v3_7_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_8_Rst_A() {
    v3_7_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_8_Rst_B() {
    v3_7_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_8_WEN_A() {
    v3_7_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_8_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_297_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_296_Addr_A.read();
    } else {
        v3_7_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_7_9_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_7_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_7_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_7_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_7_9_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_7_9_Addr_B() {
    v3_7_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_7_9_Addr_B_orig() {
    v3_7_9_Addr_B_orig =  (sc_lv<32>) (v3_7_9_addr_2_reg_61624.read());
}

void kernel_correlation_sdse::thread_v3_7_9_Clk_A() {
    v3_7_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_9_Clk_B() {
    v3_7_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_7_9_Din_A() {
    v3_7_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_7_9_Din_B() {
    v3_7_9_Din_B = grp_fu_41933_p2.read();
}

void kernel_correlation_sdse::thread_v3_7_9_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_7_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_7_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_297_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_7_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_296_EN_A.read();
    } else {
        v3_7_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_9_EN_B = ap_const_logic_1;
    } else {
        v3_7_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_7_9_Rst_A() {
    v3_7_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_9_Rst_B() {
    v3_7_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_7_9_WEN_A() {
    v3_7_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_7_9_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_7_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_367_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_328_Addr_A.read();
    } else {
        v3_8_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_0_Addr_A_orig() {
    v3_8_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_0_Addr_B() {
    v3_8_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_0_Addr_B_orig() {
    v3_8_0_Addr_B_orig =  (sc_lv<32>) (v3_8_0_addr_reg_60012.read());
}

void kernel_correlation_sdse::thread_v3_8_0_Clk_A() {
    v3_8_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_0_Clk_B() {
    v3_8_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_0_Din_A() {
    v3_8_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_0_Din_B() {
    v3_8_0_Din_B = grp_fu_41980_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_367_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_328_EN_A.read();
    } else {
        v3_8_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_0_EN_B = ap_const_logic_1;
    } else {
        v3_8_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_0_Rst_A() {
    v3_8_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_0_Rst_B() {
    v3_8_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_0_WEN_A() {
    v3_8_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_338_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_337_Addr_A.read();
    } else {
        v3_8_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_10_Addr_A_orig() {
    v3_8_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_10_Addr_B() {
    v3_8_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_10_Addr_B_orig() {
    v3_8_10_Addr_B_orig =  (sc_lv<32>) (v3_8_10_addr_reg_63344.read());
}

void kernel_correlation_sdse::thread_v3_8_10_Clk_A() {
    v3_8_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_10_Clk_B() {
    v3_8_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_10_Din_A() {
    v3_8_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_10_Din_B() {
    v3_8_10_Din_B = grp_fu_42010_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_338_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_337_EN_A.read();
    } else {
        v3_8_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_10_EN_B = ap_const_logic_1;
    } else {
        v3_8_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_10_Rst_A() {
    v3_8_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_10_Rst_B() {
    v3_8_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_10_WEN_A() {
    v3_8_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_339_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_338_Addr_A.read();
    } else {
        v3_8_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_11_Addr_A_orig() {
    v3_8_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_11_Addr_B() {
    v3_8_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_11_Addr_B_orig() {
    v3_8_11_Addr_B_orig =  (sc_lv<32>) (v3_8_11_addr_reg_65004.read());
}

void kernel_correlation_sdse::thread_v3_8_11_Clk_A() {
    v3_8_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_11_Clk_B() {
    v3_8_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_11_Din_A() {
    v3_8_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_11_Din_B() {
    v3_8_11_Din_B = grp_fu_42026_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_339_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_338_EN_A.read();
    } else {
        v3_8_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_11_EN_B = ap_const_logic_1;
    } else {
        v3_8_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_11_Rst_A() {
    v3_8_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_11_Rst_B() {
    v3_8_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_11_WEN_A() {
    v3_8_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_340_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_339_Addr_A.read();
    } else {
        v3_8_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_12_Addr_A_orig() {
    v3_8_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_12_Addr_B() {
    v3_8_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_12_Addr_B_orig() {
    v3_8_12_Addr_B_orig =  (sc_lv<32>) (v3_8_12_addr_reg_60030.read());
}

void kernel_correlation_sdse::thread_v3_8_12_Clk_A() {
    v3_8_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_12_Clk_B() {
    v3_8_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_12_Din_A() {
    v3_8_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_12_Din_B() {
    v3_8_12_Din_B = grp_fu_41980_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_340_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_339_EN_A.read();
    } else {
        v3_8_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_12_EN_B = ap_const_logic_1;
    } else {
        v3_8_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_12_Rst_A() {
    v3_8_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_12_Rst_B() {
    v3_8_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_12_WEN_A() {
    v3_8_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_341_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_340_Addr_A.read();
    } else {
        v3_8_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_13_Addr_A_orig() {
    v3_8_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_13_Addr_B() {
    v3_8_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_13_Addr_B_orig() {
    v3_8_13_Addr_B_orig =  (sc_lv<32>) (v3_8_13_addr_reg_61690.read());
}

void kernel_correlation_sdse::thread_v3_8_13_Clk_A() {
    v3_8_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_13_Clk_B() {
    v3_8_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_13_Din_A() {
    v3_8_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_13_Din_B() {
    v3_8_13_Din_B = grp_fu_41995_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_341_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_340_EN_A.read();
    } else {
        v3_8_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_13_EN_B = ap_const_logic_1;
    } else {
        v3_8_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_13_Rst_A() {
    v3_8_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_13_Rst_B() {
    v3_8_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_13_WEN_A() {
    v3_8_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_342_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_341_Addr_A.read();
    } else {
        v3_8_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_14_Addr_A_orig() {
    v3_8_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_14_Addr_B() {
    v3_8_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_14_Addr_B_orig() {
    v3_8_14_Addr_B_orig =  (sc_lv<32>) (v3_8_14_addr_reg_63350.read());
}

void kernel_correlation_sdse::thread_v3_8_14_Clk_A() {
    v3_8_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_14_Clk_B() {
    v3_8_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_14_Din_A() {
    v3_8_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_14_Din_B() {
    v3_8_14_Din_B = grp_fu_42010_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_342_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_341_EN_A.read();
    } else {
        v3_8_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_14_EN_B = ap_const_logic_1;
    } else {
        v3_8_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_14_Rst_A() {
    v3_8_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_14_Rst_B() {
    v3_8_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_14_WEN_A() {
    v3_8_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_343_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_342_Addr_A.read();
    } else {
        v3_8_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_15_Addr_A_orig() {
    v3_8_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_15_Addr_B() {
    v3_8_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_15_Addr_B_orig() {
    v3_8_15_Addr_B_orig =  (sc_lv<32>) (v3_8_15_addr_reg_65010.read());
}

void kernel_correlation_sdse::thread_v3_8_15_Clk_A() {
    v3_8_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_15_Clk_B() {
    v3_8_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_15_Din_A() {
    v3_8_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_15_Din_B() {
    v3_8_15_Din_B = grp_fu_42026_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_343_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_342_EN_A.read();
    } else {
        v3_8_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_15_EN_B = ap_const_logic_1;
    } else {
        v3_8_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_15_Rst_A() {
    v3_8_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_15_Rst_B() {
    v3_8_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_15_WEN_A() {
    v3_8_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_344_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_343_Addr_A.read();
    } else {
        v3_8_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_16_Addr_A_orig() {
    v3_8_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_16_Addr_B() {
    v3_8_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_16_Addr_B_orig() {
    v3_8_16_Addr_B_orig =  (sc_lv<32>) (v3_8_16_addr_reg_60036.read());
}

void kernel_correlation_sdse::thread_v3_8_16_Clk_A() {
    v3_8_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_16_Clk_B() {
    v3_8_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_16_Din_A() {
    v3_8_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_16_Din_B() {
    v3_8_16_Din_B = grp_fu_41980_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_344_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_343_EN_A.read();
    } else {
        v3_8_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_16_EN_B = ap_const_logic_1;
    } else {
        v3_8_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_16_Rst_A() {
    v3_8_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_16_Rst_B() {
    v3_8_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_16_WEN_A() {
    v3_8_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_345_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_344_Addr_A.read();
    } else {
        v3_8_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_17_Addr_A_orig() {
    v3_8_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_17_Addr_B() {
    v3_8_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_17_Addr_B_orig() {
    v3_8_17_Addr_B_orig =  (sc_lv<32>) (v3_8_17_addr_reg_61696.read());
}

void kernel_correlation_sdse::thread_v3_8_17_Clk_A() {
    v3_8_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_17_Clk_B() {
    v3_8_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_17_Din_A() {
    v3_8_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_17_Din_B() {
    v3_8_17_Din_B = grp_fu_41995_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_345_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_344_EN_A.read();
    } else {
        v3_8_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_17_EN_B = ap_const_logic_1;
    } else {
        v3_8_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_17_Rst_A() {
    v3_8_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_17_Rst_B() {
    v3_8_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_17_WEN_A() {
    v3_8_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_346_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_345_Addr_A.read();
    } else {
        v3_8_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_18_Addr_A_orig() {
    v3_8_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_18_Addr_B() {
    v3_8_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_18_Addr_B_orig() {
    v3_8_18_Addr_B_orig =  (sc_lv<32>) (v3_8_18_addr_reg_63356.read());
}

void kernel_correlation_sdse::thread_v3_8_18_Clk_A() {
    v3_8_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_18_Clk_B() {
    v3_8_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_18_Din_A() {
    v3_8_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_18_Din_B() {
    v3_8_18_Din_B = grp_fu_42010_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_346_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_345_EN_A.read();
    } else {
        v3_8_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_18_EN_B = ap_const_logic_1;
    } else {
        v3_8_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_18_Rst_A() {
    v3_8_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_18_Rst_B() {
    v3_8_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_18_WEN_A() {
    v3_8_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_347_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_346_Addr_A.read();
    } else {
        v3_8_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_19_Addr_A_orig() {
    v3_8_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_19_Addr_B() {
    v3_8_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_19_Addr_B_orig() {
    v3_8_19_Addr_B_orig =  (sc_lv<32>) (v3_8_19_addr_reg_65016.read());
}

void kernel_correlation_sdse::thread_v3_8_19_Clk_A() {
    v3_8_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_19_Clk_B() {
    v3_8_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_19_Din_A() {
    v3_8_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_19_Din_B() {
    v3_8_19_Din_B = grp_fu_42026_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_347_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_346_EN_A.read();
    } else {
        v3_8_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_19_EN_B = ap_const_logic_1;
    } else {
        v3_8_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_19_Rst_A() {
    v3_8_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_19_Rst_B() {
    v3_8_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_19_WEN_A() {
    v3_8_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_329_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_328_Addr_A.read();
    } else {
        v3_8_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_1_Addr_A_orig() {
    v3_8_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_1_Addr_B() {
    v3_8_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_1_Addr_B_orig() {
    v3_8_1_Addr_B_orig =  (sc_lv<32>) (v3_8_1_addr_reg_61672.read());
}

void kernel_correlation_sdse::thread_v3_8_1_Clk_A() {
    v3_8_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_1_Clk_B() {
    v3_8_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_1_Din_A() {
    v3_8_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_1_Din_B() {
    v3_8_1_Din_B = grp_fu_41995_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_329_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_328_EN_A.read();
    } else {
        v3_8_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_1_EN_B = ap_const_logic_1;
    } else {
        v3_8_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_1_Rst_A() {
    v3_8_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_1_Rst_B() {
    v3_8_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_1_WEN_A() {
    v3_8_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_348_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_347_Addr_A.read();
    } else {
        v3_8_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_20_Addr_A_orig() {
    v3_8_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_20_Addr_B() {
    v3_8_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_20_Addr_B_orig() {
    v3_8_20_Addr_B_orig =  (sc_lv<32>) (v3_8_20_addr_reg_60042.read());
}

void kernel_correlation_sdse::thread_v3_8_20_Clk_A() {
    v3_8_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_20_Clk_B() {
    v3_8_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_20_Din_A() {
    v3_8_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_20_Din_B() {
    v3_8_20_Din_B = grp_fu_41980_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_348_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_347_EN_A.read();
    } else {
        v3_8_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_20_EN_B = ap_const_logic_1;
    } else {
        v3_8_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_20_Rst_A() {
    v3_8_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_20_Rst_B() {
    v3_8_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_20_WEN_A() {
    v3_8_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_349_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_348_Addr_A.read();
    } else {
        v3_8_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_21_Addr_A_orig() {
    v3_8_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_21_Addr_B() {
    v3_8_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_21_Addr_B_orig() {
    v3_8_21_Addr_B_orig =  (sc_lv<32>) (v3_8_21_addr_reg_61702.read());
}

void kernel_correlation_sdse::thread_v3_8_21_Clk_A() {
    v3_8_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_21_Clk_B() {
    v3_8_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_21_Din_A() {
    v3_8_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_21_Din_B() {
    v3_8_21_Din_B = grp_fu_41995_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_349_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_348_EN_A.read();
    } else {
        v3_8_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_21_EN_B = ap_const_logic_1;
    } else {
        v3_8_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_21_Rst_A() {
    v3_8_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_21_Rst_B() {
    v3_8_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_21_WEN_A() {
    v3_8_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_350_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_349_Addr_A.read();
    } else {
        v3_8_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_22_Addr_A_orig() {
    v3_8_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_22_Addr_B() {
    v3_8_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_22_Addr_B_orig() {
    v3_8_22_Addr_B_orig =  (sc_lv<32>) (v3_8_22_addr_reg_63362.read());
}

void kernel_correlation_sdse::thread_v3_8_22_Clk_A() {
    v3_8_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_22_Clk_B() {
    v3_8_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_22_Din_A() {
    v3_8_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_22_Din_B() {
    v3_8_22_Din_B = grp_fu_42010_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_350_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_349_EN_A.read();
    } else {
        v3_8_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_22_EN_B = ap_const_logic_1;
    } else {
        v3_8_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_22_Rst_A() {
    v3_8_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_22_Rst_B() {
    v3_8_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_22_WEN_A() {
    v3_8_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_351_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_350_Addr_A.read();
    } else {
        v3_8_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_23_Addr_A_orig() {
    v3_8_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_23_Addr_B() {
    v3_8_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_23_Addr_B_orig() {
    v3_8_23_Addr_B_orig =  (sc_lv<32>) (v3_8_23_addr_reg_65022.read());
}

void kernel_correlation_sdse::thread_v3_8_23_Clk_A() {
    v3_8_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_23_Clk_B() {
    v3_8_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_23_Din_A() {
    v3_8_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_23_Din_B() {
    v3_8_23_Din_B = grp_fu_42026_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_351_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_350_EN_A.read();
    } else {
        v3_8_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_23_EN_B = ap_const_logic_1;
    } else {
        v3_8_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_23_Rst_A() {
    v3_8_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_23_Rst_B() {
    v3_8_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_23_WEN_A() {
    v3_8_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_352_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_351_Addr_A.read();
    } else {
        v3_8_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_24_Addr_A_orig() {
    v3_8_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_24_Addr_B() {
    v3_8_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_24_Addr_B_orig() {
    v3_8_24_Addr_B_orig =  (sc_lv<32>) (v3_8_24_addr_reg_60048.read());
}

void kernel_correlation_sdse::thread_v3_8_24_Clk_A() {
    v3_8_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_24_Clk_B() {
    v3_8_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_24_Din_A() {
    v3_8_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_24_Din_B() {
    v3_8_24_Din_B = grp_fu_41980_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_352_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_351_EN_A.read();
    } else {
        v3_8_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_24_EN_B = ap_const_logic_1;
    } else {
        v3_8_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_24_Rst_A() {
    v3_8_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_24_Rst_B() {
    v3_8_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_24_WEN_A() {
    v3_8_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_353_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_352_Addr_A.read();
    } else {
        v3_8_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_25_Addr_A_orig() {
    v3_8_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_25_Addr_B() {
    v3_8_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_25_Addr_B_orig() {
    v3_8_25_Addr_B_orig =  (sc_lv<32>) (v3_8_25_addr_reg_61708.read());
}

void kernel_correlation_sdse::thread_v3_8_25_Clk_A() {
    v3_8_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_25_Clk_B() {
    v3_8_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_25_Din_A() {
    v3_8_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_25_Din_B() {
    v3_8_25_Din_B = grp_fu_41995_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_353_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_352_EN_A.read();
    } else {
        v3_8_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_25_EN_B = ap_const_logic_1;
    } else {
        v3_8_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_25_Rst_A() {
    v3_8_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_25_Rst_B() {
    v3_8_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_25_WEN_A() {
    v3_8_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_354_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_353_Addr_A.read();
    } else {
        v3_8_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_26_Addr_A_orig() {
    v3_8_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_26_Addr_B() {
    v3_8_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_26_Addr_B_orig() {
    v3_8_26_Addr_B_orig =  (sc_lv<32>) (v3_8_26_addr_reg_63368.read());
}

void kernel_correlation_sdse::thread_v3_8_26_Clk_A() {
    v3_8_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_26_Clk_B() {
    v3_8_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_26_Din_A() {
    v3_8_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_26_Din_B() {
    v3_8_26_Din_B = grp_fu_42010_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_354_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_353_EN_A.read();
    } else {
        v3_8_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_26_EN_B = ap_const_logic_1;
    } else {
        v3_8_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_26_Rst_A() {
    v3_8_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_26_Rst_B() {
    v3_8_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_26_WEN_A() {
    v3_8_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_355_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_354_Addr_A.read();
    } else {
        v3_8_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_27_Addr_A_orig() {
    v3_8_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_27_Addr_B() {
    v3_8_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_27_Addr_B_orig() {
    v3_8_27_Addr_B_orig =  (sc_lv<32>) (v3_8_27_addr_reg_65028.read());
}

void kernel_correlation_sdse::thread_v3_8_27_Clk_A() {
    v3_8_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_27_Clk_B() {
    v3_8_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_27_Din_A() {
    v3_8_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_27_Din_B() {
    v3_8_27_Din_B = grp_fu_42026_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_355_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_354_EN_A.read();
    } else {
        v3_8_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_27_EN_B = ap_const_logic_1;
    } else {
        v3_8_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_27_Rst_A() {
    v3_8_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_27_Rst_B() {
    v3_8_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_27_WEN_A() {
    v3_8_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_356_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_355_Addr_A.read();
    } else {
        v3_8_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_28_Addr_A_orig() {
    v3_8_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_28_Addr_B() {
    v3_8_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_28_Addr_B_orig() {
    v3_8_28_Addr_B_orig =  (sc_lv<32>) (v3_8_28_addr_reg_60054.read());
}

void kernel_correlation_sdse::thread_v3_8_28_Clk_A() {
    v3_8_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_28_Clk_B() {
    v3_8_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_28_Din_A() {
    v3_8_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_28_Din_B() {
    v3_8_28_Din_B = grp_fu_41980_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_356_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_355_EN_A.read();
    } else {
        v3_8_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_28_EN_B = ap_const_logic_1;
    } else {
        v3_8_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_28_Rst_A() {
    v3_8_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_28_Rst_B() {
    v3_8_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_28_WEN_A() {
    v3_8_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_357_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_356_Addr_A.read();
    } else {
        v3_8_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_8_29_Addr_A_orig() {
    v3_8_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_8_29_Addr_B() {
    v3_8_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_8_29_Addr_B_orig() {
    v3_8_29_Addr_B_orig =  (sc_lv<32>) (v3_8_29_addr_reg_61714.read());
}

void kernel_correlation_sdse::thread_v3_8_29_Clk_A() {
    v3_8_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_29_Clk_B() {
    v3_8_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_8_29_Din_A() {
    v3_8_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_8_29_Din_B() {
    v3_8_29_Din_B = grp_fu_41995_p2.read();
}

void kernel_correlation_sdse::thread_v3_8_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_8_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_8_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_357_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_8_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_356_EN_A.read();
    } else {
        v3_8_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_29_EN_B = ap_const_logic_1;
    } else {
        v3_8_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_8_29_Rst_A() {
    v3_8_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_29_Rst_B() {
    v3_8_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_8_29_WEN_A() {
    v3_8_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_8_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_8_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_29_WEN_B = ap_const_lv4_0;
    }
}

}


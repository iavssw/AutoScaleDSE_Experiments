#include "kernel_correlation_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_correlation_sdse::thread_v3_20_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_819_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_818_Addr_A.read();
    } else {
        v3_20_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_11_Addr_A_orig() {
    v3_20_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_11_Addr_B() {
    v3_20_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_11_Addr_B_orig() {
    v3_20_11_Addr_B_orig =  (sc_lv<32>) (v3_20_11_addr_reg_65724.read());
}

void kernel_correlation_sdse::thread_v3_20_11_Clk_A() {
    v3_20_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_11_Clk_B() {
    v3_20_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_11_Din_A() {
    v3_20_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_11_Din_B() {
    v3_20_11_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_819_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_818_EN_A.read();
    } else {
        v3_20_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_11_EN_B = ap_const_logic_1;
    } else {
        v3_20_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_11_Rst_A() {
    v3_20_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_11_Rst_B() {
    v3_20_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_11_WEN_A() {
    v3_20_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_820_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_819_Addr_A.read();
    } else {
        v3_20_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_12_Addr_A_orig() {
    v3_20_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_12_Addr_B() {
    v3_20_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_12_Addr_B_orig() {
    v3_20_12_Addr_B_orig =  (sc_lv<32>) (v3_20_12_addr_reg_60750.read());
}

void kernel_correlation_sdse::thread_v3_20_12_Clk_A() {
    v3_20_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_12_Clk_B() {
    v3_20_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_12_Din_A() {
    v3_20_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_12_Din_B() {
    v3_20_12_Din_B = grp_fu_42724_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_820_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_819_EN_A.read();
    } else {
        v3_20_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_12_EN_B = ap_const_logic_1;
    } else {
        v3_20_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_12_Rst_A() {
    v3_20_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_12_Rst_B() {
    v3_20_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_12_WEN_A() {
    v3_20_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_821_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_820_Addr_A.read();
    } else {
        v3_20_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_13_Addr_A_orig() {
    v3_20_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_13_Addr_B() {
    v3_20_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_13_Addr_B_orig() {
    v3_20_13_Addr_B_orig =  (sc_lv<32>) (v3_20_13_addr_reg_62410.read());
}

void kernel_correlation_sdse::thread_v3_20_13_Clk_A() {
    v3_20_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_13_Clk_B() {
    v3_20_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_13_Din_A() {
    v3_20_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_13_Din_B() {
    v3_20_13_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_821_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_820_EN_A.read();
    } else {
        v3_20_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_13_EN_B = ap_const_logic_1;
    } else {
        v3_20_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_13_Rst_A() {
    v3_20_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_13_Rst_B() {
    v3_20_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_13_WEN_A() {
    v3_20_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_822_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_821_Addr_A.read();
    } else {
        v3_20_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_14_Addr_A_orig() {
    v3_20_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_14_Addr_B() {
    v3_20_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_14_Addr_B_orig() {
    v3_20_14_Addr_B_orig =  (sc_lv<32>) (v3_20_14_addr_reg_64070.read());
}

void kernel_correlation_sdse::thread_v3_20_14_Clk_A() {
    v3_20_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_14_Clk_B() {
    v3_20_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_14_Din_A() {
    v3_20_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_14_Din_B() {
    v3_20_14_Din_B = grp_fu_42754_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_822_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_821_EN_A.read();
    } else {
        v3_20_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_14_EN_B = ap_const_logic_1;
    } else {
        v3_20_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_14_Rst_A() {
    v3_20_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_14_Rst_B() {
    v3_20_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_14_WEN_A() {
    v3_20_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_823_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_822_Addr_A.read();
    } else {
        v3_20_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_15_Addr_A_orig() {
    v3_20_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_15_Addr_B() {
    v3_20_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_15_Addr_B_orig() {
    v3_20_15_Addr_B_orig =  (sc_lv<32>) (v3_20_15_addr_reg_65730.read());
}

void kernel_correlation_sdse::thread_v3_20_15_Clk_A() {
    v3_20_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_15_Clk_B() {
    v3_20_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_15_Din_A() {
    v3_20_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_15_Din_B() {
    v3_20_15_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_823_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_822_EN_A.read();
    } else {
        v3_20_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_15_EN_B = ap_const_logic_1;
    } else {
        v3_20_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_15_Rst_A() {
    v3_20_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_15_Rst_B() {
    v3_20_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_15_WEN_A() {
    v3_20_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_824_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_823_Addr_A.read();
    } else {
        v3_20_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_16_Addr_A_orig() {
    v3_20_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_16_Addr_B() {
    v3_20_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_16_Addr_B_orig() {
    v3_20_16_Addr_B_orig =  (sc_lv<32>) (v3_20_16_addr_reg_60756.read());
}

void kernel_correlation_sdse::thread_v3_20_16_Clk_A() {
    v3_20_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_16_Clk_B() {
    v3_20_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_16_Din_A() {
    v3_20_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_16_Din_B() {
    v3_20_16_Din_B = grp_fu_42724_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_824_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_823_EN_A.read();
    } else {
        v3_20_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_16_EN_B = ap_const_logic_1;
    } else {
        v3_20_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_16_Rst_A() {
    v3_20_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_16_Rst_B() {
    v3_20_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_16_WEN_A() {
    v3_20_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_825_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_824_Addr_A.read();
    } else {
        v3_20_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_17_Addr_A_orig() {
    v3_20_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_17_Addr_B() {
    v3_20_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_17_Addr_B_orig() {
    v3_20_17_Addr_B_orig =  (sc_lv<32>) (v3_20_17_addr_reg_62416.read());
}

void kernel_correlation_sdse::thread_v3_20_17_Clk_A() {
    v3_20_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_17_Clk_B() {
    v3_20_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_17_Din_A() {
    v3_20_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_17_Din_B() {
    v3_20_17_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_825_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_824_EN_A.read();
    } else {
        v3_20_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_17_EN_B = ap_const_logic_1;
    } else {
        v3_20_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_17_Rst_A() {
    v3_20_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_17_Rst_B() {
    v3_20_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_17_WEN_A() {
    v3_20_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_826_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_825_Addr_A.read();
    } else {
        v3_20_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_18_Addr_A_orig() {
    v3_20_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_18_Addr_B() {
    v3_20_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_18_Addr_B_orig() {
    v3_20_18_Addr_B_orig =  (sc_lv<32>) (v3_20_18_addr_reg_64076.read());
}

void kernel_correlation_sdse::thread_v3_20_18_Clk_A() {
    v3_20_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_18_Clk_B() {
    v3_20_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_18_Din_A() {
    v3_20_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_18_Din_B() {
    v3_20_18_Din_B = grp_fu_42754_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_826_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_825_EN_A.read();
    } else {
        v3_20_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_18_EN_B = ap_const_logic_1;
    } else {
        v3_20_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_18_Rst_A() {
    v3_20_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_18_Rst_B() {
    v3_20_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_18_WEN_A() {
    v3_20_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_827_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_826_Addr_A.read();
    } else {
        v3_20_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_19_Addr_A_orig() {
    v3_20_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_19_Addr_B() {
    v3_20_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_19_Addr_B_orig() {
    v3_20_19_Addr_B_orig =  (sc_lv<32>) (v3_20_19_addr_reg_65736.read());
}

void kernel_correlation_sdse::thread_v3_20_19_Clk_A() {
    v3_20_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_19_Clk_B() {
    v3_20_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_19_Din_A() {
    v3_20_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_19_Din_B() {
    v3_20_19_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_827_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_826_EN_A.read();
    } else {
        v3_20_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_19_EN_B = ap_const_logic_1;
    } else {
        v3_20_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_19_Rst_A() {
    v3_20_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_19_Rst_B() {
    v3_20_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_19_WEN_A() {
    v3_20_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_809_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_808_Addr_A.read();
    } else {
        v3_20_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_1_Addr_A_orig() {
    v3_20_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_1_Addr_B() {
    v3_20_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_1_Addr_B_orig() {
    v3_20_1_Addr_B_orig =  (sc_lv<32>) (v3_20_1_addr_reg_62392.read());
}

void kernel_correlation_sdse::thread_v3_20_1_Clk_A() {
    v3_20_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_1_Clk_B() {
    v3_20_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_1_Din_A() {
    v3_20_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_1_Din_B() {
    v3_20_1_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_809_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_808_EN_A.read();
    } else {
        v3_20_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_1_EN_B = ap_const_logic_1;
    } else {
        v3_20_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_1_Rst_A() {
    v3_20_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_1_Rst_B() {
    v3_20_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_1_WEN_A() {
    v3_20_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_828_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_827_Addr_A.read();
    } else {
        v3_20_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_20_Addr_A_orig() {
    v3_20_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_20_Addr_B() {
    v3_20_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_20_Addr_B_orig() {
    v3_20_20_Addr_B_orig =  (sc_lv<32>) (v3_20_20_addr_reg_60762.read());
}

void kernel_correlation_sdse::thread_v3_20_20_Clk_A() {
    v3_20_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_20_Clk_B() {
    v3_20_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_20_Din_A() {
    v3_20_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_20_Din_B() {
    v3_20_20_Din_B = grp_fu_42724_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_828_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_827_EN_A.read();
    } else {
        v3_20_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_20_EN_B = ap_const_logic_1;
    } else {
        v3_20_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_20_Rst_A() {
    v3_20_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_20_Rst_B() {
    v3_20_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_20_WEN_A() {
    v3_20_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_829_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_828_Addr_A.read();
    } else {
        v3_20_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_21_Addr_A_orig() {
    v3_20_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_21_Addr_B() {
    v3_20_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_21_Addr_B_orig() {
    v3_20_21_Addr_B_orig =  (sc_lv<32>) (v3_20_21_addr_reg_62422.read());
}

void kernel_correlation_sdse::thread_v3_20_21_Clk_A() {
    v3_20_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_21_Clk_B() {
    v3_20_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_21_Din_A() {
    v3_20_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_21_Din_B() {
    v3_20_21_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_829_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_828_EN_A.read();
    } else {
        v3_20_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_21_EN_B = ap_const_logic_1;
    } else {
        v3_20_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_21_Rst_A() {
    v3_20_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_21_Rst_B() {
    v3_20_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_21_WEN_A() {
    v3_20_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_830_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_829_Addr_A.read();
    } else {
        v3_20_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_22_Addr_A_orig() {
    v3_20_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_22_Addr_B() {
    v3_20_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_22_Addr_B_orig() {
    v3_20_22_Addr_B_orig =  (sc_lv<32>) (v3_20_22_addr_reg_64082.read());
}

void kernel_correlation_sdse::thread_v3_20_22_Clk_A() {
    v3_20_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_22_Clk_B() {
    v3_20_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_22_Din_A() {
    v3_20_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_22_Din_B() {
    v3_20_22_Din_B = grp_fu_42754_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_830_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_829_EN_A.read();
    } else {
        v3_20_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_22_EN_B = ap_const_logic_1;
    } else {
        v3_20_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_22_Rst_A() {
    v3_20_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_22_Rst_B() {
    v3_20_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_22_WEN_A() {
    v3_20_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_831_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_830_Addr_A.read();
    } else {
        v3_20_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_23_Addr_A_orig() {
    v3_20_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_23_Addr_B() {
    v3_20_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_23_Addr_B_orig() {
    v3_20_23_Addr_B_orig =  (sc_lv<32>) (v3_20_23_addr_reg_65742.read());
}

void kernel_correlation_sdse::thread_v3_20_23_Clk_A() {
    v3_20_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_23_Clk_B() {
    v3_20_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_23_Din_A() {
    v3_20_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_23_Din_B() {
    v3_20_23_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_831_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_830_EN_A.read();
    } else {
        v3_20_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_23_EN_B = ap_const_logic_1;
    } else {
        v3_20_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_23_Rst_A() {
    v3_20_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_23_Rst_B() {
    v3_20_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_23_WEN_A() {
    v3_20_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_832_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_831_Addr_A.read();
    } else {
        v3_20_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_24_Addr_A_orig() {
    v3_20_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_24_Addr_B() {
    v3_20_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_24_Addr_B_orig() {
    v3_20_24_Addr_B_orig =  (sc_lv<32>) (v3_20_24_addr_reg_60768.read());
}

void kernel_correlation_sdse::thread_v3_20_24_Clk_A() {
    v3_20_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_24_Clk_B() {
    v3_20_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_24_Din_A() {
    v3_20_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_24_Din_B() {
    v3_20_24_Din_B = grp_fu_42724_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_832_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_831_EN_A.read();
    } else {
        v3_20_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_24_EN_B = ap_const_logic_1;
    } else {
        v3_20_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_24_Rst_A() {
    v3_20_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_24_Rst_B() {
    v3_20_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_24_WEN_A() {
    v3_20_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_833_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_832_Addr_A.read();
    } else {
        v3_20_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_25_Addr_A_orig() {
    v3_20_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_25_Addr_B() {
    v3_20_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_25_Addr_B_orig() {
    v3_20_25_Addr_B_orig =  (sc_lv<32>) (v3_20_25_addr_reg_62428.read());
}

void kernel_correlation_sdse::thread_v3_20_25_Clk_A() {
    v3_20_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_25_Clk_B() {
    v3_20_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_25_Din_A() {
    v3_20_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_25_Din_B() {
    v3_20_25_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_833_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_832_EN_A.read();
    } else {
        v3_20_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_25_EN_B = ap_const_logic_1;
    } else {
        v3_20_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_25_Rst_A() {
    v3_20_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_25_Rst_B() {
    v3_20_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_25_WEN_A() {
    v3_20_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_834_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_833_Addr_A.read();
    } else {
        v3_20_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_26_Addr_A_orig() {
    v3_20_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_26_Addr_B() {
    v3_20_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_26_Addr_B_orig() {
    v3_20_26_Addr_B_orig =  (sc_lv<32>) (v3_20_26_addr_reg_64088.read());
}

void kernel_correlation_sdse::thread_v3_20_26_Clk_A() {
    v3_20_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_26_Clk_B() {
    v3_20_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_26_Din_A() {
    v3_20_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_26_Din_B() {
    v3_20_26_Din_B = grp_fu_42754_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_834_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_833_EN_A.read();
    } else {
        v3_20_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_26_EN_B = ap_const_logic_1;
    } else {
        v3_20_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_26_Rst_A() {
    v3_20_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_26_Rst_B() {
    v3_20_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_26_WEN_A() {
    v3_20_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_835_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_834_Addr_A.read();
    } else {
        v3_20_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_27_Addr_A_orig() {
    v3_20_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_27_Addr_B() {
    v3_20_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_27_Addr_B_orig() {
    v3_20_27_Addr_B_orig =  (sc_lv<32>) (v3_20_27_addr_reg_65748.read());
}

void kernel_correlation_sdse::thread_v3_20_27_Clk_A() {
    v3_20_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_27_Clk_B() {
    v3_20_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_27_Din_A() {
    v3_20_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_27_Din_B() {
    v3_20_27_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_835_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_834_EN_A.read();
    } else {
        v3_20_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_27_EN_B = ap_const_logic_1;
    } else {
        v3_20_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_27_Rst_A() {
    v3_20_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_27_Rst_B() {
    v3_20_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_27_WEN_A() {
    v3_20_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_836_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_835_Addr_A.read();
    } else {
        v3_20_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_28_Addr_A_orig() {
    v3_20_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_28_Addr_B() {
    v3_20_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_28_Addr_B_orig() {
    v3_20_28_Addr_B_orig =  (sc_lv<32>) (v3_20_28_addr_reg_60774.read());
}

void kernel_correlation_sdse::thread_v3_20_28_Clk_A() {
    v3_20_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_28_Clk_B() {
    v3_20_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_28_Din_A() {
    v3_20_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_28_Din_B() {
    v3_20_28_Din_B = grp_fu_42724_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_836_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_835_EN_A.read();
    } else {
        v3_20_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_28_EN_B = ap_const_logic_1;
    } else {
        v3_20_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_28_Rst_A() {
    v3_20_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_28_Rst_B() {
    v3_20_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_28_WEN_A() {
    v3_20_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_837_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_836_Addr_A.read();
    } else {
        v3_20_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_29_Addr_A_orig() {
    v3_20_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_29_Addr_B() {
    v3_20_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_29_Addr_B_orig() {
    v3_20_29_Addr_B_orig =  (sc_lv<32>) (v3_20_29_addr_reg_62434.read());
}

void kernel_correlation_sdse::thread_v3_20_29_Clk_A() {
    v3_20_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_29_Clk_B() {
    v3_20_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_29_Din_A() {
    v3_20_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_29_Din_B() {
    v3_20_29_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_837_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_836_EN_A.read();
    } else {
        v3_20_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_29_EN_B = ap_const_logic_1;
    } else {
        v3_20_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_29_Rst_A() {
    v3_20_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_29_Rst_B() {
    v3_20_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_29_WEN_A() {
    v3_20_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_810_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_809_Addr_A.read();
    } else {
        v3_20_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_2_Addr_A_orig() {
    v3_20_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_2_Addr_B() {
    v3_20_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_2_Addr_B_orig() {
    v3_20_2_Addr_B_orig =  (sc_lv<32>) (v3_20_2_addr_reg_64052.read());
}

void kernel_correlation_sdse::thread_v3_20_2_Clk_A() {
    v3_20_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_2_Clk_B() {
    v3_20_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_2_Din_A() {
    v3_20_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_2_Din_B() {
    v3_20_2_Din_B = grp_fu_42754_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_810_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_809_EN_A.read();
    } else {
        v3_20_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_2_EN_B = ap_const_logic_1;
    } else {
        v3_20_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_2_Rst_A() {
    v3_20_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_2_Rst_B() {
    v3_20_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_2_WEN_A() {
    v3_20_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_838_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_837_Addr_A.read();
    } else {
        v3_20_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_30_Addr_A_orig() {
    v3_20_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_30_Addr_B() {
    v3_20_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_30_Addr_B_orig() {
    v3_20_30_Addr_B_orig =  (sc_lv<32>) (v3_20_30_addr_reg_64094.read());
}

void kernel_correlation_sdse::thread_v3_20_30_Clk_A() {
    v3_20_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_30_Clk_B() {
    v3_20_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_30_Din_A() {
    v3_20_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_30_Din_B() {
    v3_20_30_Din_B = grp_fu_42754_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_838_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_837_EN_A.read();
    } else {
        v3_20_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_30_EN_B = ap_const_logic_1;
    } else {
        v3_20_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_30_Rst_A() {
    v3_20_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_30_Rst_B() {
    v3_20_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_30_WEN_A() {
    v3_20_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_839_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_838_Addr_A.read();
    } else {
        v3_20_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_31_Addr_A_orig() {
    v3_20_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_31_Addr_B() {
    v3_20_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_31_Addr_B_orig() {
    v3_20_31_Addr_B_orig =  (sc_lv<32>) (v3_20_31_addr_reg_65754.read());
}

void kernel_correlation_sdse::thread_v3_20_31_Clk_A() {
    v3_20_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_31_Clk_B() {
    v3_20_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_31_Din_A() {
    v3_20_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_31_Din_B() {
    v3_20_31_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_839_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_838_EN_A.read();
    } else {
        v3_20_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_31_EN_B = ap_const_logic_1;
    } else {
        v3_20_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_31_Rst_A() {
    v3_20_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_31_Rst_B() {
    v3_20_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_31_WEN_A() {
    v3_20_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_31_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_32_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_840_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_839_Addr_A.read();
    } else {
        v3_20_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_32_Addr_A_orig() {
    v3_20_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_32_Addr_B() {
    v3_20_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_32_Addr_B_orig() {
    v3_20_32_Addr_B_orig =  (sc_lv<32>) (v3_20_32_addr_reg_60780.read());
}

void kernel_correlation_sdse::thread_v3_20_32_Clk_A() {
    v3_20_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_32_Clk_B() {
    v3_20_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_32_Din_A() {
    v3_20_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_32_Din_B() {
    v3_20_32_Din_B = grp_fu_42724_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_32_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_840_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_839_EN_A.read();
    } else {
        v3_20_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_32_EN_B = ap_const_logic_1;
    } else {
        v3_20_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_32_Rst_A() {
    v3_20_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_32_Rst_B() {
    v3_20_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_32_WEN_A() {
    v3_20_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_32_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_33_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_841_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_840_Addr_A.read();
    } else {
        v3_20_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_33_Addr_A_orig() {
    v3_20_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_33_Addr_B() {
    v3_20_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_33_Addr_B_orig() {
    v3_20_33_Addr_B_orig =  (sc_lv<32>) (v3_20_33_addr_reg_62440.read());
}

void kernel_correlation_sdse::thread_v3_20_33_Clk_A() {
    v3_20_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_33_Clk_B() {
    v3_20_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_33_Din_A() {
    v3_20_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_33_Din_B() {
    v3_20_33_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_33_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_841_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_840_EN_A.read();
    } else {
        v3_20_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_33_EN_B = ap_const_logic_1;
    } else {
        v3_20_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_33_Rst_A() {
    v3_20_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_33_Rst_B() {
    v3_20_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_33_WEN_A() {
    v3_20_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_33_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_34_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_842_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_841_Addr_A.read();
    } else {
        v3_20_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_34_Addr_A_orig() {
    v3_20_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_34_Addr_B() {
    v3_20_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_34_Addr_B_orig() {
    v3_20_34_Addr_B_orig =  (sc_lv<32>) (v3_20_34_addr_reg_64100.read());
}

void kernel_correlation_sdse::thread_v3_20_34_Clk_A() {
    v3_20_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_34_Clk_B() {
    v3_20_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_34_Din_A() {
    v3_20_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_34_Din_B() {
    v3_20_34_Din_B = grp_fu_42754_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_34_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_842_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_841_EN_A.read();
    } else {
        v3_20_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_34_EN_B = ap_const_logic_1;
    } else {
        v3_20_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_34_Rst_A() {
    v3_20_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_34_Rst_B() {
    v3_20_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_34_WEN_A() {
    v3_20_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_34_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_35_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_843_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_842_Addr_A.read();
    } else {
        v3_20_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_35_Addr_A_orig() {
    v3_20_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_35_Addr_B() {
    v3_20_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_35_Addr_B_orig() {
    v3_20_35_Addr_B_orig =  (sc_lv<32>) (v3_20_35_addr_reg_65760.read());
}

void kernel_correlation_sdse::thread_v3_20_35_Clk_A() {
    v3_20_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_35_Clk_B() {
    v3_20_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_35_Din_A() {
    v3_20_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_35_Din_B() {
    v3_20_35_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_35_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_843_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_842_EN_A.read();
    } else {
        v3_20_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_35_EN_B = ap_const_logic_1;
    } else {
        v3_20_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_35_Rst_A() {
    v3_20_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_35_Rst_B() {
    v3_20_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_35_WEN_A() {
    v3_20_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_35_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_36_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_844_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_843_Addr_A.read();
    } else {
        v3_20_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_36_Addr_A_orig() {
    v3_20_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_36_Addr_B() {
    v3_20_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_36_Addr_B_orig() {
    v3_20_36_Addr_B_orig =  (sc_lv<32>) (v3_20_36_addr_reg_60786.read());
}

void kernel_correlation_sdse::thread_v3_20_36_Clk_A() {
    v3_20_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_36_Clk_B() {
    v3_20_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_36_Din_A() {
    v3_20_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_36_Din_B() {
    v3_20_36_Din_B = grp_fu_42724_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_36_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_844_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_843_EN_A.read();
    } else {
        v3_20_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_36_EN_B = ap_const_logic_1;
    } else {
        v3_20_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_36_Rst_A() {
    v3_20_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_36_Rst_B() {
    v3_20_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_36_WEN_A() {
    v3_20_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_36_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_37_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_845_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_844_Addr_A.read();
    } else {
        v3_20_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_37_Addr_A_orig() {
    v3_20_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_37_Addr_B() {
    v3_20_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_37_Addr_B_orig() {
    v3_20_37_Addr_B_orig =  (sc_lv<32>) (v3_20_37_addr_reg_62446.read());
}

void kernel_correlation_sdse::thread_v3_20_37_Clk_A() {
    v3_20_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_37_Clk_B() {
    v3_20_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_37_Din_A() {
    v3_20_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_37_Din_B() {
    v3_20_37_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_845_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_844_EN_A.read();
    } else {
        v3_20_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_37_EN_B = ap_const_logic_1;
    } else {
        v3_20_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_37_Rst_A() {
    v3_20_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_37_Rst_B() {
    v3_20_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_37_WEN_A() {
    v3_20_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_846_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_845_Addr_A.read();
    } else {
        v3_20_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_38_Addr_A_orig() {
    v3_20_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_38_Addr_B() {
    v3_20_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_38_Addr_B_orig() {
    v3_20_38_Addr_B_orig =  (sc_lv<32>) (v3_20_38_addr_reg_64106.read());
}

void kernel_correlation_sdse::thread_v3_20_38_Clk_A() {
    v3_20_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_38_Clk_B() {
    v3_20_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_38_Din_A() {
    v3_20_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_38_Din_B() {
    v3_20_38_Din_B = grp_fu_42754_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_846_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_845_EN_A.read();
    } else {
        v3_20_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_38_EN_B = ap_const_logic_1;
    } else {
        v3_20_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_38_Rst_A() {
    v3_20_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_38_Rst_B() {
    v3_20_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_38_WEN_A() {
    v3_20_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_847_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_846_Addr_A.read();
    } else {
        v3_20_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_39_Addr_A_orig() {
    v3_20_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_39_Addr_B() {
    v3_20_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_39_Addr_B_orig() {
    v3_20_39_Addr_B_orig =  (sc_lv<32>) (v3_20_39_addr_reg_65766.read());
}

void kernel_correlation_sdse::thread_v3_20_39_Clk_A() {
    v3_20_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_39_Clk_B() {
    v3_20_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_39_Din_A() {
    v3_20_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_39_Din_B() {
    v3_20_39_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_847_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_846_EN_A.read();
    } else {
        v3_20_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_39_EN_B = ap_const_logic_1;
    } else {
        v3_20_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_39_Rst_A() {
    v3_20_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_39_Rst_B() {
    v3_20_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_39_WEN_A() {
    v3_20_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_811_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_810_Addr_A.read();
    } else {
        v3_20_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_3_Addr_A_orig() {
    v3_20_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_3_Addr_B() {
    v3_20_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_3_Addr_B_orig() {
    v3_20_3_Addr_B_orig =  (sc_lv<32>) (v3_20_3_addr_reg_65712.read());
}

void kernel_correlation_sdse::thread_v3_20_3_Clk_A() {
    v3_20_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_3_Clk_B() {
    v3_20_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_3_Din_A() {
    v3_20_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_3_Din_B() {
    v3_20_3_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_811_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_810_EN_A.read();
    } else {
        v3_20_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_3_EN_B = ap_const_logic_1;
    } else {
        v3_20_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_3_Rst_A() {
    v3_20_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_3_Rst_B() {
    v3_20_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_3_WEN_A() {
    v3_20_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_812_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_811_Addr_A.read();
    } else {
        v3_20_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_4_Addr_A_orig() {
    v3_20_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_4_Addr_B() {
    v3_20_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_4_Addr_B_orig() {
    v3_20_4_Addr_B_orig =  (sc_lv<32>) (v3_20_4_addr_reg_60738.read());
}

void kernel_correlation_sdse::thread_v3_20_4_Clk_A() {
    v3_20_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_4_Clk_B() {
    v3_20_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_4_Din_A() {
    v3_20_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_4_Din_B() {
    v3_20_4_Din_B = grp_fu_42724_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_812_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_811_EN_A.read();
    } else {
        v3_20_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_4_EN_B = ap_const_logic_1;
    } else {
        v3_20_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_4_Rst_A() {
    v3_20_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_4_Rst_B() {
    v3_20_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_4_WEN_A() {
    v3_20_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_813_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_812_Addr_A.read();
    } else {
        v3_20_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_5_Addr_A_orig() {
    v3_20_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_5_Addr_B() {
    v3_20_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_5_Addr_B_orig() {
    v3_20_5_Addr_B_orig =  (sc_lv<32>) (v3_20_5_addr_reg_62398.read());
}

void kernel_correlation_sdse::thread_v3_20_5_Clk_A() {
    v3_20_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_5_Clk_B() {
    v3_20_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_5_Din_A() {
    v3_20_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_5_Din_B() {
    v3_20_5_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_813_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_812_EN_A.read();
    } else {
        v3_20_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_5_EN_B = ap_const_logic_1;
    } else {
        v3_20_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_5_Rst_A() {
    v3_20_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_5_Rst_B() {
    v3_20_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_5_WEN_A() {
    v3_20_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_814_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_813_Addr_A.read();
    } else {
        v3_20_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_6_Addr_A_orig() {
    v3_20_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_6_Addr_B() {
    v3_20_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_6_Addr_B_orig() {
    v3_20_6_Addr_B_orig =  (sc_lv<32>) (v3_20_6_addr_reg_64058.read());
}

void kernel_correlation_sdse::thread_v3_20_6_Clk_A() {
    v3_20_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_6_Clk_B() {
    v3_20_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_6_Din_A() {
    v3_20_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_6_Din_B() {
    v3_20_6_Din_B = grp_fu_42754_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_814_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_813_EN_A.read();
    } else {
        v3_20_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_6_EN_B = ap_const_logic_1;
    } else {
        v3_20_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_6_Rst_A() {
    v3_20_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_6_Rst_B() {
    v3_20_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_6_WEN_A() {
    v3_20_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_6_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_815_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_814_Addr_A.read();
    } else {
        v3_20_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_7_Addr_A_orig() {
    v3_20_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_7_Addr_B() {
    v3_20_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_7_Addr_B_orig() {
    v3_20_7_Addr_B_orig =  (sc_lv<32>) (v3_20_7_addr_reg_65718.read());
}

void kernel_correlation_sdse::thread_v3_20_7_Clk_A() {
    v3_20_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_7_Clk_B() {
    v3_20_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_7_Din_A() {
    v3_20_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_7_Din_B() {
    v3_20_7_Din_B = grp_fu_42770_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_815_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_814_EN_A.read();
    } else {
        v3_20_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_7_EN_B = ap_const_logic_1;
    } else {
        v3_20_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_7_Rst_A() {
    v3_20_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_7_Rst_B() {
    v3_20_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_7_WEN_A() {
    v3_20_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_7_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_816_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_815_Addr_A.read();
    } else {
        v3_20_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_8_Addr_A_orig() {
    v3_20_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_8_Addr_B() {
    v3_20_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_8_Addr_B_orig() {
    v3_20_8_Addr_B_orig =  (sc_lv<32>) (v3_20_8_addr_reg_60744.read());
}

void kernel_correlation_sdse::thread_v3_20_8_Clk_A() {
    v3_20_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_8_Clk_B() {
    v3_20_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_8_Din_A() {
    v3_20_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_8_Din_B() {
    v3_20_8_Din_B = grp_fu_42724_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_816_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_815_EN_A.read();
    } else {
        v3_20_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_8_EN_B = ap_const_logic_1;
    } else {
        v3_20_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_8_Rst_A() {
    v3_20_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_8_Rst_B() {
    v3_20_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_8_WEN_A() {
    v3_20_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_8_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_817_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_816_Addr_A.read();
    } else {
        v3_20_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_20_9_Addr_A_orig() {
    v3_20_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_20_9_Addr_B() {
    v3_20_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_20_9_Addr_B_orig() {
    v3_20_9_Addr_B_orig =  (sc_lv<32>) (v3_20_9_addr_reg_62404.read());
}

void kernel_correlation_sdse::thread_v3_20_9_Clk_A() {
    v3_20_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_9_Clk_B() {
    v3_20_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_20_9_Din_A() {
    v3_20_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_20_9_Din_B() {
    v3_20_9_Din_B = grp_fu_42739_p2.read();
}

void kernel_correlation_sdse::thread_v3_20_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_20_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_20_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_817_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_20_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_816_EN_A.read();
    } else {
        v3_20_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_9_EN_B = ap_const_logic_1;
    } else {
        v3_20_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_20_9_Rst_A() {
    v3_20_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_9_Rst_B() {
    v3_20_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_20_9_WEN_A() {
    v3_20_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_20_9_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_20_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_887_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_848_Addr_A.read();
    } else {
        v3_21_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_0_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_0_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_0_Addr_B() {
    v3_21_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_0_Addr_B_orig() {
    v3_21_0_Addr_B_orig =  (sc_lv<32>) (v3_21_0_addr_2_reg_60792.read());
}

void kernel_correlation_sdse::thread_v3_21_0_Clk_A() {
    v3_21_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_0_Clk_B() {
    v3_21_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_0_Din_A() {
    v3_21_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_0_Din_B() {
    v3_21_0_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_887_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_848_EN_A.read();
    } else {
        v3_21_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_0_EN_B = ap_const_logic_1;
    } else {
        v3_21_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_0_Rst_A() {
    v3_21_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_0_Rst_B() {
    v3_21_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_0_WEN_A() {
    v3_21_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_858_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_857_Addr_A.read();
    } else {
        v3_21_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_10_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_10_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_10_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_10_Addr_B() {
    v3_21_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_10_Addr_B_orig() {
    v3_21_10_Addr_B_orig =  (sc_lv<32>) (v3_21_10_addr_2_reg_64124.read());
}

void kernel_correlation_sdse::thread_v3_21_10_Clk_A() {
    v3_21_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_10_Clk_B() {
    v3_21_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_10_Din_A() {
    v3_21_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_10_Din_B() {
    v3_21_10_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_10_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_858_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_857_EN_A.read();
    } else {
        v3_21_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_10_EN_B = ap_const_logic_1;
    } else {
        v3_21_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_10_Rst_A() {
    v3_21_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_10_Rst_B() {
    v3_21_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_10_WEN_A() {
    v3_21_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_859_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_858_Addr_A.read();
    } else {
        v3_21_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_11_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_11_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_11_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_11_Addr_B() {
    v3_21_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_11_Addr_B_orig() {
    v3_21_11_Addr_B_orig =  (sc_lv<32>) (v3_21_11_addr_2_reg_65784.read());
}

void kernel_correlation_sdse::thread_v3_21_11_Clk_A() {
    v3_21_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_11_Clk_B() {
    v3_21_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_11_Din_A() {
    v3_21_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_11_Din_B() {
    v3_21_11_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_11_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_859_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_858_EN_A.read();
    } else {
        v3_21_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_11_EN_B = ap_const_logic_1;
    } else {
        v3_21_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_11_Rst_A() {
    v3_21_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_11_Rst_B() {
    v3_21_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_11_WEN_A() {
    v3_21_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_860_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_859_Addr_A.read();
    } else {
        v3_21_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_12_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_12_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_12_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_12_Addr_B() {
    v3_21_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_12_Addr_B_orig() {
    v3_21_12_Addr_B_orig =  (sc_lv<32>) (v3_21_12_addr_2_reg_60810.read());
}

void kernel_correlation_sdse::thread_v3_21_12_Clk_A() {
    v3_21_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_12_Clk_B() {
    v3_21_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_12_Din_A() {
    v3_21_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_12_Din_B() {
    v3_21_12_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_12_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_860_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_859_EN_A.read();
    } else {
        v3_21_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_12_EN_B = ap_const_logic_1;
    } else {
        v3_21_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_12_Rst_A() {
    v3_21_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_12_Rst_B() {
    v3_21_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_12_WEN_A() {
    v3_21_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_861_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_860_Addr_A.read();
    } else {
        v3_21_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_13_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_13_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_13_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_13_Addr_B() {
    v3_21_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_13_Addr_B_orig() {
    v3_21_13_Addr_B_orig =  (sc_lv<32>) (v3_21_13_addr_2_reg_62470.read());
}

void kernel_correlation_sdse::thread_v3_21_13_Clk_A() {
    v3_21_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_13_Clk_B() {
    v3_21_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_13_Din_A() {
    v3_21_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_13_Din_B() {
    v3_21_13_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_13_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_861_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_860_EN_A.read();
    } else {
        v3_21_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_13_EN_B = ap_const_logic_1;
    } else {
        v3_21_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_13_Rst_A() {
    v3_21_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_13_Rst_B() {
    v3_21_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_13_WEN_A() {
    v3_21_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_862_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_861_Addr_A.read();
    } else {
        v3_21_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_14_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_14_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_14_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_14_Addr_B() {
    v3_21_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_14_Addr_B_orig() {
    v3_21_14_Addr_B_orig =  (sc_lv<32>) (v3_21_14_addr_2_reg_64130.read());
}

void kernel_correlation_sdse::thread_v3_21_14_Clk_A() {
    v3_21_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_14_Clk_B() {
    v3_21_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_14_Din_A() {
    v3_21_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_14_Din_B() {
    v3_21_14_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_14_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_862_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_861_EN_A.read();
    } else {
        v3_21_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_14_EN_B = ap_const_logic_1;
    } else {
        v3_21_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_14_Rst_A() {
    v3_21_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_14_Rst_B() {
    v3_21_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_14_WEN_A() {
    v3_21_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_863_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_862_Addr_A.read();
    } else {
        v3_21_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_15_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_15_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_15_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_15_Addr_B() {
    v3_21_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_15_Addr_B_orig() {
    v3_21_15_Addr_B_orig =  (sc_lv<32>) (v3_21_15_addr_2_reg_65790.read());
}

void kernel_correlation_sdse::thread_v3_21_15_Clk_A() {
    v3_21_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_15_Clk_B() {
    v3_21_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_15_Din_A() {
    v3_21_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_15_Din_B() {
    v3_21_15_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_15_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_863_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_862_EN_A.read();
    } else {
        v3_21_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_15_EN_B = ap_const_logic_1;
    } else {
        v3_21_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_15_Rst_A() {
    v3_21_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_15_Rst_B() {
    v3_21_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_15_WEN_A() {
    v3_21_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_864_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_863_Addr_A.read();
    } else {
        v3_21_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_16_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_16_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_16_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_16_Addr_B() {
    v3_21_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_16_Addr_B_orig() {
    v3_21_16_Addr_B_orig =  (sc_lv<32>) (v3_21_16_addr_2_reg_60816.read());
}

void kernel_correlation_sdse::thread_v3_21_16_Clk_A() {
    v3_21_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_16_Clk_B() {
    v3_21_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_16_Din_A() {
    v3_21_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_16_Din_B() {
    v3_21_16_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_16_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_864_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_863_EN_A.read();
    } else {
        v3_21_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_16_EN_B = ap_const_logic_1;
    } else {
        v3_21_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_16_Rst_A() {
    v3_21_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_16_Rst_B() {
    v3_21_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_16_WEN_A() {
    v3_21_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_865_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_864_Addr_A.read();
    } else {
        v3_21_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_17_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_17_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_17_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_17_Addr_B() {
    v3_21_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_17_Addr_B_orig() {
    v3_21_17_Addr_B_orig =  (sc_lv<32>) (v3_21_17_addr_2_reg_62476.read());
}

void kernel_correlation_sdse::thread_v3_21_17_Clk_A() {
    v3_21_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_17_Clk_B() {
    v3_21_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_17_Din_A() {
    v3_21_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_17_Din_B() {
    v3_21_17_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_17_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_865_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_864_EN_A.read();
    } else {
        v3_21_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_17_EN_B = ap_const_logic_1;
    } else {
        v3_21_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_17_Rst_A() {
    v3_21_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_17_Rst_B() {
    v3_21_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_17_WEN_A() {
    v3_21_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_866_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_865_Addr_A.read();
    } else {
        v3_21_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_18_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_18_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_18_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_18_Addr_B() {
    v3_21_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_18_Addr_B_orig() {
    v3_21_18_Addr_B_orig =  (sc_lv<32>) (v3_21_18_addr_2_reg_64136.read());
}

void kernel_correlation_sdse::thread_v3_21_18_Clk_A() {
    v3_21_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_18_Clk_B() {
    v3_21_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_18_Din_A() {
    v3_21_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_18_Din_B() {
    v3_21_18_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_18_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_866_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_865_EN_A.read();
    } else {
        v3_21_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_18_EN_B = ap_const_logic_1;
    } else {
        v3_21_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_18_Rst_A() {
    v3_21_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_18_Rst_B() {
    v3_21_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_18_WEN_A() {
    v3_21_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_867_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_866_Addr_A.read();
    } else {
        v3_21_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_19_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_19_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_19_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_19_Addr_B() {
    v3_21_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_19_Addr_B_orig() {
    v3_21_19_Addr_B_orig =  (sc_lv<32>) (v3_21_19_addr_2_reg_65796.read());
}

void kernel_correlation_sdse::thread_v3_21_19_Clk_A() {
    v3_21_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_19_Clk_B() {
    v3_21_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_19_Din_A() {
    v3_21_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_19_Din_B() {
    v3_21_19_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_19_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_867_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_866_EN_A.read();
    } else {
        v3_21_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_19_EN_B = ap_const_logic_1;
    } else {
        v3_21_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_19_Rst_A() {
    v3_21_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_19_Rst_B() {
    v3_21_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_19_WEN_A() {
    v3_21_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_849_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_848_Addr_A.read();
    } else {
        v3_21_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_1_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_1_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_1_Addr_B() {
    v3_21_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_1_Addr_B_orig() {
    v3_21_1_Addr_B_orig =  (sc_lv<32>) (v3_21_1_addr_2_reg_62452.read());
}

void kernel_correlation_sdse::thread_v3_21_1_Clk_A() {
    v3_21_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_1_Clk_B() {
    v3_21_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_1_Din_A() {
    v3_21_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_1_Din_B() {
    v3_21_1_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_849_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_848_EN_A.read();
    } else {
        v3_21_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_1_EN_B = ap_const_logic_1;
    } else {
        v3_21_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_1_Rst_A() {
    v3_21_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_1_Rst_B() {
    v3_21_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_1_WEN_A() {
    v3_21_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_868_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_867_Addr_A.read();
    } else {
        v3_21_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_20_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_20_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_20_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_20_Addr_B() {
    v3_21_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_20_Addr_B_orig() {
    v3_21_20_Addr_B_orig =  (sc_lv<32>) (v3_21_20_addr_2_reg_60822.read());
}

void kernel_correlation_sdse::thread_v3_21_20_Clk_A() {
    v3_21_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_20_Clk_B() {
    v3_21_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_20_Din_A() {
    v3_21_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_20_Din_B() {
    v3_21_20_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_20_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_868_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_867_EN_A.read();
    } else {
        v3_21_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_20_EN_B = ap_const_logic_1;
    } else {
        v3_21_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_20_Rst_A() {
    v3_21_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_20_Rst_B() {
    v3_21_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_20_WEN_A() {
    v3_21_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_869_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_868_Addr_A.read();
    } else {
        v3_21_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_21_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_21_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_21_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_21_Addr_B() {
    v3_21_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_21_Addr_B_orig() {
    v3_21_21_Addr_B_orig =  (sc_lv<32>) (v3_21_21_addr_2_reg_62482.read());
}

void kernel_correlation_sdse::thread_v3_21_21_Clk_A() {
    v3_21_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_21_Clk_B() {
    v3_21_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_21_Din_A() {
    v3_21_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_21_Din_B() {
    v3_21_21_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_21_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_869_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_868_EN_A.read();
    } else {
        v3_21_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_21_EN_B = ap_const_logic_1;
    } else {
        v3_21_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_21_Rst_A() {
    v3_21_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_21_Rst_B() {
    v3_21_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_21_WEN_A() {
    v3_21_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_870_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_869_Addr_A.read();
    } else {
        v3_21_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_22_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_22_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_22_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_22_Addr_B() {
    v3_21_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_22_Addr_B_orig() {
    v3_21_22_Addr_B_orig =  (sc_lv<32>) (v3_21_22_addr_2_reg_64142.read());
}

void kernel_correlation_sdse::thread_v3_21_22_Clk_A() {
    v3_21_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_22_Clk_B() {
    v3_21_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_22_Din_A() {
    v3_21_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_22_Din_B() {
    v3_21_22_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_22_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_870_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_869_EN_A.read();
    } else {
        v3_21_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_22_EN_B = ap_const_logic_1;
    } else {
        v3_21_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_22_Rst_A() {
    v3_21_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_22_Rst_B() {
    v3_21_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_22_WEN_A() {
    v3_21_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_871_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_870_Addr_A.read();
    } else {
        v3_21_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_23_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_23_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_23_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_23_Addr_B() {
    v3_21_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_23_Addr_B_orig() {
    v3_21_23_Addr_B_orig =  (sc_lv<32>) (v3_21_23_addr_2_reg_65802.read());
}

void kernel_correlation_sdse::thread_v3_21_23_Clk_A() {
    v3_21_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_23_Clk_B() {
    v3_21_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_23_Din_A() {
    v3_21_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_23_Din_B() {
    v3_21_23_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_23_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_871_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_870_EN_A.read();
    } else {
        v3_21_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_23_EN_B = ap_const_logic_1;
    } else {
        v3_21_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_23_Rst_A() {
    v3_21_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_23_Rst_B() {
    v3_21_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_23_WEN_A() {
    v3_21_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_872_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_871_Addr_A.read();
    } else {
        v3_21_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_24_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_24_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_24_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_24_Addr_B() {
    v3_21_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_24_Addr_B_orig() {
    v3_21_24_Addr_B_orig =  (sc_lv<32>) (v3_21_24_addr_2_reg_60828.read());
}

void kernel_correlation_sdse::thread_v3_21_24_Clk_A() {
    v3_21_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_24_Clk_B() {
    v3_21_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_24_Din_A() {
    v3_21_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_24_Din_B() {
    v3_21_24_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_24_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_872_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_871_EN_A.read();
    } else {
        v3_21_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_24_EN_B = ap_const_logic_1;
    } else {
        v3_21_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_24_Rst_A() {
    v3_21_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_24_Rst_B() {
    v3_21_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_24_WEN_A() {
    v3_21_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_873_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_872_Addr_A.read();
    } else {
        v3_21_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_25_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_25_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_25_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_25_Addr_B() {
    v3_21_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_25_Addr_B_orig() {
    v3_21_25_Addr_B_orig =  (sc_lv<32>) (v3_21_25_addr_2_reg_62488.read());
}

void kernel_correlation_sdse::thread_v3_21_25_Clk_A() {
    v3_21_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_25_Clk_B() {
    v3_21_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_25_Din_A() {
    v3_21_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_25_Din_B() {
    v3_21_25_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_25_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_873_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_872_EN_A.read();
    } else {
        v3_21_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_25_EN_B = ap_const_logic_1;
    } else {
        v3_21_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_25_Rst_A() {
    v3_21_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_25_Rst_B() {
    v3_21_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_25_WEN_A() {
    v3_21_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_874_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_873_Addr_A.read();
    } else {
        v3_21_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_26_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_26_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_26_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_26_Addr_B() {
    v3_21_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_26_Addr_B_orig() {
    v3_21_26_Addr_B_orig =  (sc_lv<32>) (v3_21_26_addr_2_reg_64148.read());
}

void kernel_correlation_sdse::thread_v3_21_26_Clk_A() {
    v3_21_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_26_Clk_B() {
    v3_21_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_26_Din_A() {
    v3_21_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_26_Din_B() {
    v3_21_26_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_26_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_874_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_873_EN_A.read();
    } else {
        v3_21_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_26_EN_B = ap_const_logic_1;
    } else {
        v3_21_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_26_Rst_A() {
    v3_21_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_26_Rst_B() {
    v3_21_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_26_WEN_A() {
    v3_21_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_875_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_874_Addr_A.read();
    } else {
        v3_21_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_27_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_27_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_27_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_27_Addr_B() {
    v3_21_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_27_Addr_B_orig() {
    v3_21_27_Addr_B_orig =  (sc_lv<32>) (v3_21_27_addr_2_reg_65808.read());
}

void kernel_correlation_sdse::thread_v3_21_27_Clk_A() {
    v3_21_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_27_Clk_B() {
    v3_21_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_27_Din_A() {
    v3_21_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_27_Din_B() {
    v3_21_27_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_27_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_875_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_874_EN_A.read();
    } else {
        v3_21_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_27_EN_B = ap_const_logic_1;
    } else {
        v3_21_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_27_Rst_A() {
    v3_21_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_27_Rst_B() {
    v3_21_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_27_WEN_A() {
    v3_21_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_876_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_875_Addr_A.read();
    } else {
        v3_21_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_28_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_28_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_28_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_28_Addr_B() {
    v3_21_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_28_Addr_B_orig() {
    v3_21_28_Addr_B_orig =  (sc_lv<32>) (v3_21_28_addr_2_reg_60834.read());
}

void kernel_correlation_sdse::thread_v3_21_28_Clk_A() {
    v3_21_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_28_Clk_B() {
    v3_21_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_28_Din_A() {
    v3_21_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_28_Din_B() {
    v3_21_28_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_28_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_876_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_875_EN_A.read();
    } else {
        v3_21_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_28_EN_B = ap_const_logic_1;
    } else {
        v3_21_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_28_Rst_A() {
    v3_21_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_28_Rst_B() {
    v3_21_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_28_WEN_A() {
    v3_21_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_877_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_876_Addr_A.read();
    } else {
        v3_21_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_29_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_29_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_29_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_29_Addr_B() {
    v3_21_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_29_Addr_B_orig() {
    v3_21_29_Addr_B_orig =  (sc_lv<32>) (v3_21_29_addr_2_reg_62494.read());
}

void kernel_correlation_sdse::thread_v3_21_29_Clk_A() {
    v3_21_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_29_Clk_B() {
    v3_21_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_29_Din_A() {
    v3_21_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_29_Din_B() {
    v3_21_29_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_29_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_877_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_876_EN_A.read();
    } else {
        v3_21_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_29_EN_B = ap_const_logic_1;
    } else {
        v3_21_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_29_Rst_A() {
    v3_21_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_29_Rst_B() {
    v3_21_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_29_WEN_A() {
    v3_21_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_850_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_849_Addr_A.read();
    } else {
        v3_21_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_2_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_2_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_2_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_2_Addr_B() {
    v3_21_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_2_Addr_B_orig() {
    v3_21_2_Addr_B_orig =  (sc_lv<32>) (v3_21_2_addr_2_reg_64112.read());
}

void kernel_correlation_sdse::thread_v3_21_2_Clk_A() {
    v3_21_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_2_Clk_B() {
    v3_21_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_2_Din_A() {
    v3_21_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_2_Din_B() {
    v3_21_2_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_850_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_849_EN_A.read();
    } else {
        v3_21_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_2_EN_B = ap_const_logic_1;
    } else {
        v3_21_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_2_Rst_A() {
    v3_21_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_2_Rst_B() {
    v3_21_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_2_WEN_A() {
    v3_21_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_878_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_877_Addr_A.read();
    } else {
        v3_21_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_30_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_30_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_30_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_30_Addr_B() {
    v3_21_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_30_Addr_B_orig() {
    v3_21_30_Addr_B_orig =  (sc_lv<32>) (v3_21_30_addr_2_reg_64154.read());
}

void kernel_correlation_sdse::thread_v3_21_30_Clk_A() {
    v3_21_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_30_Clk_B() {
    v3_21_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_30_Din_A() {
    v3_21_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_30_Din_B() {
    v3_21_30_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_30_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_878_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_877_EN_A.read();
    } else {
        v3_21_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_30_EN_B = ap_const_logic_1;
    } else {
        v3_21_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_30_Rst_A() {
    v3_21_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_30_Rst_B() {
    v3_21_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_30_WEN_A() {
    v3_21_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_879_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_878_Addr_A.read();
    } else {
        v3_21_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_31_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_31_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_31_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_31_Addr_B() {
    v3_21_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_31_Addr_B_orig() {
    v3_21_31_Addr_B_orig =  (sc_lv<32>) (v3_21_31_addr_2_reg_65814.read());
}

void kernel_correlation_sdse::thread_v3_21_31_Clk_A() {
    v3_21_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_31_Clk_B() {
    v3_21_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_31_Din_A() {
    v3_21_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_31_Din_B() {
    v3_21_31_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_31_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_879_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_878_EN_A.read();
    } else {
        v3_21_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_31_EN_B = ap_const_logic_1;
    } else {
        v3_21_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_31_Rst_A() {
    v3_21_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_31_Rst_B() {
    v3_21_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_31_WEN_A() {
    v3_21_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_31_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_32_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_880_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_879_Addr_A.read();
    } else {
        v3_21_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_32_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_32_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_32_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_32_Addr_B() {
    v3_21_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_32_Addr_B_orig() {
    v3_21_32_Addr_B_orig =  (sc_lv<32>) (v3_21_32_addr_2_reg_60840.read());
}

void kernel_correlation_sdse::thread_v3_21_32_Clk_A() {
    v3_21_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_32_Clk_B() {
    v3_21_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_32_Din_A() {
    v3_21_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_32_Din_B() {
    v3_21_32_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_32_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_32_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_880_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_879_EN_A.read();
    } else {
        v3_21_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_32_EN_B = ap_const_logic_1;
    } else {
        v3_21_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_32_Rst_A() {
    v3_21_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_32_Rst_B() {
    v3_21_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_32_WEN_A() {
    v3_21_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_32_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_33_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_881_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_880_Addr_A.read();
    } else {
        v3_21_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_33_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_33_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_33_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_33_Addr_B() {
    v3_21_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_33_Addr_B_orig() {
    v3_21_33_Addr_B_orig =  (sc_lv<32>) (v3_21_33_addr_2_reg_62500.read());
}

void kernel_correlation_sdse::thread_v3_21_33_Clk_A() {
    v3_21_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_33_Clk_B() {
    v3_21_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_33_Din_A() {
    v3_21_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_33_Din_B() {
    v3_21_33_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_33_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_33_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_881_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_880_EN_A.read();
    } else {
        v3_21_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_33_EN_B = ap_const_logic_1;
    } else {
        v3_21_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_33_Rst_A() {
    v3_21_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_33_Rst_B() {
    v3_21_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_33_WEN_A() {
    v3_21_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_33_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_34_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_882_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_881_Addr_A.read();
    } else {
        v3_21_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_34_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_34_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_34_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_34_Addr_B() {
    v3_21_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_34_Addr_B_orig() {
    v3_21_34_Addr_B_orig =  (sc_lv<32>) (v3_21_34_addr_2_reg_64160.read());
}

void kernel_correlation_sdse::thread_v3_21_34_Clk_A() {
    v3_21_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_34_Clk_B() {
    v3_21_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_34_Din_A() {
    v3_21_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_34_Din_B() {
    v3_21_34_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_34_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_34_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_882_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_881_EN_A.read();
    } else {
        v3_21_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_34_EN_B = ap_const_logic_1;
    } else {
        v3_21_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_34_Rst_A() {
    v3_21_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_34_Rst_B() {
    v3_21_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_34_WEN_A() {
    v3_21_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_34_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_35_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_883_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_882_Addr_A.read();
    } else {
        v3_21_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_35_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_35_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_35_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_35_Addr_B() {
    v3_21_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_35_Addr_B_orig() {
    v3_21_35_Addr_B_orig =  (sc_lv<32>) (v3_21_35_addr_2_reg_65820.read());
}

void kernel_correlation_sdse::thread_v3_21_35_Clk_A() {
    v3_21_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_35_Clk_B() {
    v3_21_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_35_Din_A() {
    v3_21_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_35_Din_B() {
    v3_21_35_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_35_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_35_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_883_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_882_EN_A.read();
    } else {
        v3_21_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_35_EN_B = ap_const_logic_1;
    } else {
        v3_21_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_35_Rst_A() {
    v3_21_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_35_Rst_B() {
    v3_21_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_35_WEN_A() {
    v3_21_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_35_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_36_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_884_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_883_Addr_A.read();
    } else {
        v3_21_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_36_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_36_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_36_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_36_Addr_B() {
    v3_21_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_36_Addr_B_orig() {
    v3_21_36_Addr_B_orig =  (sc_lv<32>) (v3_21_36_addr_2_reg_60846.read());
}

void kernel_correlation_sdse::thread_v3_21_36_Clk_A() {
    v3_21_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_36_Clk_B() {
    v3_21_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_36_Din_A() {
    v3_21_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_36_Din_B() {
    v3_21_36_Din_B = grp_fu_42786_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_36_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_36_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_884_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_883_EN_A.read();
    } else {
        v3_21_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_36_EN_B = ap_const_logic_1;
    } else {
        v3_21_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_36_Rst_A() {
    v3_21_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_36_Rst_B() {
    v3_21_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_36_WEN_A() {
    v3_21_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_36_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_37_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_885_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_884_Addr_A.read();
    } else {
        v3_21_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_37_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_37_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_37_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_37_Addr_B() {
    v3_21_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_37_Addr_B_orig() {
    v3_21_37_Addr_B_orig =  (sc_lv<32>) (v3_21_37_addr_2_reg_62506.read());
}

void kernel_correlation_sdse::thread_v3_21_37_Clk_A() {
    v3_21_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_37_Clk_B() {
    v3_21_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_37_Din_A() {
    v3_21_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_37_Din_B() {
    v3_21_37_Din_B = grp_fu_42801_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_37_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_885_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_884_EN_A.read();
    } else {
        v3_21_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_37_EN_B = ap_const_logic_1;
    } else {
        v3_21_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_37_Rst_A() {
    v3_21_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_37_Rst_B() {
    v3_21_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_37_WEN_A() {
    v3_21_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_886_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_885_Addr_A.read();
    } else {
        v3_21_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_38_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_38_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_38_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_38_Addr_B() {
    v3_21_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_38_Addr_B_orig() {
    v3_21_38_Addr_B_orig =  (sc_lv<32>) (v3_21_38_addr_2_reg_64166.read());
}

void kernel_correlation_sdse::thread_v3_21_38_Clk_A() {
    v3_21_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_38_Clk_B() {
    v3_21_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_38_Din_A() {
    v3_21_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_38_Din_B() {
    v3_21_38_Din_B = grp_fu_42816_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_38_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_886_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_885_EN_A.read();
    } else {
        v3_21_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_38_EN_B = ap_const_logic_1;
    } else {
        v3_21_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_38_Rst_A() {
    v3_21_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_38_Rst_B() {
    v3_21_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_38_WEN_A() {
    v3_21_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_887_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_886_Addr_A.read();
    } else {
        v3_21_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_39_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_39_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_39_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_39_Addr_B() {
    v3_21_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_39_Addr_B_orig() {
    v3_21_39_Addr_B_orig =  (sc_lv<32>) (v3_21_39_addr_2_reg_65826.read());
}

void kernel_correlation_sdse::thread_v3_21_39_Clk_A() {
    v3_21_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_39_Clk_B() {
    v3_21_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_39_Din_A() {
    v3_21_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_21_39_Din_B() {
    v3_21_39_Din_B = grp_fu_42832_p2.read();
}

void kernel_correlation_sdse::thread_v3_21_39_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v3_21_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_887_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_886_EN_A.read();
    } else {
        v3_21_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_39_EN_B = ap_const_logic_1;
    } else {
        v3_21_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_39_Rst_A() {
    v3_21_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_39_Rst_B() {
    v3_21_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_21_39_WEN_A() {
    v3_21_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_21_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_21_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_21_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_21_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_851_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_21_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_850_Addr_A.read();
    } else {
        v3_21_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_21_3_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v3_21_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v3_21_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3020_fu_47941_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v3_21_3_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_47211_p1.read());
    } else {
        v3_21_3_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v3_21_3_Addr_B() {
    v3_21_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_21_3_Addr_B_orig() {
    v3_21_3_Addr_B_orig =  (sc_lv<32>) (v3_21_3_addr_2_reg_65772.read());
}

void kernel_correlation_sdse::thread_v3_21_3_Clk_A() {
    v3_21_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_21_3_Clk_B() {
    v3_21_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

}


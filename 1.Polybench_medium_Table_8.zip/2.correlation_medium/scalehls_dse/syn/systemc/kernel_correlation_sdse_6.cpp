#include "kernel_correlation_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_correlation_sdse::thread_icmp_ln3576_1_fu_50163_p2() {
    icmp_ln3576_1_fu_50163_p2 = (!trunc_ln3576_fu_50153_p1.read().is_01() || !ap_const_lv52_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln3576_fu_50153_p1.read() == ap_const_lv52_0);
}

void kernel_correlation_sdse::thread_icmp_ln3576_fu_50157_p2() {
    icmp_ln3576_fu_50157_p2 = (!tmp_121_fu_50143_p4.read().is_01() || !ap_const_lv11_7FF.is_01())? sc_lv<1>(): sc_lv<1>(tmp_121_fu_50143_p4.read() != ap_const_lv11_7FF);
}

void kernel_correlation_sdse::thread_icmp_ln3582_fu_50385_p2() {
    icmp_ln3582_fu_50385_p2 = (!ap_phi_mux_indvar_flatten13_phi_fu_33456_p4.read().is_01() || !ap_const_lv10_258.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten13_phi_fu_33456_p4.read() == ap_const_lv10_258);
}

void kernel_correlation_sdse::thread_icmp_ln3583_fu_50403_p2() {
    icmp_ln3583_fu_50403_p2 = (!ap_phi_mux_v2573_0_phi_fu_33478_p4.read().is_01() || !ap_const_lv6_3C.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v2573_0_phi_fu_33478_p4.read() == ap_const_lv6_3C);
}

void kernel_correlation_sdse::thread_icmp_ln4419_fu_51767_p2() {
    icmp_ln4419_fu_51767_p2 = (!v3198_0_reg_37497.read().is_01() || !ap_const_lv4_C.is_01())? sc_lv<1>(): sc_lv<1>(v3198_0_reg_37497.read() == ap_const_lv4_C);
}

void kernel_correlation_sdse::thread_icmp_ln4420_fu_51888_p2() {
    icmp_ln4420_fu_51888_p2 = (!ap_phi_mux_indvar_flatten60_phi_fu_37512_p4.read().is_01() || !mul_ln4423_reg_66698.read().is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten60_phi_fu_37512_p4.read() == mul_ln4423_reg_66698.read());
}

void kernel_correlation_sdse::thread_icmp_ln4421_fu_51893_p2() {
    icmp_ln4421_fu_51893_p2 = (!ap_phi_mux_indvar_flatten20_phi_fu_37524_p4.read().is_01() || !add_ln4423_2_reg_66693.read().is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten20_phi_fu_37524_p4.read() == add_ln4423_2_reg_66693.read());
}

void kernel_correlation_sdse::thread_icmp_ln4423_1_fu_51914_p2() {
    icmp_ln4423_1_fu_51914_p2 = (!ap_phi_mux_v3201_0_phi_fu_37547_p4.read().is_01() || !select_ln4423_reg_66685.read().is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v3201_0_phi_fu_37547_p4.read() != select_ln4423_reg_66685.read());
}

void kernel_correlation_sdse::thread_icmp_ln4423_fu_51877_p2() {
    icmp_ln4423_fu_51877_p2 = (!select_ln4423_reg_66685.read().is_01() || !ap_const_lv5_0.is_01())? sc_lv<1>(): sc_lv<1>(select_ln4423_reg_66685.read() != ap_const_lv5_0);
}

void kernel_correlation_sdse::thread_icmp_ln51_fu_47091_p2() {
    icmp_ln51_fu_47091_p2 = (!ap_phi_mux_indvar_flatten_phi_fu_30830_p4.read().is_01() || !ap_const_lv9_186.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten_phi_fu_30830_p4.read() == ap_const_lv9_186);
}

void kernel_correlation_sdse::thread_icmp_ln52_fu_47109_p2() {
    icmp_ln52_fu_47109_p2 = (!ap_phi_mux_v8_0_phi_fu_30852_p4.read().is_01() || !ap_const_lv3_6.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v8_0_phi_fu_30852_p4.read() == ap_const_lv3_6);
}

void kernel_correlation_sdse::thread_mul_ln1336_fu_52406_p0() {
    mul_ln1336_fu_52406_p0 =  (sc_lv<11>) (ap_const_lv20_277);
}

void kernel_correlation_sdse::thread_mul_ln1336_fu_52406_p1() {
    mul_ln1336_fu_52406_p1 =  (sc_lv<9>) (mul_ln1336_fu_52406_p10.read());
}

void kernel_correlation_sdse::thread_mul_ln1336_fu_52406_p10() {
    mul_ln1336_fu_52406_p10 = esl_zext<20,9>(or_ln1336_fu_47831_p2.read());
}

void kernel_correlation_sdse::thread_mul_ln3585_fu_50443_p1() {
    mul_ln3585_fu_50443_p1 =  (sc_lv<8>) (mul_ln3585_fu_50443_p10.read());
}

void kernel_correlation_sdse::thread_mul_ln3585_fu_50443_p10() {
    mul_ln3585_fu_50443_p10 = esl_zext<18,8>(shl_ln_fu_50425_p3.read());
}

void kernel_correlation_sdse::thread_mul_ln3585_fu_50443_p2() {
    mul_ln3585_fu_50443_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln3585_fu_50443_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln3585_fu_50443_p1.read());
}

void kernel_correlation_sdse::thread_mul_ln3593_fu_50468_p0() {
    mul_ln3593_fu_50468_p0 =  (sc_lv<8>) (mul_ln3593_fu_50468_p00.read());
}

void kernel_correlation_sdse::thread_mul_ln3593_fu_50468_p00() {
    mul_ln3593_fu_50468_p00 = esl_zext<18,8>(or_ln3593_fu_50459_p2.read());
}

void kernel_correlation_sdse::thread_mul_ln3593_fu_50468_p2() {
    mul_ln3593_fu_50468_p2 = (!mul_ln3593_fu_50468_p0.read().is_01() || !ap_const_lv18_19A.is_01())? sc_lv<18>(): sc_biguint<8>(mul_ln3593_fu_50468_p0.read()) * sc_biguint<18>(ap_const_lv18_19A);
}

void kernel_correlation_sdse::thread_mul_ln3601_fu_50493_p0() {
    mul_ln3601_fu_50493_p0 =  (sc_lv<8>) (mul_ln3601_fu_50493_p00.read());
}

void kernel_correlation_sdse::thread_mul_ln3601_fu_50493_p00() {
    mul_ln3601_fu_50493_p00 = esl_zext<18,8>(or_ln3601_fu_50484_p2.read());
}

void kernel_correlation_sdse::thread_mul_ln3601_fu_50493_p2() {
    mul_ln3601_fu_50493_p2 = (!mul_ln3601_fu_50493_p0.read().is_01() || !ap_const_lv18_19A.is_01())? sc_lv<18>(): sc_biguint<8>(mul_ln3601_fu_50493_p0.read()) * sc_biguint<18>(ap_const_lv18_19A);
}

void kernel_correlation_sdse::thread_mul_ln3609_fu_50518_p0() {
    mul_ln3609_fu_50518_p0 =  (sc_lv<8>) (mul_ln3609_fu_50518_p00.read());
}

void kernel_correlation_sdse::thread_mul_ln3609_fu_50518_p00() {
    mul_ln3609_fu_50518_p00 = esl_zext<18,8>(or_ln3609_fu_50509_p2.read());
}

void kernel_correlation_sdse::thread_mul_ln3609_fu_50518_p2() {
    mul_ln3609_fu_50518_p2 = (!mul_ln3609_fu_50518_p0.read().is_01() || !ap_const_lv18_19A.is_01())? sc_lv<18>(): sc_biguint<8>(mul_ln3609_fu_50518_p0.read()) * sc_biguint<18>(ap_const_lv18_19A);
}

void kernel_correlation_sdse::thread_mul_ln4420_fu_52164_p1() {
    mul_ln4420_fu_52164_p1 =  (sc_lv<8>) (mul_ln4420_fu_52164_p10.read());
}

void kernel_correlation_sdse::thread_mul_ln4420_fu_52164_p10() {
    mul_ln4420_fu_52164_p10 = esl_zext<18,8>(select_ln4420_1_reg_66761_pp3_iter2_reg.read());
}

void kernel_correlation_sdse::thread_mul_ln4420_fu_52164_p2() {
    mul_ln4420_fu_52164_p2 = (!ap_const_lv18_19A.is_01() || !mul_ln4420_fu_52164_p1.read().is_01())? sc_lv<18>(): sc_biguint<18>(ap_const_lv18_19A) * sc_biguint<8>(mul_ln4420_fu_52164_p1.read());
}

void kernel_correlation_sdse::thread_mul_ln4423_fu_52414_p0() {
    mul_ln4423_fu_52414_p0 =  (sc_lv<9>) (ap_const_lv21_EF);
}

void kernel_correlation_sdse::thread_mul_ln4423_fu_52414_p1() {
    mul_ln4423_fu_52414_p1 =  (sc_lv<14>) (mul_ln4423_fu_52414_p10.read());
}

void kernel_correlation_sdse::thread_mul_ln4423_fu_52414_p10() {
    mul_ln4423_fu_52414_p10 = esl_zext<21,14>(add_ln4423_2_fu_51867_p2.read());
}

void kernel_correlation_sdse::thread_mul_ln4427_fu_52088_p0() {
    mul_ln4427_fu_52088_p0 =  (sc_lv<8>) (mul_ln4427_fu_52088_p00.read());
}

void kernel_correlation_sdse::thread_mul_ln4427_fu_52088_p00() {
    mul_ln4427_fu_52088_p00 = esl_zext<18,8>(add_ln4425_reg_66778_pp3_iter1_reg.read());
}

void kernel_correlation_sdse::thread_mul_ln4427_fu_52088_p2() {
    mul_ln4427_fu_52088_p2 = (!mul_ln4427_fu_52088_p0.read().is_01() || !ap_const_lv18_19A.is_01())? sc_lv<18>(): sc_biguint<8>(mul_ln4427_fu_52088_p0.read()) * sc_biguint<18>(ap_const_lv18_19A);
}

void kernel_correlation_sdse::thread_mul_ln4428_1_fu_52420_p0() {
    mul_ln4428_1_fu_52420_p0 =  (sc_lv<11>) (ap_const_lv20_277);
}

void kernel_correlation_sdse::thread_mul_ln4428_1_fu_52420_p1() {
    mul_ln4428_1_fu_52420_p1 =  (sc_lv<9>) (mul_ln4428_1_fu_52420_p10.read());
}

void kernel_correlation_sdse::thread_mul_ln4428_1_fu_52420_p10() {
    mul_ln4428_1_fu_52420_p10 = esl_zext<20,9>(v3200_reg_66729_pp3_iter2_reg.read());
}

void kernel_correlation_sdse::thread_mul_ln4428_fu_52426_p0() {
    mul_ln4428_fu_52426_p0 =  (sc_lv<11>) (ap_const_lv20_277);
}

void kernel_correlation_sdse::thread_mul_ln4428_fu_52426_p1() {
    mul_ln4428_fu_52426_p1 =  (sc_lv<9>) (mul_ln4428_fu_52426_p10.read());
}

void kernel_correlation_sdse::thread_mul_ln4428_fu_52426_p10() {
    mul_ln4428_fu_52426_p10 = esl_zext<20,9>(v3200_0_reg_37531_pp3_iter2_reg.read());
}

void kernel_correlation_sdse::thread_mul_ln51_fu_52398_p0() {
    mul_ln51_fu_52398_p0 =  (sc_lv<11>) (ap_const_lv20_277);
}

void kernel_correlation_sdse::thread_mul_ln51_fu_52398_p1() {
    mul_ln51_fu_52398_p1 =  (sc_lv<9>) (mul_ln51_fu_52398_p10.read());
}

void kernel_correlation_sdse::thread_mul_ln51_fu_52398_p10() {
    mul_ln51_fu_52398_p10 = esl_zext<20,9>(or_ln51_fu_47145_p2.read());
}

void kernel_correlation_sdse::thread_or_ln1336_fu_47831_p2() {
    or_ln1336_fu_47831_p2 = (trunc_ln1340_mid2_v_s_fu_47817_p3.read() | ap_const_lv9_3);
}

void kernel_correlation_sdse::thread_or_ln3030_fu_48884_p2() {
    or_ln3030_fu_48884_p2 = (icmp_ln3030_1_reg_58948.read() | icmp_ln3030_reg_58943.read());
}

void kernel_correlation_sdse::thread_or_ln3044_fu_48903_p2() {
    or_ln3044_fu_48903_p2 = (icmp_ln3044_1_reg_58958.read() | icmp_ln3044_reg_58953.read());
}

void kernel_correlation_sdse::thread_or_ln3058_fu_48921_p2() {
    or_ln3058_fu_48921_p2 = (icmp_ln3058_1_reg_58968.read() | icmp_ln3058_reg_58963.read());
}

void kernel_correlation_sdse::thread_or_ln3072_fu_48939_p2() {
    or_ln3072_fu_48939_p2 = (icmp_ln3072_1_reg_58978.read() | icmp_ln3072_reg_58973.read());
}

void kernel_correlation_sdse::thread_or_ln3086_fu_48957_p2() {
    or_ln3086_fu_48957_p2 = (icmp_ln3086_1_reg_58988.read() | icmp_ln3086_reg_58983.read());
}

void kernel_correlation_sdse::thread_or_ln3100_fu_48975_p2() {
    or_ln3100_fu_48975_p2 = (icmp_ln3100_1_reg_58998.read() | icmp_ln3100_reg_58993.read());
}

void kernel_correlation_sdse::thread_or_ln3114_fu_48993_p2() {
    or_ln3114_fu_48993_p2 = (icmp_ln3114_1_reg_59008.read() | icmp_ln3114_reg_59003.read());
}

void kernel_correlation_sdse::thread_or_ln3128_fu_49011_p2() {
    or_ln3128_fu_49011_p2 = (icmp_ln3128_1_reg_59018.read() | icmp_ln3128_reg_59013.read());
}

void kernel_correlation_sdse::thread_or_ln3142_fu_49029_p2() {
    or_ln3142_fu_49029_p2 = (icmp_ln3142_1_reg_59028.read() | icmp_ln3142_reg_59023.read());
}

void kernel_correlation_sdse::thread_or_ln3156_fu_49047_p2() {
    or_ln3156_fu_49047_p2 = (icmp_ln3156_1_reg_59038.read() | icmp_ln3156_reg_59033.read());
}

void kernel_correlation_sdse::thread_or_ln3170_fu_49065_p2() {
    or_ln3170_fu_49065_p2 = (icmp_ln3170_1_reg_59048.read() | icmp_ln3170_reg_59043.read());
}

void kernel_correlation_sdse::thread_or_ln3184_fu_49083_p2() {
    or_ln3184_fu_49083_p2 = (icmp_ln3184_1_reg_59058.read() | icmp_ln3184_reg_59053.read());
}

void kernel_correlation_sdse::thread_or_ln3198_fu_49101_p2() {
    or_ln3198_fu_49101_p2 = (icmp_ln3198_1_reg_59068.read() | icmp_ln3198_reg_59063.read());
}

void kernel_correlation_sdse::thread_or_ln3212_fu_49119_p2() {
    or_ln3212_fu_49119_p2 = (icmp_ln3212_1_reg_59078.read() | icmp_ln3212_reg_59073.read());
}

void kernel_correlation_sdse::thread_or_ln3226_fu_49557_p2() {
    or_ln3226_fu_49557_p2 = (icmp_ln3226_1_reg_59088.read() | icmp_ln3226_reg_59083.read());
}

void kernel_correlation_sdse::thread_or_ln3240_fu_49575_p2() {
    or_ln3240_fu_49575_p2 = (icmp_ln3240_1_reg_59098.read() | icmp_ln3240_reg_59093.read());
}

void kernel_correlation_sdse::thread_or_ln3254_fu_49593_p2() {
    or_ln3254_fu_49593_p2 = (icmp_ln3254_1_reg_59108.read() | icmp_ln3254_reg_59103.read());
}

void kernel_correlation_sdse::thread_or_ln3268_fu_49611_p2() {
    or_ln3268_fu_49611_p2 = (icmp_ln3268_1_reg_59118.read() | icmp_ln3268_reg_59113.read());
}

void kernel_correlation_sdse::thread_or_ln3282_fu_49629_p2() {
    or_ln3282_fu_49629_p2 = (icmp_ln3282_1_reg_59128.read() | icmp_ln3282_reg_59123.read());
}

void kernel_correlation_sdse::thread_or_ln3296_fu_49647_p2() {
    or_ln3296_fu_49647_p2 = (icmp_ln3296_1_reg_59138.read() | icmp_ln3296_reg_59133.read());
}

void kernel_correlation_sdse::thread_or_ln3310_fu_49665_p2() {
    or_ln3310_fu_49665_p2 = (icmp_ln3310_1_reg_59148.read() | icmp_ln3310_reg_59143.read());
}

void kernel_correlation_sdse::thread_or_ln3324_fu_49683_p2() {
    or_ln3324_fu_49683_p2 = (icmp_ln3324_1_reg_59158.read() | icmp_ln3324_reg_59153.read());
}

void kernel_correlation_sdse::thread_or_ln3338_fu_49701_p2() {
    or_ln3338_fu_49701_p2 = (icmp_ln3338_1_reg_59168.read() | icmp_ln3338_reg_59163.read());
}

void kernel_correlation_sdse::thread_or_ln3352_fu_49719_p2() {
    or_ln3352_fu_49719_p2 = (icmp_ln3352_1_reg_59178.read() | icmp_ln3352_reg_59173.read());
}

void kernel_correlation_sdse::thread_or_ln3366_fu_49737_p2() {
    or_ln3366_fu_49737_p2 = (icmp_ln3366_1_reg_59188.read() | icmp_ln3366_reg_59183.read());
}

void kernel_correlation_sdse::thread_or_ln3380_fu_49755_p2() {
    or_ln3380_fu_49755_p2 = (icmp_ln3380_1_reg_59198.read() | icmp_ln3380_reg_59193.read());
}

void kernel_correlation_sdse::thread_or_ln3394_fu_49773_p2() {
    or_ln3394_fu_49773_p2 = (icmp_ln3394_1_reg_59208.read() | icmp_ln3394_reg_59203.read());
}

void kernel_correlation_sdse::thread_or_ln3408_fu_49791_p2() {
    or_ln3408_fu_49791_p2 = (icmp_ln3408_1_reg_59218.read() | icmp_ln3408_reg_59213.read());
}

void kernel_correlation_sdse::thread_or_ln3422_fu_50169_p2() {
    or_ln3422_fu_50169_p2 = (icmp_ln3422_1_reg_59360.read() | icmp_ln3422_reg_59355.read());
}

void kernel_correlation_sdse::thread_or_ln3436_fu_50187_p2() {
    or_ln3436_fu_50187_p2 = (icmp_ln3436_1_reg_59370.read() | icmp_ln3436_reg_59365.read());
}

void kernel_correlation_sdse::thread_or_ln3450_fu_50205_p2() {
    or_ln3450_fu_50205_p2 = (icmp_ln3450_1_reg_59380.read() | icmp_ln3450_reg_59375.read());
}

void kernel_correlation_sdse::thread_or_ln3464_fu_50223_p2() {
    or_ln3464_fu_50223_p2 = (icmp_ln3464_1_reg_59390.read() | icmp_ln3464_reg_59385.read());
}

void kernel_correlation_sdse::thread_or_ln3478_fu_50241_p2() {
    or_ln3478_fu_50241_p2 = (icmp_ln3478_1_reg_59400.read() | icmp_ln3478_reg_59395.read());
}

void kernel_correlation_sdse::thread_or_ln3492_fu_50259_p2() {
    or_ln3492_fu_50259_p2 = (icmp_ln3492_1_reg_59410.read() | icmp_ln3492_reg_59405.read());
}

void kernel_correlation_sdse::thread_or_ln3506_fu_50277_p2() {
    or_ln3506_fu_50277_p2 = (icmp_ln3506_1_reg_59420.read() | icmp_ln3506_reg_59415.read());
}

void kernel_correlation_sdse::thread_or_ln3520_fu_50295_p2() {
    or_ln3520_fu_50295_p2 = (icmp_ln3520_1_reg_59430.read() | icmp_ln3520_reg_59425.read());
}

void kernel_correlation_sdse::thread_or_ln3534_fu_50313_p2() {
    or_ln3534_fu_50313_p2 = (icmp_ln3534_1_reg_59440.read() | icmp_ln3534_reg_59435.read());
}

void kernel_correlation_sdse::thread_or_ln3548_fu_50331_p2() {
    or_ln3548_fu_50331_p2 = (icmp_ln3548_1_reg_59450.read() | icmp_ln3548_reg_59445.read());
}

void kernel_correlation_sdse::thread_or_ln3562_fu_50349_p2() {
    or_ln3562_fu_50349_p2 = (icmp_ln3562_1_reg_59460.read() | icmp_ln3562_reg_59455.read());
}

void kernel_correlation_sdse::thread_or_ln3576_fu_50367_p2() {
    or_ln3576_fu_50367_p2 = (icmp_ln3576_1_reg_59470.read() | icmp_ln3576_reg_59465.read());
}

void kernel_correlation_sdse::thread_or_ln3593_fu_50459_p2() {
    or_ln3593_fu_50459_p2 = (shl_ln_reg_59496.read() | ap_const_lv8_1);
}

void kernel_correlation_sdse::thread_or_ln3601_fu_50484_p2() {
    or_ln3601_fu_50484_p2 = (shl_ln_reg_59496.read() | ap_const_lv8_2);
}

void kernel_correlation_sdse::thread_or_ln3609_fu_50509_p2() {
    or_ln3609_fu_50509_p2 = (shl_ln_reg_59496.read() | ap_const_lv8_3);
}

void kernel_correlation_sdse::thread_or_ln51_fu_47145_p2() {
    or_ln51_fu_47145_p2 = (trunc_ln1015_mid2_v_s_fu_47131_p3.read() | ap_const_lv9_3);
}

void kernel_correlation_sdse::thread_select_ln1336_1_fu_47809_p3() {
    select_ln1336_1_fu_47809_p3 = (!icmp_ln1337_fu_47795_p2.read()[0].is_01())? sc_lv<7>(): ((icmp_ln1337_fu_47795_p2.read()[0].to_bool())? v809_fu_47789_p2.read(): ap_phi_mux_v809_0_phi_fu_32154_p4.read());
}

void kernel_correlation_sdse::thread_select_ln1336_fu_47801_p3() {
    select_ln1336_fu_47801_p3 = (!icmp_ln1337_fu_47795_p2.read()[0].is_01())? sc_lv<3>(): ((icmp_ln1337_fu_47795_p2.read()[0].to_bool())? ap_const_lv3_0: ap_phi_mux_v810_0_phi_fu_32165_p4.read());
}

void kernel_correlation_sdse::thread_select_ln3586_1_fu_50417_p3() {
    select_ln3586_1_fu_50417_p3 = (!icmp_ln3583_fu_50403_p2.read()[0].is_01())? sc_lv<4>(): ((icmp_ln3583_fu_50403_p2.read()[0].to_bool())? v2572_fu_50397_p2.read(): ap_phi_mux_v2572_0_phi_fu_33467_p4.read());
}

void kernel_correlation_sdse::thread_select_ln3586_fu_50409_p3() {
    select_ln3586_fu_50409_p3 = (!icmp_ln3583_fu_50403_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln3583_fu_50403_p2.read()[0].to_bool())? ap_const_lv6_0: ap_phi_mux_v2573_0_phi_fu_33478_p4.read());
}

void kernel_correlation_sdse::thread_select_ln4420_1_fu_52008_p3() {
    select_ln4420_1_fu_52008_p3 = (!icmp_ln4421_reg_66712.read()[0].is_01())? sc_lv<8>(): ((icmp_ln4421_reg_66712.read()[0].to_bool())? add_ln4426_fu_51996_p2.read(): add_ln4426_2_fu_52002_p2.read());
}

void kernel_correlation_sdse::thread_select_ln4420_2_fu_52015_p3() {
    select_ln4420_2_fu_52015_p3 = (!icmp_ln4421_reg_66712.read()[0].is_01())? sc_lv<8>(): ((icmp_ln4421_reg_66712.read()[0].to_bool())? add_ln4426_2_fu_52002_p2.read(): ap_phi_mux_v3199_0_phi_fu_37558_p4.read());
}

void kernel_correlation_sdse::thread_select_ln4420_3_fu_52272_p3() {
    select_ln4420_3_fu_52272_p3 = (!icmp_ln4421_reg_66712_pp3_iter3_reg.read()[0].is_01())? sc_lv<6>(): ((icmp_ln4421_reg_66712_pp3_iter3_reg.read()[0].to_bool())? trunc_ln4420_fu_52265_p1.read(): trunc_ln4420_1_fu_52269_p1.read());
}

void kernel_correlation_sdse::thread_select_ln4420_4_fu_52180_p3() {
    select_ln4420_4_fu_52180_p3 = (!icmp_ln4421_reg_66712_pp3_iter2_reg.read()[0].is_01())? sc_lv<10>(): ((icmp_ln4421_reg_66712_pp3_iter2_reg.read()[0].to_bool())? ap_const_lv10_0: add_ln4427_1_fu_52136_p2.read());
}

void kernel_correlation_sdse::thread_select_ln4420_5_fu_52283_p3() {
    select_ln4420_5_fu_52283_p3 = (!icmp_ln4421_reg_66712_pp3_iter3_reg.read()[0].is_01())? sc_lv<11>(): ((icmp_ln4421_reg_66712_pp3_iter3_reg.read()[0].to_bool())? zext_ln4428_2_fu_52261_p1.read(): add_ln4428_reg_66807.read());
}

void kernel_correlation_sdse::thread_select_ln4420_6_fu_52187_p3() {
    select_ln4420_6_fu_52187_p3 = (!icmp_ln4421_reg_66712_pp3_iter2_reg.read()[0].is_01())? sc_lv<4>(): ((icmp_ln4421_reg_66712_pp3_iter2_reg.read()[0].to_bool())? ap_const_lv4_0: trunc_ln4427_1_fu_52152_p4.read());
}

void kernel_correlation_sdse::thread_select_ln4420_7_fu_51906_p3() {
    select_ln4420_7_fu_51906_p3 = (!icmp_ln4421_fu_51893_p2.read()[0].is_01())? sc_lv<5>(): ((icmp_ln4421_fu_51893_p2.read()[0].to_bool())? ap_const_lv5_0: ap_phi_mux_v3201_0_phi_fu_37547_p4.read());
}

void kernel_correlation_sdse::thread_select_ln4420_8_fu_51919_p3() {
    select_ln4420_8_fu_51919_p3 = (!icmp_ln4421_fu_51893_p2.read()[0].is_01())? sc_lv<1>(): ((icmp_ln4421_fu_51893_p2.read()[0].to_bool())? icmp_ln4423_reg_66703.read(): icmp_ln4423_1_fu_51914_p2.read());
}

void kernel_correlation_sdse::thread_select_ln4420_fu_51898_p3() {
    select_ln4420_fu_51898_p3 = (!icmp_ln4421_fu_51893_p2.read()[0].is_01())? sc_lv<9>(): ((icmp_ln4421_fu_51893_p2.read()[0].to_bool())? ap_const_lv9_0: ap_phi_mux_v3200_0_phi_fu_37535_p4.read());
}

void kernel_correlation_sdse::thread_select_ln4421_1_fu_51982_p3() {
    select_ln4421_1_fu_51982_p3 = (!icmp_ln4421_fu_51893_p2.read()[0].is_01())? sc_lv<14>(): ((icmp_ln4421_fu_51893_p2.read()[0].to_bool())? ap_const_lv14_1: add_ln4421_1_fu_51976_p2.read());
}

void kernel_correlation_sdse::thread_select_ln4421_fu_51946_p3() {
    select_ln4421_fu_51946_p3 = (!select_ln4420_8_fu_51919_p3.read()[0].is_01())? sc_lv<9>(): ((select_ln4420_8_fu_51919_p3.read()[0].to_bool())? select_ln4420_fu_51898_p3.read(): v3200_fu_51926_p2.read());
}

void kernel_correlation_sdse::thread_select_ln4422_1_fu_52298_p3() {
    select_ln4422_1_fu_52298_p3 = (!select_ln4420_8_reg_66722_pp3_iter3_reg.read()[0].is_01())? sc_lv<11>(): ((select_ln4420_8_reg_66722_pp3_iter3_reg.read()[0].to_bool())? select_ln4420_5_fu_52283_p3.read(): add_ln4428_1_fu_52292_p2.read());
}

void kernel_correlation_sdse::thread_select_ln4422_2_fu_52244_p3() {
    select_ln4422_2_fu_52244_p3 = (!select_ln4420_8_reg_66722_pp3_iter2_reg.read()[0].is_01())? sc_lv<4>(): ((select_ln4420_8_reg_66722_pp3_iter2_reg.read()[0].to_bool())? select_ln4420_6_fu_52187_p3.read(): trunc_ln4427_1_mid1_fu_52235_p4.read());
}

void kernel_correlation_sdse::thread_select_ln4422_3_fu_51938_p3() {
    select_ln4422_3_fu_51938_p3 = (!select_ln4420_8_fu_51919_p3.read()[0].is_01())? sc_lv<5>(): ((select_ln4420_8_fu_51919_p3.read()[0].to_bool())? select_ln4420_7_fu_51906_p3.read(): ap_const_lv5_0);
}

void kernel_correlation_sdse::thread_select_ln4422_fu_52224_p3() {
    select_ln4422_fu_52224_p3 = (!select_ln4420_8_reg_66722_pp3_iter2_reg.read()[0].is_01())? sc_lv<10>(): ((select_ln4420_8_reg_66722_pp3_iter2_reg.read()[0].to_bool())? select_ln4420_4_fu_52180_p3.read(): add_ln4427_2_fu_52218_p2.read());
}

void kernel_correlation_sdse::thread_select_ln4423_1_fu_51960_p3() {
    select_ln4423_1_fu_51960_p3 = (!icmp_ln4421_fu_51893_p2.read()[0].is_01())? sc_lv<5>(): ((icmp_ln4421_fu_51893_p2.read()[0].to_bool())? ap_const_lv5_1: add_ln4423_3_fu_51954_p2.read());
}

void kernel_correlation_sdse::thread_select_ln4423_fu_51837_p3() {
    select_ln4423_fu_51837_p3 = (!icmp_ln191_fu_51831_p2.read()[0].is_01())? sc_lv<5>(): ((icmp_ln191_fu_51831_p2.read()[0].to_bool())? add_ln4423_1_fu_51825_p2.read(): ap_const_lv5_14);
}

void kernel_correlation_sdse::thread_select_ln51_1_fu_47123_p3() {
    select_ln51_1_fu_47123_p3 = (!icmp_ln52_fu_47109_p2.read()[0].is_01())? sc_lv<7>(): ((icmp_ln52_fu_47109_p2.read()[0].to_bool())? v7_fu_47103_p2.read(): ap_phi_mux_v7_0_phi_fu_30841_p4.read());
}

void kernel_correlation_sdse::thread_select_ln51_fu_47115_p3() {
    select_ln51_fu_47115_p3 = (!icmp_ln52_fu_47109_p2.read()[0].is_01())? sc_lv<3>(): ((icmp_ln52_fu_47109_p2.read()[0].to_bool())? ap_const_lv3_0: ap_phi_mux_v8_0_phi_fu_30852_p4.read());
}

void kernel_correlation_sdse::thread_sext_ln1015_fu_47211_p1() {
    sext_ln1015_fu_47211_p1 = esl_sext<64,7>(add_ln1015_reg_52499_pp0_iter5_reg.read());
}

void kernel_correlation_sdse::thread_sext_ln3020_fu_47941_p1() {
    sext_ln3020_fu_47941_p1 = esl_sext<64,7>(add_ln3020_reg_55492_pp1_iter3_reg.read());
}

void kernel_correlation_sdse::thread_sext_ln3585_fu_50562_p1() {
    sext_ln3585_fu_50562_p1 = esl_sext<8,4>(tmp_130_reg_59504.read());
}

void kernel_correlation_sdse::thread_sext_ln3586_1_fu_50598_p1() {
    sext_ln3586_1_fu_50598_p1 = esl_sext<64,7>(add_ln3586_fu_50592_p2.read());
}

void kernel_correlation_sdse::thread_sext_ln3586_fu_50589_p1() {
    sext_ln3586_fu_50589_p1 = esl_sext<7,4>(tmp_130_reg_59504.read());
}

void kernel_correlation_sdse::thread_sext_ln3593_fu_50862_p1() {
    sext_ln3593_fu_50862_p1 = esl_sext<8,4>(tmp_138_reg_59510.read());
}

void kernel_correlation_sdse::thread_sext_ln3594_1_fu_50898_p1() {
    sext_ln3594_1_fu_50898_p1 = esl_sext<64,7>(add_ln3594_fu_50892_p2.read());
}

void kernel_correlation_sdse::thread_sext_ln3594_fu_50889_p1() {
    sext_ln3594_fu_50889_p1 = esl_sext<7,4>(tmp_138_reg_59510.read());
}

void kernel_correlation_sdse::thread_sext_ln3601_fu_51162_p1() {
    sext_ln3601_fu_51162_p1 = esl_sext<8,4>(tmp_139_reg_59516.read());
}

void kernel_correlation_sdse::thread_sext_ln3602_1_fu_51198_p1() {
    sext_ln3602_1_fu_51198_p1 = esl_sext<64,7>(add_ln3602_fu_51192_p2.read());
}

void kernel_correlation_sdse::thread_sext_ln3602_fu_51189_p1() {
    sext_ln3602_fu_51189_p1 = esl_sext<7,4>(tmp_139_reg_59516.read());
}

void kernel_correlation_sdse::thread_sext_ln3609_fu_51462_p1() {
    sext_ln3609_fu_51462_p1 = esl_sext<8,4>(tmp_140_reg_59522.read());
}

void kernel_correlation_sdse::thread_sext_ln3610_1_fu_51498_p1() {
    sext_ln3610_1_fu_51498_p1 = esl_sext<64,7>(add_ln3610_fu_51492_p2.read());
}

void kernel_correlation_sdse::thread_sext_ln3610_fu_51489_p1() {
    sext_ln3610_fu_51489_p1 = esl_sext<7,4>(tmp_140_reg_59522.read());
}

void kernel_correlation_sdse::thread_sext_ln4425_fu_52373_p1() {
    sext_ln4425_fu_52373_p1 = esl_sext<64,17>(add_ln4425_2_fu_52367_p2.read());
}

void kernel_correlation_sdse::thread_sext_ln4426_fu_52390_p1() {
    sext_ln4426_fu_52390_p1 = esl_sext<64,17>(add_ln4426_1_reg_66847.read());
}

void kernel_correlation_sdse::thread_sext_ln4434_fu_52394_p1() {
    sext_ln4434_fu_52394_p1 = esl_sext<64,17>(add_ln4434_reg_66852.read());
}

void kernel_correlation_sdse::thread_shl_ln1_fu_51779_p3() {
    shl_ln1_fu_51779_p3 = esl_concat<4,4>(v3198_0_reg_37497.read(), ap_const_lv4_0);
}

void kernel_correlation_sdse::thread_shl_ln2_fu_52116_p3() {
    shl_ln2_fu_52116_p3 = esl_concat<5,5>(trunc_ln4427_fu_52112_p1.read(), ap_const_lv5_0);
}

void kernel_correlation_sdse::thread_shl_ln4423_1_fu_51797_p3() {
    shl_ln4423_1_fu_51797_p3 = esl_concat<4,2>(v3198_0_reg_37497.read(), ap_const_lv2_0);
}

void kernel_correlation_sdse::thread_shl_ln4427_1_fu_52124_p3() {
    shl_ln4427_1_fu_52124_p3 = esl_concat<5,3>(trunc_ln4427_fu_52112_p1.read(), ap_const_lv3_0);
}

void kernel_correlation_sdse::thread_shl_ln4427_1_mid1_fu_52206_p3() {
    shl_ln4427_1_mid1_fu_52206_p3 = esl_concat<5,3>(trunc_ln4427_3_fu_52194_p1.read(), ap_const_lv3_0);
}

void kernel_correlation_sdse::thread_shl_ln4427_mid1_fu_52198_p3() {
    shl_ln4427_mid1_fu_52198_p3 = esl_concat<5,5>(trunc_ln4427_3_fu_52194_p1.read(), ap_const_lv5_0);
}

void kernel_correlation_sdse::thread_shl_ln_fu_50425_p3() {
    shl_ln_fu_50425_p3 = esl_concat<6,2>(select_ln3586_fu_50409_p3.read(), ap_const_lv2_0);
}

void kernel_correlation_sdse::thread_sub_ln1015_fu_47187_p2() {
    sub_ln1015_fu_47187_p2 = (!zext_ln1015_cast_fu_47173_p3.read().is_01() || !tmp_124_fu_47180_p3.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln1015_cast_fu_47173_p3.read()) - sc_biguint<7>(tmp_124_fu_47180_p3.read()));
}

void kernel_correlation_sdse::thread_sub_ln3020_fu_47917_p2() {
    sub_ln3020_fu_47917_p2 = (!zext_ln3020_cast_fu_47903_p3.read().is_01() || !tmp_127_fu_47910_p3.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln3020_cast_fu_47903_p3.read()) - sc_biguint<7>(tmp_127_fu_47910_p3.read()));
}

void kernel_correlation_sdse::thread_sub_ln3586_fu_50552_p2() {
    sub_ln3586_fu_50552_p2 = (!tmp_128_fu_50534_p3.read().is_01() || !zext_ln3586_fu_50548_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(tmp_128_fu_50534_p3.read()) - sc_biguint<7>(zext_ln3586_fu_50548_p1.read()));
}

void kernel_correlation_sdse::thread_sub_ln4423_1_fu_51809_p2() {
    sub_ln4423_1_fu_51809_p2 = (!sub_ln4423_fu_51791_p2.read().is_01() || !zext_ln4423_1_fu_51805_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(sub_ln4423_fu_51791_p2.read()) - sc_biguint<9>(zext_ln4423_1_fu_51805_p1.read()));
}

void kernel_correlation_sdse::thread_sub_ln4423_fu_51791_p2() {
    sub_ln4423_fu_51791_p2 = (!ap_const_lv9_0.is_01() || !zext_ln4423_fu_51787_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(ap_const_lv9_0) - sc_biguint<9>(zext_ln4423_fu_51787_p1.read()));
}

void kernel_correlation_sdse::thread_sub_ln4424_fu_52037_p2() {
    sub_ln4424_fu_52037_p2 = (!add_ln4420_fu_52026_p2.read().is_01() || !zext_ln4422_1_fu_52031_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(add_ln4420_fu_52026_p2.read()) - sc_biguint<9>(zext_ln4422_1_fu_52031_p1.read()));
}

void kernel_correlation_sdse::thread_sub_ln4425_fu_52361_p2() {
    sub_ln4425_fu_52361_p2 = (!zext_ln4425_2_fu_52346_p1.read().is_01() || !zext_ln4425_3_fu_52357_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(zext_ln4425_2_fu_52346_p1.read()) - sc_biguint<17>(zext_ln4425_3_fu_52357_p1.read()));
}

void kernel_correlation_sdse::thread_sub_ln4434_fu_52330_p2() {
    sub_ln4434_fu_52330_p2 = (!zext_ln4434_1_fu_52315_p1.read().is_01() || !zext_ln4434_2_fu_52326_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(zext_ln4434_1_fu_52315_p1.read()) - sc_biguint<17>(zext_ln4434_2_fu_52326_p1.read()));
}

void kernel_correlation_sdse::thread_tmp_100_fu_49933_p4() {
    tmp_100_fu_49933_p4 = bitcast_ln3478_fu_49929_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_103_fu_49963_p4() {
    tmp_103_fu_49963_p4 = bitcast_ln3492_fu_49959_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_106_fu_49993_p4() {
    tmp_106_fu_49993_p4 = bitcast_ln3506_fu_49989_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_109_fu_50023_p4() {
    tmp_109_fu_50023_p4 = bitcast_ln3520_fu_50019_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_10_fu_48528_p4() {
    tmp_10_fu_48528_p4 = bitcast_ln3058_fu_48524_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_112_fu_50053_p4() {
    tmp_112_fu_50053_p4 = bitcast_ln3534_fu_50049_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_115_fu_50083_p4() {
    tmp_115_fu_50083_p4 = bitcast_ln3548_fu_50079_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_118_fu_50113_p4() {
    tmp_118_fu_50113_p4 = bitcast_ln3562_fu_50109_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_121_fu_50143_p4() {
    tmp_121_fu_50143_p4 = bitcast_ln3576_fu_50139_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_124_fu_47180_p3() {
    tmp_124_fu_47180_p3 = esl_concat<6,1>(tmp_8_reg_52489.read(), ap_const_lv1_0);
}

void kernel_correlation_sdse::thread_tmp_127_fu_47910_p3() {
    tmp_127_fu_47910_p3 = esl_concat<6,1>(tmp_125_reg_55238.read(), ap_const_lv1_0);
}

void kernel_correlation_sdse::thread_tmp_128_fu_50534_p3() {
    tmp_128_fu_50534_p3 = esl_concat<4,3>(select_ln3586_1_reg_59489.read(), ap_const_lv3_0);
}

void kernel_correlation_sdse::thread_tmp_129_fu_50541_p3() {
    tmp_129_fu_50541_p3 = esl_concat<4,1>(select_ln3586_1_reg_59489.read(), ap_const_lv1_0);
}

void kernel_correlation_sdse::thread_tmp_131_fu_51845_p3() {
    tmp_131_fu_51845_p3 = esl_concat<5,8>(select_ln4423_reg_66685.read(), ap_const_lv8_0);
}

void kernel_correlation_sdse::thread_tmp_132_fu_51856_p3() {
    tmp_132_fu_51856_p3 = esl_concat<5,2>(select_ln4423_reg_66685.read(), ap_const_lv2_0);
}

void kernel_correlation_sdse::thread_tmp_133_fu_52308_p3() {
    tmp_133_fu_52308_p3 = esl_concat<8,8>(select_ln4420_1_reg_66761_pp3_iter5_reg.read(), ap_const_lv8_0);
}

void kernel_correlation_sdse::thread_tmp_134_fu_52319_p3() {
    tmp_134_fu_52319_p3 = esl_concat<8,4>(select_ln4420_1_reg_66761_pp3_iter5_reg.read(), ap_const_lv4_0);
}

void kernel_correlation_sdse::thread_tmp_135_fu_52043_p3() {
    tmp_135_fu_52043_p3 = sub_ln4424_fu_52037_p2.read().range(8, 8);
}

void kernel_correlation_sdse::thread_tmp_136_fu_52339_p3() {
    tmp_136_fu_52339_p3 = esl_concat<8,8>(add_ln4425_reg_66778_pp3_iter5_reg.read(), ap_const_lv8_0);
}

void kernel_correlation_sdse::thread_tmp_137_fu_52350_p3() {
    tmp_137_fu_52350_p3 = esl_concat<8,4>(add_ln4425_reg_66778_pp3_iter5_reg.read(), ap_const_lv4_0);
}

void kernel_correlation_sdse::thread_tmp_13_fu_48558_p4() {
    tmp_13_fu_48558_p4 = bitcast_ln3072_fu_48554_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_16_fu_48588_p4() {
    tmp_16_fu_48588_p4 = bitcast_ln3086_fu_48584_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_19_fu_48618_p4() {
    tmp_19_fu_48618_p4 = bitcast_ln3100_fu_48614_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_22_fu_48648_p4() {
    tmp_22_fu_48648_p4 = bitcast_ln3114_fu_48644_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_25_fu_48678_p4() {
    tmp_25_fu_48678_p4 = bitcast_ln3128_fu_48674_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_28_fu_48708_p4() {
    tmp_28_fu_48708_p4 = bitcast_ln3142_fu_48704_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_31_fu_48738_p4() {
    tmp_31_fu_48738_p4 = bitcast_ln3156_fu_48734_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_34_fu_48768_p4() {
    tmp_34_fu_48768_p4 = bitcast_ln3170_fu_48764_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_37_fu_48798_p4() {
    tmp_37_fu_48798_p4 = bitcast_ln3184_fu_48794_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_3_fu_48468_p4() {
    tmp_3_fu_48468_p4 = bitcast_ln3030_fu_48464_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_40_fu_48828_p4() {
    tmp_40_fu_48828_p4 = bitcast_ln3198_fu_48824_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_43_fu_48858_p4() {
    tmp_43_fu_48858_p4 = bitcast_ln3212_fu_48854_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_46_fu_49141_p4() {
    tmp_46_fu_49141_p4 = bitcast_ln3226_fu_49137_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_49_fu_49171_p4() {
    tmp_49_fu_49171_p4 = bitcast_ln3240_fu_49167_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_52_fu_49201_p4() {
    tmp_52_fu_49201_p4 = bitcast_ln3254_fu_49197_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_55_fu_49231_p4() {
    tmp_55_fu_49231_p4 = bitcast_ln3268_fu_49227_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_58_fu_49261_p4() {
    tmp_58_fu_49261_p4 = bitcast_ln3282_fu_49257_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_61_fu_49291_p4() {
    tmp_61_fu_49291_p4 = bitcast_ln3296_fu_49287_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_64_fu_49321_p4() {
    tmp_64_fu_49321_p4 = bitcast_ln3310_fu_49317_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_67_fu_49351_p4() {
    tmp_67_fu_49351_p4 = bitcast_ln3324_fu_49347_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_6_fu_48498_p4() {
    tmp_6_fu_48498_p4 = bitcast_ln3044_fu_48494_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_70_fu_49381_p4() {
    tmp_70_fu_49381_p4 = bitcast_ln3338_fu_49377_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_73_fu_49411_p4() {
    tmp_73_fu_49411_p4 = bitcast_ln3352_fu_49407_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_76_fu_49441_p4() {
    tmp_76_fu_49441_p4 = bitcast_ln3366_fu_49437_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_79_fu_49471_p4() {
    tmp_79_fu_49471_p4 = bitcast_ln3380_fu_49467_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_82_fu_49501_p4() {
    tmp_82_fu_49501_p4 = bitcast_ln3394_fu_49497_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_85_fu_49531_p4() {
    tmp_85_fu_49531_p4 = bitcast_ln3408_fu_49527_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_88_fu_49813_p4() {
    tmp_88_fu_49813_p4 = bitcast_ln3422_fu_49809_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_91_fu_49843_p4() {
    tmp_91_fu_49843_p4 = bitcast_ln3436_fu_49839_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_94_fu_49873_p4() {
    tmp_94_fu_49873_p4 = bitcast_ln3450_fu_49869_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_tmp_97_fu_49903_p4() {
    tmp_97_fu_49903_p4 = bitcast_ln3464_fu_49899_p1.read().range(62, 52);
}

void kernel_correlation_sdse::thread_trunc_ln1015_mid2_v_s_fu_47131_p3() {
    trunc_ln1015_mid2_v_s_fu_47131_p3 = esl_concat<7,2>(select_ln51_1_fu_47123_p3.read(), ap_const_lv2_0);
}

void kernel_correlation_sdse::thread_trunc_ln1336_fu_47937_p1() {
    trunc_ln1336_fu_47937_p1 = grp_fu_47825_p2.read().range(6-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln1340_mid2_v_s_fu_47817_p3() {
    trunc_ln1340_mid2_v_s_fu_47817_p3 = esl_concat<7,2>(select_ln1336_1_fu_47809_p3.read(), ap_const_lv2_0);
}

void kernel_correlation_sdse::thread_trunc_ln3030_fu_48478_p1() {
    trunc_ln3030_fu_48478_p1 = bitcast_ln3030_fu_48464_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3044_fu_48508_p1() {
    trunc_ln3044_fu_48508_p1 = bitcast_ln3044_fu_48494_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3058_fu_48538_p1() {
    trunc_ln3058_fu_48538_p1 = bitcast_ln3058_fu_48524_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3072_fu_48568_p1() {
    trunc_ln3072_fu_48568_p1 = bitcast_ln3072_fu_48554_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3086_fu_48598_p1() {
    trunc_ln3086_fu_48598_p1 = bitcast_ln3086_fu_48584_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3100_fu_48628_p1() {
    trunc_ln3100_fu_48628_p1 = bitcast_ln3100_fu_48614_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3114_fu_48658_p1() {
    trunc_ln3114_fu_48658_p1 = bitcast_ln3114_fu_48644_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3128_fu_48688_p1() {
    trunc_ln3128_fu_48688_p1 = bitcast_ln3128_fu_48674_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3142_fu_48718_p1() {
    trunc_ln3142_fu_48718_p1 = bitcast_ln3142_fu_48704_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3156_fu_48748_p1() {
    trunc_ln3156_fu_48748_p1 = bitcast_ln3156_fu_48734_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3170_fu_48778_p1() {
    trunc_ln3170_fu_48778_p1 = bitcast_ln3170_fu_48764_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3184_fu_48808_p1() {
    trunc_ln3184_fu_48808_p1 = bitcast_ln3184_fu_48794_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3198_fu_48838_p1() {
    trunc_ln3198_fu_48838_p1 = bitcast_ln3198_fu_48824_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3212_fu_48868_p1() {
    trunc_ln3212_fu_48868_p1 = bitcast_ln3212_fu_48854_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3226_fu_49151_p1() {
    trunc_ln3226_fu_49151_p1 = bitcast_ln3226_fu_49137_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3240_fu_49181_p1() {
    trunc_ln3240_fu_49181_p1 = bitcast_ln3240_fu_49167_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3254_fu_49211_p1() {
    trunc_ln3254_fu_49211_p1 = bitcast_ln3254_fu_49197_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3268_fu_49241_p1() {
    trunc_ln3268_fu_49241_p1 = bitcast_ln3268_fu_49227_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3282_fu_49271_p1() {
    trunc_ln3282_fu_49271_p1 = bitcast_ln3282_fu_49257_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3296_fu_49301_p1() {
    trunc_ln3296_fu_49301_p1 = bitcast_ln3296_fu_49287_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3310_fu_49331_p1() {
    trunc_ln3310_fu_49331_p1 = bitcast_ln3310_fu_49317_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3324_fu_49361_p1() {
    trunc_ln3324_fu_49361_p1 = bitcast_ln3324_fu_49347_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3338_fu_49391_p1() {
    trunc_ln3338_fu_49391_p1 = bitcast_ln3338_fu_49377_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3352_fu_49421_p1() {
    trunc_ln3352_fu_49421_p1 = bitcast_ln3352_fu_49407_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3366_fu_49451_p1() {
    trunc_ln3366_fu_49451_p1 = bitcast_ln3366_fu_49437_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3380_fu_49481_p1() {
    trunc_ln3380_fu_49481_p1 = bitcast_ln3380_fu_49467_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3394_fu_49511_p1() {
    trunc_ln3394_fu_49511_p1 = bitcast_ln3394_fu_49497_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3408_fu_49541_p1() {
    trunc_ln3408_fu_49541_p1 = bitcast_ln3408_fu_49527_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3422_fu_49823_p1() {
    trunc_ln3422_fu_49823_p1 = bitcast_ln3422_fu_49809_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3436_fu_49853_p1() {
    trunc_ln3436_fu_49853_p1 = bitcast_ln3436_fu_49839_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3450_fu_49883_p1() {
    trunc_ln3450_fu_49883_p1 = bitcast_ln3450_fu_49869_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3464_fu_49913_p1() {
    trunc_ln3464_fu_49913_p1 = bitcast_ln3464_fu_49899_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3478_fu_49943_p1() {
    trunc_ln3478_fu_49943_p1 = bitcast_ln3478_fu_49929_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3492_fu_49973_p1() {
    trunc_ln3492_fu_49973_p1 = bitcast_ln3492_fu_49959_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3506_fu_50003_p1() {
    trunc_ln3506_fu_50003_p1 = bitcast_ln3506_fu_49989_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3520_fu_50033_p1() {
    trunc_ln3520_fu_50033_p1 = bitcast_ln3520_fu_50019_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3534_fu_50063_p1() {
    trunc_ln3534_fu_50063_p1 = bitcast_ln3534_fu_50049_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3548_fu_50093_p1() {
    trunc_ln3548_fu_50093_p1 = bitcast_ln3548_fu_50079_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3562_fu_50123_p1() {
    trunc_ln3562_fu_50123_p1 = bitcast_ln3562_fu_50109_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3576_fu_50153_p1() {
    trunc_ln3576_fu_50153_p1 = bitcast_ln3576_fu_50139_p1.read().range(52-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln3585_fu_50558_p1() {
    trunc_ln3585_fu_50558_p1 = grp_fu_50433_p2.read().range(7-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln4420_1_fu_52269_p1() {
    trunc_ln4420_1_fu_52269_p1 = urem_ln4428_1_reg_66802.read().range(6-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln4420_fu_52265_p1() {
    trunc_ln4420_fu_52265_p1 = grp_fu_52071_p2.read().range(6-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln4423_fu_51815_p1() {
    trunc_ln4423_fu_51815_p1 = sub_ln4423_1_fu_51809_p2.read().range(5-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln4427_1_fu_52152_p4() {
    trunc_ln4427_1_fu_52152_p4 = mul_ln4428_fu_52426_p2.read().range(17, 14);
}

void kernel_correlation_sdse::thread_trunc_ln4427_1_mid1_fu_52235_p4() {
    trunc_ln4427_1_mid1_fu_52235_p4 = mul_ln4428_1_reg_66792.read().range(17, 14);
}

void kernel_correlation_sdse::thread_trunc_ln4427_3_fu_52194_p1() {
    trunc_ln4427_3_fu_52194_p1 = grp_fu_51932_p2.read().range(5-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln4427_fu_52112_p1() {
    trunc_ln4427_fu_52112_p1 = grp_fu_51882_p2.read().range(5-1, 0);
}

void kernel_correlation_sdse::thread_trunc_ln51_fu_47207_p1() {
    trunc_ln51_fu_47207_p1 = grp_fu_47139_p2.read().range(6-1, 0);
}

void kernel_correlation_sdse::thread_v2572_fu_50397_p2() {
    v2572_fu_50397_p2 = (!ap_const_lv4_1.is_01() || !ap_phi_mux_v2572_0_phi_fu_33467_p4.read().is_01())? sc_lv<4>(): (sc_biguint<4>(ap_const_lv4_1) + sc_biguint<4>(ap_phi_mux_v2572_0_phi_fu_33467_p4.read()));
}

void kernel_correlation_sdse::thread_v2573_fu_51762_p2() {
    v2573_fu_51762_p2 = (!select_ln3586_reg_59484.read().is_01() || !ap_const_lv6_1.is_01())? sc_lv<6>(): (sc_biguint<6>(select_ln3586_reg_59484.read()) + sc_biguint<6>(ap_const_lv6_1));
}

void kernel_correlation_sdse::thread_v3198_fu_51773_p2() {
    v3198_fu_51773_p2 = (!v3198_0_reg_37497.read().is_01() || !ap_const_lv4_1.is_01())? sc_lv<4>(): (sc_biguint<4>(v3198_0_reg_37497.read()) + sc_biguint<4>(ap_const_lv4_1));
}

void kernel_correlation_sdse::thread_v3200_fu_51926_p2() {
    v3200_fu_51926_p2 = (!ap_const_lv9_1.is_01() || !select_ln4420_fu_51898_p3.read().is_01())? sc_lv<9>(): (sc_biguint<9>(ap_const_lv9_1) + sc_biguint<9>(select_ln4420_fu_51898_p3.read()));
}

void kernel_correlation_sdse::thread_v3201_fu_51968_p3() {
    v3201_fu_51968_p3 = (!select_ln4420_8_fu_51919_p3.read()[0].is_01())? sc_lv<5>(): ((select_ln4420_8_fu_51919_p3.read()[0].to_bool())? select_ln4423_1_fu_51960_p3.read(): ap_const_lv5_1);
}

void kernel_correlation_sdse::thread_v3_0_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_47_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_8_Addr_A.read();
    } else {
        v3_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_0_Addr_A_orig() {
    v3_0_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_0_Addr_B() {
    v3_0_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_0_Addr_B_orig() {
    v3_0_0_Addr_B_orig =  (sc_lv<32>) (v3_0_0_addr_reg_59532.read());
}

void kernel_correlation_sdse::thread_v3_0_0_Clk_A() {
    v3_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_0_Clk_B() {
    v3_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_0_Din_A() {
    v3_0_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_0_Din_B() {
    v3_0_0_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_47_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_8_EN_A.read();
    } else {
        v3_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_0_EN_B = ap_const_logic_1;
    } else {
        v3_0_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_0_Rst_A() {
    v3_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_0_Rst_B() {
    v3_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_0_WEN_A() {
    v3_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_17_Addr_A.read();
    } else {
        v3_0_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_10_Addr_A_orig() {
    v3_0_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_10_Addr_B() {
    v3_0_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_10_Addr_B_orig() {
    v3_0_10_Addr_B_orig =  (sc_lv<32>) (v3_0_10_addr_reg_62864.read());
}

void kernel_correlation_sdse::thread_v3_0_10_Clk_A() {
    v3_0_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_10_Clk_B() {
    v3_0_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_10_Din_A() {
    v3_0_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_10_Din_B() {
    v3_0_10_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_17_EN_A.read();
    } else {
        v3_0_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_10_EN_B = ap_const_logic_1;
    } else {
        v3_0_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_10_Rst_A() {
    v3_0_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_10_Rst_B() {
    v3_0_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_10_WEN_A() {
    v3_0_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_18_Addr_A.read();
    } else {
        v3_0_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_11_Addr_A_orig() {
    v3_0_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_11_Addr_B() {
    v3_0_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_11_Addr_B_orig() {
    v3_0_11_Addr_B_orig =  (sc_lv<32>) (v3_0_11_addr_reg_64524.read());
}

void kernel_correlation_sdse::thread_v3_0_11_Clk_A() {
    v3_0_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_11_Clk_B() {
    v3_0_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_11_Din_A() {
    v3_0_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_11_Din_B() {
    v3_0_11_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_18_EN_A.read();
    } else {
        v3_0_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_11_EN_B = ap_const_logic_1;
    } else {
        v3_0_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_11_Rst_A() {
    v3_0_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_11_Rst_B() {
    v3_0_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_11_WEN_A() {
    v3_0_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_19_Addr_A.read();
    } else {
        v3_0_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_12_Addr_A_orig() {
    v3_0_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_12_Addr_B() {
    v3_0_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_12_Addr_B_orig() {
    v3_0_12_Addr_B_orig =  (sc_lv<32>) (v3_0_12_addr_reg_59550.read());
}

void kernel_correlation_sdse::thread_v3_0_12_Clk_A() {
    v3_0_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_12_Clk_B() {
    v3_0_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_12_Din_A() {
    v3_0_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_12_Din_B() {
    v3_0_12_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_19_EN_A.read();
    } else {
        v3_0_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_12_EN_B = ap_const_logic_1;
    } else {
        v3_0_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_12_Rst_A() {
    v3_0_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_12_Rst_B() {
    v3_0_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_12_WEN_A() {
    v3_0_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_20_Addr_A.read();
    } else {
        v3_0_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_13_Addr_A_orig() {
    v3_0_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_13_Addr_B() {
    v3_0_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_13_Addr_B_orig() {
    v3_0_13_Addr_B_orig =  (sc_lv<32>) (v3_0_13_addr_reg_61210.read());
}

void kernel_correlation_sdse::thread_v3_0_13_Clk_A() {
    v3_0_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_13_Clk_B() {
    v3_0_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_13_Din_A() {
    v3_0_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_13_Din_B() {
    v3_0_13_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_20_EN_A.read();
    } else {
        v3_0_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_13_EN_B = ap_const_logic_1;
    } else {
        v3_0_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_13_Rst_A() {
    v3_0_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_13_Rst_B() {
    v3_0_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_13_WEN_A() {
    v3_0_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_21_Addr_A.read();
    } else {
        v3_0_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_14_Addr_A_orig() {
    v3_0_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_14_Addr_B() {
    v3_0_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_14_Addr_B_orig() {
    v3_0_14_Addr_B_orig =  (sc_lv<32>) (v3_0_14_addr_reg_62870.read());
}

void kernel_correlation_sdse::thread_v3_0_14_Clk_A() {
    v3_0_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_14_Clk_B() {
    v3_0_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_14_Din_A() {
    v3_0_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_14_Din_B() {
    v3_0_14_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_21_EN_A.read();
    } else {
        v3_0_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_14_EN_B = ap_const_logic_1;
    } else {
        v3_0_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_14_Rst_A() {
    v3_0_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_14_Rst_B() {
    v3_0_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_14_WEN_A() {
    v3_0_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_23_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_22_Addr_A.read();
    } else {
        v3_0_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_15_Addr_A_orig() {
    v3_0_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_15_Addr_B() {
    v3_0_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_15_Addr_B_orig() {
    v3_0_15_Addr_B_orig =  (sc_lv<32>) (v3_0_15_addr_reg_64530.read());
}

void kernel_correlation_sdse::thread_v3_0_15_Clk_A() {
    v3_0_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_15_Clk_B() {
    v3_0_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_15_Din_A() {
    v3_0_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_15_Din_B() {
    v3_0_15_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_23_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_22_EN_A.read();
    } else {
        v3_0_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_15_EN_B = ap_const_logic_1;
    } else {
        v3_0_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_15_Rst_A() {
    v3_0_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_15_Rst_B() {
    v3_0_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_15_WEN_A() {
    v3_0_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_24_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_23_Addr_A.read();
    } else {
        v3_0_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_16_Addr_A_orig() {
    v3_0_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_16_Addr_B() {
    v3_0_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_16_Addr_B_orig() {
    v3_0_16_Addr_B_orig =  (sc_lv<32>) (v3_0_16_addr_reg_59556.read());
}

void kernel_correlation_sdse::thread_v3_0_16_Clk_A() {
    v3_0_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_16_Clk_B() {
    v3_0_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_16_Din_A() {
    v3_0_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_16_Din_B() {
    v3_0_16_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_24_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_23_EN_A.read();
    } else {
        v3_0_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_16_EN_B = ap_const_logic_1;
    } else {
        v3_0_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_16_Rst_A() {
    v3_0_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_16_Rst_B() {
    v3_0_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_16_WEN_A() {
    v3_0_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_25_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_24_Addr_A.read();
    } else {
        v3_0_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_17_Addr_A_orig() {
    v3_0_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_17_Addr_B() {
    v3_0_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_17_Addr_B_orig() {
    v3_0_17_Addr_B_orig =  (sc_lv<32>) (v3_0_17_addr_reg_61216.read());
}

void kernel_correlation_sdse::thread_v3_0_17_Clk_A() {
    v3_0_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_17_Clk_B() {
    v3_0_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_17_Din_A() {
    v3_0_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_17_Din_B() {
    v3_0_17_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_25_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_24_EN_A.read();
    } else {
        v3_0_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_17_EN_B = ap_const_logic_1;
    } else {
        v3_0_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_17_Rst_A() {
    v3_0_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_17_Rst_B() {
    v3_0_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_17_WEN_A() {
    v3_0_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_25_Addr_A.read();
    } else {
        v3_0_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_18_Addr_A_orig() {
    v3_0_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_18_Addr_B() {
    v3_0_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_18_Addr_B_orig() {
    v3_0_18_Addr_B_orig =  (sc_lv<32>) (v3_0_18_addr_reg_62876.read());
}

void kernel_correlation_sdse::thread_v3_0_18_Clk_A() {
    v3_0_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_18_Clk_B() {
    v3_0_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_18_Din_A() {
    v3_0_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_18_Din_B() {
    v3_0_18_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_25_EN_A.read();
    } else {
        v3_0_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_18_EN_B = ap_const_logic_1;
    } else {
        v3_0_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_18_Rst_A() {
    v3_0_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_18_Rst_B() {
    v3_0_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_18_WEN_A() {
    v3_0_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_26_Addr_A.read();
    } else {
        v3_0_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_19_Addr_A_orig() {
    v3_0_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_19_Addr_B() {
    v3_0_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_19_Addr_B_orig() {
    v3_0_19_Addr_B_orig =  (sc_lv<32>) (v3_0_19_addr_reg_64536.read());
}

void kernel_correlation_sdse::thread_v3_0_19_Clk_A() {
    v3_0_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_19_Clk_B() {
    v3_0_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_19_Din_A() {
    v3_0_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_19_Din_B() {
    v3_0_19_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_26_EN_A.read();
    } else {
        v3_0_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_19_EN_B = ap_const_logic_1;
    } else {
        v3_0_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_19_Rst_A() {
    v3_0_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_19_Rst_B() {
    v3_0_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_19_WEN_A() {
    v3_0_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_8_Addr_A.read();
    } else {
        v3_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_1_Addr_A_orig() {
    v3_0_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_1_Addr_B() {
    v3_0_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_1_Addr_B_orig() {
    v3_0_1_Addr_B_orig =  (sc_lv<32>) (v3_0_1_addr_reg_61192.read());
}

void kernel_correlation_sdse::thread_v3_0_1_Clk_A() {
    v3_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_1_Clk_B() {
    v3_0_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_1_Din_A() {
    v3_0_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_1_Din_B() {
    v3_0_1_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_8_EN_A.read();
    } else {
        v3_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_1_EN_B = ap_const_logic_1;
    } else {
        v3_0_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_1_Rst_A() {
    v3_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_1_Rst_B() {
    v3_0_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_1_WEN_A() {
    v3_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_27_Addr_A.read();
    } else {
        v3_0_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_20_Addr_A_orig() {
    v3_0_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_20_Addr_B() {
    v3_0_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_20_Addr_B_orig() {
    v3_0_20_Addr_B_orig =  (sc_lv<32>) (v3_0_20_addr_reg_59562.read());
}

void kernel_correlation_sdse::thread_v3_0_20_Clk_A() {
    v3_0_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_20_Clk_B() {
    v3_0_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_20_Din_A() {
    v3_0_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_20_Din_B() {
    v3_0_20_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_27_EN_A.read();
    } else {
        v3_0_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_20_EN_B = ap_const_logic_1;
    } else {
        v3_0_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_20_Rst_A() {
    v3_0_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_20_Rst_B() {
    v3_0_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_20_WEN_A() {
    v3_0_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_28_Addr_A.read();
    } else {
        v3_0_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_21_Addr_A_orig() {
    v3_0_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_21_Addr_B() {
    v3_0_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_21_Addr_B_orig() {
    v3_0_21_Addr_B_orig =  (sc_lv<32>) (v3_0_21_addr_reg_61222.read());
}

void kernel_correlation_sdse::thread_v3_0_21_Clk_A() {
    v3_0_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_21_Clk_B() {
    v3_0_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_21_Din_A() {
    v3_0_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_21_Din_B() {
    v3_0_21_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_21_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_21_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_28_EN_A.read();
    } else {
        v3_0_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_21_EN_B = ap_const_logic_1;
    } else {
        v3_0_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_21_Rst_A() {
    v3_0_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_21_Rst_B() {
    v3_0_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_21_WEN_A() {
    v3_0_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_21_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_22_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_30_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_22_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_29_Addr_A.read();
    } else {
        v3_0_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_22_Addr_A_orig() {
    v3_0_22_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_22_Addr_B() {
    v3_0_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_22_Addr_B_orig() {
    v3_0_22_Addr_B_orig =  (sc_lv<32>) (v3_0_22_addr_reg_62882.read());
}

void kernel_correlation_sdse::thread_v3_0_22_Clk_A() {
    v3_0_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_22_Clk_B() {
    v3_0_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_22_Din_A() {
    v3_0_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_22_Din_B() {
    v3_0_22_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_22_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_30_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_22_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_29_EN_A.read();
    } else {
        v3_0_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_22_EN_B = ap_const_logic_1;
    } else {
        v3_0_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_22_Rst_A() {
    v3_0_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_22_Rst_B() {
    v3_0_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_22_WEN_A() {
    v3_0_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_22_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_23_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_31_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_23_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_30_Addr_A.read();
    } else {
        v3_0_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_23_Addr_A_orig() {
    v3_0_23_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_23_Addr_B() {
    v3_0_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_23_Addr_B_orig() {
    v3_0_23_Addr_B_orig =  (sc_lv<32>) (v3_0_23_addr_reg_64542.read());
}

void kernel_correlation_sdse::thread_v3_0_23_Clk_A() {
    v3_0_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_23_Clk_B() {
    v3_0_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_23_Din_A() {
    v3_0_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_23_Din_B() {
    v3_0_23_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_23_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_31_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_23_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_30_EN_A.read();
    } else {
        v3_0_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_23_EN_B = ap_const_logic_1;
    } else {
        v3_0_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_23_Rst_A() {
    v3_0_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_23_Rst_B() {
    v3_0_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_23_WEN_A() {
    v3_0_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_23_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_24_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_32_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_24_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_31_Addr_A.read();
    } else {
        v3_0_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_24_Addr_A_orig() {
    v3_0_24_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_24_Addr_B() {
    v3_0_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_24_Addr_B_orig() {
    v3_0_24_Addr_B_orig =  (sc_lv<32>) (v3_0_24_addr_reg_59568.read());
}

void kernel_correlation_sdse::thread_v3_0_24_Clk_A() {
    v3_0_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_24_Clk_B() {
    v3_0_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_24_Din_A() {
    v3_0_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_24_Din_B() {
    v3_0_24_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_24_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_32_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_24_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_31_EN_A.read();
    } else {
        v3_0_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_24_EN_B = ap_const_logic_1;
    } else {
        v3_0_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_24_Rst_A() {
    v3_0_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_24_Rst_B() {
    v3_0_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_24_WEN_A() {
    v3_0_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_24_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_25_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_33_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_25_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_32_Addr_A.read();
    } else {
        v3_0_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_25_Addr_A_orig() {
    v3_0_25_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_25_Addr_B() {
    v3_0_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_25_Addr_B_orig() {
    v3_0_25_Addr_B_orig =  (sc_lv<32>) (v3_0_25_addr_reg_61228.read());
}

void kernel_correlation_sdse::thread_v3_0_25_Clk_A() {
    v3_0_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_25_Clk_B() {
    v3_0_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_25_Din_A() {
    v3_0_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_25_Din_B() {
    v3_0_25_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_25_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_33_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_25_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_32_EN_A.read();
    } else {
        v3_0_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_25_EN_B = ap_const_logic_1;
    } else {
        v3_0_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_25_Rst_A() {
    v3_0_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_25_Rst_B() {
    v3_0_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_25_WEN_A() {
    v3_0_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_25_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_26_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_34_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_26_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_33_Addr_A.read();
    } else {
        v3_0_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_26_Addr_A_orig() {
    v3_0_26_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_26_Addr_B() {
    v3_0_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_26_Addr_B_orig() {
    v3_0_26_Addr_B_orig =  (sc_lv<32>) (v3_0_26_addr_reg_62888.read());
}

void kernel_correlation_sdse::thread_v3_0_26_Clk_A() {
    v3_0_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_26_Clk_B() {
    v3_0_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_26_Din_A() {
    v3_0_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_26_Din_B() {
    v3_0_26_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_26_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_34_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_26_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_33_EN_A.read();
    } else {
        v3_0_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_26_EN_B = ap_const_logic_1;
    } else {
        v3_0_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_26_Rst_A() {
    v3_0_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_26_Rst_B() {
    v3_0_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_26_WEN_A() {
    v3_0_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_26_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_27_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_35_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_27_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_34_Addr_A.read();
    } else {
        v3_0_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_27_Addr_A_orig() {
    v3_0_27_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_27_Addr_B() {
    v3_0_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_27_Addr_B_orig() {
    v3_0_27_Addr_B_orig =  (sc_lv<32>) (v3_0_27_addr_reg_64548.read());
}

void kernel_correlation_sdse::thread_v3_0_27_Clk_A() {
    v3_0_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_27_Clk_B() {
    v3_0_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_27_Din_A() {
    v3_0_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_27_Din_B() {
    v3_0_27_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_27_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_35_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_27_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_34_EN_A.read();
    } else {
        v3_0_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_27_EN_B = ap_const_logic_1;
    } else {
        v3_0_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_27_Rst_A() {
    v3_0_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_27_Rst_B() {
    v3_0_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_27_WEN_A() {
    v3_0_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_27_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_28_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_36_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_28_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_35_Addr_A.read();
    } else {
        v3_0_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_28_Addr_A_orig() {
    v3_0_28_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_28_Addr_B() {
    v3_0_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_28_Addr_B_orig() {
    v3_0_28_Addr_B_orig =  (sc_lv<32>) (v3_0_28_addr_reg_59574.read());
}

void kernel_correlation_sdse::thread_v3_0_28_Clk_A() {
    v3_0_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_28_Clk_B() {
    v3_0_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_28_Din_A() {
    v3_0_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_28_Din_B() {
    v3_0_28_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_28_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_36_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_28_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_35_EN_A.read();
    } else {
        v3_0_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_28_EN_B = ap_const_logic_1;
    } else {
        v3_0_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_28_Rst_A() {
    v3_0_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_28_Rst_B() {
    v3_0_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_28_WEN_A() {
    v3_0_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_28_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_29_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_37_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_29_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_36_Addr_A.read();
    } else {
        v3_0_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_29_Addr_A_orig() {
    v3_0_29_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_29_Addr_B() {
    v3_0_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_29_Addr_B_orig() {
    v3_0_29_Addr_B_orig =  (sc_lv<32>) (v3_0_29_addr_reg_61234.read());
}

void kernel_correlation_sdse::thread_v3_0_29_Clk_A() {
    v3_0_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_29_Clk_B() {
    v3_0_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_29_Din_A() {
    v3_0_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_29_Din_B() {
    v3_0_29_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_29_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_37_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_29_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_36_EN_A.read();
    } else {
        v3_0_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_29_EN_B = ap_const_logic_1;
    } else {
        v3_0_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_29_Rst_A() {
    v3_0_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_29_Rst_B() {
    v3_0_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_29_WEN_A() {
    v3_0_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_29_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_2_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_9_Addr_A.read();
    } else {
        v3_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_2_Addr_A_orig() {
    v3_0_2_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_2_Addr_B() {
    v3_0_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_2_Addr_B_orig() {
    v3_0_2_Addr_B_orig =  (sc_lv<32>) (v3_0_2_addr_reg_62852.read());
}

void kernel_correlation_sdse::thread_v3_0_2_Clk_A() {
    v3_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_2_Clk_B() {
    v3_0_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_2_Din_A() {
    v3_0_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_2_Din_B() {
    v3_0_2_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_2_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_9_EN_A.read();
    } else {
        v3_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_2_EN_B = ap_const_logic_1;
    } else {
        v3_0_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_2_Rst_A() {
    v3_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_2_Rst_B() {
    v3_0_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_2_WEN_A() {
    v3_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_2_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_30_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_38_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_30_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_37_Addr_A.read();
    } else {
        v3_0_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_30_Addr_A_orig() {
    v3_0_30_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_30_Addr_B() {
    v3_0_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_30_Addr_B_orig() {
    v3_0_30_Addr_B_orig =  (sc_lv<32>) (v3_0_30_addr_reg_62894.read());
}

void kernel_correlation_sdse::thread_v3_0_30_Clk_A() {
    v3_0_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_30_Clk_B() {
    v3_0_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_30_Din_A() {
    v3_0_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_30_Din_B() {
    v3_0_30_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_30_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_38_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_30_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_37_EN_A.read();
    } else {
        v3_0_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_30_EN_B = ap_const_logic_1;
    } else {
        v3_0_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_30_Rst_A() {
    v3_0_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_30_Rst_B() {
    v3_0_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_30_WEN_A() {
    v3_0_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_30_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_31_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_39_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_31_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_38_Addr_A.read();
    } else {
        v3_0_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_31_Addr_A_orig() {
    v3_0_31_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_31_Addr_B() {
    v3_0_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_31_Addr_B_orig() {
    v3_0_31_Addr_B_orig =  (sc_lv<32>) (v3_0_31_addr_reg_64554.read());
}

void kernel_correlation_sdse::thread_v3_0_31_Clk_A() {
    v3_0_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_31_Clk_B() {
    v3_0_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_31_Din_A() {
    v3_0_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_31_Din_B() {
    v3_0_31_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_31_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_39_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_31_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_38_EN_A.read();
    } else {
        v3_0_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_31_EN_B = ap_const_logic_1;
    } else {
        v3_0_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_31_Rst_A() {
    v3_0_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_31_Rst_B() {
    v3_0_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_31_WEN_A() {
    v3_0_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_31_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_32_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_40_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_32_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_39_Addr_A.read();
    } else {
        v3_0_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_32_Addr_A_orig() {
    v3_0_32_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_32_Addr_B() {
    v3_0_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_32_Addr_B_orig() {
    v3_0_32_Addr_B_orig =  (sc_lv<32>) (v3_0_32_addr_reg_59580.read());
}

void kernel_correlation_sdse::thread_v3_0_32_Clk_A() {
    v3_0_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_32_Clk_B() {
    v3_0_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_32_Din_A() {
    v3_0_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_32_Din_B() {
    v3_0_32_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_32_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_40_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_32_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_39_EN_A.read();
    } else {
        v3_0_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_32_EN_B = ap_const_logic_1;
    } else {
        v3_0_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_32_Rst_A() {
    v3_0_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_32_Rst_B() {
    v3_0_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_32_WEN_A() {
    v3_0_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_32_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_33_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_41_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_33_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_40_Addr_A.read();
    } else {
        v3_0_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_33_Addr_A_orig() {
    v3_0_33_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_33_Addr_B() {
    v3_0_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_33_Addr_B_orig() {
    v3_0_33_Addr_B_orig =  (sc_lv<32>) (v3_0_33_addr_reg_61240.read());
}

void kernel_correlation_sdse::thread_v3_0_33_Clk_A() {
    v3_0_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_33_Clk_B() {
    v3_0_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_33_Din_A() {
    v3_0_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_33_Din_B() {
    v3_0_33_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_33_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_41_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_33_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_40_EN_A.read();
    } else {
        v3_0_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_33_EN_B = ap_const_logic_1;
    } else {
        v3_0_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_33_Rst_A() {
    v3_0_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_33_Rst_B() {
    v3_0_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_33_WEN_A() {
    v3_0_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_33_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_34_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_42_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_34_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_41_Addr_A.read();
    } else {
        v3_0_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_34_Addr_A_orig() {
    v3_0_34_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_34_Addr_B() {
    v3_0_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_34_Addr_B_orig() {
    v3_0_34_Addr_B_orig =  (sc_lv<32>) (v3_0_34_addr_reg_62900.read());
}

void kernel_correlation_sdse::thread_v3_0_34_Clk_A() {
    v3_0_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_34_Clk_B() {
    v3_0_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_34_Din_A() {
    v3_0_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_34_Din_B() {
    v3_0_34_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_34_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_42_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_34_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_41_EN_A.read();
    } else {
        v3_0_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_34_EN_B = ap_const_logic_1;
    } else {
        v3_0_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_34_Rst_A() {
    v3_0_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_34_Rst_B() {
    v3_0_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_34_WEN_A() {
    v3_0_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_34_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_35_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_43_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_35_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_42_Addr_A.read();
    } else {
        v3_0_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_35_Addr_A_orig() {
    v3_0_35_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_35_Addr_B() {
    v3_0_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_35_Addr_B_orig() {
    v3_0_35_Addr_B_orig =  (sc_lv<32>) (v3_0_35_addr_reg_64560.read());
}

void kernel_correlation_sdse::thread_v3_0_35_Clk_A() {
    v3_0_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_35_Clk_B() {
    v3_0_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_35_Din_A() {
    v3_0_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_35_Din_B() {
    v3_0_35_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_35_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_43_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_35_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_42_EN_A.read();
    } else {
        v3_0_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_35_EN_B = ap_const_logic_1;
    } else {
        v3_0_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_35_Rst_A() {
    v3_0_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_35_Rst_B() {
    v3_0_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_35_WEN_A() {
    v3_0_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_35_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_36_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_44_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_36_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_43_Addr_A.read();
    } else {
        v3_0_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_36_Addr_A_orig() {
    v3_0_36_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_36_Addr_B() {
    v3_0_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_36_Addr_B_orig() {
    v3_0_36_Addr_B_orig =  (sc_lv<32>) (v3_0_36_addr_reg_59586.read());
}

void kernel_correlation_sdse::thread_v3_0_36_Clk_A() {
    v3_0_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_36_Clk_B() {
    v3_0_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_36_Din_A() {
    v3_0_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_36_Din_B() {
    v3_0_36_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_36_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_44_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_36_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_43_EN_A.read();
    } else {
        v3_0_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_36_EN_B = ap_const_logic_1;
    } else {
        v3_0_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_36_Rst_A() {
    v3_0_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_36_Rst_B() {
    v3_0_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_36_WEN_A() {
    v3_0_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_36_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_37_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_45_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_37_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_44_Addr_A.read();
    } else {
        v3_0_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_37_Addr_A_orig() {
    v3_0_37_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_37_Addr_B() {
    v3_0_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_37_Addr_B_orig() {
    v3_0_37_Addr_B_orig =  (sc_lv<32>) (v3_0_37_addr_reg_61246.read());
}

void kernel_correlation_sdse::thread_v3_0_37_Clk_A() {
    v3_0_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_37_Clk_B() {
    v3_0_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_37_Din_A() {
    v3_0_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_37_Din_B() {
    v3_0_37_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_37_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_45_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_37_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_44_EN_A.read();
    } else {
        v3_0_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_37_EN_B = ap_const_logic_1;
    } else {
        v3_0_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_37_Rst_A() {
    v3_0_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_37_Rst_B() {
    v3_0_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_37_WEN_A() {
    v3_0_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_37_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_38_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_46_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_38_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_45_Addr_A.read();
    } else {
        v3_0_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_38_Addr_A_orig() {
    v3_0_38_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_38_Addr_B() {
    v3_0_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_38_Addr_B_orig() {
    v3_0_38_Addr_B_orig =  (sc_lv<32>) (v3_0_38_addr_reg_62906.read());
}

void kernel_correlation_sdse::thread_v3_0_38_Clk_A() {
    v3_0_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_38_Clk_B() {
    v3_0_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_38_Din_A() {
    v3_0_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_38_Din_B() {
    v3_0_38_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_38_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_46_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_38_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_45_EN_A.read();
    } else {
        v3_0_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_38_EN_B = ap_const_logic_1;
    } else {
        v3_0_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_38_Rst_A() {
    v3_0_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_38_Rst_B() {
    v3_0_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_38_WEN_A() {
    v3_0_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_38_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_39_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_47_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_39_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_46_Addr_A.read();
    } else {
        v3_0_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_39_Addr_A_orig() {
    v3_0_39_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_39_Addr_B() {
    v3_0_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_39_Addr_B_orig() {
    v3_0_39_Addr_B_orig =  (sc_lv<32>) (v3_0_39_addr_reg_64566.read());
}

void kernel_correlation_sdse::thread_v3_0_39_Clk_A() {
    v3_0_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_39_Clk_B() {
    v3_0_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_39_Din_A() {
    v3_0_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_39_Din_B() {
    v3_0_39_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_39_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_47_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_39_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_46_EN_A.read();
    } else {
        v3_0_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_39_EN_B = ap_const_logic_1;
    } else {
        v3_0_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_39_Rst_A() {
    v3_0_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_39_Rst_B() {
    v3_0_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_39_WEN_A() {
    v3_0_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_39_WEN_B() {
    if ((!esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_18) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_1C) && 
         !esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_20) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_3_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_10_Addr_A.read();
    } else {
        v3_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_3_Addr_A_orig() {
    v3_0_3_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_3_Addr_B() {
    v3_0_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_3_Addr_B_orig() {
    v3_0_3_Addr_B_orig =  (sc_lv<32>) (v3_0_3_addr_reg_64512.read());
}

void kernel_correlation_sdse::thread_v3_0_3_Clk_A() {
    v3_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_3_Clk_B() {
    v3_0_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_3_Din_A() {
    v3_0_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_3_Din_B() {
    v3_0_3_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_3_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_10_EN_A.read();
    } else {
        v3_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_3_EN_B = ap_const_logic_1;
    } else {
        v3_0_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_3_Rst_A() {
    v3_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_3_Rst_B() {
    v3_0_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_3_WEN_A() {
    v3_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_3_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_4_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_11_Addr_A.read();
    } else {
        v3_0_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_4_Addr_A_orig() {
    v3_0_4_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_4_Addr_B() {
    v3_0_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_4_Addr_B_orig() {
    v3_0_4_Addr_B_orig =  (sc_lv<32>) (v3_0_4_addr_reg_59538.read());
}

void kernel_correlation_sdse::thread_v3_0_4_Clk_A() {
    v3_0_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_4_Clk_B() {
    v3_0_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_4_Din_A() {
    v3_0_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_4_Din_B() {
    v3_0_4_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_4_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_11_EN_A.read();
    } else {
        v3_0_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_4_EN_B = ap_const_logic_1;
    } else {
        v3_0_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_4_Rst_A() {
    v3_0_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_4_Rst_B() {
    v3_0_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_4_WEN_A() {
    v3_0_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_4_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_5_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_12_Addr_A.read();
    } else {
        v3_0_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_5_Addr_A_orig() {
    v3_0_5_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_5_Addr_B() {
    v3_0_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_5_Addr_B_orig() {
    v3_0_5_Addr_B_orig =  (sc_lv<32>) (v3_0_5_addr_reg_61198.read());
}

void kernel_correlation_sdse::thread_v3_0_5_Clk_A() {
    v3_0_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_5_Clk_B() {
    v3_0_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_5_Din_A() {
    v3_0_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_5_Din_B() {
    v3_0_5_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_5_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_12_EN_A.read();
    } else {
        v3_0_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_5_EN_B = ap_const_logic_1;
    } else {
        v3_0_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_5_Rst_A() {
    v3_0_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_5_Rst_B() {
    v3_0_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_5_WEN_A() {
    v3_0_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_5_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_6_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_13_Addr_A.read();
    } else {
        v3_0_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_6_Addr_A_orig() {
    v3_0_6_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_6_Addr_B() {
    v3_0_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_6_Addr_B_orig() {
    v3_0_6_Addr_B_orig =  (sc_lv<32>) (v3_0_6_addr_reg_62858.read());
}

void kernel_correlation_sdse::thread_v3_0_6_Clk_A() {
    v3_0_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_6_Clk_B() {
    v3_0_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_6_Din_A() {
    v3_0_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_6_Din_B() {
    v3_0_6_Din_B = grp_fu_41492_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_6_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_13_EN_A.read();
    } else {
        v3_0_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_6_EN_B = ap_const_logic_1;
    } else {
        v3_0_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_6_Rst_A() {
    v3_0_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_6_Rst_B() {
    v3_0_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_6_WEN_A() {
    v3_0_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_6_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_7_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_14_Addr_A.read();
    } else {
        v3_0_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_7_Addr_A_orig() {
    v3_0_7_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_7_Addr_B() {
    v3_0_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_7_Addr_B_orig() {
    v3_0_7_Addr_B_orig =  (sc_lv<32>) (v3_0_7_addr_reg_64518.read());
}

void kernel_correlation_sdse::thread_v3_0_7_Clk_A() {
    v3_0_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_7_Clk_B() {
    v3_0_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_7_Din_A() {
    v3_0_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_7_Din_B() {
    v3_0_7_Din_B = grp_fu_41496_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_7_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_14_EN_A.read();
    } else {
        v3_0_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_7_EN_B = ap_const_logic_1;
    } else {
        v3_0_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_7_Rst_A() {
    v3_0_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_7_Rst_B() {
    v3_0_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_7_WEN_A() {
    v3_0_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_7_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_4) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_16_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_8_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_15_Addr_A.read();
    } else {
        v3_0_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_8_Addr_A_orig() {
    v3_0_8_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_8_Addr_B() {
    v3_0_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_8_Addr_B_orig() {
    v3_0_8_Addr_B_orig =  (sc_lv<32>) (v3_0_8_addr_reg_59544.read());
}

void kernel_correlation_sdse::thread_v3_0_8_Clk_A() {
    v3_0_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_8_Clk_B() {
    v3_0_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_8_Din_A() {
    v3_0_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_8_Din_B() {
    v3_0_8_Din_B = grp_fu_41484_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_16_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_8_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_15_EN_A.read();
    } else {
        v3_0_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_8_EN_B = ap_const_logic_1;
    } else {
        v3_0_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_8_Rst_A() {
    v3_0_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_8_Rst_B() {
    v3_0_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_8_WEN_A() {
    v3_0_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_8_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_17_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_9_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_16_Addr_A.read();
    } else {
        v3_0_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_0_9_Addr_A_orig() {
    v3_0_9_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_0_9_Addr_B() {
    v3_0_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_0_9_Addr_B_orig() {
    v3_0_9_Addr_B_orig =  (sc_lv<32>) (v3_0_9_addr_reg_61204.read());
}

void kernel_correlation_sdse::thread_v3_0_9_Clk_A() {
    v3_0_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_9_Clk_B() {
    v3_0_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_0_9_Din_A() {
    v3_0_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_0_9_Din_B() {
    v3_0_9_Din_B = grp_fu_41488_p2.read();
}

void kernel_correlation_sdse::thread_v3_0_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_0_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_0_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_17_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_0_9_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_16_EN_A.read();
    } else {
        v3_0_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_9_EN_B = ap_const_logic_1;
    } else {
        v3_0_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_0_9_Rst_A() {
    v3_0_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_9_Rst_B() {
    v3_0_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_0_9_WEN_A() {
    v3_0_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_0_9_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_0_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_447_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_0_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_408_Addr_A.read();
    } else {
        v3_10_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_0_Addr_A_orig() {
    v3_10_0_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_0_Addr_B() {
    v3_10_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_0_Addr_B_orig() {
    v3_10_0_Addr_B_orig =  (sc_lv<32>) (v3_10_0_addr_reg_60132.read());
}

void kernel_correlation_sdse::thread_v3_10_0_Clk_A() {
    v3_10_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_0_Clk_B() {
    v3_10_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_0_Din_A() {
    v3_10_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_0_Din_B() {
    v3_10_0_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_447_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_0_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_408_EN_A.read();
    } else {
        v3_10_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_0_EN_B = ap_const_logic_1;
    } else {
        v3_10_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_0_Rst_A() {
    v3_10_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_0_Rst_B() {
    v3_10_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_0_WEN_A() {
    v3_10_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_0_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_10_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_418_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_10_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_417_Addr_A.read();
    } else {
        v3_10_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_10_Addr_A_orig() {
    v3_10_10_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_10_Addr_B() {
    v3_10_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_10_Addr_B_orig() {
    v3_10_10_Addr_B_orig =  (sc_lv<32>) (v3_10_10_addr_reg_63464.read());
}

void kernel_correlation_sdse::thread_v3_10_10_Clk_A() {
    v3_10_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_10_Clk_B() {
    v3_10_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_10_Din_A() {
    v3_10_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_10_Din_B() {
    v3_10_10_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_10_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_418_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_10_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_417_EN_A.read();
    } else {
        v3_10_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_10_EN_B = ap_const_logic_1;
    } else {
        v3_10_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_10_Rst_A() {
    v3_10_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_10_Rst_B() {
    v3_10_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_10_WEN_A() {
    v3_10_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_10_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_11_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_419_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_11_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_418_Addr_A.read();
    } else {
        v3_10_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_11_Addr_A_orig() {
    v3_10_11_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_11_Addr_B() {
    v3_10_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_11_Addr_B_orig() {
    v3_10_11_Addr_B_orig =  (sc_lv<32>) (v3_10_11_addr_reg_65124.read());
}

void kernel_correlation_sdse::thread_v3_10_11_Clk_A() {
    v3_10_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_11_Clk_B() {
    v3_10_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_11_Din_A() {
    v3_10_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_11_Din_B() {
    v3_10_11_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_11_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_419_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_11_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_418_EN_A.read();
    } else {
        v3_10_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_11_EN_B = ap_const_logic_1;
    } else {
        v3_10_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_11_Rst_A() {
    v3_10_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_11_Rst_B() {
    v3_10_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_11_WEN_A() {
    v3_10_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_11_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_8) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_12_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_420_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_12_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_419_Addr_A.read();
    } else {
        v3_10_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_12_Addr_A_orig() {
    v3_10_12_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_12_Addr_B() {
    v3_10_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_12_Addr_B_orig() {
    v3_10_12_Addr_B_orig =  (sc_lv<32>) (v3_10_12_addr_reg_60150.read());
}

void kernel_correlation_sdse::thread_v3_10_12_Clk_A() {
    v3_10_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_12_Clk_B() {
    v3_10_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_12_Din_A() {
    v3_10_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_12_Din_B() {
    v3_10_12_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_12_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_420_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_12_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_419_EN_A.read();
    } else {
        v3_10_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_12_EN_B = ap_const_logic_1;
    } else {
        v3_10_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_12_Rst_A() {
    v3_10_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_12_Rst_B() {
    v3_10_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_12_WEN_A() {
    v3_10_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_12_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_13_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_421_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_13_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_420_Addr_A.read();
    } else {
        v3_10_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_13_Addr_A_orig() {
    v3_10_13_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_13_Addr_B() {
    v3_10_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_13_Addr_B_orig() {
    v3_10_13_Addr_B_orig =  (sc_lv<32>) (v3_10_13_addr_reg_61810.read());
}

void kernel_correlation_sdse::thread_v3_10_13_Clk_A() {
    v3_10_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_13_Clk_B() {
    v3_10_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_13_Din_A() {
    v3_10_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_13_Din_B() {
    v3_10_13_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_13_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_421_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_13_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_420_EN_A.read();
    } else {
        v3_10_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_13_EN_B = ap_const_logic_1;
    } else {
        v3_10_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_13_Rst_A() {
    v3_10_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_13_Rst_B() {
    v3_10_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_13_WEN_A() {
    v3_10_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_13_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_14_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_422_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_14_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_421_Addr_A.read();
    } else {
        v3_10_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_14_Addr_A_orig() {
    v3_10_14_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_14_Addr_B() {
    v3_10_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_14_Addr_B_orig() {
    v3_10_14_Addr_B_orig =  (sc_lv<32>) (v3_10_14_addr_reg_63470.read());
}

void kernel_correlation_sdse::thread_v3_10_14_Clk_A() {
    v3_10_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_14_Clk_B() {
    v3_10_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_14_Din_A() {
    v3_10_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_14_Din_B() {
    v3_10_14_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_14_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_422_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_14_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_421_EN_A.read();
    } else {
        v3_10_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_14_EN_B = ap_const_logic_1;
    } else {
        v3_10_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_14_Rst_A() {
    v3_10_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_14_Rst_B() {
    v3_10_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_14_WEN_A() {
    v3_10_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_14_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_15_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_423_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_15_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_422_Addr_A.read();
    } else {
        v3_10_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_15_Addr_A_orig() {
    v3_10_15_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_15_Addr_B() {
    v3_10_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_15_Addr_B_orig() {
    v3_10_15_Addr_B_orig =  (sc_lv<32>) (v3_10_15_addr_reg_65130.read());
}

void kernel_correlation_sdse::thread_v3_10_15_Clk_A() {
    v3_10_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_15_Clk_B() {
    v3_10_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_15_Din_A() {
    v3_10_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_15_Din_B() {
    v3_10_15_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_15_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_423_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_15_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_422_EN_A.read();
    } else {
        v3_10_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_15_EN_B = ap_const_logic_1;
    } else {
        v3_10_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_15_Rst_A() {
    v3_10_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_15_Rst_B() {
    v3_10_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_15_WEN_A() {
    v3_10_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_15_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_C) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_16_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_424_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_16_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_423_Addr_A.read();
    } else {
        v3_10_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_16_Addr_A_orig() {
    v3_10_16_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_16_Addr_B() {
    v3_10_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_16_Addr_B_orig() {
    v3_10_16_Addr_B_orig =  (sc_lv<32>) (v3_10_16_addr_reg_60156.read());
}

void kernel_correlation_sdse::thread_v3_10_16_Clk_A() {
    v3_10_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_16_Clk_B() {
    v3_10_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_16_Din_A() {
    v3_10_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_16_Din_B() {
    v3_10_16_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_16_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_424_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_16_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_423_EN_A.read();
    } else {
        v3_10_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_16_EN_B = ap_const_logic_1;
    } else {
        v3_10_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_16_Rst_A() {
    v3_10_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_16_Rst_B() {
    v3_10_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_16_WEN_A() {
    v3_10_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_16_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_17_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_425_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_17_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_424_Addr_A.read();
    } else {
        v3_10_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_17_Addr_A_orig() {
    v3_10_17_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_17_Addr_B() {
    v3_10_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_17_Addr_B_orig() {
    v3_10_17_Addr_B_orig =  (sc_lv<32>) (v3_10_17_addr_reg_61816.read());
}

void kernel_correlation_sdse::thread_v3_10_17_Clk_A() {
    v3_10_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_17_Clk_B() {
    v3_10_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_17_Din_A() {
    v3_10_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_17_Din_B() {
    v3_10_17_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_17_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_425_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_17_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_424_EN_A.read();
    } else {
        v3_10_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_17_EN_B = ap_const_logic_1;
    } else {
        v3_10_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_17_Rst_A() {
    v3_10_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_17_Rst_B() {
    v3_10_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_17_WEN_A() {
    v3_10_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_17_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_18_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_426_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_18_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_425_Addr_A.read();
    } else {
        v3_10_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_18_Addr_A_orig() {
    v3_10_18_Addr_A_orig =  (sc_lv<32>) (sext_ln3602_1_fu_51198_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_18_Addr_B() {
    v3_10_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_18_Addr_B_orig() {
    v3_10_18_Addr_B_orig =  (sc_lv<32>) (v3_10_18_addr_reg_63476.read());
}

void kernel_correlation_sdse::thread_v3_10_18_Clk_A() {
    v3_10_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_18_Clk_B() {
    v3_10_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_18_Din_A() {
    v3_10_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_18_Din_B() {
    v3_10_18_Din_B = grp_fu_42134_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_18_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_426_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_18_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_425_EN_A.read();
    } else {
        v3_10_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_18_EN_B = ap_const_logic_1;
    } else {
        v3_10_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_18_Rst_A() {
    v3_10_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_18_Rst_B() {
    v3_10_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_18_WEN_A() {
    v3_10_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_18_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_19_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_427_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_19_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_426_Addr_A.read();
    } else {
        v3_10_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_19_Addr_A_orig() {
    v3_10_19_Addr_A_orig =  (sc_lv<32>) (sext_ln3610_1_fu_51498_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_19_Addr_B() {
    v3_10_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_19_Addr_B_orig() {
    v3_10_19_Addr_B_orig =  (sc_lv<32>) (v3_10_19_addr_reg_65136.read());
}

void kernel_correlation_sdse::thread_v3_10_19_Clk_A() {
    v3_10_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_19_Clk_B() {
    v3_10_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_19_Din_A() {
    v3_10_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_19_Din_B() {
    v3_10_19_Din_B = grp_fu_42150_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_19_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_427_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_19_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_426_EN_A.read();
    } else {
        v3_10_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_19_EN_B = ap_const_logic_1;
    } else {
        v3_10_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_19_Rst_A() {
    v3_10_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_19_Rst_B() {
    v3_10_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_19_WEN_A() {
    v3_10_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_19_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_10) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_409_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_1_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_408_Addr_A.read();
    } else {
        v3_10_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_1_Addr_A_orig() {
    v3_10_1_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_1_Addr_B() {
    v3_10_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_1_Addr_B_orig() {
    v3_10_1_Addr_B_orig =  (sc_lv<32>) (v3_10_1_addr_reg_61792.read());
}

void kernel_correlation_sdse::thread_v3_10_1_Clk_A() {
    v3_10_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_1_Clk_B() {
    v3_10_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_1_Din_A() {
    v3_10_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_1_Din_B() {
    v3_10_1_Din_B = grp_fu_42119_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_409_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_1_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_408_EN_A.read();
    } else {
        v3_10_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_1_EN_B = ap_const_logic_1;
    } else {
        v3_10_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_1_Rst_A() {
    v3_10_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_1_Rst_B() {
    v3_10_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_1_WEN_A() {
    v3_10_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_1_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_20_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_428_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_20_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_427_Addr_A.read();
    } else {
        v3_10_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_20_Addr_A_orig() {
    v3_10_20_Addr_A_orig =  (sc_lv<32>) (sext_ln3586_1_fu_50598_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_20_Addr_B() {
    v3_10_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_20_Addr_B_orig() {
    v3_10_20_Addr_B_orig =  (sc_lv<32>) (v3_10_20_addr_reg_60162.read());
}

void kernel_correlation_sdse::thread_v3_10_20_Clk_A() {
    v3_10_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_20_Clk_B() {
    v3_10_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_20_Din_A() {
    v3_10_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v3_10_20_Din_B() {
    v3_10_20_Din_B = grp_fu_42104_p2.read();
}

void kernel_correlation_sdse::thread_v3_10_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v3_10_20_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_428_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_20_EN_A = grp_aesl_mux_load_1040_1_fu_37566_empty_427_EN_A.read();
    } else {
        v3_10_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_20_EN_B = ap_const_logic_1;
    } else {
        v3_10_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_20_Rst_A() {
    v3_10_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_20_Rst_B() {
    v3_10_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v3_10_20_WEN_A() {
    v3_10_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v3_10_20_WEN_B() {
    if ((esl_seteq<1,7,7>(trunc_ln3585_reg_59528.read(), ap_const_lv7_14) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp2_iter1.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0))) {
        v3_10_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v3_10_21_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage2.read(), ap_const_boolean_0)))) {
        v3_10_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_429_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln4420_reg_66708_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, tmp_135_reg_66774_pp3_iter3_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0)))) {
        v3_10_21_Addr_A = grp_aesl_mux_load_1040_1_fu_37566_empty_428_Addr_A.read();
    } else {
        v3_10_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_correlation_sdse::thread_v3_10_21_Addr_A_orig() {
    v3_10_21_Addr_A_orig =  (sc_lv<32>) (sext_ln3594_1_fu_50898_p1.read());
}

void kernel_correlation_sdse::thread_v3_10_21_Addr_B() {
    v3_10_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v3_10_21_Addr_B_orig() {
    v3_10_21_Addr_B_orig =  (sc_lv<32>) (v3_10_21_addr_reg_61822.read());
}

void kernel_correlation_sdse::thread_v3_10_21_Clk_A() {
    v3_10_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v3_10_21_Clk_B() {
    v3_10_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

}


#include "kernel_correlation_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_correlation_sdse::thread_v5_20_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_20_WEN_B = ap_const_lv4_F;
    } else {
        v5_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_21_Addr_A() {
    v5_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_21_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_21_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_21_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_21_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_21_Addr_B() {
    v5_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_21_Addr_B_orig() {
    v5_21_Addr_B_orig =  (sc_lv<32>) (v5_21_addr_reg_55118.read());
}

void kernel_correlation_sdse::thread_v5_21_Clk_A() {
    v5_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_21_Clk_B() {
    v5_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_21_Din_A() {
    v5_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_21_Din_B() {
    v5_21_Din_B = reg_46713.read();
}

void kernel_correlation_sdse::thread_v5_21_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_21_EN_A = ap_const_logic_1;
    } else {
        v5_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_21_EN_B = ap_const_logic_1;
    } else {
        v5_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_21_Rst_A() {
    v5_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_21_Rst_B() {
    v5_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_21_WEN_A() {
    v5_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_21_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_21_WEN_B = ap_const_lv4_F;
    } else {
        v5_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_22_Addr_A() {
    v5_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_22_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_22_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_22_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_22_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_22_Addr_B() {
    v5_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_22_Addr_B_orig() {
    v5_22_Addr_B_orig =  (sc_lv<32>) (v5_22_addr_reg_55123.read());
}

void kernel_correlation_sdse::thread_v5_22_Clk_A() {
    v5_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_22_Clk_B() {
    v5_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_22_Din_A() {
    v5_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_22_Din_B() {
    v5_22_Din_B = reg_46720.read();
}

void kernel_correlation_sdse::thread_v5_22_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_22_EN_A = ap_const_logic_1;
    } else {
        v5_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_22_EN_B = ap_const_logic_1;
    } else {
        v5_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_22_Rst_A() {
    v5_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_22_Rst_B() {
    v5_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_22_WEN_A() {
    v5_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_22_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_22_WEN_B = ap_const_lv4_F;
    } else {
        v5_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_23_Addr_A() {
    v5_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_23_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_23_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_23_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_23_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_23_Addr_B() {
    v5_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_23_Addr_B_orig() {
    v5_23_Addr_B_orig =  (sc_lv<32>) (v5_23_addr_reg_55128.read());
}

void kernel_correlation_sdse::thread_v5_23_Clk_A() {
    v5_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_23_Clk_B() {
    v5_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_23_Din_A() {
    v5_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_23_Din_B() {
    v5_23_Din_B = reg_46727.read();
}

void kernel_correlation_sdse::thread_v5_23_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_23_EN_A = ap_const_logic_1;
    } else {
        v5_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_23_EN_B = ap_const_logic_1;
    } else {
        v5_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_23_Rst_A() {
    v5_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_23_Rst_B() {
    v5_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_23_WEN_A() {
    v5_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_23_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_23_WEN_B = ap_const_lv4_F;
    } else {
        v5_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_24_Addr_A() {
    v5_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_24_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_24_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_24_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_24_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_24_Addr_B() {
    v5_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_24_Addr_B_orig() {
    v5_24_Addr_B_orig =  (sc_lv<32>) (v5_24_addr_reg_55133.read());
}

void kernel_correlation_sdse::thread_v5_24_Clk_A() {
    v5_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_24_Clk_B() {
    v5_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_24_Din_A() {
    v5_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_24_Din_B() {
    v5_24_Din_B = reg_46734.read();
}

void kernel_correlation_sdse::thread_v5_24_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_24_EN_A = ap_const_logic_1;
    } else {
        v5_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_24_EN_B = ap_const_logic_1;
    } else {
        v5_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_24_Rst_A() {
    v5_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_24_Rst_B() {
    v5_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_24_WEN_A() {
    v5_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_24_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_24_WEN_B = ap_const_lv4_F;
    } else {
        v5_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_25_Addr_A() {
    v5_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_25_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_25_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_25_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_25_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_25_Addr_B() {
    v5_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_25_Addr_B_orig() {
    v5_25_Addr_B_orig =  (sc_lv<32>) (v5_25_addr_reg_55138.read());
}

void kernel_correlation_sdse::thread_v5_25_Clk_A() {
    v5_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_25_Clk_B() {
    v5_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_25_Din_A() {
    v5_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_25_Din_B() {
    v5_25_Din_B = reg_46741.read();
}

void kernel_correlation_sdse::thread_v5_25_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_25_EN_A = ap_const_logic_1;
    } else {
        v5_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_25_EN_B = ap_const_logic_1;
    } else {
        v5_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_25_Rst_A() {
    v5_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_25_Rst_B() {
    v5_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_25_WEN_A() {
    v5_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_25_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_25_WEN_B = ap_const_lv4_F;
    } else {
        v5_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_26_Addr_A() {
    v5_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_26_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_26_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_26_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_26_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_26_Addr_B() {
    v5_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_26_Addr_B_orig() {
    v5_26_Addr_B_orig =  (sc_lv<32>) (v5_26_addr_reg_55143.read());
}

void kernel_correlation_sdse::thread_v5_26_Clk_A() {
    v5_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_26_Clk_B() {
    v5_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_26_Din_A() {
    v5_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_26_Din_B() {
    v5_26_Din_B = reg_46748.read();
}

void kernel_correlation_sdse::thread_v5_26_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_26_EN_A = ap_const_logic_1;
    } else {
        v5_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_26_EN_B = ap_const_logic_1;
    } else {
        v5_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_26_Rst_A() {
    v5_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_26_Rst_B() {
    v5_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_26_WEN_A() {
    v5_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_26_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_26_WEN_B = ap_const_lv4_F;
    } else {
        v5_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_27_Addr_A() {
    v5_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_27_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_27_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_27_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_27_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_27_Addr_B() {
    v5_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_27_Addr_B_orig() {
    v5_27_Addr_B_orig =  (sc_lv<32>) (v5_27_addr_reg_55148.read());
}

void kernel_correlation_sdse::thread_v5_27_Clk_A() {
    v5_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_27_Clk_B() {
    v5_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_27_Din_A() {
    v5_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_27_Din_B() {
    v5_27_Din_B = reg_46755.read();
}

void kernel_correlation_sdse::thread_v5_27_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_27_EN_A = ap_const_logic_1;
    } else {
        v5_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_27_EN_B = ap_const_logic_1;
    } else {
        v5_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_27_Rst_A() {
    v5_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_27_Rst_B() {
    v5_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_27_WEN_A() {
    v5_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_27_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_27_WEN_B = ap_const_lv4_F;
    } else {
        v5_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_28_Addr_A() {
    v5_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_28_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_28_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_28_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_28_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_28_Addr_B() {
    v5_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_28_Addr_B_orig() {
    v5_28_Addr_B_orig =  (sc_lv<32>) (v5_28_addr_reg_55153.read());
}

void kernel_correlation_sdse::thread_v5_28_Clk_A() {
    v5_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_28_Clk_B() {
    v5_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_28_Din_A() {
    v5_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_28_Din_B() {
    v5_28_Din_B = reg_46762.read();
}

void kernel_correlation_sdse::thread_v5_28_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_28_EN_A = ap_const_logic_1;
    } else {
        v5_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_28_EN_B = ap_const_logic_1;
    } else {
        v5_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_28_Rst_A() {
    v5_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_28_Rst_B() {
    v5_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_28_WEN_A() {
    v5_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_28_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_28_WEN_B = ap_const_lv4_F;
    } else {
        v5_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_29_Addr_A() {
    v5_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_29_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_29_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_29_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_29_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_29_Addr_B() {
    v5_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_29_Addr_B_orig() {
    v5_29_Addr_B_orig =  (sc_lv<32>) (v5_29_addr_reg_55158.read());
}

void kernel_correlation_sdse::thread_v5_29_Clk_A() {
    v5_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_29_Clk_B() {
    v5_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_29_Din_A() {
    v5_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_29_Din_B() {
    v5_29_Din_B = reg_46769.read();
}

void kernel_correlation_sdse::thread_v5_29_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_29_EN_A = ap_const_logic_1;
    } else {
        v5_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_29_EN_B = ap_const_logic_1;
    } else {
        v5_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_29_Rst_A() {
    v5_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_29_Rst_B() {
    v5_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_29_WEN_A() {
    v5_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_29_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_29_WEN_B = ap_const_lv4_F;
    } else {
        v5_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_2_Addr_A() {
    v5_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_2_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_2_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_2_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_2_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_2_Addr_B() {
    v5_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_2_Addr_B_orig() {
    v5_2_Addr_B_orig =  (sc_lv<32>) (zext_ln54_fu_47734_p1.read());
}

void kernel_correlation_sdse::thread_v5_2_Clk_A() {
    v5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_2_Clk_B() {
    v5_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_2_Din_A() {
    v5_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_2_Din_B() {
    v5_2_Din_B = reg_46720.read();
}

void kernel_correlation_sdse::thread_v5_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_2_EN_A = ap_const_logic_1;
    } else {
        v5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_2_EN_B = ap_const_logic_1;
    } else {
        v5_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_2_Rst_A() {
    v5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_2_Rst_B() {
    v5_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_2_WEN_A() {
    v5_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_30_Addr_A() {
    v5_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_30_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_30_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_30_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_30_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_30_Addr_B() {
    v5_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_30_Addr_B_orig() {
    v5_30_Addr_B_orig =  (sc_lv<32>) (v5_30_addr_reg_55163.read());
}

void kernel_correlation_sdse::thread_v5_30_Clk_A() {
    v5_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_30_Clk_B() {
    v5_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_30_Din_A() {
    v5_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_30_Din_B() {
    v5_30_Din_B = reg_46776.read();
}

void kernel_correlation_sdse::thread_v5_30_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_30_EN_A = ap_const_logic_1;
    } else {
        v5_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_30_EN_B = ap_const_logic_1;
    } else {
        v5_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_30_Rst_A() {
    v5_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_30_Rst_B() {
    v5_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_30_WEN_A() {
    v5_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_30_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_30_WEN_B = ap_const_lv4_F;
    } else {
        v5_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_31_Addr_A() {
    v5_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_31_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_31_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_31_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_31_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_31_Addr_B() {
    v5_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_31_Addr_B_orig() {
    v5_31_Addr_B_orig =  (sc_lv<32>) (v5_31_addr_reg_55168.read());
}

void kernel_correlation_sdse::thread_v5_31_Clk_A() {
    v5_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_31_Clk_B() {
    v5_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_31_Din_A() {
    v5_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_31_Din_B() {
    v5_31_Din_B = reg_46783.read();
}

void kernel_correlation_sdse::thread_v5_31_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_31_EN_A = ap_const_logic_1;
    } else {
        v5_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_31_EN_B = ap_const_logic_1;
    } else {
        v5_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_31_Rst_A() {
    v5_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_31_Rst_B() {
    v5_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_31_WEN_A() {
    v5_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_31_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_31_WEN_B = ap_const_lv4_F;
    } else {
        v5_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_32_Addr_A() {
    v5_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_32_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_32_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_32_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_32_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_32_Addr_B() {
    v5_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_32_Addr_B_orig() {
    v5_32_Addr_B_orig =  (sc_lv<32>) (v5_32_addr_reg_55173.read());
}

void kernel_correlation_sdse::thread_v5_32_Clk_A() {
    v5_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_32_Clk_B() {
    v5_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_32_Din_A() {
    v5_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_32_Din_B() {
    v5_32_Din_B = reg_46790.read();
}

void kernel_correlation_sdse::thread_v5_32_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_32_EN_A = ap_const_logic_1;
    } else {
        v5_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_32_EN_B = ap_const_logic_1;
    } else {
        v5_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_32_Rst_A() {
    v5_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_32_Rst_B() {
    v5_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_32_WEN_A() {
    v5_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_32_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_32_WEN_B = ap_const_lv4_F;
    } else {
        v5_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_33_Addr_A() {
    v5_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_33_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_33_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_33_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_33_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_33_Addr_B() {
    v5_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_33_Addr_B_orig() {
    v5_33_Addr_B_orig =  (sc_lv<32>) (v5_33_addr_reg_55178.read());
}

void kernel_correlation_sdse::thread_v5_33_Clk_A() {
    v5_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_33_Clk_B() {
    v5_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_33_Din_A() {
    v5_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_33_Din_B() {
    v5_33_Din_B = reg_46797.read();
}

void kernel_correlation_sdse::thread_v5_33_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_33_EN_A = ap_const_logic_1;
    } else {
        v5_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_33_EN_B = ap_const_logic_1;
    } else {
        v5_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_33_Rst_A() {
    v5_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_33_Rst_B() {
    v5_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_33_WEN_A() {
    v5_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_33_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_33_WEN_B = ap_const_lv4_F;
    } else {
        v5_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_34_Addr_A() {
    v5_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_34_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_34_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_34_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_34_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_34_Addr_B() {
    v5_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_34_Addr_B_orig() {
    v5_34_Addr_B_orig =  (sc_lv<32>) (v5_34_addr_reg_55183.read());
}

void kernel_correlation_sdse::thread_v5_34_Clk_A() {
    v5_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_34_Clk_B() {
    v5_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_34_Din_A() {
    v5_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_34_Din_B() {
    v5_34_Din_B = reg_46804.read();
}

void kernel_correlation_sdse::thread_v5_34_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_34_EN_A = ap_const_logic_1;
    } else {
        v5_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_34_EN_B = ap_const_logic_1;
    } else {
        v5_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_34_Rst_A() {
    v5_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_34_Rst_B() {
    v5_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_34_WEN_A() {
    v5_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_34_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_34_WEN_B = ap_const_lv4_F;
    } else {
        v5_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_35_Addr_A() {
    v5_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_35_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_35_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_35_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_35_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_35_Addr_B() {
    v5_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_35_Addr_B_orig() {
    v5_35_Addr_B_orig =  (sc_lv<32>) (v5_35_addr_reg_55188.read());
}

void kernel_correlation_sdse::thread_v5_35_Clk_A() {
    v5_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_35_Clk_B() {
    v5_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_35_Din_A() {
    v5_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_35_Din_B() {
    v5_35_Din_B = reg_46810.read();
}

void kernel_correlation_sdse::thread_v5_35_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_35_EN_A = ap_const_logic_1;
    } else {
        v5_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_35_EN_B = ap_const_logic_1;
    } else {
        v5_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_35_Rst_A() {
    v5_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_35_Rst_B() {
    v5_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_35_WEN_A() {
    v5_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_35_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_35_WEN_B = ap_const_lv4_F;
    } else {
        v5_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_36_Addr_A() {
    v5_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_36_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_36_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_36_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_36_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_36_Addr_B() {
    v5_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_36_Addr_B_orig() {
    v5_36_Addr_B_orig =  (sc_lv<32>) (v5_36_addr_reg_55193.read());
}

void kernel_correlation_sdse::thread_v5_36_Clk_A() {
    v5_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_36_Clk_B() {
    v5_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_36_Din_A() {
    v5_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_36_Din_B() {
    v5_36_Din_B = reg_46816.read();
}

void kernel_correlation_sdse::thread_v5_36_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_36_EN_A = ap_const_logic_1;
    } else {
        v5_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_36_EN_B = ap_const_logic_1;
    } else {
        v5_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_36_Rst_A() {
    v5_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_36_Rst_B() {
    v5_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_36_WEN_A() {
    v5_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_36_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_36_WEN_B = ap_const_lv4_F;
    } else {
        v5_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_37_Addr_A() {
    v5_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_37_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_37_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_37_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_37_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_37_Addr_B() {
    v5_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_37_Addr_B_orig() {
    v5_37_Addr_B_orig =  (sc_lv<32>) (v5_37_addr_reg_55198.read());
}

void kernel_correlation_sdse::thread_v5_37_Clk_A() {
    v5_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_37_Clk_B() {
    v5_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_37_Din_A() {
    v5_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_37_Din_B() {
    v5_37_Din_B = reg_46822.read();
}

void kernel_correlation_sdse::thread_v5_37_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_37_EN_A = ap_const_logic_1;
    } else {
        v5_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_37_EN_B = ap_const_logic_1;
    } else {
        v5_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_37_Rst_A() {
    v5_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_37_Rst_B() {
    v5_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_37_WEN_A() {
    v5_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_37_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_37_WEN_B = ap_const_lv4_F;
    } else {
        v5_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_38_Addr_A() {
    v5_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_38_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_38_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_38_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_38_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_38_Addr_B() {
    v5_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_38_Addr_B_orig() {
    v5_38_Addr_B_orig =  (sc_lv<32>) (v5_38_addr_reg_55203.read());
}

void kernel_correlation_sdse::thread_v5_38_Clk_A() {
    v5_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_38_Clk_B() {
    v5_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_38_Din_A() {
    v5_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_38_Din_B() {
    v5_38_Din_B = reg_46828.read();
}

void kernel_correlation_sdse::thread_v5_38_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_38_EN_A = ap_const_logic_1;
    } else {
        v5_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_38_EN_B = ap_const_logic_1;
    } else {
        v5_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_38_Rst_A() {
    v5_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_38_Rst_B() {
    v5_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_38_WEN_A() {
    v5_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_38_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_38_WEN_B = ap_const_lv4_F;
    } else {
        v5_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_39_Addr_A() {
    v5_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_39_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_39_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_39_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_39_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_39_Addr_B() {
    v5_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_39_Addr_B_orig() {
    v5_39_Addr_B_orig =  (sc_lv<32>) (v5_39_addr_reg_55208.read());
}

void kernel_correlation_sdse::thread_v5_39_Clk_A() {
    v5_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_39_Clk_B() {
    v5_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_39_Din_A() {
    v5_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_39_Din_B() {
    v5_39_Din_B = reg_46834.read();
}

void kernel_correlation_sdse::thread_v5_39_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_39_EN_A = ap_const_logic_1;
    } else {
        v5_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_39_EN_B = ap_const_logic_1;
    } else {
        v5_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_39_Rst_A() {
    v5_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_39_Rst_B() {
    v5_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_39_WEN_A() {
    v5_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_39_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln51_reg_52463_pp0_iter15_reg.read()))) {
        v5_39_WEN_B = ap_const_lv4_F;
    } else {
        v5_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_3_Addr_A() {
    v5_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_3_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_3_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_3_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_3_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_3_Addr_B() {
    v5_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_3_Addr_B_orig() {
    v5_3_Addr_B_orig =  (sc_lv<32>) (zext_ln54_fu_47734_p1.read());
}

void kernel_correlation_sdse::thread_v5_3_Clk_A() {
    v5_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_3_Clk_B() {
    v5_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_3_Din_A() {
    v5_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_3_Din_B() {
    v5_3_Din_B = reg_46727.read();
}

void kernel_correlation_sdse::thread_v5_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_3_EN_A = ap_const_logic_1;
    } else {
        v5_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_3_EN_B = ap_const_logic_1;
    } else {
        v5_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_3_Rst_A() {
    v5_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_3_Rst_B() {
    v5_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_3_WEN_A() {
    v5_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_4_Addr_A() {
    v5_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_4_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_4_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_4_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_4_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_4_Addr_B() {
    v5_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_4_Addr_B_orig() {
    v5_4_Addr_B_orig =  (sc_lv<32>) (zext_ln54_fu_47734_p1.read());
}

void kernel_correlation_sdse::thread_v5_4_Clk_A() {
    v5_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_4_Clk_B() {
    v5_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_4_Din_A() {
    v5_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_4_Din_B() {
    v5_4_Din_B = reg_46734.read();
}

void kernel_correlation_sdse::thread_v5_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_4_EN_A = ap_const_logic_1;
    } else {
        v5_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_4_EN_B = ap_const_logic_1;
    } else {
        v5_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_4_Rst_A() {
    v5_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_4_Rst_B() {
    v5_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_4_WEN_A() {
    v5_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_5_Addr_A() {
    v5_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_5_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_5_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_5_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_5_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_5_Addr_B() {
    v5_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_5_Addr_B_orig() {
    v5_5_Addr_B_orig =  (sc_lv<32>) (zext_ln54_fu_47734_p1.read());
}

void kernel_correlation_sdse::thread_v5_5_Clk_A() {
    v5_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_5_Clk_B() {
    v5_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_5_Din_A() {
    v5_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_5_Din_B() {
    v5_5_Din_B = reg_46741.read();
}

void kernel_correlation_sdse::thread_v5_5_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_5_EN_A = ap_const_logic_1;
    } else {
        v5_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_5_EN_B = ap_const_logic_1;
    } else {
        v5_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_5_Rst_A() {
    v5_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_5_Rst_B() {
    v5_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_5_WEN_A() {
    v5_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_5_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_5_WEN_B = ap_const_lv4_F;
    } else {
        v5_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_6_Addr_A() {
    v5_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_6_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_6_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_6_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_6_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_6_Addr_B() {
    v5_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_6_Addr_B_orig() {
    v5_6_Addr_B_orig =  (sc_lv<32>) (zext_ln54_fu_47734_p1.read());
}

void kernel_correlation_sdse::thread_v5_6_Clk_A() {
    v5_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_6_Clk_B() {
    v5_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_6_Din_A() {
    v5_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_6_Din_B() {
    v5_6_Din_B = reg_46748.read();
}

void kernel_correlation_sdse::thread_v5_6_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_6_EN_A = ap_const_logic_1;
    } else {
        v5_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_6_EN_B = ap_const_logic_1;
    } else {
        v5_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_6_Rst_A() {
    v5_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_6_Rst_B() {
    v5_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_6_WEN_A() {
    v5_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_6_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_6_WEN_B = ap_const_lv4_F;
    } else {
        v5_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_7_Addr_A() {
    v5_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_7_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_7_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_7_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_7_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_7_Addr_B() {
    v5_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_7_Addr_B_orig() {
    v5_7_Addr_B_orig =  (sc_lv<32>) (zext_ln54_fu_47734_p1.read());
}

void kernel_correlation_sdse::thread_v5_7_Clk_A() {
    v5_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_7_Clk_B() {
    v5_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_7_Din_A() {
    v5_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_7_Din_B() {
    v5_7_Din_B = reg_46755.read();
}

void kernel_correlation_sdse::thread_v5_7_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_7_EN_A = ap_const_logic_1;
    } else {
        v5_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_7_EN_B = ap_const_logic_1;
    } else {
        v5_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_7_Rst_A() {
    v5_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_7_Rst_B() {
    v5_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_7_WEN_A() {
    v5_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_7_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_7_WEN_B = ap_const_lv4_F;
    } else {
        v5_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_8_Addr_A() {
    v5_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_8_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_8_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_8_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_8_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_8_Addr_B() {
    v5_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_8_Addr_B_orig() {
    v5_8_Addr_B_orig =  (sc_lv<32>) (zext_ln54_fu_47734_p1.read());
}

void kernel_correlation_sdse::thread_v5_8_Clk_A() {
    v5_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_8_Clk_B() {
    v5_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_8_Din_A() {
    v5_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_8_Din_B() {
    v5_8_Din_B = reg_46762.read();
}

void kernel_correlation_sdse::thread_v5_8_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_8_EN_A = ap_const_logic_1;
    } else {
        v5_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_8_EN_B = ap_const_logic_1;
    } else {
        v5_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_8_Rst_A() {
    v5_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_8_Rst_B() {
    v5_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_8_WEN_A() {
    v5_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_8_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_8_WEN_B = ap_const_lv4_F;
    } else {
        v5_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v5_9_Addr_A() {
    v5_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_9_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_9_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_9_Addr_A_orig =  (sc_lv<32>) (zext_ln1339_fu_47859_p1.read());
    } else {
        v5_9_Addr_A_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_correlation_sdse::thread_v5_9_Addr_B() {
    v5_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v5_9_Addr_B_orig() {
    v5_9_Addr_B_orig =  (sc_lv<32>) (zext_ln54_fu_47734_p1.read());
}

void kernel_correlation_sdse::thread_v5_9_Clk_A() {
    v5_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_9_Clk_B() {
    v5_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v5_9_Din_A() {
    v5_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v5_9_Din_B() {
    v5_9_Din_B = reg_46769.read();
}

void kernel_correlation_sdse::thread_v5_9_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)))) {
        v5_9_EN_A = ap_const_logic_1;
    } else {
        v5_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_9_EN_B = ap_const_logic_1;
    } else {
        v5_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v5_9_Rst_A() {
    v5_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_9_Rst_B() {
    v5_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v5_9_WEN_A() {
    v5_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v5_9_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter15.read()))) {
        v5_9_WEN_B = ap_const_lv4_F;
    } else {
        v5_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_0_Addr_A() {
    v6_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_0_Addr_A_orig() {
    v6_0_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_0_Addr_B() {
    v6_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_0_Addr_B_orig() {
    v6_0_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_0_Clk_A() {
    v6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_0_Clk_B() {
    v6_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_0_Din_A() {
    v6_0_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_0_Din_B() {
    v6_0_Din_B = (!and_ln3030_fu_48888_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3030_fu_48888_p2.read()[0].to_bool())? ap_const_lv32_3F800000: reg_47014.read());
}

void kernel_correlation_sdse::thread_v6_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_0_EN_A = ap_const_logic_1;
    } else {
        v6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_0_EN_B = ap_const_logic_1;
    } else {
        v6_0_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_0_Rst_A() {
    v6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_0_Rst_B() {
    v6_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_0_WEN_A() {
    v6_0_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_10_Addr_A() {
    v6_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_10_Addr_A_orig() {
    v6_10_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_10_Addr_B() {
    v6_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_10_Addr_B_orig() {
    v6_10_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_10_Clk_A() {
    v6_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_10_Clk_B() {
    v6_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_10_Din_A() {
    v6_10_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_10_Din_B() {
    v6_10_Din_B = (!and_ln3170_fu_49069_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3170_fu_49069_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2249_reg_58835.read());
}

void kernel_correlation_sdse::thread_v6_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_10_EN_A = ap_const_logic_1;
    } else {
        v6_10_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_10_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_10_EN_B = ap_const_logic_1;
    } else {
        v6_10_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_10_Rst_A() {
    v6_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_10_Rst_B() {
    v6_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_10_WEN_A() {
    v6_10_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_10_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_10_WEN_B = ap_const_lv4_F;
    } else {
        v6_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_11_Addr_A() {
    v6_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_11_Addr_A_orig() {
    v6_11_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_11_Addr_B() {
    v6_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_11_Addr_B_orig() {
    v6_11_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_11_Clk_A() {
    v6_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_11_Clk_B() {
    v6_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_11_Din_A() {
    v6_11_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_11_Din_B() {
    v6_11_Din_B = (!and_ln3184_fu_49087_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3184_fu_49087_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2260_reg_58841.read());
}

void kernel_correlation_sdse::thread_v6_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_11_EN_A = ap_const_logic_1;
    } else {
        v6_11_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_11_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_11_EN_B = ap_const_logic_1;
    } else {
        v6_11_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_11_Rst_A() {
    v6_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_11_Rst_B() {
    v6_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_11_WEN_A() {
    v6_11_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_11_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_11_WEN_B = ap_const_lv4_F;
    } else {
        v6_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_12_Addr_A() {
    v6_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_12_Addr_A_orig() {
    v6_12_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_12_Addr_B() {
    v6_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_12_Addr_B_orig() {
    v6_12_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_12_Clk_A() {
    v6_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_12_Clk_B() {
    v6_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_12_Din_A() {
    v6_12_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_12_Din_B() {
    v6_12_Din_B = (!and_ln3198_fu_49105_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3198_fu_49105_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2271_reg_58847.read());
}

void kernel_correlation_sdse::thread_v6_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_12_EN_A = ap_const_logic_1;
    } else {
        v6_12_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_12_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_12_EN_B = ap_const_logic_1;
    } else {
        v6_12_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_12_Rst_A() {
    v6_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_12_Rst_B() {
    v6_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_12_WEN_A() {
    v6_12_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_12_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_12_WEN_B = ap_const_lv4_F;
    } else {
        v6_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_13_Addr_A() {
    v6_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_13_Addr_A_orig() {
    v6_13_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_13_Addr_B() {
    v6_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_13_Addr_B_orig() {
    v6_13_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_13_Clk_A() {
    v6_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_13_Clk_B() {
    v6_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_13_Din_A() {
    v6_13_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_13_Din_B() {
    v6_13_Din_B = (!and_ln3212_fu_49123_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3212_fu_49123_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2282_reg_58853.read());
}

void kernel_correlation_sdse::thread_v6_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_13_EN_A = ap_const_logic_1;
    } else {
        v6_13_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_13_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_13_EN_B = ap_const_logic_1;
    } else {
        v6_13_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_13_Rst_A() {
    v6_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_13_Rst_B() {
    v6_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_13_WEN_A() {
    v6_13_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_13_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_13_WEN_B = ap_const_lv4_F;
    } else {
        v6_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_14_Addr_A() {
    v6_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_14_Addr_A_orig() {
    v6_14_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_14_Addr_B() {
    v6_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_14_Addr_B_orig() {
    v6_14_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_14_Clk_A() {
    v6_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_14_Clk_B() {
    v6_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_14_Din_A() {
    v6_14_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_14_Din_B() {
    v6_14_Din_B = (!and_ln3226_fu_49561_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3226_fu_49561_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2293_reg_58859.read());
}

void kernel_correlation_sdse::thread_v6_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_14_EN_A = ap_const_logic_1;
    } else {
        v6_14_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_14_EN_B = ap_const_logic_1;
    } else {
        v6_14_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_14_Rst_A() {
    v6_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_14_Rst_B() {
    v6_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_14_WEN_A() {
    v6_14_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_14_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_14_WEN_B = ap_const_lv4_F;
    } else {
        v6_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_15_Addr_A() {
    v6_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_15_Addr_A_orig() {
    v6_15_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_15_Addr_B() {
    v6_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_15_Addr_B_orig() {
    v6_15_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_15_Clk_A() {
    v6_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_15_Clk_B() {
    v6_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_15_Din_A() {
    v6_15_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_15_Din_B() {
    v6_15_Din_B = (!and_ln3240_fu_49579_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3240_fu_49579_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2304_reg_58865.read());
}

void kernel_correlation_sdse::thread_v6_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_15_EN_A = ap_const_logic_1;
    } else {
        v6_15_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_15_EN_B = ap_const_logic_1;
    } else {
        v6_15_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_15_Rst_A() {
    v6_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_15_Rst_B() {
    v6_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_15_WEN_A() {
    v6_15_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_15_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_15_WEN_B = ap_const_lv4_F;
    } else {
        v6_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_16_Addr_A() {
    v6_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_16_Addr_A_orig() {
    v6_16_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_16_Addr_B() {
    v6_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_16_Addr_B_orig() {
    v6_16_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_16_Clk_A() {
    v6_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_16_Clk_B() {
    v6_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_16_Din_A() {
    v6_16_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_16_Din_B() {
    v6_16_Din_B = (!and_ln3254_fu_49597_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3254_fu_49597_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2315_reg_58871.read());
}

void kernel_correlation_sdse::thread_v6_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_16_EN_A = ap_const_logic_1;
    } else {
        v6_16_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_16_EN_B = ap_const_logic_1;
    } else {
        v6_16_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_16_Rst_A() {
    v6_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_16_Rst_B() {
    v6_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_16_WEN_A() {
    v6_16_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_16_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_16_WEN_B = ap_const_lv4_F;
    } else {
        v6_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_17_Addr_A() {
    v6_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_17_Addr_A_orig() {
    v6_17_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_17_Addr_B() {
    v6_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_17_Addr_B_orig() {
    v6_17_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_17_Clk_A() {
    v6_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_17_Clk_B() {
    v6_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_17_Din_A() {
    v6_17_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_17_Din_B() {
    v6_17_Din_B = (!and_ln3268_fu_49615_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3268_fu_49615_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2326_reg_58877.read());
}

void kernel_correlation_sdse::thread_v6_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_17_EN_A = ap_const_logic_1;
    } else {
        v6_17_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_17_EN_B = ap_const_logic_1;
    } else {
        v6_17_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_17_Rst_A() {
    v6_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_17_Rst_B() {
    v6_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_17_WEN_A() {
    v6_17_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_17_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_17_WEN_B = ap_const_lv4_F;
    } else {
        v6_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_18_Addr_A() {
    v6_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_18_Addr_A_orig() {
    v6_18_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_18_Addr_B() {
    v6_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_18_Addr_B_orig() {
    v6_18_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_18_Clk_A() {
    v6_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_18_Clk_B() {
    v6_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_18_Din_A() {
    v6_18_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_18_Din_B() {
    v6_18_Din_B = (!and_ln3282_fu_49633_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3282_fu_49633_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2337_reg_58883.read());
}

void kernel_correlation_sdse::thread_v6_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_18_EN_A = ap_const_logic_1;
    } else {
        v6_18_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_18_EN_B = ap_const_logic_1;
    } else {
        v6_18_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_18_Rst_A() {
    v6_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_18_Rst_B() {
    v6_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_18_WEN_A() {
    v6_18_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_18_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_18_WEN_B = ap_const_lv4_F;
    } else {
        v6_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_19_Addr_A() {
    v6_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_19_Addr_A_orig() {
    v6_19_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_19_Addr_B() {
    v6_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_19_Addr_B_orig() {
    v6_19_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_19_Clk_A() {
    v6_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_19_Clk_B() {
    v6_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_19_Din_A() {
    v6_19_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_19_Din_B() {
    v6_19_Din_B = (!and_ln3296_fu_49651_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3296_fu_49651_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2348_reg_58889.read());
}

void kernel_correlation_sdse::thread_v6_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_19_EN_A = ap_const_logic_1;
    } else {
        v6_19_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_19_EN_B = ap_const_logic_1;
    } else {
        v6_19_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_19_Rst_A() {
    v6_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_19_Rst_B() {
    v6_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_19_WEN_A() {
    v6_19_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_19_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_19_WEN_B = ap_const_lv4_F;
    } else {
        v6_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_1_Addr_A() {
    v6_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_1_Addr_A_orig() {
    v6_1_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_1_Addr_B() {
    v6_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_1_Addr_B_orig() {
    v6_1_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_1_Clk_A() {
    v6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_1_Clk_B() {
    v6_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_1_Din_A() {
    v6_1_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_1_Din_B() {
    v6_1_Din_B = (!and_ln3044_fu_48907_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3044_fu_48907_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2150_reg_58781.read());
}

void kernel_correlation_sdse::thread_v6_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_1_EN_A = ap_const_logic_1;
    } else {
        v6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_1_EN_B = ap_const_logic_1;
    } else {
        v6_1_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_1_Rst_A() {
    v6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_1_Rst_B() {
    v6_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_1_WEN_A() {
    v6_1_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_20_Addr_A() {
    v6_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_20_Addr_A_orig() {
    v6_20_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_20_Addr_B() {
    v6_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_20_Addr_B_orig() {
    v6_20_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_20_Clk_A() {
    v6_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_20_Clk_B() {
    v6_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_20_Din_A() {
    v6_20_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_20_Din_B() {
    v6_20_Din_B = (!and_ln3310_fu_49669_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3310_fu_49669_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2359_reg_58895.read());
}

void kernel_correlation_sdse::thread_v6_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_20_EN_A = ap_const_logic_1;
    } else {
        v6_20_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_20_EN_B = ap_const_logic_1;
    } else {
        v6_20_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_20_Rst_A() {
    v6_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_20_Rst_B() {
    v6_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_20_WEN_A() {
    v6_20_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_20_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_20_WEN_B = ap_const_lv4_F;
    } else {
        v6_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_21_Addr_A() {
    v6_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_21_Addr_A_orig() {
    v6_21_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_21_Addr_B() {
    v6_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_21_Addr_B_orig() {
    v6_21_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_21_Clk_A() {
    v6_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_21_Clk_B() {
    v6_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_21_Din_A() {
    v6_21_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_21_Din_B() {
    v6_21_Din_B = (!and_ln3324_fu_49687_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3324_fu_49687_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2370_reg_58901.read());
}

void kernel_correlation_sdse::thread_v6_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_21_EN_A = ap_const_logic_1;
    } else {
        v6_21_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_21_EN_B = ap_const_logic_1;
    } else {
        v6_21_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_21_Rst_A() {
    v6_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_21_Rst_B() {
    v6_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_21_WEN_A() {
    v6_21_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_21_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_21_WEN_B = ap_const_lv4_F;
    } else {
        v6_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_22_Addr_A() {
    v6_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_22_Addr_A_orig() {
    v6_22_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_22_Addr_B() {
    v6_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_22_Addr_B_orig() {
    v6_22_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_22_Clk_A() {
    v6_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_22_Clk_B() {
    v6_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_22_Din_A() {
    v6_22_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_22_Din_B() {
    v6_22_Din_B = (!and_ln3338_fu_49705_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3338_fu_49705_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2381_reg_58907.read());
}

void kernel_correlation_sdse::thread_v6_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_22_EN_A = ap_const_logic_1;
    } else {
        v6_22_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_22_EN_B = ap_const_logic_1;
    } else {
        v6_22_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_22_Rst_A() {
    v6_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_22_Rst_B() {
    v6_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_22_WEN_A() {
    v6_22_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_22_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_22_WEN_B = ap_const_lv4_F;
    } else {
        v6_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_23_Addr_A() {
    v6_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_23_Addr_A_orig() {
    v6_23_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_23_Addr_B() {
    v6_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_23_Addr_B_orig() {
    v6_23_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_23_Clk_A() {
    v6_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_23_Clk_B() {
    v6_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_23_Din_A() {
    v6_23_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_23_Din_B() {
    v6_23_Din_B = (!and_ln3352_fu_49723_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3352_fu_49723_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2392_reg_58913.read());
}

void kernel_correlation_sdse::thread_v6_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_23_EN_A = ap_const_logic_1;
    } else {
        v6_23_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_23_EN_B = ap_const_logic_1;
    } else {
        v6_23_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_23_Rst_A() {
    v6_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_23_Rst_B() {
    v6_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_23_WEN_A() {
    v6_23_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_23_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_23_WEN_B = ap_const_lv4_F;
    } else {
        v6_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_24_Addr_A() {
    v6_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_24_Addr_A_orig() {
    v6_24_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_24_Addr_B() {
    v6_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_24_Addr_B_orig() {
    v6_24_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_24_Clk_A() {
    v6_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_24_Clk_B() {
    v6_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_24_Din_A() {
    v6_24_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_24_Din_B() {
    v6_24_Din_B = (!and_ln3366_fu_49741_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3366_fu_49741_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2403_reg_58919.read());
}

void kernel_correlation_sdse::thread_v6_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_24_EN_A = ap_const_logic_1;
    } else {
        v6_24_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_24_EN_B = ap_const_logic_1;
    } else {
        v6_24_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_24_Rst_A() {
    v6_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_24_Rst_B() {
    v6_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_24_WEN_A() {
    v6_24_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_24_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_24_WEN_B = ap_const_lv4_F;
    } else {
        v6_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_25_Addr_A() {
    v6_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_25_Addr_A_orig() {
    v6_25_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_25_Addr_B() {
    v6_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_25_Addr_B_orig() {
    v6_25_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_25_Clk_A() {
    v6_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_25_Clk_B() {
    v6_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_25_Din_A() {
    v6_25_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_25_Din_B() {
    v6_25_Din_B = (!and_ln3380_fu_49759_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3380_fu_49759_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2414_reg_58925.read());
}

void kernel_correlation_sdse::thread_v6_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_25_EN_A = ap_const_logic_1;
    } else {
        v6_25_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_25_EN_B = ap_const_logic_1;
    } else {
        v6_25_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_25_Rst_A() {
    v6_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_25_Rst_B() {
    v6_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_25_WEN_A() {
    v6_25_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_25_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_25_WEN_B = ap_const_lv4_F;
    } else {
        v6_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_26_Addr_A() {
    v6_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_26_Addr_A_orig() {
    v6_26_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_26_Addr_B() {
    v6_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_26_Addr_B_orig() {
    v6_26_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_26_Clk_A() {
    v6_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_26_Clk_B() {
    v6_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_26_Din_A() {
    v6_26_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_26_Din_B() {
    v6_26_Din_B = (!and_ln3394_fu_49777_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3394_fu_49777_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2425_reg_58931.read());
}

void kernel_correlation_sdse::thread_v6_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_26_EN_A = ap_const_logic_1;
    } else {
        v6_26_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_26_EN_B = ap_const_logic_1;
    } else {
        v6_26_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_26_Rst_A() {
    v6_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_26_Rst_B() {
    v6_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_26_WEN_A() {
    v6_26_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_26_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_26_WEN_B = ap_const_lv4_F;
    } else {
        v6_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_27_Addr_A() {
    v6_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_27_Addr_A_orig() {
    v6_27_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_27_Addr_B() {
    v6_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_27_Addr_B_orig() {
    v6_27_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_27_Clk_A() {
    v6_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_27_Clk_B() {
    v6_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_27_Din_A() {
    v6_27_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_27_Din_B() {
    v6_27_Din_B = (!and_ln3408_fu_49795_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3408_fu_49795_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2436_reg_58937.read());
}

void kernel_correlation_sdse::thread_v6_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_27_EN_A = ap_const_logic_1;
    } else {
        v6_27_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_27_EN_B = ap_const_logic_1;
    } else {
        v6_27_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_27_Rst_A() {
    v6_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_27_Rst_B() {
    v6_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_27_WEN_A() {
    v6_27_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_27_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_27_WEN_B = ap_const_lv4_F;
    } else {
        v6_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_28_Addr_A() {
    v6_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_28_Addr_A_orig() {
    v6_28_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_28_Addr_B() {
    v6_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_28_Addr_B_orig() {
    v6_28_Addr_B_orig =  (sc_lv<32>) (v6_28_addr_1_reg_59223_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_28_Clk_A() {
    v6_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_28_Clk_B() {
    v6_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_28_Din_A() {
    v6_28_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_28_Din_B() {
    v6_28_Din_B = (!and_ln3422_fu_50173_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3422_fu_50173_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2447_reg_59283.read());
}

void kernel_correlation_sdse::thread_v6_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_28_EN_A = ap_const_logic_1;
    } else {
        v6_28_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_28_EN_B = ap_const_logic_1;
    } else {
        v6_28_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_28_Rst_A() {
    v6_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_28_Rst_B() {
    v6_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_28_WEN_A() {
    v6_28_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_28_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_28_WEN_B = ap_const_lv4_F;
    } else {
        v6_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_29_Addr_A() {
    v6_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_29_Addr_A_orig() {
    v6_29_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_29_Addr_B() {
    v6_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_29_Addr_B_orig() {
    v6_29_Addr_B_orig =  (sc_lv<32>) (v6_29_addr_1_reg_59228_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_29_Clk_A() {
    v6_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_29_Clk_B() {
    v6_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_29_Din_A() {
    v6_29_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_29_Din_B() {
    v6_29_Din_B = (!and_ln3436_fu_50191_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3436_fu_50191_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2458_reg_59289.read());
}

void kernel_correlation_sdse::thread_v6_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_29_EN_A = ap_const_logic_1;
    } else {
        v6_29_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_29_EN_B = ap_const_logic_1;
    } else {
        v6_29_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_29_Rst_A() {
    v6_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_29_Rst_B() {
    v6_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_29_WEN_A() {
    v6_29_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_29_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_29_WEN_B = ap_const_lv4_F;
    } else {
        v6_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_2_Addr_A() {
    v6_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_2_Addr_A_orig() {
    v6_2_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_2_Addr_B() {
    v6_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_2_Addr_B_orig() {
    v6_2_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_2_Clk_A() {
    v6_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_2_Clk_B() {
    v6_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_2_Din_A() {
    v6_2_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_2_Din_B() {
    v6_2_Din_B = (!and_ln3058_fu_48925_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3058_fu_48925_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2161_reg_58787.read());
}

void kernel_correlation_sdse::thread_v6_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_2_EN_A = ap_const_logic_1;
    } else {
        v6_2_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_2_EN_B = ap_const_logic_1;
    } else {
        v6_2_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_2_Rst_A() {
    v6_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_2_Rst_B() {
    v6_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_2_WEN_A() {
    v6_2_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_30_Addr_A() {
    v6_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_30_Addr_A_orig() {
    v6_30_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_30_Addr_B() {
    v6_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_30_Addr_B_orig() {
    v6_30_Addr_B_orig =  (sc_lv<32>) (v6_30_addr_1_reg_59233_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_30_Clk_A() {
    v6_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_30_Clk_B() {
    v6_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_30_Din_A() {
    v6_30_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_30_Din_B() {
    v6_30_Din_B = (!and_ln3450_fu_50209_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3450_fu_50209_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2469_reg_59295.read());
}

void kernel_correlation_sdse::thread_v6_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_30_EN_A = ap_const_logic_1;
    } else {
        v6_30_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_30_EN_B = ap_const_logic_1;
    } else {
        v6_30_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_30_Rst_A() {
    v6_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_30_Rst_B() {
    v6_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_30_WEN_A() {
    v6_30_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_30_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_30_WEN_B = ap_const_lv4_F;
    } else {
        v6_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_31_Addr_A() {
    v6_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_31_Addr_A_orig() {
    v6_31_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_31_Addr_B() {
    v6_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_31_Addr_B_orig() {
    v6_31_Addr_B_orig =  (sc_lv<32>) (v6_31_addr_1_reg_59238_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_31_Clk_A() {
    v6_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_31_Clk_B() {
    v6_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_31_Din_A() {
    v6_31_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_31_Din_B() {
    v6_31_Din_B = (!and_ln3464_fu_50227_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3464_fu_50227_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2480_reg_59301.read());
}

void kernel_correlation_sdse::thread_v6_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_31_EN_A = ap_const_logic_1;
    } else {
        v6_31_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_31_EN_B = ap_const_logic_1;
    } else {
        v6_31_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_31_Rst_A() {
    v6_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_31_Rst_B() {
    v6_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_31_WEN_A() {
    v6_31_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_31_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_31_WEN_B = ap_const_lv4_F;
    } else {
        v6_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_32_Addr_A() {
    v6_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_32_Addr_A_orig() {
    v6_32_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_32_Addr_B() {
    v6_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_32_Addr_B_orig() {
    v6_32_Addr_B_orig =  (sc_lv<32>) (v6_32_addr_1_reg_59243_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_32_Clk_A() {
    v6_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_32_Clk_B() {
    v6_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_32_Din_A() {
    v6_32_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_32_Din_B() {
    v6_32_Din_B = (!and_ln3478_fu_50245_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3478_fu_50245_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2491_reg_59307.read());
}

void kernel_correlation_sdse::thread_v6_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_32_EN_A = ap_const_logic_1;
    } else {
        v6_32_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_32_EN_B = ap_const_logic_1;
    } else {
        v6_32_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_32_Rst_A() {
    v6_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_32_Rst_B() {
    v6_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_32_WEN_A() {
    v6_32_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_32_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_32_WEN_B = ap_const_lv4_F;
    } else {
        v6_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_33_Addr_A() {
    v6_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_33_Addr_A_orig() {
    v6_33_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_33_Addr_B() {
    v6_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_33_Addr_B_orig() {
    v6_33_Addr_B_orig =  (sc_lv<32>) (v6_33_addr_1_reg_59248_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_33_Clk_A() {
    v6_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_33_Clk_B() {
    v6_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_33_Din_A() {
    v6_33_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_33_Din_B() {
    v6_33_Din_B = (!and_ln3492_fu_50263_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3492_fu_50263_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2502_reg_59313.read());
}

void kernel_correlation_sdse::thread_v6_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_33_EN_A = ap_const_logic_1;
    } else {
        v6_33_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_33_EN_B = ap_const_logic_1;
    } else {
        v6_33_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_33_Rst_A() {
    v6_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_33_Rst_B() {
    v6_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_33_WEN_A() {
    v6_33_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_33_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_33_WEN_B = ap_const_lv4_F;
    } else {
        v6_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_34_Addr_A() {
    v6_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_34_Addr_A_orig() {
    v6_34_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_34_Addr_B() {
    v6_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_34_Addr_B_orig() {
    v6_34_Addr_B_orig =  (sc_lv<32>) (v6_34_addr_1_reg_59253_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_34_Clk_A() {
    v6_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_34_Clk_B() {
    v6_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_34_Din_A() {
    v6_34_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_34_Din_B() {
    v6_34_Din_B = (!and_ln3506_fu_50281_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3506_fu_50281_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2513_reg_59319.read());
}

void kernel_correlation_sdse::thread_v6_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_34_EN_A = ap_const_logic_1;
    } else {
        v6_34_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_34_EN_B = ap_const_logic_1;
    } else {
        v6_34_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_34_Rst_A() {
    v6_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_34_Rst_B() {
    v6_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_34_WEN_A() {
    v6_34_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_34_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_34_WEN_B = ap_const_lv4_F;
    } else {
        v6_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_35_Addr_A() {
    v6_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_35_Addr_A_orig() {
    v6_35_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_35_Addr_B() {
    v6_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_35_Addr_B_orig() {
    v6_35_Addr_B_orig =  (sc_lv<32>) (v6_35_addr_1_reg_59258_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_35_Clk_A() {
    v6_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_35_Clk_B() {
    v6_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_35_Din_A() {
    v6_35_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_35_Din_B() {
    v6_35_Din_B = (!and_ln3520_fu_50299_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3520_fu_50299_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2524_reg_59325.read());
}

void kernel_correlation_sdse::thread_v6_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_35_EN_A = ap_const_logic_1;
    } else {
        v6_35_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_35_EN_B = ap_const_logic_1;
    } else {
        v6_35_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_35_Rst_A() {
    v6_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_35_Rst_B() {
    v6_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_35_WEN_A() {
    v6_35_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_35_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_35_WEN_B = ap_const_lv4_F;
    } else {
        v6_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_36_Addr_A() {
    v6_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_36_Addr_A_orig() {
    v6_36_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_36_Addr_B() {
    v6_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_36_Addr_B_orig() {
    v6_36_Addr_B_orig =  (sc_lv<32>) (v6_36_addr_1_reg_59263_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_36_Clk_A() {
    v6_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_36_Clk_B() {
    v6_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_36_Din_A() {
    v6_36_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_36_Din_B() {
    v6_36_Din_B = (!and_ln3534_fu_50317_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3534_fu_50317_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2535_reg_59331.read());
}

void kernel_correlation_sdse::thread_v6_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_36_EN_A = ap_const_logic_1;
    } else {
        v6_36_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_36_EN_B = ap_const_logic_1;
    } else {
        v6_36_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_36_Rst_A() {
    v6_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_36_Rst_B() {
    v6_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_36_WEN_A() {
    v6_36_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_36_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_36_WEN_B = ap_const_lv4_F;
    } else {
        v6_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_37_Addr_A() {
    v6_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_37_Addr_A_orig() {
    v6_37_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_37_Addr_B() {
    v6_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_37_Addr_B_orig() {
    v6_37_Addr_B_orig =  (sc_lv<32>) (v6_37_addr_1_reg_59268_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_37_Clk_A() {
    v6_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_37_Clk_B() {
    v6_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_37_Din_A() {
    v6_37_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_37_Din_B() {
    v6_37_Din_B = (!and_ln3548_fu_50335_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3548_fu_50335_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2546_reg_59337.read());
}

void kernel_correlation_sdse::thread_v6_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_37_EN_A = ap_const_logic_1;
    } else {
        v6_37_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_37_EN_B = ap_const_logic_1;
    } else {
        v6_37_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_37_Rst_A() {
    v6_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_37_Rst_B() {
    v6_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_37_WEN_A() {
    v6_37_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_37_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_37_WEN_B = ap_const_lv4_F;
    } else {
        v6_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_38_Addr_A() {
    v6_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_38_Addr_A_orig() {
    v6_38_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_38_Addr_B() {
    v6_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_38_Addr_B_orig() {
    v6_38_Addr_B_orig =  (sc_lv<32>) (v6_38_addr_1_reg_59273_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_38_Clk_A() {
    v6_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_38_Clk_B() {
    v6_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_38_Din_A() {
    v6_38_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_38_Din_B() {
    v6_38_Din_B = (!and_ln3562_fu_50353_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3562_fu_50353_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2557_reg_59343.read());
}

void kernel_correlation_sdse::thread_v6_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_38_EN_A = ap_const_logic_1;
    } else {
        v6_38_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_38_EN_B = ap_const_logic_1;
    } else {
        v6_38_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_38_Rst_A() {
    v6_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_38_Rst_B() {
    v6_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_38_WEN_A() {
    v6_38_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_38_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_38_WEN_B = ap_const_lv4_F;
    } else {
        v6_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_39_Addr_A() {
    v6_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_39_Addr_A_orig() {
    v6_39_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_39_Addr_B() {
    v6_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_39_Addr_B_orig() {
    v6_39_Addr_B_orig =  (sc_lv<32>) (v6_39_addr_1_reg_59278_pp1_iter17_reg.read());
}

void kernel_correlation_sdse::thread_v6_39_Clk_A() {
    v6_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_39_Clk_B() {
    v6_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_39_Din_A() {
    v6_39_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_39_Din_B() {
    v6_39_Din_B = (!and_ln3576_fu_50371_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3576_fu_50371_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2568_reg_59349.read());
}

void kernel_correlation_sdse::thread_v6_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_39_EN_A = ap_const_logic_1;
    } else {
        v6_39_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_39_EN_B = ap_const_logic_1;
    } else {
        v6_39_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_39_Rst_A() {
    v6_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_39_Rst_B() {
    v6_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_39_WEN_A() {
    v6_39_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_39_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln1336_reg_55213_pp1_iter17_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter18.read()))) {
        v6_39_WEN_B = ap_const_lv4_F;
    } else {
        v6_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_3_Addr_A() {
    v6_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_3_Addr_A_orig() {
    v6_3_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_3_Addr_B() {
    v6_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_3_Addr_B_orig() {
    v6_3_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_3_Clk_A() {
    v6_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_3_Clk_B() {
    v6_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_3_Din_A() {
    v6_3_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_3_Din_B() {
    v6_3_Din_B = (!and_ln3072_fu_48943_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3072_fu_48943_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2172_reg_58793.read());
}

void kernel_correlation_sdse::thread_v6_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_3_EN_A = ap_const_logic_1;
    } else {
        v6_3_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_3_EN_B = ap_const_logic_1;
    } else {
        v6_3_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_3_Rst_A() {
    v6_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_3_Rst_B() {
    v6_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_3_WEN_A() {
    v6_3_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_4_Addr_A() {
    v6_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_4_Addr_A_orig() {
    v6_4_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_4_Addr_B() {
    v6_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_4_Addr_B_orig() {
    v6_4_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_4_Clk_A() {
    v6_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_4_Clk_B() {
    v6_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_4_Din_A() {
    v6_4_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_4_Din_B() {
    v6_4_Din_B = (!and_ln3086_fu_48961_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3086_fu_48961_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2183_reg_58799.read());
}

void kernel_correlation_sdse::thread_v6_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_4_EN_A = ap_const_logic_1;
    } else {
        v6_4_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_4_EN_B = ap_const_logic_1;
    } else {
        v6_4_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_4_Rst_A() {
    v6_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_4_Rst_B() {
    v6_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_4_WEN_A() {
    v6_4_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_5_Addr_A() {
    v6_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_5_Addr_A_orig() {
    v6_5_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_5_Addr_B() {
    v6_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_5_Addr_B_orig() {
    v6_5_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_5_Clk_A() {
    v6_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_5_Clk_B() {
    v6_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_5_Din_A() {
    v6_5_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_5_Din_B() {
    v6_5_Din_B = (!and_ln3100_fu_48979_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3100_fu_48979_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2194_reg_58805.read());
}

void kernel_correlation_sdse::thread_v6_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_5_EN_A = ap_const_logic_1;
    } else {
        v6_5_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_5_EN_B = ap_const_logic_1;
    } else {
        v6_5_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_5_Rst_A() {
    v6_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_5_Rst_B() {
    v6_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_5_WEN_A() {
    v6_5_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_5_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_5_WEN_B = ap_const_lv4_F;
    } else {
        v6_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_6_Addr_A() {
    v6_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_6_Addr_A_orig() {
    v6_6_Addr_A_orig =  (sc_lv<32>) (zext_ln3601_fu_51165_p1.read());
}

void kernel_correlation_sdse::thread_v6_6_Addr_B() {
    v6_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_6_Addr_B_orig() {
    v6_6_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_6_Clk_A() {
    v6_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_6_Clk_B() {
    v6_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_6_Din_A() {
    v6_6_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_6_Din_B() {
    v6_6_Din_B = (!and_ln3114_fu_48997_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3114_fu_48997_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2205_reg_58811.read());
}

void kernel_correlation_sdse::thread_v6_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_6_EN_A = ap_const_logic_1;
    } else {
        v6_6_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_6_EN_B = ap_const_logic_1;
    } else {
        v6_6_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_6_Rst_A() {
    v6_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_6_Rst_B() {
    v6_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_6_WEN_A() {
    v6_6_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_6_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_6_WEN_B = ap_const_lv4_F;
    } else {
        v6_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_7_Addr_A() {
    v6_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_7_Addr_A_orig() {
    v6_7_Addr_A_orig =  (sc_lv<32>) (zext_ln3609_fu_51465_p1.read());
}

void kernel_correlation_sdse::thread_v6_7_Addr_B() {
    v6_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_7_Addr_B_orig() {
    v6_7_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_7_Clk_A() {
    v6_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_7_Clk_B() {
    v6_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_7_Din_A() {
    v6_7_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_7_Din_B() {
    v6_7_Din_B = (!and_ln3128_fu_49015_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3128_fu_49015_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2216_reg_58817.read());
}

void kernel_correlation_sdse::thread_v6_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_7_EN_A = ap_const_logic_1;
    } else {
        v6_7_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_7_EN_B = ap_const_logic_1;
    } else {
        v6_7_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_7_Rst_A() {
    v6_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_7_Rst_B() {
    v6_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_7_WEN_A() {
    v6_7_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_7_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_7_WEN_B = ap_const_lv4_F;
    } else {
        v6_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_8_Addr_A() {
    v6_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_8_Addr_A_orig() {
    v6_8_Addr_A_orig =  (sc_lv<32>) (zext_ln3585_fu_50565_p1.read());
}

void kernel_correlation_sdse::thread_v6_8_Addr_B() {
    v6_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_8_Addr_B_orig() {
    v6_8_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_8_Clk_A() {
    v6_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_8_Clk_B() {
    v6_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_8_Din_A() {
    v6_8_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_8_Din_B() {
    v6_8_Din_B = (!and_ln3142_fu_49033_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3142_fu_49033_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2227_reg_58823.read());
}

void kernel_correlation_sdse::thread_v6_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_8_EN_A = ap_const_logic_1;
    } else {
        v6_8_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_8_EN_B = ap_const_logic_1;
    } else {
        v6_8_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_8_Rst_A() {
    v6_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_8_Rst_B() {
    v6_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_8_WEN_A() {
    v6_8_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_8_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_8_WEN_B = ap_const_lv4_F;
    } else {
        v6_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v6_9_Addr_A() {
    v6_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_9_Addr_A_orig() {
    v6_9_Addr_A_orig =  (sc_lv<32>) (zext_ln3593_fu_50865_p1.read());
}

void kernel_correlation_sdse::thread_v6_9_Addr_B() {
    v6_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_correlation_sdse::thread_v6_9_Addr_B_orig() {
    v6_9_Addr_B_orig =  (sc_lv<32>) (zext_ln1339_reg_55248_pp1_iter16_reg.read());
}

void kernel_correlation_sdse::thread_v6_9_Clk_A() {
    v6_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_9_Clk_B() {
    v6_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_correlation_sdse::thread_v6_9_Din_A() {
    v6_9_Din_A = ap_const_lv32_0;
}

void kernel_correlation_sdse::thread_v6_9_Din_B() {
    v6_9_Din_B = (!and_ln3156_fu_49051_p2.read()[0].is_01())? sc_lv<32>(): ((and_ln3156_fu_49051_p2.read()[0].to_bool())? ap_const_lv32_3F800000: v2238_reg_58829.read());
}

void kernel_correlation_sdse::thread_v6_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0))) {
        v6_9_EN_A = ap_const_logic_1;
    } else {
        v6_9_EN_A = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_9_EN_B = ap_const_logic_1;
    } else {
        v6_9_EN_B = ap_const_logic_0;
    }
}

void kernel_correlation_sdse::thread_v6_9_Rst_A() {
    v6_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_9_Rst_B() {
    v6_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_correlation_sdse::thread_v6_9_WEN_A() {
    v6_9_WEN_A = ap_const_lv4_0;
}

void kernel_correlation_sdse::thread_v6_9_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter16.read()))) {
        v6_9_WEN_B = ap_const_lv4_F;
    } else {
        v6_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_correlation_sdse::thread_v7_fu_47103_p2() {
    v7_fu_47103_p2 = (!ap_const_lv7_1.is_01() || !ap_phi_mux_v7_0_phi_fu_30841_p4.read().is_01())? sc_lv<7>(): (sc_biguint<7>(ap_const_lv7_1) + sc_biguint<7>(ap_phi_mux_v7_0_phi_fu_30841_p4.read()));
}

void kernel_correlation_sdse::thread_v809_fu_47789_p2() {
    v809_fu_47789_p2 = (!ap_const_lv7_1.is_01() || !ap_phi_mux_v809_0_phi_fu_32154_p4.read().is_01())? sc_lv<7>(): (sc_biguint<7>(ap_const_lv7_1) + sc_biguint<7>(ap_phi_mux_v809_0_phi_fu_32154_p4.read()));
}

void kernel_correlation_sdse::thread_v810_fu_47932_p2() {
    v810_fu_47932_p2 = (!ap_const_lv3_1.is_01() || !select_ln1336_reg_55222.read().is_01())? sc_lv<3>(): (sc_biguint<3>(ap_const_lv3_1) + sc_biguint<3>(select_ln1336_reg_55222.read()));
}

void kernel_correlation_sdse::thread_v8_fu_47202_p2() {
    v8_fu_47202_p2 = (!select_ln51_reg_52472.read().is_01() || !ap_const_lv3_1.is_01())? sc_lv<3>(): (sc_biguint<3>(select_ln51_reg_52472.read()) + sc_biguint<3>(ap_const_lv3_1));
}

void kernel_correlation_sdse::thread_zext_ln1015_cast_fu_47173_p3() {
    zext_ln1015_cast_fu_47173_p3 = esl_concat<4,3>(tmp_123_reg_52494.read(), ap_const_lv3_0);
}

void kernel_correlation_sdse::thread_zext_ln1015_fu_47193_p1() {
    zext_ln1015_fu_47193_p1 = esl_zext<7,3>(select_ln51_reg_52472.read());
}

void kernel_correlation_sdse::thread_zext_ln1339_fu_47859_p1() {
    zext_ln1339_fu_47859_p1 = esl_zext<64,3>(select_ln1336_fu_47801_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln3020_cast_fu_47903_p3() {
    zext_ln3020_cast_fu_47903_p3 = esl_concat<4,3>(tmp_126_reg_55243.read(), ap_const_lv3_0);
}

void kernel_correlation_sdse::thread_zext_ln3020_fu_47923_p1() {
    zext_ln3020_fu_47923_p1 = esl_zext<7,3>(select_ln1336_reg_55222.read());
}

void kernel_correlation_sdse::thread_zext_ln3585_fu_50565_p1() {
    zext_ln3585_fu_50565_p1 = esl_zext<64,8>(sext_ln3585_fu_50562_p1.read());
}

void kernel_correlation_sdse::thread_zext_ln3586_fu_50548_p1() {
    zext_ln3586_fu_50548_p1 = esl_zext<7,5>(tmp_129_fu_50541_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln3593_fu_50865_p1() {
    zext_ln3593_fu_50865_p1 = esl_zext<64,8>(sext_ln3593_fu_50862_p1.read());
}

void kernel_correlation_sdse::thread_zext_ln3601_fu_51165_p1() {
    zext_ln3601_fu_51165_p1 = esl_zext<64,8>(sext_ln3601_fu_51162_p1.read());
}

void kernel_correlation_sdse::thread_zext_ln3609_fu_51465_p1() {
    zext_ln3609_fu_51465_p1 = esl_zext<64,8>(sext_ln3609_fu_51462_p1.read());
}

void kernel_correlation_sdse::thread_zext_ln4420_1_fu_52279_p1() {
    zext_ln4420_1_fu_52279_p1 = esl_zext<11,6>(select_ln4420_3_fu_52272_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4420_fu_52022_p1() {
    zext_ln4420_fu_52022_p1 = esl_zext<9,8>(select_ln4420_2_fu_52015_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4422_1_fu_52031_p1() {
    zext_ln4422_1_fu_52031_p1 = esl_zext<9,5>(select_ln4422_3_reg_66735.read());
}

void kernel_correlation_sdse::thread_zext_ln4422_2_fu_52034_p1() {
    zext_ln4422_2_fu_52034_p1 = esl_zext<6,5>(select_ln4422_3_reg_66735.read());
}

void kernel_correlation_sdse::thread_zext_ln4422_fu_52231_p1() {
    zext_ln4422_fu_52231_p1 = esl_zext<11,10>(select_ln4422_fu_52224_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4423_1_fu_51805_p1() {
    zext_ln4423_1_fu_51805_p1 = esl_zext<9,6>(shl_ln4423_1_fu_51797_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4423_2_fu_51852_p1() {
    zext_ln4423_2_fu_51852_p1 = esl_zext<14,13>(tmp_131_fu_51845_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4423_3_fu_51863_p1() {
    zext_ln4423_3_fu_51863_p1 = esl_zext<14,7>(tmp_132_fu_51856_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4423_fu_51787_p1() {
    zext_ln4423_fu_51787_p1 = esl_zext<9,8>(shl_ln1_fu_51779_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4425_1_fu_52336_p1() {
    zext_ln4425_1_fu_52336_p1 = esl_zext<17,8>(add_ln4425_reg_66778_pp3_iter5_reg.read());
}

void kernel_correlation_sdse::thread_zext_ln4425_2_fu_52346_p1() {
    zext_ln4425_2_fu_52346_p1 = esl_zext<17,16>(tmp_136_fu_52339_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4425_3_fu_52357_p1() {
    zext_ln4425_3_fu_52357_p1 = esl_zext<17,12>(tmp_137_fu_52350_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4425_fu_52056_p1() {
    zext_ln4425_fu_52056_p1 = esl_zext<8,6>(add_ln4425_1_fu_52051_p2.read());
}

void kernel_correlation_sdse::thread_zext_ln4427_1_fu_52142_p1() {
    zext_ln4427_1_fu_52142_p1 = esl_zext<11,10>(add_ln4427_1_fu_52136_p2.read());
}

void kernel_correlation_sdse::thread_zext_ln4427_2_fu_52214_p1() {
    zext_ln4427_2_fu_52214_p1 = esl_zext<10,8>(shl_ln4427_1_mid1_fu_52206_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4427_3_fu_52251_p1() {
    zext_ln4427_3_fu_52251_p1 = esl_zext<11,8>(grp_fu_52065_p2.read());
}

void kernel_correlation_sdse::thread_zext_ln4427_4_fu_52289_p1() {
    zext_ln4427_4_fu_52289_p1 = esl_zext<11,10>(add_ln4427_2_reg_66817.read());
}

void kernel_correlation_sdse::thread_zext_ln4427_fu_52132_p1() {
    zext_ln4427_fu_52132_p1 = esl_zext<10,8>(shl_ln4427_1_fu_52124_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4428_2_fu_52261_p1() {
    zext_ln4428_2_fu_52261_p1 = esl_zext<11,8>(grp_fu_52071_p2.read());
}

void kernel_correlation_sdse::thread_zext_ln4428_fu_52104_p1() {
    zext_ln4428_fu_52104_p1 = esl_zext<11,8>(grp_fu_51990_p2.read());
}

void kernel_correlation_sdse::thread_zext_ln4434_1_fu_52315_p1() {
    zext_ln4434_1_fu_52315_p1 = esl_zext<17,16>(tmp_133_fu_52308_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4434_2_fu_52326_p1() {
    zext_ln4434_2_fu_52326_p1 = esl_zext<17,12>(tmp_134_fu_52319_p3.read());
}

void kernel_correlation_sdse::thread_zext_ln4434_fu_52305_p1() {
    zext_ln4434_fu_52305_p1 = esl_zext<17,8>(select_ln4420_1_reg_66761_pp3_iter5_reg.read());
}

void kernel_correlation_sdse::thread_zext_ln54_fu_47734_p1() {
    zext_ln54_fu_47734_p1 = esl_zext<64,3>(select_ln51_reg_52472_pp0_iter14_reg.read());
}

}


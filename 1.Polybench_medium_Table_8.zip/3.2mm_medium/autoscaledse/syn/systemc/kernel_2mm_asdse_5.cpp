#include "kernel_2mm_asdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_2mm_asdse::thread_v2_4_1_WEN_A() {
    v2_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_4_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_1_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_2_Addr_A() {
    v2_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_2_Addr_A_orig() {
    v2_4_2_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter14_reg.read());
}

void kernel_2mm_asdse::thread_v2_4_2_Addr_B() {
    v2_4_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_2_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_2_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_2_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_2_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_4_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_2_Clk_A() {
    v2_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_2_Clk_B() {
    v2_4_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_2_Din_A() {
    v2_4_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_4_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_2_Din_B = reg_7270.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_2_Din_B = reg_7130.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_2_Din_B = reg_6990.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_2_Din_B = reg_6850.read();
        } else {
            v2_4_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        v2_4_2_EN_A = ap_const_logic_1;
    } else {
        v2_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_2_EN_B = ap_const_logic_1;
    } else {
        v2_4_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_2_Rst_A() {
    v2_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_2_Rst_B() {
    v2_4_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_2_WEN_A() {
    v2_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_4_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_2_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_3_Addr_A() {
    v2_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_3_Addr_A_orig() {
    v2_4_3_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter21_reg.read());
}

void kernel_2mm_asdse::thread_v2_4_3_Addr_B() {
    v2_4_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_3_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_3_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_3_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_3_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_4_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_3_Clk_A() {
    v2_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_3_Clk_B() {
    v2_4_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_3_Din_A() {
    v2_4_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_4_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_3_Din_B = reg_7284.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_3_Din_B = reg_7144.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_3_Din_B = reg_7004.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_3_Din_B = reg_6864.read();
        } else {
            v2_4_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter22.read()))) {
        v2_4_3_EN_A = ap_const_logic_1;
    } else {
        v2_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_3_EN_B = ap_const_logic_1;
    } else {
        v2_4_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_3_Rst_A() {
    v2_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_3_Rst_B() {
    v2_4_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_3_WEN_A() {
    v2_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_4_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_3_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_4_Addr_A() {
    v2_4_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_4_Addr_A_orig() {
    v2_4_4_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter28_reg.read());
}

void kernel_2mm_asdse::thread_v2_4_4_Addr_B() {
    v2_4_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_4_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_4_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_4_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_4_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_4_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_4_Clk_A() {
    v2_4_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_4_Clk_B() {
    v2_4_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_4_Din_A() {
    v2_4_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_4_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_4_Din_B = reg_7298.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_4_Din_B = reg_7158.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_4_Din_B = reg_7018.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_4_Din_B = reg_6878.read();
        } else {
            v2_4_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter29.read()))) {
        v2_4_4_EN_A = ap_const_logic_1;
    } else {
        v2_4_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_4_EN_B = ap_const_logic_1;
    } else {
        v2_4_4_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_4_Rst_A() {
    v2_4_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_4_Rst_B() {
    v2_4_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_4_WEN_A() {
    v2_4_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_4_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_4_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_5_Addr_A() {
    v2_4_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_5_Addr_A_orig() {
    v2_4_5_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter35_reg.read());
}

void kernel_2mm_asdse::thread_v2_4_5_Addr_B() {
    v2_4_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_5_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_5_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_5_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_5_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_5_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_4_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_5_Clk_A() {
    v2_4_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_5_Clk_B() {
    v2_4_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_5_Din_A() {
    v2_4_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_4_5_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_5_Din_B = reg_7312.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_5_Din_B = reg_7172.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_5_Din_B = reg_7032.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_5_Din_B = reg_6892.read();
        } else {
            v2_4_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter36.read()))) {
        v2_4_5_EN_A = ap_const_logic_1;
    } else {
        v2_4_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_5_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_5_EN_B = ap_const_logic_1;
    } else {
        v2_4_5_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_5_Rst_A() {
    v2_4_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_5_Rst_B() {
    v2_4_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_5_WEN_A() {
    v2_4_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_4_5_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_5_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_6_Addr_A() {
    v2_4_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_6_Addr_A_orig() {
    v2_4_6_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter42_reg.read());
}

void kernel_2mm_asdse::thread_v2_4_6_Addr_B() {
    v2_4_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_6_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_6_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_6_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_6_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_6_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_4_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_6_Clk_A() {
    v2_4_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_6_Clk_B() {
    v2_4_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_6_Din_A() {
    v2_4_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_4_6_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_6_Din_B = reg_7326.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_6_Din_B = reg_7186.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_6_Din_B = reg_7046.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_6_Din_B = reg_6906.read();
        } else {
            v2_4_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter43.read()))) {
        v2_4_6_EN_A = ap_const_logic_1;
    } else {
        v2_4_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_6_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_6_EN_B = ap_const_logic_1;
    } else {
        v2_4_6_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_6_Rst_A() {
    v2_4_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_6_Rst_B() {
    v2_4_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_6_WEN_A() {
    v2_4_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_4_6_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_6_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_7_Addr_A() {
    v2_4_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_7_Addr_A_orig() {
    v2_4_7_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter49_reg.read());
}

void kernel_2mm_asdse::thread_v2_4_7_Addr_B() {
    v2_4_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_7_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_7_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_7_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_7_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_7_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_4_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_7_Clk_A() {
    v2_4_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_7_Clk_B() {
    v2_4_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_7_Din_A() {
    v2_4_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_4_7_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_7_Din_B = reg_7340.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_7_Din_B = reg_7200.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_7_Din_B = reg_7060.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_7_Din_B = reg_6920.read();
        } else {
            v2_4_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter50.read()))) {
        v2_4_7_EN_A = ap_const_logic_1;
    } else {
        v2_4_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_7_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_7_EN_B = ap_const_logic_1;
    } else {
        v2_4_7_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_7_Rst_A() {
    v2_4_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_7_Rst_B() {
    v2_4_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_7_WEN_A() {
    v2_4_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_4_7_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_7_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_8_Addr_A() {
    v2_4_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_8_Addr_A_orig() {
    v2_4_8_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter56_reg.read());
}

void kernel_2mm_asdse::thread_v2_4_8_Addr_B() {
    v2_4_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_8_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_8_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_8_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_8_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_8_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_4_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_8_Clk_A() {
    v2_4_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_8_Clk_B() {
    v2_4_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_8_Din_A() {
    v2_4_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_4_8_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_8_Din_B = reg_7354.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_8_Din_B = reg_7214.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_8_Din_B = reg_7074.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_8_Din_B = reg_6934.read();
        } else {
            v2_4_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter57.read()))) {
        v2_4_8_EN_A = ap_const_logic_1;
    } else {
        v2_4_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_8_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_8_EN_B = ap_const_logic_1;
    } else {
        v2_4_8_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_8_Rst_A() {
    v2_4_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_8_Rst_B() {
    v2_4_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_8_WEN_A() {
    v2_4_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_4_8_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_8_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_9_Addr_A() {
    v2_4_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_9_Addr_A_orig() {
    v2_4_9_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter63_reg.read());
}

void kernel_2mm_asdse::thread_v2_4_9_Addr_B() {
    v2_4_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_4_9_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_9_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_9_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_9_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_9_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_4_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_9_Clk_A() {
    v2_4_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_9_Clk_B() {
    v2_4_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_4_9_Din_A() {
    v2_4_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_4_9_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) {
            v2_4_9_Din_B = reg_7368.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_4_9_Din_B = reg_7228.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_4_9_Din_B = reg_7088.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_4_9_Din_B = reg_6948.read();
        } else {
            v2_4_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_4_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_4_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter64.read()))) {
        v2_4_9_EN_A = ap_const_logic_1;
    } else {
        v2_4_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_9_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_9_EN_B = ap_const_logic_1;
    } else {
        v2_4_9_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_4_9_Rst_A() {
    v2_4_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_9_Rst_B() {
    v2_4_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_4_9_WEN_A() {
    v2_4_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_4_9_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_4_9_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_0_Addr_A() {
    v2_5_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_0_Addr_A_orig() {
    v2_5_0_Addr_A_orig =  (sc_lv<32>) (sext_ln711_fu_8351_p1.read());
}

void kernel_2mm_asdse::thread_v2_5_0_Addr_B() {
    v2_5_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_0_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_0_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_0_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_0_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_0_Clk_A() {
    v2_5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_0_Clk_B() {
    v2_5_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_0_Din_A() {
    v2_5_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_0_Din_B = reg_7242.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_0_Din_B = reg_7102.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_0_Din_B = reg_6962.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_0_Din_B = reg_6822.read();
        } else {
            v2_5_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v2_5_0_EN_A = ap_const_logic_1;
    } else {
        v2_5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_0_EN_B = ap_const_logic_1;
    } else {
        v2_5_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_0_Rst_A() {
    v2_5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_0_Rst_B() {
    v2_5_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_0_WEN_A() {
    v2_5_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_0_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_1_Addr_A() {
    v2_5_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_1_Addr_A_orig() {
    v2_5_1_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter7_reg.read());
}

void kernel_2mm_asdse::thread_v2_5_1_Addr_B() {
    v2_5_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_1_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_1_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_1_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_1_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_1_Clk_A() {
    v2_5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_1_Clk_B() {
    v2_5_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_1_Din_A() {
    v2_5_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_1_Din_B = reg_7256.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_1_Din_B = reg_7116.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_1_Din_B = reg_6976.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_1_Din_B = reg_6836.read();
        } else {
            v2_5_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v2_5_1_EN_A = ap_const_logic_1;
    } else {
        v2_5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_1_EN_B = ap_const_logic_1;
    } else {
        v2_5_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_1_Rst_A() {
    v2_5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_1_Rst_B() {
    v2_5_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_1_WEN_A() {
    v2_5_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_1_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_2_Addr_A() {
    v2_5_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_2_Addr_A_orig() {
    v2_5_2_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter14_reg.read());
}

void kernel_2mm_asdse::thread_v2_5_2_Addr_B() {
    v2_5_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_2_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_2_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_2_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_2_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_2_Clk_A() {
    v2_5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_2_Clk_B() {
    v2_5_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_2_Din_A() {
    v2_5_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_2_Din_B = reg_7270.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_2_Din_B = reg_7130.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_2_Din_B = reg_6990.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_2_Din_B = reg_6850.read();
        } else {
            v2_5_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        v2_5_2_EN_A = ap_const_logic_1;
    } else {
        v2_5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_2_EN_B = ap_const_logic_1;
    } else {
        v2_5_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_2_Rst_A() {
    v2_5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_2_Rst_B() {
    v2_5_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_2_WEN_A() {
    v2_5_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_2_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_3_Addr_A() {
    v2_5_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_3_Addr_A_orig() {
    v2_5_3_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter21_reg.read());
}

void kernel_2mm_asdse::thread_v2_5_3_Addr_B() {
    v2_5_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_3_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_3_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_3_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_3_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_3_Clk_A() {
    v2_5_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_3_Clk_B() {
    v2_5_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_3_Din_A() {
    v2_5_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_3_Din_B = reg_7284.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_3_Din_B = reg_7144.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_3_Din_B = reg_7004.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_3_Din_B = reg_6864.read();
        } else {
            v2_5_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter22.read()))) {
        v2_5_3_EN_A = ap_const_logic_1;
    } else {
        v2_5_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_3_EN_B = ap_const_logic_1;
    } else {
        v2_5_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_3_Rst_A() {
    v2_5_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_3_Rst_B() {
    v2_5_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_3_WEN_A() {
    v2_5_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_3_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_4_Addr_A() {
    v2_5_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_4_Addr_A_orig() {
    v2_5_4_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter28_reg.read());
}

void kernel_2mm_asdse::thread_v2_5_4_Addr_B() {
    v2_5_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_4_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_4_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_4_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_4_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_4_Clk_A() {
    v2_5_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_4_Clk_B() {
    v2_5_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_4_Din_A() {
    v2_5_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_4_Din_B = reg_7298.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_4_Din_B = reg_7158.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_4_Din_B = reg_7018.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_4_Din_B = reg_6878.read();
        } else {
            v2_5_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter29.read()))) {
        v2_5_4_EN_A = ap_const_logic_1;
    } else {
        v2_5_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_4_EN_B = ap_const_logic_1;
    } else {
        v2_5_4_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_4_Rst_A() {
    v2_5_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_4_Rst_B() {
    v2_5_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_4_WEN_A() {
    v2_5_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_4_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_5_Addr_A() {
    v2_5_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_5_Addr_A_orig() {
    v2_5_5_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter35_reg.read());
}

void kernel_2mm_asdse::thread_v2_5_5_Addr_B() {
    v2_5_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_5_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_5_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_5_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_5_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_5_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_5_Clk_A() {
    v2_5_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_5_Clk_B() {
    v2_5_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_5_Din_A() {
    v2_5_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_5_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_5_Din_B = reg_7312.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_5_Din_B = reg_7172.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_5_Din_B = reg_7032.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_5_Din_B = reg_6892.read();
        } else {
            v2_5_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter36.read()))) {
        v2_5_5_EN_A = ap_const_logic_1;
    } else {
        v2_5_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_5_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_5_EN_B = ap_const_logic_1;
    } else {
        v2_5_5_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_5_Rst_A() {
    v2_5_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_5_Rst_B() {
    v2_5_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_5_WEN_A() {
    v2_5_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_5_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_5_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_6_Addr_A() {
    v2_5_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_6_Addr_A_orig() {
    v2_5_6_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter42_reg.read());
}

void kernel_2mm_asdse::thread_v2_5_6_Addr_B() {
    v2_5_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_6_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_6_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_6_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_6_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_6_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_6_Clk_A() {
    v2_5_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_6_Clk_B() {
    v2_5_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_6_Din_A() {
    v2_5_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_6_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_6_Din_B = reg_7326.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_6_Din_B = reg_7186.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_6_Din_B = reg_7046.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_6_Din_B = reg_6906.read();
        } else {
            v2_5_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter43.read()))) {
        v2_5_6_EN_A = ap_const_logic_1;
    } else {
        v2_5_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_6_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_6_EN_B = ap_const_logic_1;
    } else {
        v2_5_6_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_6_Rst_A() {
    v2_5_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_6_Rst_B() {
    v2_5_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_6_WEN_A() {
    v2_5_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_6_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_6_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_7_Addr_A() {
    v2_5_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_7_Addr_A_orig() {
    v2_5_7_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter49_reg.read());
}

void kernel_2mm_asdse::thread_v2_5_7_Addr_B() {
    v2_5_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_7_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_7_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_7_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_7_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_7_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_7_Clk_A() {
    v2_5_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_7_Clk_B() {
    v2_5_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_7_Din_A() {
    v2_5_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_7_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_7_Din_B = reg_7340.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_7_Din_B = reg_7200.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_7_Din_B = reg_7060.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_7_Din_B = reg_6920.read();
        } else {
            v2_5_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter50.read()))) {
        v2_5_7_EN_A = ap_const_logic_1;
    } else {
        v2_5_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_7_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_7_EN_B = ap_const_logic_1;
    } else {
        v2_5_7_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_7_Rst_A() {
    v2_5_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_7_Rst_B() {
    v2_5_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_7_WEN_A() {
    v2_5_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_7_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_7_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_8_Addr_A() {
    v2_5_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_8_Addr_A_orig() {
    v2_5_8_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter56_reg.read());
}

void kernel_2mm_asdse::thread_v2_5_8_Addr_B() {
    v2_5_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_8_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_8_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_8_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_8_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_8_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_8_Clk_A() {
    v2_5_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_8_Clk_B() {
    v2_5_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_8_Din_A() {
    v2_5_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_8_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_8_Din_B = reg_7354.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_8_Din_B = reg_7214.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_8_Din_B = reg_7074.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_8_Din_B = reg_6934.read();
        } else {
            v2_5_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter57.read()))) {
        v2_5_8_EN_A = ap_const_logic_1;
    } else {
        v2_5_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_8_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_8_EN_B = ap_const_logic_1;
    } else {
        v2_5_8_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_8_Rst_A() {
    v2_5_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_8_Rst_B() {
    v2_5_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_8_WEN_A() {
    v2_5_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_8_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_8_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_9_Addr_A() {
    v2_5_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_9_Addr_A_orig() {
    v2_5_9_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter63_reg.read());
}

void kernel_2mm_asdse::thread_v2_5_9_Addr_B() {
    v2_5_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_5_9_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_9_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_9_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_9_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_9_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_5_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_9_Clk_A() {
    v2_5_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_9_Clk_B() {
    v2_5_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_5_9_Din_A() {
    v2_5_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_5_9_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)) {
            v2_5_9_Din_B = reg_7368.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_5_9_Din_B = reg_7228.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_5_9_Din_B = reg_7088.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_5_9_Din_B = reg_6948.read();
        } else {
            v2_5_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_5_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_5_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter64.read()))) {
        v2_5_9_EN_A = ap_const_logic_1;
    } else {
        v2_5_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_9_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_9_EN_B = ap_const_logic_1;
    } else {
        v2_5_9_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_5_9_Rst_A() {
    v2_5_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_9_Rst_B() {
    v2_5_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_5_9_WEN_A() {
    v2_5_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_5_9_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2)))) {
        v2_5_9_WEN_B = ap_const_lv4_F;
    } else {
        v2_5_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_0_Addr_A() {
    v2_6_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_0_Addr_A_orig() {
    v2_6_0_Addr_A_orig =  (sc_lv<32>) (sext_ln711_fu_8351_p1.read());
}

void kernel_2mm_asdse::thread_v2_6_0_Addr_B() {
    v2_6_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_0_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_0_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_0_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_0_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_0_Clk_A() {
    v2_6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_0_Clk_B() {
    v2_6_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_0_Din_A() {
    v2_6_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_0_Din_B = reg_7242.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_0_Din_B = reg_7102.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_0_Din_B = reg_6962.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_0_Din_B = reg_6822.read();
        } else {
            v2_6_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v2_6_0_EN_A = ap_const_logic_1;
    } else {
        v2_6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_0_EN_B = ap_const_logic_1;
    } else {
        v2_6_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_0_Rst_A() {
    v2_6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_0_Rst_B() {
    v2_6_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_0_WEN_A() {
    v2_6_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_0_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_1_Addr_A() {
    v2_6_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_1_Addr_A_orig() {
    v2_6_1_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter7_reg.read());
}

void kernel_2mm_asdse::thread_v2_6_1_Addr_B() {
    v2_6_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_1_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_1_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_1_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_1_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_1_Clk_A() {
    v2_6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_1_Clk_B() {
    v2_6_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_1_Din_A() {
    v2_6_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_1_Din_B = reg_7256.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_1_Din_B = reg_7116.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_1_Din_B = reg_6976.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_1_Din_B = reg_6836.read();
        } else {
            v2_6_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v2_6_1_EN_A = ap_const_logic_1;
    } else {
        v2_6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_1_EN_B = ap_const_logic_1;
    } else {
        v2_6_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_1_Rst_A() {
    v2_6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_1_Rst_B() {
    v2_6_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_1_WEN_A() {
    v2_6_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_1_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_2_Addr_A() {
    v2_6_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_2_Addr_A_orig() {
    v2_6_2_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter14_reg.read());
}

void kernel_2mm_asdse::thread_v2_6_2_Addr_B() {
    v2_6_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_2_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_2_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_2_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_2_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_2_Clk_A() {
    v2_6_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_2_Clk_B() {
    v2_6_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_2_Din_A() {
    v2_6_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_2_Din_B = reg_7270.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_2_Din_B = reg_7130.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_2_Din_B = reg_6990.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_2_Din_B = reg_6850.read();
        } else {
            v2_6_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        v2_6_2_EN_A = ap_const_logic_1;
    } else {
        v2_6_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_2_EN_B = ap_const_logic_1;
    } else {
        v2_6_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_2_Rst_A() {
    v2_6_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_2_Rst_B() {
    v2_6_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_2_WEN_A() {
    v2_6_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_2_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_3_Addr_A() {
    v2_6_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_3_Addr_A_orig() {
    v2_6_3_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter21_reg.read());
}

void kernel_2mm_asdse::thread_v2_6_3_Addr_B() {
    v2_6_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_3_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_3_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_3_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_3_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_3_Clk_A() {
    v2_6_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_3_Clk_B() {
    v2_6_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_3_Din_A() {
    v2_6_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_3_Din_B = reg_7284.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_3_Din_B = reg_7144.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_3_Din_B = reg_7004.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_3_Din_B = reg_6864.read();
        } else {
            v2_6_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter22.read()))) {
        v2_6_3_EN_A = ap_const_logic_1;
    } else {
        v2_6_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_3_EN_B = ap_const_logic_1;
    } else {
        v2_6_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_3_Rst_A() {
    v2_6_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_3_Rst_B() {
    v2_6_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_3_WEN_A() {
    v2_6_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_3_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_4_Addr_A() {
    v2_6_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_4_Addr_A_orig() {
    v2_6_4_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter28_reg.read());
}

void kernel_2mm_asdse::thread_v2_6_4_Addr_B() {
    v2_6_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_4_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_4_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_4_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_4_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_4_Clk_A() {
    v2_6_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_4_Clk_B() {
    v2_6_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_4_Din_A() {
    v2_6_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_4_Din_B = reg_7298.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_4_Din_B = reg_7158.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_4_Din_B = reg_7018.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_4_Din_B = reg_6878.read();
        } else {
            v2_6_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter29.read()))) {
        v2_6_4_EN_A = ap_const_logic_1;
    } else {
        v2_6_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_4_EN_B = ap_const_logic_1;
    } else {
        v2_6_4_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_4_Rst_A() {
    v2_6_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_4_Rst_B() {
    v2_6_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_4_WEN_A() {
    v2_6_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_4_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_5_Addr_A() {
    v2_6_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_5_Addr_A_orig() {
    v2_6_5_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter35_reg.read());
}

void kernel_2mm_asdse::thread_v2_6_5_Addr_B() {
    v2_6_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_5_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_5_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_5_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_5_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_5_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_5_Clk_A() {
    v2_6_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_5_Clk_B() {
    v2_6_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_5_Din_A() {
    v2_6_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_5_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_5_Din_B = reg_7312.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_5_Din_B = reg_7172.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_5_Din_B = reg_7032.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_5_Din_B = reg_6892.read();
        } else {
            v2_6_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter36.read()))) {
        v2_6_5_EN_A = ap_const_logic_1;
    } else {
        v2_6_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_5_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_5_EN_B = ap_const_logic_1;
    } else {
        v2_6_5_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_5_Rst_A() {
    v2_6_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_5_Rst_B() {
    v2_6_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_5_WEN_A() {
    v2_6_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_5_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_5_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_6_Addr_A() {
    v2_6_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_6_Addr_A_orig() {
    v2_6_6_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter42_reg.read());
}

void kernel_2mm_asdse::thread_v2_6_6_Addr_B() {
    v2_6_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_6_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_6_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_6_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_6_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_6_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_6_Clk_A() {
    v2_6_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_6_Clk_B() {
    v2_6_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_6_Din_A() {
    v2_6_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_6_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_6_Din_B = reg_7326.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_6_Din_B = reg_7186.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_6_Din_B = reg_7046.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_6_Din_B = reg_6906.read();
        } else {
            v2_6_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter43.read()))) {
        v2_6_6_EN_A = ap_const_logic_1;
    } else {
        v2_6_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_6_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_6_EN_B = ap_const_logic_1;
    } else {
        v2_6_6_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_6_Rst_A() {
    v2_6_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_6_Rst_B() {
    v2_6_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_6_WEN_A() {
    v2_6_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_6_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_6_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_7_Addr_A() {
    v2_6_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_7_Addr_A_orig() {
    v2_6_7_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter49_reg.read());
}

void kernel_2mm_asdse::thread_v2_6_7_Addr_B() {
    v2_6_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_7_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_7_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_7_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_7_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_7_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_7_Clk_A() {
    v2_6_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_7_Clk_B() {
    v2_6_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_7_Din_A() {
    v2_6_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_7_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_7_Din_B = reg_7340.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_7_Din_B = reg_7200.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_7_Din_B = reg_7060.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_7_Din_B = reg_6920.read();
        } else {
            v2_6_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter50.read()))) {
        v2_6_7_EN_A = ap_const_logic_1;
    } else {
        v2_6_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_7_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_7_EN_B = ap_const_logic_1;
    } else {
        v2_6_7_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_7_Rst_A() {
    v2_6_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_7_Rst_B() {
    v2_6_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_7_WEN_A() {
    v2_6_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_7_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_7_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_8_Addr_A() {
    v2_6_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_8_Addr_A_orig() {
    v2_6_8_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter56_reg.read());
}

void kernel_2mm_asdse::thread_v2_6_8_Addr_B() {
    v2_6_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_8_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_8_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_8_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_8_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_8_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_8_Clk_A() {
    v2_6_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_8_Clk_B() {
    v2_6_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_8_Din_A() {
    v2_6_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_8_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_8_Din_B = reg_7354.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_8_Din_B = reg_7214.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_8_Din_B = reg_7074.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_8_Din_B = reg_6934.read();
        } else {
            v2_6_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter57.read()))) {
        v2_6_8_EN_A = ap_const_logic_1;
    } else {
        v2_6_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_8_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_8_EN_B = ap_const_logic_1;
    } else {
        v2_6_8_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_8_Rst_A() {
    v2_6_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_8_Rst_B() {
    v2_6_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_8_WEN_A() {
    v2_6_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_8_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_8_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_9_Addr_A() {
    v2_6_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_9_Addr_A_orig() {
    v2_6_9_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter63_reg.read());
}

void kernel_2mm_asdse::thread_v2_6_9_Addr_B() {
    v2_6_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_6_9_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_9_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_9_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_9_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_9_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_6_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_9_Clk_A() {
    v2_6_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_9_Clk_B() {
    v2_6_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_6_9_Din_A() {
    v2_6_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_6_9_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)) {
            v2_6_9_Din_B = reg_7368.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_6_9_Din_B = reg_7228.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_6_9_Din_B = reg_7088.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_6_9_Din_B = reg_6948.read();
        } else {
            v2_6_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_6_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_6_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter64.read()))) {
        v2_6_9_EN_A = ap_const_logic_1;
    } else {
        v2_6_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_9_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_9_EN_B = ap_const_logic_1;
    } else {
        v2_6_9_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_6_9_Rst_A() {
    v2_6_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_9_Rst_B() {
    v2_6_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_6_9_WEN_A() {
    v2_6_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_6_9_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3)))) {
        v2_6_9_WEN_B = ap_const_lv4_F;
    } else {
        v2_6_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_0_Addr_A() {
    v2_7_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_0_Addr_A_orig() {
    v2_7_0_Addr_A_orig =  (sc_lv<32>) (sext_ln711_fu_8351_p1.read());
}

void kernel_2mm_asdse::thread_v2_7_0_Addr_B() {
    v2_7_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_0_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_0_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_0_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_0_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_0_Clk_A() {
    v2_7_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_0_Clk_B() {
    v2_7_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_0_Din_A() {
    v2_7_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_0_Din_B = reg_7242.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_0_Din_B = reg_7102.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_0_Din_B = reg_6962.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_0_Din_B = reg_6822.read();
        } else {
            v2_7_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v2_7_0_EN_A = ap_const_logic_1;
    } else {
        v2_7_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_0_EN_B = ap_const_logic_1;
    } else {
        v2_7_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_0_Rst_A() {
    v2_7_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_0_Rst_B() {
    v2_7_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_0_WEN_A() {
    v2_7_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_0_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_1_Addr_A() {
    v2_7_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_1_Addr_A_orig() {
    v2_7_1_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter7_reg.read());
}

void kernel_2mm_asdse::thread_v2_7_1_Addr_B() {
    v2_7_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_1_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_1_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_1_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_1_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_1_Clk_A() {
    v2_7_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_1_Clk_B() {
    v2_7_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_1_Din_A() {
    v2_7_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_1_Din_B = reg_7256.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_1_Din_B = reg_7116.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_1_Din_B = reg_6976.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_1_Din_B = reg_6836.read();
        } else {
            v2_7_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v2_7_1_EN_A = ap_const_logic_1;
    } else {
        v2_7_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_1_EN_B = ap_const_logic_1;
    } else {
        v2_7_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_1_Rst_A() {
    v2_7_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_1_Rst_B() {
    v2_7_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_1_WEN_A() {
    v2_7_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_1_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_2_Addr_A() {
    v2_7_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_2_Addr_A_orig() {
    v2_7_2_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter14_reg.read());
}

void kernel_2mm_asdse::thread_v2_7_2_Addr_B() {
    v2_7_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_2_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_2_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_2_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_2_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_2_Clk_A() {
    v2_7_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_2_Clk_B() {
    v2_7_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_2_Din_A() {
    v2_7_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_2_Din_B = reg_7270.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_2_Din_B = reg_7130.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_2_Din_B = reg_6990.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_2_Din_B = reg_6850.read();
        } else {
            v2_7_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        v2_7_2_EN_A = ap_const_logic_1;
    } else {
        v2_7_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_2_EN_B = ap_const_logic_1;
    } else {
        v2_7_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_2_Rst_A() {
    v2_7_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_2_Rst_B() {
    v2_7_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_2_WEN_A() {
    v2_7_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_2_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_3_Addr_A() {
    v2_7_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_3_Addr_A_orig() {
    v2_7_3_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter21_reg.read());
}

void kernel_2mm_asdse::thread_v2_7_3_Addr_B() {
    v2_7_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_3_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_3_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_3_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_3_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_3_Clk_A() {
    v2_7_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_3_Clk_B() {
    v2_7_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_3_Din_A() {
    v2_7_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_3_Din_B = reg_7284.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_3_Din_B = reg_7144.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_3_Din_B = reg_7004.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_3_Din_B = reg_6864.read();
        } else {
            v2_7_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter22.read()))) {
        v2_7_3_EN_A = ap_const_logic_1;
    } else {
        v2_7_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_3_EN_B = ap_const_logic_1;
    } else {
        v2_7_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_3_Rst_A() {
    v2_7_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_3_Rst_B() {
    v2_7_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_3_WEN_A() {
    v2_7_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_3_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_4_Addr_A() {
    v2_7_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_4_Addr_A_orig() {
    v2_7_4_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter28_reg.read());
}

void kernel_2mm_asdse::thread_v2_7_4_Addr_B() {
    v2_7_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_4_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_4_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_4_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_4_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_4_Clk_A() {
    v2_7_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_4_Clk_B() {
    v2_7_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_4_Din_A() {
    v2_7_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_4_Din_B = reg_7298.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_4_Din_B = reg_7158.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_4_Din_B = reg_7018.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_4_Din_B = reg_6878.read();
        } else {
            v2_7_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter29.read()))) {
        v2_7_4_EN_A = ap_const_logic_1;
    } else {
        v2_7_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_4_EN_B = ap_const_logic_1;
    } else {
        v2_7_4_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_4_Rst_A() {
    v2_7_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_4_Rst_B() {
    v2_7_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_4_WEN_A() {
    v2_7_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_4_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_5_Addr_A() {
    v2_7_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_5_Addr_A_orig() {
    v2_7_5_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter35_reg.read());
}

void kernel_2mm_asdse::thread_v2_7_5_Addr_B() {
    v2_7_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_5_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_5_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_5_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_5_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_5_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_5_Clk_A() {
    v2_7_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_5_Clk_B() {
    v2_7_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_5_Din_A() {
    v2_7_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_5_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_5_Din_B = reg_7312.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_5_Din_B = reg_7172.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_5_Din_B = reg_7032.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_5_Din_B = reg_6892.read();
        } else {
            v2_7_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter36.read()))) {
        v2_7_5_EN_A = ap_const_logic_1;
    } else {
        v2_7_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_5_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_5_EN_B = ap_const_logic_1;
    } else {
        v2_7_5_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_5_Rst_A() {
    v2_7_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_5_Rst_B() {
    v2_7_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_5_WEN_A() {
    v2_7_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_5_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_5_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_6_Addr_A() {
    v2_7_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_6_Addr_A_orig() {
    v2_7_6_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter42_reg.read());
}

void kernel_2mm_asdse::thread_v2_7_6_Addr_B() {
    v2_7_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_6_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_6_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_6_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_6_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_6_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_6_Clk_A() {
    v2_7_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_6_Clk_B() {
    v2_7_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_6_Din_A() {
    v2_7_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_6_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_6_Din_B = reg_7326.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_6_Din_B = reg_7186.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_6_Din_B = reg_7046.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_6_Din_B = reg_6906.read();
        } else {
            v2_7_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter43.read()))) {
        v2_7_6_EN_A = ap_const_logic_1;
    } else {
        v2_7_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_6_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_6_EN_B = ap_const_logic_1;
    } else {
        v2_7_6_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_6_Rst_A() {
    v2_7_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_6_Rst_B() {
    v2_7_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_6_WEN_A() {
    v2_7_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_6_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_6_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_7_Addr_A() {
    v2_7_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_7_Addr_A_orig() {
    v2_7_7_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter49_reg.read());
}

void kernel_2mm_asdse::thread_v2_7_7_Addr_B() {
    v2_7_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_7_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_7_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_7_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_7_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_7_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_7_Clk_A() {
    v2_7_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_7_Clk_B() {
    v2_7_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_7_Din_A() {
    v2_7_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_7_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_7_Din_B = reg_7340.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_7_Din_B = reg_7200.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_7_Din_B = reg_7060.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_7_Din_B = reg_6920.read();
        } else {
            v2_7_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter50.read()))) {
        v2_7_7_EN_A = ap_const_logic_1;
    } else {
        v2_7_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_7_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_7_EN_B = ap_const_logic_1;
    } else {
        v2_7_7_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_7_Rst_A() {
    v2_7_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_7_Rst_B() {
    v2_7_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_7_WEN_A() {
    v2_7_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_7_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_7_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_8_Addr_A() {
    v2_7_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_8_Addr_A_orig() {
    v2_7_8_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter56_reg.read());
}

void kernel_2mm_asdse::thread_v2_7_8_Addr_B() {
    v2_7_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_8_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_8_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_8_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_8_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_8_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_8_Clk_A() {
    v2_7_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_8_Clk_B() {
    v2_7_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_8_Din_A() {
    v2_7_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_8_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_8_Din_B = reg_7354.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_8_Din_B = reg_7214.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_8_Din_B = reg_7074.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_8_Din_B = reg_6934.read();
        } else {
            v2_7_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter57.read()))) {
        v2_7_8_EN_A = ap_const_logic_1;
    } else {
        v2_7_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_8_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_8_EN_B = ap_const_logic_1;
    } else {
        v2_7_8_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_8_Rst_A() {
    v2_7_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_8_Rst_B() {
    v2_7_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_8_WEN_A() {
    v2_7_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_8_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_8_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_9_Addr_A() {
    v2_7_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_9_Addr_A_orig() {
    v2_7_9_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter63_reg.read());
}

void kernel_2mm_asdse::thread_v2_7_9_Addr_B() {
    v2_7_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_7_9_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_9_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_9_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_9_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_9_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else {
            v2_7_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_9_Clk_A() {
    v2_7_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_9_Clk_B() {
    v2_7_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_7_9_Din_A() {
    v2_7_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_7_9_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)) {
            v2_7_9_Din_B = reg_7368.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_7_9_Din_B = reg_7228.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_7_9_Din_B = reg_7088.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_7_9_Din_B = reg_6948.read();
        } else {
            v2_7_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_7_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_7_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter64.read()))) {
        v2_7_9_EN_A = ap_const_logic_1;
    } else {
        v2_7_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_9_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_9_EN_B = ap_const_logic_1;
    } else {
        v2_7_9_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_7_9_Rst_A() {
    v2_7_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_9_Rst_B() {
    v2_7_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_7_9_WEN_A() {
    v2_7_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_7_9_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4)))) {
        v2_7_9_WEN_B = ap_const_lv4_F;
    } else {
        v2_7_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_0_Addr_A() {
    v2_8_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_0_Addr_A_orig() {
    v2_8_0_Addr_A_orig =  (sc_lv<32>) (sext_ln711_fu_8351_p1.read());
}

void kernel_2mm_asdse::thread_v2_8_0_Addr_B() {
    v2_8_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_0_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_0_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_0_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_0_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_0_Clk_A() {
    v2_8_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_0_Clk_B() {
    v2_8_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_0_Din_A() {
    v2_8_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_0_Din_B = reg_6822.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_0_Din_B = reg_7242.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_0_Din_B = reg_7102.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_0_Din_B = reg_6962.read();
        } else {
            v2_8_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v2_8_0_EN_A = ap_const_logic_1;
    } else {
        v2_8_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_0_EN_B = ap_const_logic_1;
    } else {
        v2_8_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_0_Rst_A() {
    v2_8_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_0_Rst_B() {
    v2_8_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_0_WEN_A() {
    v2_8_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_0_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_1_Addr_A() {
    v2_8_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_1_Addr_A_orig() {
    v2_8_1_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter7_reg.read());
}

void kernel_2mm_asdse::thread_v2_8_1_Addr_B() {
    v2_8_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_1_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_1_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_1_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_1_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_1_Clk_A() {
    v2_8_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_1_Clk_B() {
    v2_8_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_1_Din_A() {
    v2_8_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_1_Din_B = reg_6836.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_1_Din_B = reg_7256.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_1_Din_B = reg_7116.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_1_Din_B = reg_6976.read();
        } else {
            v2_8_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v2_8_1_EN_A = ap_const_logic_1;
    } else {
        v2_8_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_1_EN_B = ap_const_logic_1;
    } else {
        v2_8_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_1_Rst_A() {
    v2_8_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_1_Rst_B() {
    v2_8_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_1_WEN_A() {
    v2_8_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_1_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_2_Addr_A() {
    v2_8_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_2_Addr_A_orig() {
    v2_8_2_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter14_reg.read());
}

void kernel_2mm_asdse::thread_v2_8_2_Addr_B() {
    v2_8_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_2_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_2_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_2_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_2_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_2_Clk_A() {
    v2_8_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_2_Clk_B() {
    v2_8_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_2_Din_A() {
    v2_8_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_2_Din_B = reg_6850.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_2_Din_B = reg_7270.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_2_Din_B = reg_7130.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_2_Din_B = reg_6990.read();
        } else {
            v2_8_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        v2_8_2_EN_A = ap_const_logic_1;
    } else {
        v2_8_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_2_EN_B = ap_const_logic_1;
    } else {
        v2_8_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_2_Rst_A() {
    v2_8_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_2_Rst_B() {
    v2_8_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_2_WEN_A() {
    v2_8_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_2_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_3_Addr_A() {
    v2_8_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_3_Addr_A_orig() {
    v2_8_3_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter21_reg.read());
}

void kernel_2mm_asdse::thread_v2_8_3_Addr_B() {
    v2_8_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_3_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_3_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_3_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_3_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_3_Clk_A() {
    v2_8_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_3_Clk_B() {
    v2_8_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_3_Din_A() {
    v2_8_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_3_Din_B = reg_6864.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_3_Din_B = reg_7284.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_3_Din_B = reg_7144.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_3_Din_B = reg_7004.read();
        } else {
            v2_8_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter22.read()))) {
        v2_8_3_EN_A = ap_const_logic_1;
    } else {
        v2_8_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_3_EN_B = ap_const_logic_1;
    } else {
        v2_8_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_3_Rst_A() {
    v2_8_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_3_Rst_B() {
    v2_8_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_3_WEN_A() {
    v2_8_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_3_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_4_Addr_A() {
    v2_8_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_4_Addr_A_orig() {
    v2_8_4_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter28_reg.read());
}

void kernel_2mm_asdse::thread_v2_8_4_Addr_B() {
    v2_8_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_4_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_4_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_4_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_4_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_4_Clk_A() {
    v2_8_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_4_Clk_B() {
    v2_8_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_4_Din_A() {
    v2_8_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_4_Din_B = reg_6878.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_4_Din_B = reg_7298.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_4_Din_B = reg_7158.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_4_Din_B = reg_7018.read();
        } else {
            v2_8_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter29.read()))) {
        v2_8_4_EN_A = ap_const_logic_1;
    } else {
        v2_8_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_4_EN_B = ap_const_logic_1;
    } else {
        v2_8_4_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_4_Rst_A() {
    v2_8_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_4_Rst_B() {
    v2_8_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_4_WEN_A() {
    v2_8_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_4_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_5_Addr_A() {
    v2_8_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_5_Addr_A_orig() {
    v2_8_5_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter35_reg.read());
}

void kernel_2mm_asdse::thread_v2_8_5_Addr_B() {
    v2_8_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_5_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_5_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_5_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_5_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_5_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_5_Clk_A() {
    v2_8_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_5_Clk_B() {
    v2_8_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_5_Din_A() {
    v2_8_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_5_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_5_Din_B = reg_6892.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_5_Din_B = reg_7312.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_5_Din_B = reg_7172.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_5_Din_B = reg_7032.read();
        } else {
            v2_8_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter36.read()))) {
        v2_8_5_EN_A = ap_const_logic_1;
    } else {
        v2_8_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_5_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_5_EN_B = ap_const_logic_1;
    } else {
        v2_8_5_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_5_Rst_A() {
    v2_8_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_5_Rst_B() {
    v2_8_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_5_WEN_A() {
    v2_8_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_5_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_5_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_6_Addr_A() {
    v2_8_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_6_Addr_A_orig() {
    v2_8_6_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter42_reg.read());
}

void kernel_2mm_asdse::thread_v2_8_6_Addr_B() {
    v2_8_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_6_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_6_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_6_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_6_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_6_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_6_Clk_A() {
    v2_8_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_6_Clk_B() {
    v2_8_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_6_Din_A() {
    v2_8_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_6_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_6_Din_B = reg_6906.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_6_Din_B = reg_7326.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_6_Din_B = reg_7186.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_6_Din_B = reg_7046.read();
        } else {
            v2_8_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter43.read()))) {
        v2_8_6_EN_A = ap_const_logic_1;
    } else {
        v2_8_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_6_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_6_EN_B = ap_const_logic_1;
    } else {
        v2_8_6_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_6_Rst_A() {
    v2_8_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_6_Rst_B() {
    v2_8_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_6_WEN_A() {
    v2_8_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_6_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_6_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_7_Addr_A() {
    v2_8_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_7_Addr_A_orig() {
    v2_8_7_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter49_reg.read());
}

void kernel_2mm_asdse::thread_v2_8_7_Addr_B() {
    v2_8_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_7_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_7_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_7_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_7_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_7_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_7_Clk_A() {
    v2_8_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_7_Clk_B() {
    v2_8_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_7_Din_A() {
    v2_8_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_7_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_7_Din_B = reg_6920.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_7_Din_B = reg_7340.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_7_Din_B = reg_7200.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_7_Din_B = reg_7060.read();
        } else {
            v2_8_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter50.read()))) {
        v2_8_7_EN_A = ap_const_logic_1;
    } else {
        v2_8_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_7_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_7_EN_B = ap_const_logic_1;
    } else {
        v2_8_7_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_7_Rst_A() {
    v2_8_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_7_Rst_B() {
    v2_8_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_7_WEN_A() {
    v2_8_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_7_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_7_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_8_Addr_A() {
    v2_8_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_8_Addr_A_orig() {
    v2_8_8_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter56_reg.read());
}

void kernel_2mm_asdse::thread_v2_8_8_Addr_B() {
    v2_8_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_8_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_8_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_8_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_8_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_8_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_8_Clk_A() {
    v2_8_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_8_Clk_B() {
    v2_8_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_8_Din_A() {
    v2_8_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_8_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_8_Din_B = reg_6934.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_8_Din_B = reg_7354.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_8_Din_B = reg_7214.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_8_Din_B = reg_7074.read();
        } else {
            v2_8_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter57.read()))) {
        v2_8_8_EN_A = ap_const_logic_1;
    } else {
        v2_8_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_8_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_8_EN_B = ap_const_logic_1;
    } else {
        v2_8_8_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_8_Rst_A() {
    v2_8_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_8_Rst_B() {
    v2_8_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_8_WEN_A() {
    v2_8_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_8_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_8_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_9_Addr_A() {
    v2_8_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_9_Addr_A_orig() {
    v2_8_9_Addr_A_orig =  (sc_lv<32>) (sext_ln711_reg_8871_pp1_iter63_reg.read());
}

void kernel_2mm_asdse::thread_v2_8_9_Addr_B() {
    v2_8_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v2_8_9_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_9_Addr_B_orig =  (sc_lv<32>) (sext_ln61_2_fu_7861_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_9_Addr_B_orig =  (sc_lv<32>) (sext_ln301_2_fu_8140_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_9_Addr_B_orig =  (sc_lv<32>) (sext_ln221_2_fu_8047_p1.read());
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_9_Addr_B_orig =  (sc_lv<32>) (sext_ln141_2_fu_7954_p1.read());
        } else {
            v2_8_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_9_Clk_A() {
    v2_8_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_9_Clk_B() {
    v2_8_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v2_8_9_Din_A() {
    v2_8_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v2_8_9_Din_B() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()))) {
        if (esl_seteq<1,1,1>(ap_condition_6530.read(), ap_const_boolean_1)) {
            v2_8_9_Din_B = reg_6948.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) {
            v2_8_9_Din_B = reg_7368.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) {
            v2_8_9_Din_B = reg_7228.read();
        } else if (esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) {
            v2_8_9_Din_B = reg_7088.read();
        } else {
            v2_8_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        v2_8_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_2mm_asdse::thread_v2_8_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter64.read()))) {
        v2_8_9_EN_A = ap_const_logic_1;
    } else {
        v2_8_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_9_EN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_9_EN_B = ap_const_logic_1;
    } else {
        v2_8_9_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v2_8_9_Rst_A() {
    v2_8_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_9_Rst_B() {
    v2_8_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v2_8_9_WEN_A() {
    v2_8_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v2_8_9_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5)) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter13.read()) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_0) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_1) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_2) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_3) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_4) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_5) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_6) && 
          !esl_seteq<1,5,5>(select_ln58_2_reg_8809_pp0_iter12_reg.read(), ap_const_lv5_7)))) {
        v2_8_9_WEN_B = ap_const_lv4_F;
    } else {
        v2_8_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v3_0_0_Addr_A() {
    v3_0_0_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_0_0_Addr_B() {
    v3_0_0_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_0_0_Clk_A() {
    v3_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_0_0_Clk_B() {
    v3_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_0_0_Din_A() {
    v3_0_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_0_0_Din_B() {
    v3_0_0_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_0_0_EN_A() {
    v3_0_0_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v3_0_0_EN_B() {
    v3_0_0_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v3_0_0_Rst_A() {
    v3_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_0_0_Rst_B() {
    v3_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_0_0_WEN_A() {
    v3_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_0_0_WEN_B() {
    v3_0_0_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_0_1_Addr_A() {
    v3_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v3_0_1_Addr_A_orig() {
    v3_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln382_1_fu_7522_p1.read());
}

void kernel_2mm_asdse::thread_v3_0_1_Clk_A() {
    v3_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_0_1_Din_A() {
    v3_0_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v3_0_1_EN_A = ap_const_logic_1;
    } else {
        v3_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v3_0_1_Rst_A() {
    v3_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_0_1_WEN_A() {
    v3_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_1_0_Addr_A() {
    v3_1_0_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_1_0_Addr_B() {
    v3_1_0_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_1_0_Clk_A() {
    v3_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_1_0_Clk_B() {
    v3_1_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_1_0_Din_A() {
    v3_1_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_1_0_Din_B() {
    v3_1_0_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_1_0_EN_A() {
    v3_1_0_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v3_1_0_EN_B() {
    v3_1_0_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v3_1_0_Rst_A() {
    v3_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_1_0_Rst_B() {
    v3_1_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_1_0_WEN_A() {
    v3_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_1_0_WEN_B() {
    v3_1_0_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_1_1_Addr_A() {
    v3_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v3_1_1_Addr_A_orig() {
    v3_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln382_1_fu_7522_p1.read());
}

void kernel_2mm_asdse::thread_v3_1_1_Clk_A() {
    v3_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_1_1_Din_A() {
    v3_1_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v3_1_1_EN_A = ap_const_logic_1;
    } else {
        v3_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v3_1_1_Rst_A() {
    v3_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_1_1_WEN_A() {
    v3_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_2_0_Addr_A() {
    v3_2_0_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_2_0_Addr_B() {
    v3_2_0_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_2_0_Clk_A() {
    v3_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_2_0_Clk_B() {
    v3_2_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_2_0_Din_A() {
    v3_2_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_2_0_Din_B() {
    v3_2_0_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_2_0_EN_A() {
    v3_2_0_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v3_2_0_EN_B() {
    v3_2_0_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v3_2_0_Rst_A() {
    v3_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_2_0_Rst_B() {
    v3_2_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_2_0_WEN_A() {
    v3_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_2_0_WEN_B() {
    v3_2_0_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_2_1_Addr_A() {
    v3_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v3_2_1_Addr_A_orig() {
    v3_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln382_1_fu_7522_p1.read());
}

void kernel_2mm_asdse::thread_v3_2_1_Clk_A() {
    v3_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_2_1_Din_A() {
    v3_2_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v3_2_1_EN_A = ap_const_logic_1;
    } else {
        v3_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v3_2_1_Rst_A() {
    v3_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_2_1_WEN_A() {
    v3_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_3_0_Addr_A() {
    v3_3_0_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_3_0_Addr_B() {
    v3_3_0_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_3_0_Clk_A() {
    v3_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_3_0_Clk_B() {
    v3_3_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_3_0_Din_A() {
    v3_3_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_3_0_Din_B() {
    v3_3_0_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_3_0_EN_A() {
    v3_3_0_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v3_3_0_EN_B() {
    v3_3_0_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v3_3_0_Rst_A() {
    v3_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_3_0_Rst_B() {
    v3_3_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_3_0_WEN_A() {
    v3_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_3_0_WEN_B() {
    v3_3_0_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v3_3_1_Addr_A() {
    v3_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v3_3_1_Addr_A_orig() {
    v3_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln382_1_fu_7522_p1.read());
}

void kernel_2mm_asdse::thread_v3_3_1_Clk_A() {
    v3_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v3_3_1_Din_A() {
    v3_3_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v3_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v3_3_1_EN_A = ap_const_logic_1;
    } else {
        v3_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v3_3_1_Rst_A() {
    v3_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v3_3_1_WEN_A() {
    v3_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v490_fu_8245_p2() {
    v490_fu_8245_p2 = (!ap_phi_mux_v490_0_phi_fu_5363_p4.read().is_01() || !ap_const_lv5_1.is_01())? sc_lv<5>(): (sc_biguint<5>(ap_phi_mux_v490_0_phi_fu_5363_p4.read()) + sc_biguint<5>(ap_const_lv5_1));
}

void kernel_2mm_asdse::thread_v491_fu_8291_p2() {
    v491_fu_8291_p2 = (!select_ln711_fu_8257_p3.read().is_01() || !ap_const_lv5_1.is_01())? sc_lv<5>(): (sc_biguint<5>(select_ln711_fu_8257_p3.read()) + sc_biguint<5>(ap_const_lv5_1));
}

void kernel_2mm_asdse::thread_v492_fu_8319_p2() {
    v492_fu_8319_p2 = (!select_ln711_2_fu_8303_p3.read().is_01() || !ap_const_lv8_1.is_01())? sc_lv<8>(): (sc_biguint<8>(select_ln711_2_fu_8303_p3.read()) + sc_biguint<8>(ap_const_lv8_1));
}

void kernel_2mm_asdse::thread_v4_0_0_Addr_A() {
    v4_0_0_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_0_Addr_B() {
    v4_0_0_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_0_Clk_A() {
    v4_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_0_Clk_B() {
    v4_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_0_Din_A() {
    v4_0_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_0_Din_B() {
    v4_0_0_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_0_EN_A() {
    v4_0_0_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_0_EN_B() {
    v4_0_0_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_0_Rst_A() {
    v4_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_0_Rst_B() {
    v4_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_0_WEN_A() {
    v4_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_0_WEN_B() {
    v4_0_0_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_1_Addr_A() {
    v4_0_1_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_1_Addr_B() {
    v4_0_1_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_1_Clk_A() {
    v4_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_1_Clk_B() {
    v4_0_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_1_Din_A() {
    v4_0_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_1_Din_B() {
    v4_0_1_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_1_EN_A() {
    v4_0_1_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_1_EN_B() {
    v4_0_1_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_1_Rst_A() {
    v4_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_1_Rst_B() {
    v4_0_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_1_WEN_A() {
    v4_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_1_WEN_B() {
    v4_0_1_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_2_Addr_A() {
    v4_0_2_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_2_Addr_B() {
    v4_0_2_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_2_Clk_A() {
    v4_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_2_Clk_B() {
    v4_0_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_2_Din_A() {
    v4_0_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_2_Din_B() {
    v4_0_2_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_2_EN_A() {
    v4_0_2_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_2_EN_B() {
    v4_0_2_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_2_Rst_A() {
    v4_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_2_Rst_B() {
    v4_0_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_2_WEN_A() {
    v4_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_2_WEN_B() {
    v4_0_2_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_3_Addr_A() {
    v4_0_3_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_3_Addr_B() {
    v4_0_3_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_3_Clk_A() {
    v4_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_3_Clk_B() {
    v4_0_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_3_Din_A() {
    v4_0_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_3_Din_B() {
    v4_0_3_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_3_EN_A() {
    v4_0_3_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_3_EN_B() {
    v4_0_3_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_3_Rst_A() {
    v4_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_3_Rst_B() {
    v4_0_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_3_WEN_A() {
    v4_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_3_WEN_B() {
    v4_0_3_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_4_Addr_A() {
    v4_0_4_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_4_Addr_B() {
    v4_0_4_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_4_Clk_A() {
    v4_0_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_4_Clk_B() {
    v4_0_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_4_Din_A() {
    v4_0_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_4_Din_B() {
    v4_0_4_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_4_EN_A() {
    v4_0_4_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_4_EN_B() {
    v4_0_4_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_4_Rst_A() {
    v4_0_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_4_Rst_B() {
    v4_0_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_4_WEN_A() {
    v4_0_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_4_WEN_B() {
    v4_0_4_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_5_Addr_A() {
    v4_0_5_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_5_Addr_B() {
    v4_0_5_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_5_Clk_A() {
    v4_0_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_5_Clk_B() {
    v4_0_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_5_Din_A() {
    v4_0_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_5_Din_B() {
    v4_0_5_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_5_EN_A() {
    v4_0_5_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_5_EN_B() {
    v4_0_5_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_5_Rst_A() {
    v4_0_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_5_Rst_B() {
    v4_0_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_5_WEN_A() {
    v4_0_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_5_WEN_B() {
    v4_0_5_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_6_Addr_A() {
    v4_0_6_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_6_Addr_B() {
    v4_0_6_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_6_Clk_A() {
    v4_0_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_6_Clk_B() {
    v4_0_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_6_Din_A() {
    v4_0_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_6_Din_B() {
    v4_0_6_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_6_EN_A() {
    v4_0_6_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_6_EN_B() {
    v4_0_6_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_6_Rst_A() {
    v4_0_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_6_Rst_B() {
    v4_0_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_6_WEN_A() {
    v4_0_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_6_WEN_B() {
    v4_0_6_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_7_Addr_A() {
    v4_0_7_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_7_Addr_B() {
    v4_0_7_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_7_Clk_A() {
    v4_0_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_7_Clk_B() {
    v4_0_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_7_Din_A() {
    v4_0_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_7_Din_B() {
    v4_0_7_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_7_EN_A() {
    v4_0_7_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_7_EN_B() {
    v4_0_7_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_7_Rst_A() {
    v4_0_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_7_Rst_B() {
    v4_0_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_7_WEN_A() {
    v4_0_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_7_WEN_B() {
    v4_0_7_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_8_Addr_A() {
    v4_0_8_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_8_Addr_B() {
    v4_0_8_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_8_Clk_A() {
    v4_0_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_8_Clk_B() {
    v4_0_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_8_Din_A() {
    v4_0_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_8_Din_B() {
    v4_0_8_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_8_EN_A() {
    v4_0_8_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_8_EN_B() {
    v4_0_8_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_8_Rst_A() {
    v4_0_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_8_Rst_B() {
    v4_0_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_8_WEN_A() {
    v4_0_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_8_WEN_B() {
    v4_0_8_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_9_Addr_A() {
    v4_0_9_Addr_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_9_Addr_B() {
    v4_0_9_Addr_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_9_Clk_A() {
    v4_0_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_9_Clk_B() {
    v4_0_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_0_9_Din_A() {
    v4_0_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_9_Din_B() {
    v4_0_9_Din_B = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_0_9_EN_A() {
    v4_0_9_EN_A = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_9_EN_B() {
    v4_0_9_EN_B = ap_const_logic_0;
}

void kernel_2mm_asdse::thread_v4_0_9_Rst_A() {
    v4_0_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_9_Rst_B() {
    v4_0_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_0_9_WEN_A() {
    v4_0_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_0_9_WEN_B() {
    v4_0_9_WEN_B = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_0_Addr_A() {
    v4_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_0_Addr_A_orig() {
    v4_1_0_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_0_Clk_A() {
    v4_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_0_Din_A() {
    v4_1_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_0_EN_A = ap_const_logic_1;
    } else {
        v4_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_0_Rst_A() {
    v4_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_0_WEN_A() {
    v4_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_1_Addr_A() {
    v4_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_1_Addr_A_orig() {
    v4_1_1_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_1_Clk_A() {
    v4_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_1_Din_A() {
    v4_1_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_1_EN_A = ap_const_logic_1;
    } else {
        v4_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_1_Rst_A() {
    v4_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_1_WEN_A() {
    v4_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_2_Addr_A() {
    v4_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_2_Addr_A_orig() {
    v4_1_2_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_2_Clk_A() {
    v4_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_2_Din_A() {
    v4_1_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_2_EN_A = ap_const_logic_1;
    } else {
        v4_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_2_Rst_A() {
    v4_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_2_WEN_A() {
    v4_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_3_Addr_A() {
    v4_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_3_Addr_A_orig() {
    v4_1_3_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_3_Clk_A() {
    v4_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_3_Din_A() {
    v4_1_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_3_EN_A = ap_const_logic_1;
    } else {
        v4_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_3_Rst_A() {
    v4_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_3_WEN_A() {
    v4_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_4_Addr_A() {
    v4_1_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_4_Addr_A_orig() {
    v4_1_4_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_4_Clk_A() {
    v4_1_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_4_Din_A() {
    v4_1_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_4_EN_A = ap_const_logic_1;
    } else {
        v4_1_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_4_Rst_A() {
    v4_1_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_4_WEN_A() {
    v4_1_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_5_Addr_A() {
    v4_1_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_5_Addr_A_orig() {
    v4_1_5_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_5_Clk_A() {
    v4_1_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_5_Din_A() {
    v4_1_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_5_EN_A = ap_const_logic_1;
    } else {
        v4_1_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_5_Rst_A() {
    v4_1_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_5_WEN_A() {
    v4_1_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_6_Addr_A() {
    v4_1_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_6_Addr_A_orig() {
    v4_1_6_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_6_Clk_A() {
    v4_1_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_6_Din_A() {
    v4_1_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_6_EN_A = ap_const_logic_1;
    } else {
        v4_1_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_6_Rst_A() {
    v4_1_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_6_WEN_A() {
    v4_1_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_7_Addr_A() {
    v4_1_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_7_Addr_A_orig() {
    v4_1_7_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_7_Clk_A() {
    v4_1_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_7_Din_A() {
    v4_1_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_7_EN_A = ap_const_logic_1;
    } else {
        v4_1_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_7_Rst_A() {
    v4_1_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_7_WEN_A() {
    v4_1_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_8_Addr_A() {
    v4_1_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_8_Addr_A_orig() {
    v4_1_8_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_8_Clk_A() {
    v4_1_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_8_Din_A() {
    v4_1_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_8_EN_A = ap_const_logic_1;
    } else {
        v4_1_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_8_Rst_A() {
    v4_1_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_8_WEN_A() {
    v4_1_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v4_1_9_Addr_A() {
    v4_1_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v4_1_9_Addr_A_orig() {
    v4_1_9_Addr_A_orig =  (sc_lv<32>) (sext_ln384_fu_7535_p1.read());
}

void kernel_2mm_asdse::thread_v4_1_9_Clk_A() {
    v4_1_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v4_1_9_Din_A() {
    v4_1_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v4_1_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()))) {
        v4_1_9_EN_A = ap_const_logic_1;
    } else {
        v4_1_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v4_1_9_Rst_A() {
    v4_1_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v4_1_9_WEN_A() {
    v4_1_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_0_Addr_A() {
    v5_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v5_0_Addr_A_orig() {
    v5_0_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_fu_8366_p1.read());
}

void kernel_2mm_asdse::thread_v5_0_Clk_A() {
    v5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_0_Din_A() {
    v5_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v5_0_EN_A = ap_const_logic_1;
    } else {
        v5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_0_Rst_A() {
    v5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_0_WEN_A() {
    v5_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_1_Addr_A() {
    v5_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v5_1_Addr_A_orig() {
    v5_1_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_reg_9001_pp1_iter7_reg.read());
}

void kernel_2mm_asdse::thread_v5_1_Clk_A() {
    v5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_1_Din_A() {
    v5_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_1_EN_A = ap_const_logic_1;
    } else {
        v5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_1_Rst_A() {
    v5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_1_WEN_A() {
    v5_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_2_Addr_A() {
    v5_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v5_2_Addr_A_orig() {
    v5_2_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_reg_9001_pp1_iter14_reg.read());
}

void kernel_2mm_asdse::thread_v5_2_Clk_A() {
    v5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_2_Din_A() {
    v5_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter15.read()))) {
        v5_2_EN_A = ap_const_logic_1;
    } else {
        v5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_2_Rst_A() {
    v5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_2_WEN_A() {
    v5_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_3_Addr_A() {
    v5_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v5_3_Addr_A_orig() {
    v5_3_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_reg_9001_pp1_iter21_reg.read());
}

void kernel_2mm_asdse::thread_v5_3_Clk_A() {
    v5_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_3_Din_A() {
    v5_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter22.read()))) {
        v5_3_EN_A = ap_const_logic_1;
    } else {
        v5_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_3_Rst_A() {
    v5_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_3_WEN_A() {
    v5_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_4_Addr_A() {
    v5_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v5_4_Addr_A_orig() {
    v5_4_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_reg_9001_pp1_iter28_reg.read());
}

void kernel_2mm_asdse::thread_v5_4_Clk_A() {
    v5_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_4_Din_A() {
    v5_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter29.read()))) {
        v5_4_EN_A = ap_const_logic_1;
    } else {
        v5_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_4_Rst_A() {
    v5_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_4_WEN_A() {
    v5_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_5_Addr_A() {
    v5_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v5_5_Addr_A_orig() {
    v5_5_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_reg_9001_pp1_iter35_reg.read());
}

void kernel_2mm_asdse::thread_v5_5_Clk_A() {
    v5_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_5_Din_A() {
    v5_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter36.read()))) {
        v5_5_EN_A = ap_const_logic_1;
    } else {
        v5_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_5_Rst_A() {
    v5_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_5_WEN_A() {
    v5_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_6_Addr_A() {
    v5_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v5_6_Addr_A_orig() {
    v5_6_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_reg_9001_pp1_iter42_reg.read());
}

void kernel_2mm_asdse::thread_v5_6_Clk_A() {
    v5_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_6_Din_A() {
    v5_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter43.read()))) {
        v5_6_EN_A = ap_const_logic_1;
    } else {
        v5_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_6_Rst_A() {
    v5_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_6_WEN_A() {
    v5_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_7_Addr_A() {
    v5_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v5_7_Addr_A_orig() {
    v5_7_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_reg_9001_pp1_iter49_reg.read());
}

void kernel_2mm_asdse::thread_v5_7_Clk_A() {
    v5_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_7_Din_A() {
    v5_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter50.read()))) {
        v5_7_EN_A = ap_const_logic_1;
    } else {
        v5_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_7_Rst_A() {
    v5_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_7_WEN_A() {
    v5_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_8_Addr_A() {
    v5_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

}


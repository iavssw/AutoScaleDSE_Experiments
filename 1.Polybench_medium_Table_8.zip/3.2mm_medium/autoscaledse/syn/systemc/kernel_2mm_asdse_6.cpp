#include "kernel_2mm_asdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_2mm_asdse::thread_v5_8_Addr_A_orig() {
    v5_8_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_reg_9001_pp1_iter56_reg.read());
}

void kernel_2mm_asdse::thread_v5_8_Clk_A() {
    v5_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_8_Din_A() {
    v5_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter57.read()))) {
        v5_8_EN_A = ap_const_logic_1;
    } else {
        v5_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_8_Rst_A() {
    v5_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_8_WEN_A() {
    v5_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v5_9_Addr_A() {
    v5_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v5_9_Addr_A_orig() {
    v5_9_Addr_A_orig =  (sc_lv<32>) (zext_ln712_3_reg_9001_pp1_iter63_reg.read());
}

void kernel_2mm_asdse::thread_v5_9_Clk_A() {
    v5_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v5_9_Din_A() {
    v5_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v5_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter64.read()))) {
        v5_9_EN_A = ap_const_logic_1;
    } else {
        v5_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v5_9_Rst_A() {
    v5_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v5_9_WEN_A() {
    v5_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_0_Addr_A() {
    v6_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_0_Addr_A_orig() {
    v6_0_Addr_A_orig =  (sc_lv<32>) (zext_ln708_1_fu_8370_p1.read());
}

void kernel_2mm_asdse::thread_v6_0_Addr_B() {
    v6_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_0_Addr_B_orig() {
    v6_0_Addr_B_orig =  (sc_lv<32>) (v6_0_addr_reg_9019_pp1_iter72_reg.read());
}

void kernel_2mm_asdse::thread_v6_0_Clk_A() {
    v6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_0_Clk_B() {
    v6_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_0_Din_A() {
    v6_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v6_0_Din_B() {
    v6_0_Din_B = v1066_reg_11033.read();
}

void kernel_2mm_asdse::thread_v6_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v6_0_EN_A = ap_const_logic_1;
    } else {
        v6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()))) {
        v6_0_EN_B = ap_const_logic_1;
    } else {
        v6_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_0_Rst_A() {
    v6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_0_Rst_B() {
    v6_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_0_WEN_A() {
    v6_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln704_reg_8833_pp1_iter72_reg.read()))) {
        v6_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v6_1_Addr_A() {
    v6_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_1_Addr_A_orig() {
    v6_1_Addr_A_orig =  (sc_lv<32>) (zext_ln708_1_fu_8370_p1.read());
}

void kernel_2mm_asdse::thread_v6_1_Addr_B() {
    v6_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_1_Addr_B_orig() {
    v6_1_Addr_B_orig =  (sc_lv<32>) (v6_1_addr_reg_9025_pp1_iter72_reg.read());
}

void kernel_2mm_asdse::thread_v6_1_Clk_A() {
    v6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_1_Clk_B() {
    v6_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_1_Din_A() {
    v6_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v6_1_Din_B() {
    v6_1_Din_B = v1073_reg_11038.read();
}

void kernel_2mm_asdse::thread_v6_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v6_1_EN_A = ap_const_logic_1;
    } else {
        v6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()))) {
        v6_1_EN_B = ap_const_logic_1;
    } else {
        v6_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_1_Rst_A() {
    v6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_1_Rst_B() {
    v6_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_1_WEN_A() {
    v6_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln704_reg_8833_pp1_iter72_reg.read()))) {
        v6_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v6_2_Addr_A() {
    v6_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_2_Addr_A_orig() {
    v6_2_Addr_A_orig =  (sc_lv<32>) (zext_ln708_1_fu_8370_p1.read());
}

void kernel_2mm_asdse::thread_v6_2_Addr_B() {
    v6_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_2_Addr_B_orig() {
    v6_2_Addr_B_orig =  (sc_lv<32>) (v6_2_addr_reg_9031_pp1_iter72_reg.read());
}

void kernel_2mm_asdse::thread_v6_2_Clk_A() {
    v6_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_2_Clk_B() {
    v6_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_2_Din_A() {
    v6_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v6_2_Din_B() {
    v6_2_Din_B = v1080_reg_11043.read();
}

void kernel_2mm_asdse::thread_v6_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v6_2_EN_A = ap_const_logic_1;
    } else {
        v6_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()))) {
        v6_2_EN_B = ap_const_logic_1;
    } else {
        v6_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_2_Rst_A() {
    v6_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_2_Rst_B() {
    v6_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_2_WEN_A() {
    v6_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln704_reg_8833_pp1_iter72_reg.read()))) {
        v6_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v6_3_Addr_A() {
    v6_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_3_Addr_A_orig() {
    v6_3_Addr_A_orig =  (sc_lv<32>) (zext_ln708_1_fu_8370_p1.read());
}

void kernel_2mm_asdse::thread_v6_3_Addr_B() {
    v6_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_3_Addr_B_orig() {
    v6_3_Addr_B_orig =  (sc_lv<32>) (v6_3_addr_reg_9037_pp1_iter72_reg.read());
}

void kernel_2mm_asdse::thread_v6_3_Clk_A() {
    v6_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_3_Clk_B() {
    v6_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_3_Din_A() {
    v6_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v6_3_Din_B() {
    v6_3_Din_B = v1087_reg_11048.read();
}

void kernel_2mm_asdse::thread_v6_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v6_3_EN_A = ap_const_logic_1;
    } else {
        v6_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()))) {
        v6_3_EN_B = ap_const_logic_1;
    } else {
        v6_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_3_Rst_A() {
    v6_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_3_Rst_B() {
    v6_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_3_WEN_A() {
    v6_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln704_reg_8833_pp1_iter72_reg.read()))) {
        v6_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v6_4_Addr_A() {
    v6_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_4_Addr_A_orig() {
    v6_4_Addr_A_orig =  (sc_lv<32>) (zext_ln708_1_fu_8370_p1.read());
}

void kernel_2mm_asdse::thread_v6_4_Addr_B() {
    v6_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_4_Addr_B_orig() {
    v6_4_Addr_B_orig =  (sc_lv<32>) (v6_4_addr_reg_9043_pp1_iter72_reg.read());
}

void kernel_2mm_asdse::thread_v6_4_Clk_A() {
    v6_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_4_Clk_B() {
    v6_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_4_Din_A() {
    v6_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v6_4_Din_B() {
    v6_4_Din_B = v1094_reg_11053.read();
}

void kernel_2mm_asdse::thread_v6_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v6_4_EN_A = ap_const_logic_1;
    } else {
        v6_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()))) {
        v6_4_EN_B = ap_const_logic_1;
    } else {
        v6_4_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_4_Rst_A() {
    v6_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_4_Rst_B() {
    v6_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_4_WEN_A() {
    v6_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln704_reg_8833_pp1_iter72_reg.read()))) {
        v6_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v6_5_Addr_A() {
    v6_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_5_Addr_A_orig() {
    v6_5_Addr_A_orig =  (sc_lv<32>) (zext_ln708_1_fu_8370_p1.read());
}

void kernel_2mm_asdse::thread_v6_5_Addr_B() {
    v6_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_5_Addr_B_orig() {
    v6_5_Addr_B_orig =  (sc_lv<32>) (v6_5_addr_reg_9049_pp1_iter72_reg.read());
}

void kernel_2mm_asdse::thread_v6_5_Clk_A() {
    v6_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_5_Clk_B() {
    v6_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_5_Din_A() {
    v6_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v6_5_Din_B() {
    v6_5_Din_B = v1101_reg_11058.read();
}

void kernel_2mm_asdse::thread_v6_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v6_5_EN_A = ap_const_logic_1;
    } else {
        v6_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()))) {
        v6_5_EN_B = ap_const_logic_1;
    } else {
        v6_5_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_5_Rst_A() {
    v6_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_5_Rst_B() {
    v6_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_5_WEN_A() {
    v6_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_5_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln704_reg_8833_pp1_iter72_reg.read()))) {
        v6_5_WEN_B = ap_const_lv4_F;
    } else {
        v6_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v6_6_Addr_A() {
    v6_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_6_Addr_A_orig() {
    v6_6_Addr_A_orig =  (sc_lv<32>) (zext_ln708_1_fu_8370_p1.read());
}

void kernel_2mm_asdse::thread_v6_6_Addr_B() {
    v6_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_6_Addr_B_orig() {
    v6_6_Addr_B_orig =  (sc_lv<32>) (v6_6_addr_reg_9055_pp1_iter72_reg.read());
}

void kernel_2mm_asdse::thread_v6_6_Clk_A() {
    v6_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_6_Clk_B() {
    v6_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_6_Din_A() {
    v6_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v6_6_Din_B() {
    v6_6_Din_B = v1108_reg_11063.read();
}

void kernel_2mm_asdse::thread_v6_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v6_6_EN_A = ap_const_logic_1;
    } else {
        v6_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()))) {
        v6_6_EN_B = ap_const_logic_1;
    } else {
        v6_6_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_6_Rst_A() {
    v6_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_6_Rst_B() {
    v6_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_6_WEN_A() {
    v6_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_6_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln704_reg_8833_pp1_iter72_reg.read()))) {
        v6_6_WEN_B = ap_const_lv4_F;
    } else {
        v6_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v6_7_Addr_A() {
    v6_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_7_Addr_A_orig() {
    v6_7_Addr_A_orig =  (sc_lv<32>) (zext_ln708_1_fu_8370_p1.read());
}

void kernel_2mm_asdse::thread_v6_7_Addr_B() {
    v6_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_7_Addr_B_orig() {
    v6_7_Addr_B_orig =  (sc_lv<32>) (v6_7_addr_reg_9061_pp1_iter72_reg.read());
}

void kernel_2mm_asdse::thread_v6_7_Clk_A() {
    v6_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_7_Clk_B() {
    v6_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_7_Din_A() {
    v6_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v6_7_Din_B() {
    v6_7_Din_B = v1115_reg_11068.read();
}

void kernel_2mm_asdse::thread_v6_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v6_7_EN_A = ap_const_logic_1;
    } else {
        v6_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()))) {
        v6_7_EN_B = ap_const_logic_1;
    } else {
        v6_7_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_7_Rst_A() {
    v6_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_7_Rst_B() {
    v6_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_7_WEN_A() {
    v6_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_7_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln704_reg_8833_pp1_iter72_reg.read()))) {
        v6_7_WEN_B = ap_const_lv4_F;
    } else {
        v6_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v6_8_Addr_A() {
    v6_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_8_Addr_A_orig() {
    v6_8_Addr_A_orig =  (sc_lv<32>) (zext_ln708_1_fu_8370_p1.read());
}

void kernel_2mm_asdse::thread_v6_8_Addr_B() {
    v6_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_asdse::thread_v6_8_Addr_B_orig() {
    v6_8_Addr_B_orig =  (sc_lv<32>) (v6_8_addr_reg_9067_pp1_iter72_reg.read());
}

void kernel_2mm_asdse::thread_v6_8_Clk_A() {
    v6_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_8_Clk_B() {
    v6_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_asdse::thread_v6_8_Din_A() {
    v6_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_asdse::thread_v6_8_Din_B() {
    v6_8_Din_B = v1122_reg_11073.read();
}

void kernel_2mm_asdse::thread_v6_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()))) {
        v6_8_EN_A = ap_const_logic_1;
    } else {
        v6_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()))) {
        v6_8_EN_B = ap_const_logic_1;
    } else {
        v6_8_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_asdse::thread_v6_8_Rst_A() {
    v6_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_8_Rst_B() {
    v6_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_asdse::thread_v6_8_WEN_A() {
    v6_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_asdse::thread_v6_8_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp1_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter73.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln704_reg_8833_pp1_iter72_reg.read()))) {
        v6_8_WEN_B = ap_const_lv4_F;
    } else {
        v6_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_asdse::thread_v7_fu_7502_p2() {
    v7_fu_7502_p2 = (!ap_const_lv7_1.is_01() || !ap_phi_mux_v7_0_phi_fu_5341_p4.read().is_01())? sc_lv<7>(): (sc_biguint<7>(ap_const_lv7_1) + sc_biguint<7>(ap_phi_mux_v7_0_phi_fu_5341_p4.read()));
}

void kernel_2mm_asdse::thread_v8_fu_7440_p2() {
    v8_fu_7440_p2 = (!ap_const_lv6_1.is_01() || !select_ln62_fu_7414_p3.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_1) + sc_biguint<6>(select_ln62_fu_7414_p3.read()));
}

void kernel_2mm_asdse::thread_v9_fu_7482_p2() {
    v9_fu_7482_p2 = (!select_ln58_fu_7452_p3.read().is_01() || !ap_const_lv5_1.is_01())? sc_lv<5>(): (sc_biguint<5>(select_ln58_fu_7452_p3.read()) + sc_biguint<5>(ap_const_lv5_1));
}

void kernel_2mm_asdse::thread_xor_ln62_fu_7422_p2() {
    xor_ln62_fu_7422_p2 = (icmp_ln58_fu_7408_p2.read() ^ ap_const_lv1_1);
}

void kernel_2mm_asdse::thread_xor_ln711_fu_8273_p2() {
    xor_ln711_fu_8273_p2 = (icmp_ln705_fu_8251_p2.read() ^ ap_const_lv1_1);
}

void kernel_2mm_asdse::thread_zext_ln382_1_fu_7522_p1() {
    zext_ln382_1_fu_7522_p1 = esl_zext<64,13>(grp_fu_8382_p3.read());
}

void kernel_2mm_asdse::thread_zext_ln61_3_fu_7858_p1() {
    zext_ln61_3_fu_7858_p1 = esl_zext<10,5>(select_ln58_reg_8602_pp0_iter12_reg.read());
}

void kernel_2mm_asdse::thread_zext_ln708_1_fu_8370_p1() {
    zext_ln708_1_fu_8370_p1 = esl_zext<64,13>(grp_fu_8454_p3.read());
}

void kernel_2mm_asdse::thread_zext_ln712_2_fu_8363_p1() {
    zext_ln712_2_fu_8363_p1 = esl_zext<13,8>(select_ln711_2_reg_8849.read());
}

void kernel_2mm_asdse::thread_zext_ln712_3_fu_8366_p1() {
    zext_ln712_3_fu_8366_p1 = esl_zext<64,13>(grp_fu_8436_p3.read());
}

}


#include "kernel_bicg_asdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_bicg_asdse::thread_v5_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_13_EN_A = ap_const_logic_1;
    } else {
        v5_13_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_13_Rst_A() {
    v5_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_13_WEN_A() {
    v5_13_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_14_Addr_A() {
    v5_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_14_Addr_A_orig() {
    v5_14_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_14_Clk_A() {
    v5_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_14_Din_A() {
    v5_14_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_14_EN_A = ap_const_logic_1;
    } else {
        v5_14_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_14_Rst_A() {
    v5_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_14_WEN_A() {
    v5_14_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_15_Addr_A() {
    v5_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_15_Addr_A_orig() {
    v5_15_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_15_Clk_A() {
    v5_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_15_Din_A() {
    v5_15_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_15_EN_A = ap_const_logic_1;
    } else {
        v5_15_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_15_Rst_A() {
    v5_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_15_WEN_A() {
    v5_15_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_16_Addr_A() {
    v5_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_16_Addr_A_orig() {
    v5_16_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_16_Clk_A() {
    v5_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_16_Din_A() {
    v5_16_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_16_EN_A = ap_const_logic_1;
    } else {
        v5_16_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_16_Rst_A() {
    v5_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_16_WEN_A() {
    v5_16_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_17_Addr_A() {
    v5_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_17_Addr_A_orig() {
    v5_17_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_17_Clk_A() {
    v5_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_17_Din_A() {
    v5_17_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_17_EN_A = ap_const_logic_1;
    } else {
        v5_17_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_17_Rst_A() {
    v5_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_17_WEN_A() {
    v5_17_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_18_Addr_A() {
    v5_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_18_Addr_A_orig() {
    v5_18_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_18_Clk_A() {
    v5_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_18_Din_A() {
    v5_18_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_18_EN_A = ap_const_logic_1;
    } else {
        v5_18_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_18_Rst_A() {
    v5_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_18_WEN_A() {
    v5_18_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_19_Addr_A() {
    v5_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_19_Addr_A_orig() {
    v5_19_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_19_Clk_A() {
    v5_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_19_Din_A() {
    v5_19_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_19_EN_A = ap_const_logic_1;
    } else {
        v5_19_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_19_Rst_A() {
    v5_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_19_WEN_A() {
    v5_19_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_1_Addr_A() {
    v5_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_1_Addr_A_orig() {
    v5_1_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_1_Clk_A() {
    v5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_1_Din_A() {
    v5_1_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_1_EN_A = ap_const_logic_1;
    } else {
        v5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_1_Rst_A() {
    v5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_1_WEN_A() {
    v5_1_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_20_Addr_A() {
    v5_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_20_Addr_A_orig() {
    v5_20_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_20_Clk_A() {
    v5_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_20_Din_A() {
    v5_20_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_20_EN_A = ap_const_logic_1;
    } else {
        v5_20_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_20_Rst_A() {
    v5_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_20_WEN_A() {
    v5_20_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_21_Addr_A() {
    v5_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_21_Addr_A_orig() {
    v5_21_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_21_Clk_A() {
    v5_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_21_Din_A() {
    v5_21_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_21_EN_A = ap_const_logic_1;
    } else {
        v5_21_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_21_Rst_A() {
    v5_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_21_WEN_A() {
    v5_21_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_22_Addr_A() {
    v5_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_22_Addr_A_orig() {
    v5_22_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_22_Clk_A() {
    v5_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_22_Din_A() {
    v5_22_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_22_EN_A = ap_const_logic_1;
    } else {
        v5_22_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_22_Rst_A() {
    v5_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_22_WEN_A() {
    v5_22_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_23_Addr_A() {
    v5_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_23_Addr_A_orig() {
    v5_23_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_23_Clk_A() {
    v5_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_23_Din_A() {
    v5_23_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_23_EN_A = ap_const_logic_1;
    } else {
        v5_23_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_23_Rst_A() {
    v5_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_23_WEN_A() {
    v5_23_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_24_Addr_A() {
    v5_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_24_Addr_A_orig() {
    v5_24_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_24_Clk_A() {
    v5_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_24_Din_A() {
    v5_24_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_24_EN_A = ap_const_logic_1;
    } else {
        v5_24_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_24_Rst_A() {
    v5_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_24_WEN_A() {
    v5_24_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_25_Addr_A() {
    v5_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_25_Addr_A_orig() {
    v5_25_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_25_Clk_A() {
    v5_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_25_Din_A() {
    v5_25_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_25_EN_A = ap_const_logic_1;
    } else {
        v5_25_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_25_Rst_A() {
    v5_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_25_WEN_A() {
    v5_25_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_26_Addr_A() {
    v5_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_26_Addr_A_orig() {
    v5_26_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_26_Clk_A() {
    v5_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_26_Din_A() {
    v5_26_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_26_EN_A = ap_const_logic_1;
    } else {
        v5_26_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_26_Rst_A() {
    v5_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_26_WEN_A() {
    v5_26_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_27_Addr_A() {
    v5_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_27_Addr_A_orig() {
    v5_27_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_27_Clk_A() {
    v5_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_27_Din_A() {
    v5_27_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_27_EN_A = ap_const_logic_1;
    } else {
        v5_27_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_27_Rst_A() {
    v5_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_27_WEN_A() {
    v5_27_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_28_Addr_A() {
    v5_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_28_Addr_A_orig() {
    v5_28_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_28_Clk_A() {
    v5_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_28_Din_A() {
    v5_28_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_28_EN_A = ap_const_logic_1;
    } else {
        v5_28_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_28_Rst_A() {
    v5_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_28_WEN_A() {
    v5_28_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_29_Addr_A() {
    v5_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_29_Addr_A_orig() {
    v5_29_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_29_Clk_A() {
    v5_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_29_Din_A() {
    v5_29_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_29_EN_A = ap_const_logic_1;
    } else {
        v5_29_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_29_Rst_A() {
    v5_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_29_WEN_A() {
    v5_29_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_2_Addr_A() {
    v5_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_2_Addr_A_orig() {
    v5_2_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_2_Clk_A() {
    v5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_2_Din_A() {
    v5_2_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_2_EN_A = ap_const_logic_1;
    } else {
        v5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_2_Rst_A() {
    v5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_2_WEN_A() {
    v5_2_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_30_Addr_A() {
    v5_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_30_Addr_A_orig() {
    v5_30_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_30_Clk_A() {
    v5_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_30_Din_A() {
    v5_30_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_30_EN_A = ap_const_logic_1;
    } else {
        v5_30_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_30_Rst_A() {
    v5_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_30_WEN_A() {
    v5_30_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_31_Addr_A() {
    v5_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_31_Addr_A_orig() {
    v5_31_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_31_Clk_A() {
    v5_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_31_Din_A() {
    v5_31_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_31_EN_A = ap_const_logic_1;
    } else {
        v5_31_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_31_Rst_A() {
    v5_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_31_WEN_A() {
    v5_31_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_32_Addr_A() {
    v5_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_32_Addr_A_orig() {
    v5_32_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_32_Clk_A() {
    v5_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_32_Din_A() {
    v5_32_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_32_EN_A = ap_const_logic_1;
    } else {
        v5_32_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_32_Rst_A() {
    v5_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_32_WEN_A() {
    v5_32_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_33_Addr_A() {
    v5_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_33_Addr_A_orig() {
    v5_33_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_33_Clk_A() {
    v5_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_33_Din_A() {
    v5_33_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_33_EN_A = ap_const_logic_1;
    } else {
        v5_33_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_33_Rst_A() {
    v5_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_33_WEN_A() {
    v5_33_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_34_Addr_A() {
    v5_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_34_Addr_A_orig() {
    v5_34_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_34_Clk_A() {
    v5_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_34_Din_A() {
    v5_34_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_34_EN_A = ap_const_logic_1;
    } else {
        v5_34_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_34_Rst_A() {
    v5_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_34_WEN_A() {
    v5_34_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_35_Addr_A() {
    v5_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_35_Addr_A_orig() {
    v5_35_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_35_Clk_A() {
    v5_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_35_Din_A() {
    v5_35_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_35_EN_A = ap_const_logic_1;
    } else {
        v5_35_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_35_Rst_A() {
    v5_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_35_WEN_A() {
    v5_35_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_36_Addr_A() {
    v5_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_36_Addr_A_orig() {
    v5_36_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_36_Clk_A() {
    v5_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_36_Din_A() {
    v5_36_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_36_EN_A = ap_const_logic_1;
    } else {
        v5_36_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_36_Rst_A() {
    v5_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_36_WEN_A() {
    v5_36_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_37_Addr_A() {
    v5_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_37_Addr_A_orig() {
    v5_37_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_37_Clk_A() {
    v5_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_37_Din_A() {
    v5_37_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_37_EN_A = ap_const_logic_1;
    } else {
        v5_37_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_37_Rst_A() {
    v5_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_37_WEN_A() {
    v5_37_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_38_Addr_A() {
    v5_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_38_Addr_A_orig() {
    v5_38_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_38_Clk_A() {
    v5_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_38_Din_A() {
    v5_38_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_38_EN_A = ap_const_logic_1;
    } else {
        v5_38_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_38_Rst_A() {
    v5_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_38_WEN_A() {
    v5_38_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_39_Addr_A() {
    v5_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_39_Addr_A_orig() {
    v5_39_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_39_Clk_A() {
    v5_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_39_Din_A() {
    v5_39_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_39_EN_A = ap_const_logic_1;
    } else {
        v5_39_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_39_Rst_A() {
    v5_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_39_WEN_A() {
    v5_39_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_3_Addr_A() {
    v5_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_3_Addr_A_orig() {
    v5_3_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_3_Clk_A() {
    v5_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_3_Din_A() {
    v5_3_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_3_EN_A = ap_const_logic_1;
    } else {
        v5_3_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_3_Rst_A() {
    v5_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_3_WEN_A() {
    v5_3_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_40_Addr_A() {
    v5_40_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_40_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_40_Addr_A_orig() {
    v5_40_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_40_Clk_A() {
    v5_40_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_40_Din_A() {
    v5_40_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_40_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_40_EN_A = ap_const_logic_1;
    } else {
        v5_40_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_40_Rst_A() {
    v5_40_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_40_WEN_A() {
    v5_40_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_41_Addr_A() {
    v5_41_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_41_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_41_Addr_A_orig() {
    v5_41_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_41_Clk_A() {
    v5_41_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_41_Din_A() {
    v5_41_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_41_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_41_EN_A = ap_const_logic_1;
    } else {
        v5_41_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_41_Rst_A() {
    v5_41_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_41_WEN_A() {
    v5_41_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_42_Addr_A() {
    v5_42_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_42_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_42_Addr_A_orig() {
    v5_42_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_42_Clk_A() {
    v5_42_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_42_Din_A() {
    v5_42_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_42_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_42_EN_A = ap_const_logic_1;
    } else {
        v5_42_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_42_Rst_A() {
    v5_42_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_42_WEN_A() {
    v5_42_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_43_Addr_A() {
    v5_43_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_43_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_43_Addr_A_orig() {
    v5_43_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_43_Clk_A() {
    v5_43_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_43_Din_A() {
    v5_43_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_43_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_43_EN_A = ap_const_logic_1;
    } else {
        v5_43_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_43_Rst_A() {
    v5_43_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_43_WEN_A() {
    v5_43_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_44_Addr_A() {
    v5_44_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_44_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_44_Addr_A_orig() {
    v5_44_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_44_Clk_A() {
    v5_44_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_44_Din_A() {
    v5_44_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_44_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_44_EN_A = ap_const_logic_1;
    } else {
        v5_44_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_44_Rst_A() {
    v5_44_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_44_WEN_A() {
    v5_44_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_45_Addr_A() {
    v5_45_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_45_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_45_Addr_A_orig() {
    v5_45_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_45_Clk_A() {
    v5_45_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_45_Din_A() {
    v5_45_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_45_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_45_EN_A = ap_const_logic_1;
    } else {
        v5_45_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_45_Rst_A() {
    v5_45_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_45_WEN_A() {
    v5_45_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_46_Addr_A() {
    v5_46_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_46_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_46_Addr_A_orig() {
    v5_46_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_46_Clk_A() {
    v5_46_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_46_Din_A() {
    v5_46_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_46_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_46_EN_A = ap_const_logic_1;
    } else {
        v5_46_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_46_Rst_A() {
    v5_46_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_46_WEN_A() {
    v5_46_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_47_Addr_A() {
    v5_47_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_47_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_47_Addr_A_orig() {
    v5_47_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_47_Clk_A() {
    v5_47_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_47_Din_A() {
    v5_47_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_47_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_47_EN_A = ap_const_logic_1;
    } else {
        v5_47_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_47_Rst_A() {
    v5_47_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_47_WEN_A() {
    v5_47_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_48_Addr_A() {
    v5_48_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_48_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_48_Addr_A_orig() {
    v5_48_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_48_Clk_A() {
    v5_48_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_48_Din_A() {
    v5_48_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_48_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_48_EN_A = ap_const_logic_1;
    } else {
        v5_48_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_48_Rst_A() {
    v5_48_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_48_WEN_A() {
    v5_48_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_49_Addr_A() {
    v5_49_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_49_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_49_Addr_A_orig() {
    v5_49_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_49_Clk_A() {
    v5_49_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_49_Din_A() {
    v5_49_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_49_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_49_EN_A = ap_const_logic_1;
    } else {
        v5_49_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_49_Rst_A() {
    v5_49_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_49_WEN_A() {
    v5_49_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_4_Addr_A() {
    v5_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_4_Addr_A_orig() {
    v5_4_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_4_Clk_A() {
    v5_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_4_Din_A() {
    v5_4_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_4_EN_A = ap_const_logic_1;
    } else {
        v5_4_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_4_Rst_A() {
    v5_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_4_WEN_A() {
    v5_4_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_50_Addr_A() {
    v5_50_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_50_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_50_Addr_A_orig() {
    v5_50_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_50_Clk_A() {
    v5_50_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_50_Din_A() {
    v5_50_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_50_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_50_EN_A = ap_const_logic_1;
    } else {
        v5_50_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_50_Rst_A() {
    v5_50_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_50_WEN_A() {
    v5_50_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_51_Addr_A() {
    v5_51_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_51_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_51_Addr_A_orig() {
    v5_51_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_51_Clk_A() {
    v5_51_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_51_Din_A() {
    v5_51_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_51_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_51_EN_A = ap_const_logic_1;
    } else {
        v5_51_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_51_Rst_A() {
    v5_51_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_51_WEN_A() {
    v5_51_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_52_Addr_A() {
    v5_52_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_52_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_52_Addr_A_orig() {
    v5_52_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_52_Clk_A() {
    v5_52_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_52_Din_A() {
    v5_52_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_52_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_52_EN_A = ap_const_logic_1;
    } else {
        v5_52_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_52_Rst_A() {
    v5_52_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_52_WEN_A() {
    v5_52_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_53_Addr_A() {
    v5_53_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_53_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_53_Addr_A_orig() {
    v5_53_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_53_Clk_A() {
    v5_53_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_53_Din_A() {
    v5_53_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_53_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_53_EN_A = ap_const_logic_1;
    } else {
        v5_53_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_53_Rst_A() {
    v5_53_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_53_WEN_A() {
    v5_53_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_54_Addr_A() {
    v5_54_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_54_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_54_Addr_A_orig() {
    v5_54_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_54_Clk_A() {
    v5_54_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_54_Din_A() {
    v5_54_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_54_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_54_EN_A = ap_const_logic_1;
    } else {
        v5_54_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_54_Rst_A() {
    v5_54_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_54_WEN_A() {
    v5_54_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_55_Addr_A() {
    v5_55_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_55_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_55_Addr_A_orig() {
    v5_55_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_55_Clk_A() {
    v5_55_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_55_Din_A() {
    v5_55_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_55_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_55_EN_A = ap_const_logic_1;
    } else {
        v5_55_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_55_Rst_A() {
    v5_55_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_55_WEN_A() {
    v5_55_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_56_Addr_A() {
    v5_56_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_56_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_56_Addr_A_orig() {
    v5_56_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_56_Clk_A() {
    v5_56_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_56_Din_A() {
    v5_56_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_56_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_56_EN_A = ap_const_logic_1;
    } else {
        v5_56_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_56_Rst_A() {
    v5_56_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_56_WEN_A() {
    v5_56_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_57_Addr_A() {
    v5_57_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_57_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_57_Addr_A_orig() {
    v5_57_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_57_Clk_A() {
    v5_57_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_57_Din_A() {
    v5_57_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_57_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_57_EN_A = ap_const_logic_1;
    } else {
        v5_57_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_57_Rst_A() {
    v5_57_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_57_WEN_A() {
    v5_57_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_58_Addr_A() {
    v5_58_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_58_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_58_Addr_A_orig() {
    v5_58_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_58_Clk_A() {
    v5_58_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_58_Din_A() {
    v5_58_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_58_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_58_EN_A = ap_const_logic_1;
    } else {
        v5_58_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_58_Rst_A() {
    v5_58_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_58_WEN_A() {
    v5_58_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_59_Addr_A() {
    v5_59_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_59_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_59_Addr_A_orig() {
    v5_59_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_59_Clk_A() {
    v5_59_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_59_Din_A() {
    v5_59_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_59_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_59_EN_A = ap_const_logic_1;
    } else {
        v5_59_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_59_Rst_A() {
    v5_59_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_59_WEN_A() {
    v5_59_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_5_Addr_A() {
    v5_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_5_Addr_A_orig() {
    v5_5_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_5_Clk_A() {
    v5_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_5_Din_A() {
    v5_5_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_5_EN_A = ap_const_logic_1;
    } else {
        v5_5_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_5_Rst_A() {
    v5_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_5_WEN_A() {
    v5_5_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_60_Addr_A() {
    v5_60_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_60_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_60_Addr_A_orig() {
    v5_60_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_60_Clk_A() {
    v5_60_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_60_Din_A() {
    v5_60_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_60_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_60_EN_A = ap_const_logic_1;
    } else {
        v5_60_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_60_Rst_A() {
    v5_60_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_60_WEN_A() {
    v5_60_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_61_Addr_A() {
    v5_61_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_61_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_61_Addr_A_orig() {
    v5_61_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_61_Clk_A() {
    v5_61_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_61_Din_A() {
    v5_61_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_61_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_61_EN_A = ap_const_logic_1;
    } else {
        v5_61_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_61_Rst_A() {
    v5_61_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_61_WEN_A() {
    v5_61_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_62_Addr_A() {
    v5_62_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_62_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_62_Addr_A_orig() {
    v5_62_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_62_Clk_A() {
    v5_62_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_62_Din_A() {
    v5_62_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_62_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_62_EN_A = ap_const_logic_1;
    } else {
        v5_62_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_62_Rst_A() {
    v5_62_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_62_WEN_A() {
    v5_62_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_63_Addr_A() {
    v5_63_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_63_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_63_Addr_A_orig() {
    v5_63_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_63_Clk_A() {
    v5_63_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_63_Din_A() {
    v5_63_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_63_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_63_EN_A = ap_const_logic_1;
    } else {
        v5_63_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_63_Rst_A() {
    v5_63_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_63_WEN_A() {
    v5_63_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_64_Addr_A() {
    v5_64_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_64_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_64_Addr_A_orig() {
    v5_64_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_64_Clk_A() {
    v5_64_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_64_Din_A() {
    v5_64_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_64_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_64_EN_A = ap_const_logic_1;
    } else {
        v5_64_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_64_Rst_A() {
    v5_64_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_64_WEN_A() {
    v5_64_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_6_Addr_A() {
    v5_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_6_Addr_A_orig() {
    v5_6_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_6_Clk_A() {
    v5_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_6_Din_A() {
    v5_6_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_6_EN_A = ap_const_logic_1;
    } else {
        v5_6_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_6_Rst_A() {
    v5_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_6_WEN_A() {
    v5_6_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_7_Addr_A() {
    v5_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_7_Addr_A_orig() {
    v5_7_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_7_Clk_A() {
    v5_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_7_Din_A() {
    v5_7_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_7_EN_A = ap_const_logic_1;
    } else {
        v5_7_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_7_Rst_A() {
    v5_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_7_WEN_A() {
    v5_7_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_8_Addr_A() {
    v5_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_8_Addr_A_orig() {
    v5_8_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_8_Clk_A() {
    v5_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_8_Din_A() {
    v5_8_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_8_EN_A = ap_const_logic_1;
    } else {
        v5_8_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_8_Rst_A() {
    v5_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_8_WEN_A() {
    v5_8_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_9_Addr_A() {
    v5_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_9_Addr_A_orig() {
    v5_9_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_9_Clk_A() {
    v5_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_9_Din_A() {
    v5_9_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_9_EN_A = ap_const_logic_1;
    } else {
        v5_9_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_9_Rst_A() {
    v5_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_9_WEN_A() {
    v5_9_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v6_0_Addr_A() {
    v6_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v6_0_Addr_A_orig() {
    v6_0_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v6_0_Clk_A() {
    v6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v6_0_Din_A() {
    v6_0_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v6_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_0_EN_A = ap_const_logic_1;
    } else {
        v6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v6_0_Rst_A() {
    v6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v6_0_WEN_A() {
    v6_0_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v6_1_Addr_A() {
    v6_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v6_1_Addr_A_orig() {
    v6_1_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v6_1_Clk_A() {
    v6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v6_1_Din_A() {
    v6_1_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v6_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_1_EN_A = ap_const_logic_1;
    } else {
        v6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v6_1_Rst_A() {
    v6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v6_1_WEN_A() {
    v6_1_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v6_2_Addr_A() {
    v6_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v6_2_Addr_A_orig() {
    v6_2_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v6_2_Clk_A() {
    v6_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v6_2_Din_A() {
    v6_2_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v6_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_2_EN_A = ap_const_logic_1;
    } else {
        v6_2_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v6_2_Rst_A() {
    v6_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v6_2_WEN_A() {
    v6_2_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v6_3_Addr_A() {
    v6_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v6_3_Addr_A_orig() {
    v6_3_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v6_3_Clk_A() {
    v6_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v6_3_Din_A() {
    v6_3_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v6_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_3_EN_A = ap_const_logic_1;
    } else {
        v6_3_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v6_3_Rst_A() {
    v6_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v6_3_WEN_A() {
    v6_3_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v6_4_Addr_A() {
    v6_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v6_4_Addr_A_orig() {
    v6_4_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v6_4_Clk_A() {
    v6_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v6_4_Din_A() {
    v6_4_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v6_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_4_EN_A = ap_const_logic_1;
    } else {
        v6_4_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v6_4_Rst_A() {
    v6_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v6_4_WEN_A() {
    v6_4_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v7_fu_10208_p2() {
    v7_fu_10208_p2 = (!v7_0_reg_7922.read().is_01() || !ap_const_lv3_1.is_01())? sc_lv<3>(): (sc_biguint<3>(v7_0_reg_7922.read()) + sc_biguint<3>(ap_const_lv3_1));
}

void kernel_bicg_asdse::thread_v8_fu_10327_p2() {
    v8_fu_10327_p2 = (!ap_phi_mux_v8_0_phi_fu_7948_p4.read().is_01() || !ap_const_lv3_1.is_01())? sc_lv<3>(): (sc_biguint<3>(ap_phi_mux_v8_0_phi_fu_7948_p4.read()) + sc_biguint<3>(ap_const_lv3_1));
}

void kernel_bicg_asdse::thread_v9_fu_10843_p2() {
    v9_fu_10843_p2 = (!select_ln125_fu_10339_p3.read().is_01() || !ap_const_lv7_1.is_01())? sc_lv<7>(): (sc_biguint<7>(select_ln125_fu_10339_p3.read()) + sc_biguint<7>(ap_const_lv7_1));
}

void kernel_bicg_asdse::thread_zext_ln125_1_fu_10347_p1() {
    zext_ln125_1_fu_10347_p1 = esl_zext<4,3>(v8_fu_10327_p2.read());
}

void kernel_bicg_asdse::thread_zext_ln125_2_fu_10395_p1() {
    zext_ln125_2_fu_10395_p1 = esl_zext<64,3>(select_ln125_2_fu_10387_p3.read());
}

void kernel_bicg_asdse::thread_zext_ln125_fu_10283_p1() {
    zext_ln125_fu_10283_p1 = esl_zext<4,3>(ap_phi_mux_v8_0_phi_fu_7948_p4.read());
}

void kernel_bicg_asdse::thread_zext_ln126_fu_10464_p1() {
    zext_ln126_fu_10464_p1 = esl_zext<10,3>(select_ln125_2_fu_10387_p3.read());
}

void kernel_bicg_asdse::thread_zext_ln128_fu_10468_p1() {
    zext_ln128_fu_10468_p1 = esl_zext<64,7>(select_ln125_fu_10339_p3.read());
}

void kernel_bicg_asdse::thread_zext_ln129_1_fu_10359_p1() {
    zext_ln129_1_fu_10359_p1 = esl_zext<10,9>(shl_ln129_mid1_fu_10351_p3.read());
}

void kernel_bicg_asdse::thread_zext_ln129_2_fu_10498_p1() {
    zext_ln129_2_fu_10498_p1 = esl_zext<10,8>(tmp_3_fu_10490_p3.read());
}

void kernel_bicg_asdse::thread_zext_ln129_fu_10295_p1() {
    zext_ln129_fu_10295_p1 = esl_zext<10,9>(shl_ln_fu_10287_p3.read());
}

void kernel_bicg_asdse::thread_zext_ln59_fu_10214_p1() {
    zext_ln59_fu_10214_p1 = esl_zext<64,3>(v7_0_reg_7922.read());
}

}


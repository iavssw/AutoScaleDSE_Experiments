#include "kernel_bicg_asdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_bicg_asdse::thread_v3_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_0_WEN_B = ap_const_lv4_F;
    } else {
        v3_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_10_Addr_A() {
    v3_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_10_Addr_A_orig() {
    v3_10_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_10_Addr_B() {
    v3_10_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_10_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_10_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_10_Addr_B_orig =  (sc_lv<32>) (v3_10_addr_1_reg_19549.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_10_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_10_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_10_Clk_A() {
    v3_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_10_Clk_B() {
    v3_10_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_10_Din_A() {
    v3_10_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_10_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_10_Din_B = reg_8912.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_10_Din_B = ap_const_lv32_0;
    } else {
        v3_10_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_10_EN_A = ap_const_logic_1;
    } else {
        v3_10_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_10_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_10_EN_B = ap_const_logic_1;
    } else {
        v3_10_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_10_Rst_A() {
    v3_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_10_Rst_B() {
    v3_10_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_10_WEN_A() {
    v3_10_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_10_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_10_WEN_B = ap_const_lv4_F;
    } else {
        v3_10_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_11_Addr_A() {
    v3_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_11_Addr_A_orig() {
    v3_11_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_11_Addr_B() {
    v3_11_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_11_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_11_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_11_Addr_B_orig =  (sc_lv<32>) (v3_11_addr_1_reg_19555.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_11_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_11_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_11_Clk_A() {
    v3_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_11_Clk_B() {
    v3_11_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_11_Din_A() {
    v3_11_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_11_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_11_Din_B = reg_8918.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_11_Din_B = ap_const_lv32_0;
    } else {
        v3_11_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_11_EN_A = ap_const_logic_1;
    } else {
        v3_11_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_11_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_11_EN_B = ap_const_logic_1;
    } else {
        v3_11_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_11_Rst_A() {
    v3_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_11_Rst_B() {
    v3_11_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_11_WEN_A() {
    v3_11_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_11_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_11_WEN_B = ap_const_lv4_F;
    } else {
        v3_11_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_12_Addr_A() {
    v3_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_12_Addr_A_orig() {
    v3_12_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_12_Addr_B() {
    v3_12_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_12_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_12_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_12_Addr_B_orig =  (sc_lv<32>) (v3_12_addr_1_reg_19561.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_12_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_12_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_12_Clk_A() {
    v3_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_12_Clk_B() {
    v3_12_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_12_Din_A() {
    v3_12_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_12_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_12_Din_B = reg_8924.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_12_Din_B = ap_const_lv32_0;
    } else {
        v3_12_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_12_EN_A = ap_const_logic_1;
    } else {
        v3_12_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_12_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_12_EN_B = ap_const_logic_1;
    } else {
        v3_12_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_12_Rst_A() {
    v3_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_12_Rst_B() {
    v3_12_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_12_WEN_A() {
    v3_12_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_12_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_12_WEN_B = ap_const_lv4_F;
    } else {
        v3_12_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_13_Addr_A() {
    v3_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_13_Addr_A_orig() {
    v3_13_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_13_Addr_B() {
    v3_13_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_13_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_13_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_13_Addr_B_orig =  (sc_lv<32>) (v3_13_addr_1_reg_19567.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_13_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_13_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_13_Clk_A() {
    v3_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_13_Clk_B() {
    v3_13_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_13_Din_A() {
    v3_13_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_13_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_13_Din_B = reg_8930.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_13_Din_B = ap_const_lv32_0;
    } else {
        v3_13_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_13_EN_A = ap_const_logic_1;
    } else {
        v3_13_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_13_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_13_EN_B = ap_const_logic_1;
    } else {
        v3_13_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_13_Rst_A() {
    v3_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_13_Rst_B() {
    v3_13_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_13_WEN_A() {
    v3_13_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_13_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_13_WEN_B = ap_const_lv4_F;
    } else {
        v3_13_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_14_Addr_A() {
    v3_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_14_Addr_A_orig() {
    v3_14_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_14_Addr_B() {
    v3_14_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_14_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_14_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_14_Addr_B_orig =  (sc_lv<32>) (v3_14_addr_1_reg_19648.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_14_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_14_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_14_Clk_A() {
    v3_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_14_Clk_B() {
    v3_14_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_14_Din_A() {
    v3_14_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_14_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_14_Din_B = reg_8966.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_14_Din_B = ap_const_lv32_0;
    } else {
        v3_14_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_14_EN_A = ap_const_logic_1;
    } else {
        v3_14_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_14_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_14_EN_B = ap_const_logic_1;
    } else {
        v3_14_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_14_Rst_A() {
    v3_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_14_Rst_B() {
    v3_14_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_14_WEN_A() {
    v3_14_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_14_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_14_WEN_B = ap_const_lv4_F;
    } else {
        v3_14_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_15_Addr_A() {
    v3_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_15_Addr_A_orig() {
    v3_15_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_15_Addr_B() {
    v3_15_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_15_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_15_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_15_Addr_B_orig =  (sc_lv<32>) (v3_15_addr_1_reg_19654.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_15_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_15_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_15_Clk_A() {
    v3_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_15_Clk_B() {
    v3_15_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_15_Din_A() {
    v3_15_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_15_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_15_Din_B = reg_8972.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_15_Din_B = ap_const_lv32_0;
    } else {
        v3_15_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_15_EN_A = ap_const_logic_1;
    } else {
        v3_15_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_15_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_15_EN_B = ap_const_logic_1;
    } else {
        v3_15_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_15_Rst_A() {
    v3_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_15_Rst_B() {
    v3_15_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_15_WEN_A() {
    v3_15_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_15_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_15_WEN_B = ap_const_lv4_F;
    } else {
        v3_15_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_16_Addr_A() {
    v3_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_16_Addr_A_orig() {
    v3_16_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_16_Addr_B() {
    v3_16_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_16_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_16_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_16_Addr_B_orig =  (sc_lv<32>) (v3_16_addr_1_reg_19660.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_16_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_16_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_16_Clk_A() {
    v3_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_16_Clk_B() {
    v3_16_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_16_Din_A() {
    v3_16_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_16_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_16_Din_B = reg_8978.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_16_Din_B = ap_const_lv32_0;
    } else {
        v3_16_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_16_EN_A = ap_const_logic_1;
    } else {
        v3_16_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_16_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_16_EN_B = ap_const_logic_1;
    } else {
        v3_16_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_16_Rst_A() {
    v3_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_16_Rst_B() {
    v3_16_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_16_WEN_A() {
    v3_16_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_16_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_16_WEN_B = ap_const_lv4_F;
    } else {
        v3_16_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_17_Addr_A() {
    v3_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_17_Addr_A_orig() {
    v3_17_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_17_Addr_B() {
    v3_17_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_17_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_17_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_17_Addr_B_orig =  (sc_lv<32>) (v3_17_addr_1_reg_19666.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_17_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_17_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_17_Clk_A() {
    v3_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_17_Clk_B() {
    v3_17_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_17_Din_A() {
    v3_17_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_17_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_17_Din_B = reg_8984.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_17_Din_B = ap_const_lv32_0;
    } else {
        v3_17_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_17_EN_A = ap_const_logic_1;
    } else {
        v3_17_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_17_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_17_EN_B = ap_const_logic_1;
    } else {
        v3_17_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_17_Rst_A() {
    v3_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_17_Rst_B() {
    v3_17_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_17_WEN_A() {
    v3_17_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_17_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_17_WEN_B = ap_const_lv4_F;
    } else {
        v3_17_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_18_Addr_A() {
    v3_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_18_Addr_A_orig() {
    v3_18_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_18_Addr_B() {
    v3_18_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_18_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_18_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_18_Addr_B_orig =  (sc_lv<32>) (v3_18_addr_1_reg_19672.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_18_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_18_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_18_Clk_A() {
    v3_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_18_Clk_B() {
    v3_18_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_18_Din_A() {
    v3_18_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_18_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_18_Din_B = reg_9404.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_18_Din_B = ap_const_lv32_0;
    } else {
        v3_18_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_18_EN_A = ap_const_logic_1;
    } else {
        v3_18_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_18_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_18_EN_B = ap_const_logic_1;
    } else {
        v3_18_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_18_Rst_A() {
    v3_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_18_Rst_B() {
    v3_18_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_18_WEN_A() {
    v3_18_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_18_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_18_WEN_B = ap_const_lv4_F;
    } else {
        v3_18_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_19_Addr_A() {
    v3_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_19_Addr_A_orig() {
    v3_19_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_19_Addr_B() {
    v3_19_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_19_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_19_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_19_Addr_B_orig =  (sc_lv<32>) (v3_19_addr_1_reg_19678.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_19_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_19_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_19_Clk_A() {
    v3_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_19_Clk_B() {
    v3_19_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_19_Din_A() {
    v3_19_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_19_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_19_Din_B = reg_9410.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_19_Din_B = ap_const_lv32_0;
    } else {
        v3_19_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_19_EN_A = ap_const_logic_1;
    } else {
        v3_19_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_19_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_19_EN_B = ap_const_logic_1;
    } else {
        v3_19_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_19_Rst_A() {
    v3_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_19_Rst_B() {
    v3_19_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_19_WEN_A() {
    v3_19_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_19_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_19_WEN_B = ap_const_lv4_F;
    } else {
        v3_19_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_1_Addr_A() {
    v3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_1_Addr_A_orig() {
    v3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_1_Addr_B() {
    v3_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_1_Addr_B_orig =  (sc_lv<32>) (v3_1_addr_1_reg_19495.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_1_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_1_Clk_A() {
    v3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_1_Clk_B() {
    v3_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_1_Din_A() {
    v3_1_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_1_Din_B = reg_8858.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_1_Din_B = ap_const_lv32_0;
    } else {
        v3_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_1_EN_A = ap_const_logic_1;
    } else {
        v3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_1_EN_B = ap_const_logic_1;
    } else {
        v3_1_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_1_Rst_A() {
    v3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_1_Rst_B() {
    v3_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_1_WEN_A() {
    v3_1_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_1_WEN_B = ap_const_lv4_F;
    } else {
        v3_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_20_Addr_A() {
    v3_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_20_Addr_A_orig() {
    v3_20_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_20_Addr_B() {
    v3_20_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_20_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_20_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_20_Addr_B_orig =  (sc_lv<32>) (v3_20_addr_1_reg_19684.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_20_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_20_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_20_Clk_A() {
    v3_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_20_Clk_B() {
    v3_20_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_20_Din_A() {
    v3_20_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_20_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_20_Din_B = reg_9416.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_20_Din_B = ap_const_lv32_0;
    } else {
        v3_20_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_20_EN_A = ap_const_logic_1;
    } else {
        v3_20_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_20_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_20_EN_B = ap_const_logic_1;
    } else {
        v3_20_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_20_Rst_A() {
    v3_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_20_Rst_B() {
    v3_20_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_20_WEN_A() {
    v3_20_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_20_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_20_WEN_B = ap_const_lv4_F;
    } else {
        v3_20_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_21_Addr_A() {
    v3_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_21_Addr_A_orig() {
    v3_21_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_21_Addr_B() {
    v3_21_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_21_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_21_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_21_Addr_B_orig =  (sc_lv<32>) (v3_21_addr_1_reg_19690.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_21_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_21_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_21_Clk_A() {
    v3_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_21_Clk_B() {
    v3_21_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_21_Din_A() {
    v3_21_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_21_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_21_Din_B = reg_9422.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_21_Din_B = ap_const_lv32_0;
    } else {
        v3_21_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_21_EN_A = ap_const_logic_1;
    } else {
        v3_21_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_21_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_21_EN_B = ap_const_logic_1;
    } else {
        v3_21_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_21_Rst_A() {
    v3_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_21_Rst_B() {
    v3_21_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_21_WEN_A() {
    v3_21_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_21_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_21_WEN_B = ap_const_lv4_F;
    } else {
        v3_21_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_22_Addr_A() {
    v3_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_22_Addr_A_orig() {
    v3_22_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_22_Addr_B() {
    v3_22_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_22_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_22_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_22_Addr_B_orig =  (sc_lv<32>) (v3_22_addr_1_reg_19696.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_22_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_22_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_22_Clk_A() {
    v3_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_22_Clk_B() {
    v3_22_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_22_Din_A() {
    v3_22_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_22_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_22_Din_B = reg_9428.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_22_Din_B = ap_const_lv32_0;
    } else {
        v3_22_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_22_EN_A = ap_const_logic_1;
    } else {
        v3_22_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_22_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_22_EN_B = ap_const_logic_1;
    } else {
        v3_22_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_22_Rst_A() {
    v3_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_22_Rst_B() {
    v3_22_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_22_WEN_A() {
    v3_22_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_22_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_22_WEN_B = ap_const_lv4_F;
    } else {
        v3_22_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_23_Addr_A() {
    v3_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_23_Addr_A_orig() {
    v3_23_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_23_Addr_B() {
    v3_23_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_23_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_23_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_23_Addr_B_orig =  (sc_lv<32>) (v3_23_addr_1_reg_19702.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_23_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_23_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_23_Clk_A() {
    v3_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_23_Clk_B() {
    v3_23_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_23_Din_A() {
    v3_23_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_23_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_23_Din_B = reg_9434.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_23_Din_B = ap_const_lv32_0;
    } else {
        v3_23_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_23_EN_A = ap_const_logic_1;
    } else {
        v3_23_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_23_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_23_EN_B = ap_const_logic_1;
    } else {
        v3_23_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_23_Rst_A() {
    v3_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_23_Rst_B() {
    v3_23_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_23_WEN_A() {
    v3_23_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_23_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_23_WEN_B = ap_const_lv4_F;
    } else {
        v3_23_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_24_Addr_A() {
    v3_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_24_Addr_A_orig() {
    v3_24_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_24_Addr_B() {
    v3_24_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_24_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_24_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_24_Addr_B_orig =  (sc_lv<32>) (v3_24_addr_1_reg_19708.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_24_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_24_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_24_Clk_A() {
    v3_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_24_Clk_B() {
    v3_24_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_24_Din_A() {
    v3_24_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_24_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_24_Din_B = reg_9440.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_24_Din_B = ap_const_lv32_0;
    } else {
        v3_24_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_24_EN_A = ap_const_logic_1;
    } else {
        v3_24_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_24_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_24_EN_B = ap_const_logic_1;
    } else {
        v3_24_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_24_Rst_A() {
    v3_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_24_Rst_B() {
    v3_24_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_24_WEN_A() {
    v3_24_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_24_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_24_WEN_B = ap_const_lv4_F;
    } else {
        v3_24_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_25_Addr_A() {
    v3_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_25_Addr_A_orig() {
    v3_25_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_25_Addr_B() {
    v3_25_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_25_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_25_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_25_Addr_B_orig =  (sc_lv<32>) (v3_25_addr_1_reg_19714.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_25_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_25_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_25_Clk_A() {
    v3_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_25_Clk_B() {
    v3_25_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_25_Din_A() {
    v3_25_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_25_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_25_Din_B = reg_9446.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_25_Din_B = ap_const_lv32_0;
    } else {
        v3_25_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_25_EN_A = ap_const_logic_1;
    } else {
        v3_25_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_25_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_25_EN_B = ap_const_logic_1;
    } else {
        v3_25_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_25_Rst_A() {
    v3_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_25_Rst_B() {
    v3_25_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_25_WEN_A() {
    v3_25_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_25_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_25_WEN_B = ap_const_lv4_F;
    } else {
        v3_25_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_26_Addr_A() {
    v3_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_26_Addr_A_orig() {
    v3_26_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_26_Addr_B() {
    v3_26_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_26_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_26_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_26_Addr_B_orig =  (sc_lv<32>) (v3_26_addr_1_reg_19720.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_26_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_26_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_26_Clk_A() {
    v3_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_26_Clk_B() {
    v3_26_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_26_Din_A() {
    v3_26_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_26_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_26_Din_B = reg_9452.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_26_Din_B = ap_const_lv32_0;
    } else {
        v3_26_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_26_EN_A = ap_const_logic_1;
    } else {
        v3_26_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_26_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_26_EN_B = ap_const_logic_1;
    } else {
        v3_26_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_26_Rst_A() {
    v3_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_26_Rst_B() {
    v3_26_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_26_WEN_A() {
    v3_26_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_26_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_26_WEN_B = ap_const_lv4_F;
    } else {
        v3_26_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_27_Addr_A() {
    v3_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_27_Addr_A_orig() {
    v3_27_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_27_Addr_B() {
    v3_27_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_27_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_27_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_27_Addr_B_orig =  (sc_lv<32>) (v3_27_addr_1_reg_19726.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_27_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_27_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_27_Clk_A() {
    v3_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_27_Clk_B() {
    v3_27_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_27_Din_A() {
    v3_27_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_27_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_27_Din_B = reg_9458.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_27_Din_B = ap_const_lv32_0;
    } else {
        v3_27_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_27_EN_A = ap_const_logic_1;
    } else {
        v3_27_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_27_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_27_EN_B = ap_const_logic_1;
    } else {
        v3_27_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_27_Rst_A() {
    v3_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_27_Rst_B() {
    v3_27_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_27_WEN_A() {
    v3_27_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_27_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_27_WEN_B = ap_const_lv4_F;
    } else {
        v3_27_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_28_Addr_A() {
    v3_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_28_Addr_A_orig() {
    v3_28_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_28_Addr_B() {
    v3_28_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_28_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_28_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_28_Addr_B_orig =  (sc_lv<32>) (v3_28_addr_1_reg_19732.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_28_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_28_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_28_Clk_A() {
    v3_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_28_Clk_B() {
    v3_28_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_28_Din_A() {
    v3_28_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_28_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_28_Din_B = reg_9464.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_28_Din_B = ap_const_lv32_0;
    } else {
        v3_28_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_28_EN_A = ap_const_logic_1;
    } else {
        v3_28_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_28_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_28_EN_B = ap_const_logic_1;
    } else {
        v3_28_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_28_Rst_A() {
    v3_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_28_Rst_B() {
    v3_28_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_28_WEN_A() {
    v3_28_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_28_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_28_WEN_B = ap_const_lv4_F;
    } else {
        v3_28_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_29_Addr_A() {
    v3_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_29_Addr_A_orig() {
    v3_29_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_29_Addr_B() {
    v3_29_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_29_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_29_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_29_Addr_B_orig =  (sc_lv<32>) (v3_29_addr_1_reg_19738.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_29_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_29_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_29_Clk_A() {
    v3_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_29_Clk_B() {
    v3_29_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_29_Din_A() {
    v3_29_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_29_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_29_Din_B = reg_9470.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_29_Din_B = ap_const_lv32_0;
    } else {
        v3_29_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_29_EN_A = ap_const_logic_1;
    } else {
        v3_29_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_29_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_29_EN_B = ap_const_logic_1;
    } else {
        v3_29_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_29_Rst_A() {
    v3_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_29_Rst_B() {
    v3_29_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_29_WEN_A() {
    v3_29_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_29_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_29_WEN_B = ap_const_lv4_F;
    } else {
        v3_29_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_2_Addr_A() {
    v3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_2_Addr_A_orig() {
    v3_2_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_2_Addr_B() {
    v3_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_2_Addr_B_orig =  (sc_lv<32>) (v3_2_addr_1_reg_19501.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_2_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_2_Clk_A() {
    v3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_2_Clk_B() {
    v3_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_2_Din_A() {
    v3_2_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_2_Din_B = reg_8864.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_2_Din_B = ap_const_lv32_0;
    } else {
        v3_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_2_EN_A = ap_const_logic_1;
    } else {
        v3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_2_EN_B = ap_const_logic_1;
    } else {
        v3_2_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_2_Rst_A() {
    v3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_2_Rst_B() {
    v3_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_2_WEN_A() {
    v3_2_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_2_WEN_B = ap_const_lv4_F;
    } else {
        v3_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_30_Addr_A() {
    v3_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_30_Addr_A_orig() {
    v3_30_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_30_Addr_B() {
    v3_30_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_30_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_30_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_30_Addr_B_orig =  (sc_lv<32>) (v3_30_addr_1_reg_19744.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_30_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_30_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_30_Clk_A() {
    v3_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_30_Clk_B() {
    v3_30_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_30_Din_A() {
    v3_30_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_30_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_30_Din_B = reg_9476.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_30_Din_B = ap_const_lv32_0;
    } else {
        v3_30_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_30_EN_A = ap_const_logic_1;
    } else {
        v3_30_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_30_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_30_EN_B = ap_const_logic_1;
    } else {
        v3_30_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_30_Rst_A() {
    v3_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_30_Rst_B() {
    v3_30_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_30_WEN_A() {
    v3_30_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_30_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_30_WEN_B = ap_const_lv4_F;
    } else {
        v3_30_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_31_Addr_A() {
    v3_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_31_Addr_A_orig() {
    v3_31_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_31_Addr_B() {
    v3_31_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_31_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_31_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_31_Addr_B_orig =  (sc_lv<32>) (v3_31_addr_1_reg_19750.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_31_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_31_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_31_Clk_A() {
    v3_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_31_Clk_B() {
    v3_31_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_31_Din_A() {
    v3_31_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_31_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_31_Din_B = reg_9482.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_31_Din_B = ap_const_lv32_0;
    } else {
        v3_31_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_31_EN_A = ap_const_logic_1;
    } else {
        v3_31_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_31_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_31_EN_B = ap_const_logic_1;
    } else {
        v3_31_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_31_Rst_A() {
    v3_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_31_Rst_B() {
    v3_31_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_31_WEN_A() {
    v3_31_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_31_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_31_WEN_B = ap_const_lv4_F;
    } else {
        v3_31_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_32_Addr_A() {
    v3_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_32_Addr_A_orig() {
    v3_32_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_32_Addr_B() {
    v3_32_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_32_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_32_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_32_Addr_B_orig =  (sc_lv<32>) (v3_32_addr_1_reg_19756.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_32_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_32_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_32_Clk_A() {
    v3_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_32_Clk_B() {
    v3_32_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_32_Din_A() {
    v3_32_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_32_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_32_Din_B = reg_9488.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_32_Din_B = ap_const_lv32_0;
    } else {
        v3_32_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_32_EN_A = ap_const_logic_1;
    } else {
        v3_32_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_32_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_32_EN_B = ap_const_logic_1;
    } else {
        v3_32_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_32_Rst_A() {
    v3_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_32_Rst_B() {
    v3_32_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_32_WEN_A() {
    v3_32_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_32_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_32_WEN_B = ap_const_lv4_F;
    } else {
        v3_32_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_33_Addr_A() {
    v3_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_33_Addr_A_orig() {
    v3_33_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_33_Addr_B() {
    v3_33_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_33_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_33_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_33_Addr_B_orig =  (sc_lv<32>) (v3_33_addr_1_reg_19762.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_33_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_33_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_33_Clk_A() {
    v3_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_33_Clk_B() {
    v3_33_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_33_Din_A() {
    v3_33_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_33_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_33_Din_B = reg_9494.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_33_Din_B = ap_const_lv32_0;
    } else {
        v3_33_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_33_EN_A = ap_const_logic_1;
    } else {
        v3_33_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_33_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_33_EN_B = ap_const_logic_1;
    } else {
        v3_33_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_33_Rst_A() {
    v3_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_33_Rst_B() {
    v3_33_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_33_WEN_A() {
    v3_33_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_33_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_33_WEN_B = ap_const_lv4_F;
    } else {
        v3_33_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_34_Addr_A() {
    v3_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_34_Addr_A_orig() {
    v3_34_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_34_Addr_B() {
    v3_34_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_34_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_34_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_34_Addr_B_orig =  (sc_lv<32>) (v3_34_addr_1_reg_19768.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_34_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_34_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_34_Clk_A() {
    v3_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_34_Clk_B() {
    v3_34_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_34_Din_A() {
    v3_34_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_34_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_34_Din_B = reg_9500.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_34_Din_B = ap_const_lv32_0;
    } else {
        v3_34_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_34_EN_A = ap_const_logic_1;
    } else {
        v3_34_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_34_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_34_EN_B = ap_const_logic_1;
    } else {
        v3_34_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_34_Rst_A() {
    v3_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_34_Rst_B() {
    v3_34_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_34_WEN_A() {
    v3_34_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_34_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_34_WEN_B = ap_const_lv4_F;
    } else {
        v3_34_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_35_Addr_A() {
    v3_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_35_Addr_A_orig() {
    v3_35_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_35_Addr_B() {
    v3_35_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_35_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_35_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_35_Addr_B_orig =  (sc_lv<32>) (v3_35_addr_1_reg_19774.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_35_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_35_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_35_Clk_A() {
    v3_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_35_Clk_B() {
    v3_35_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_35_Din_A() {
    v3_35_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_35_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_35_Din_B = reg_9506.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_35_Din_B = ap_const_lv32_0;
    } else {
        v3_35_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_35_EN_A = ap_const_logic_1;
    } else {
        v3_35_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_35_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_35_EN_B = ap_const_logic_1;
    } else {
        v3_35_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_35_Rst_A() {
    v3_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_35_Rst_B() {
    v3_35_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_35_WEN_A() {
    v3_35_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_35_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_35_WEN_B = ap_const_lv4_F;
    } else {
        v3_35_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_36_Addr_A() {
    v3_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_36_Addr_A_orig() {
    v3_36_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_36_Addr_B() {
    v3_36_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_36_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_36_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_36_Addr_B_orig =  (sc_lv<32>) (v3_36_addr_1_reg_19780.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_36_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_36_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_36_Clk_A() {
    v3_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_36_Clk_B() {
    v3_36_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_36_Din_A() {
    v3_36_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_36_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_36_Din_B = reg_9512.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_36_Din_B = ap_const_lv32_0;
    } else {
        v3_36_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_36_EN_A = ap_const_logic_1;
    } else {
        v3_36_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_36_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_36_EN_B = ap_const_logic_1;
    } else {
        v3_36_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_36_Rst_A() {
    v3_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_36_Rst_B() {
    v3_36_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_36_WEN_A() {
    v3_36_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_36_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_36_WEN_B = ap_const_lv4_F;
    } else {
        v3_36_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_37_Addr_A() {
    v3_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_37_Addr_A_orig() {
    v3_37_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_37_Addr_B() {
    v3_37_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_37_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_37_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_37_Addr_B_orig =  (sc_lv<32>) (v3_37_addr_1_reg_19786.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_37_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_37_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_37_Clk_A() {
    v3_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_37_Clk_B() {
    v3_37_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_37_Din_A() {
    v3_37_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_37_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_37_Din_B = reg_9518.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_37_Din_B = ap_const_lv32_0;
    } else {
        v3_37_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_37_EN_A = ap_const_logic_1;
    } else {
        v3_37_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_37_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_37_EN_B = ap_const_logic_1;
    } else {
        v3_37_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_37_Rst_A() {
    v3_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_37_Rst_B() {
    v3_37_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_37_WEN_A() {
    v3_37_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_37_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_37_WEN_B = ap_const_lv4_F;
    } else {
        v3_37_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_38_Addr_A() {
    v3_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_38_Addr_A_orig() {
    v3_38_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_38_Addr_B() {
    v3_38_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_38_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_38_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_38_Addr_B_orig =  (sc_lv<32>) (v3_38_addr_1_reg_19792.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_38_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_38_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_38_Clk_A() {
    v3_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_38_Clk_B() {
    v3_38_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_38_Din_A() {
    v3_38_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_38_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_38_Din_B = reg_9524.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_38_Din_B = ap_const_lv32_0;
    } else {
        v3_38_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_38_EN_A = ap_const_logic_1;
    } else {
        v3_38_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_38_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_38_EN_B = ap_const_logic_1;
    } else {
        v3_38_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_38_Rst_A() {
    v3_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_38_Rst_B() {
    v3_38_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_38_WEN_A() {
    v3_38_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_38_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_38_WEN_B = ap_const_lv4_F;
    } else {
        v3_38_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_39_Addr_A() {
    v3_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_39_Addr_A_orig() {
    v3_39_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_39_Addr_B() {
    v3_39_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_39_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_39_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_39_Addr_B_orig =  (sc_lv<32>) (v3_39_addr_1_reg_19798.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_39_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_39_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_39_Clk_A() {
    v3_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_39_Clk_B() {
    v3_39_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_39_Din_A() {
    v3_39_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_39_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_39_Din_B = reg_9530.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_39_Din_B = ap_const_lv32_0;
    } else {
        v3_39_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_39_EN_A = ap_const_logic_1;
    } else {
        v3_39_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_39_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_39_EN_B = ap_const_logic_1;
    } else {
        v3_39_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_39_Rst_A() {
    v3_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_39_Rst_B() {
    v3_39_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_39_WEN_A() {
    v3_39_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_39_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_39_WEN_B = ap_const_lv4_F;
    } else {
        v3_39_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_3_Addr_A() {
    v3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_3_Addr_A_orig() {
    v3_3_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_3_Addr_B() {
    v3_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_3_Addr_B_orig =  (sc_lv<32>) (v3_3_addr_1_reg_19507.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_3_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_3_Clk_A() {
    v3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_3_Clk_B() {
    v3_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_3_Din_A() {
    v3_3_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_3_Din_B = reg_8870.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_3_Din_B = ap_const_lv32_0;
    } else {
        v3_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_3_EN_A = ap_const_logic_1;
    } else {
        v3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_3_EN_B = ap_const_logic_1;
    } else {
        v3_3_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_3_Rst_A() {
    v3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_3_Rst_B() {
    v3_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_3_WEN_A() {
    v3_3_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_3_WEN_B = ap_const_lv4_F;
    } else {
        v3_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_40_Addr_A() {
    v3_40_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_40_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_40_Addr_A_orig() {
    v3_40_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_40_Addr_B() {
    v3_40_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_40_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_40_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_40_Addr_B_orig =  (sc_lv<32>) (v3_40_addr_1_reg_19804.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_40_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_40_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_40_Clk_A() {
    v3_40_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_40_Clk_B() {
    v3_40_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_40_Din_A() {
    v3_40_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_40_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_40_Din_B = reg_9536.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_40_Din_B = ap_const_lv32_0;
    } else {
        v3_40_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_40_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_40_EN_A = ap_const_logic_1;
    } else {
        v3_40_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_40_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_40_EN_B = ap_const_logic_1;
    } else {
        v3_40_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_40_Rst_A() {
    v3_40_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_40_Rst_B() {
    v3_40_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_40_WEN_A() {
    v3_40_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_40_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_40_WEN_B = ap_const_lv4_F;
    } else {
        v3_40_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_41_Addr_A() {
    v3_41_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_41_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_41_Addr_A_orig() {
    v3_41_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_41_Addr_B() {
    v3_41_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_41_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_41_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_41_Addr_B_orig =  (sc_lv<32>) (v3_41_addr_1_reg_19810.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_41_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_41_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_41_Clk_A() {
    v3_41_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_41_Clk_B() {
    v3_41_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_41_Din_A() {
    v3_41_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_41_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_41_Din_B = reg_9542.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_41_Din_B = ap_const_lv32_0;
    } else {
        v3_41_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_41_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_41_EN_A = ap_const_logic_1;
    } else {
        v3_41_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_41_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_41_EN_B = ap_const_logic_1;
    } else {
        v3_41_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_41_Rst_A() {
    v3_41_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_41_Rst_B() {
    v3_41_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_41_WEN_A() {
    v3_41_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_41_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_41_WEN_B = ap_const_lv4_F;
    } else {
        v3_41_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_42_Addr_A() {
    v3_42_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_42_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_42_Addr_A_orig() {
    v3_42_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_42_Addr_B() {
    v3_42_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_42_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_42_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_42_Addr_B_orig =  (sc_lv<32>) (v3_42_addr_1_reg_19816.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_42_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_42_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_42_Clk_A() {
    v3_42_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_42_Clk_B() {
    v3_42_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_42_Din_A() {
    v3_42_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_42_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_42_Din_B = reg_9548.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_42_Din_B = ap_const_lv32_0;
    } else {
        v3_42_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_42_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_42_EN_A = ap_const_logic_1;
    } else {
        v3_42_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_42_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_42_EN_B = ap_const_logic_1;
    } else {
        v3_42_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_42_Rst_A() {
    v3_42_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_42_Rst_B() {
    v3_42_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_42_WEN_A() {
    v3_42_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_42_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_42_WEN_B = ap_const_lv4_F;
    } else {
        v3_42_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_43_Addr_A() {
    v3_43_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_43_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_43_Addr_A_orig() {
    v3_43_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_43_Addr_B() {
    v3_43_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_43_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_43_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_43_Addr_B_orig =  (sc_lv<32>) (v3_43_addr_1_reg_19822.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_43_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_43_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_43_Clk_A() {
    v3_43_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_43_Clk_B() {
    v3_43_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_43_Din_A() {
    v3_43_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_43_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_43_Din_B = reg_9554.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_43_Din_B = ap_const_lv32_0;
    } else {
        v3_43_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_43_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_43_EN_A = ap_const_logic_1;
    } else {
        v3_43_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_43_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_43_EN_B = ap_const_logic_1;
    } else {
        v3_43_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_43_Rst_A() {
    v3_43_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_43_Rst_B() {
    v3_43_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_43_WEN_A() {
    v3_43_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_43_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_43_WEN_B = ap_const_lv4_F;
    } else {
        v3_43_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_44_Addr_A() {
    v3_44_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_44_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_44_Addr_A_orig() {
    v3_44_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_44_Addr_B() {
    v3_44_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_44_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_44_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_44_Addr_B_orig =  (sc_lv<32>) (v3_44_addr_1_reg_19828.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_44_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_44_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_44_Clk_A() {
    v3_44_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_44_Clk_B() {
    v3_44_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_44_Din_A() {
    v3_44_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_44_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_44_Din_B = reg_9560.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_44_Din_B = ap_const_lv32_0;
    } else {
        v3_44_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_44_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_44_EN_A = ap_const_logic_1;
    } else {
        v3_44_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_44_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_44_EN_B = ap_const_logic_1;
    } else {
        v3_44_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_44_Rst_A() {
    v3_44_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_44_Rst_B() {
    v3_44_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_44_WEN_A() {
    v3_44_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_44_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_44_WEN_B = ap_const_lv4_F;
    } else {
        v3_44_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_45_Addr_A() {
    v3_45_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_45_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_45_Addr_A_orig() {
    v3_45_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_45_Addr_B() {
    v3_45_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_45_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_45_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_45_Addr_B_orig =  (sc_lv<32>) (v3_45_addr_1_reg_19834.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_45_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_45_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_45_Clk_A() {
    v3_45_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_45_Clk_B() {
    v3_45_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_45_Din_A() {
    v3_45_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_45_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_45_Din_B = reg_9566.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_45_Din_B = ap_const_lv32_0;
    } else {
        v3_45_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_45_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_45_EN_A = ap_const_logic_1;
    } else {
        v3_45_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_45_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_45_EN_B = ap_const_logic_1;
    } else {
        v3_45_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_45_Rst_A() {
    v3_45_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_45_Rst_B() {
    v3_45_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_45_WEN_A() {
    v3_45_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_45_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_45_WEN_B = ap_const_lv4_F;
    } else {
        v3_45_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_46_Addr_A() {
    v3_46_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_46_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_46_Addr_A_orig() {
    v3_46_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_46_Addr_B() {
    v3_46_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_46_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_46_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_46_Addr_B_orig =  (sc_lv<32>) (v3_46_addr_1_reg_19840.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_46_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_46_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_46_Clk_A() {
    v3_46_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_46_Clk_B() {
    v3_46_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_46_Din_A() {
    v3_46_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_46_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_46_Din_B = reg_9572.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_46_Din_B = ap_const_lv32_0;
    } else {
        v3_46_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_46_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_46_EN_A = ap_const_logic_1;
    } else {
        v3_46_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_46_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_46_EN_B = ap_const_logic_1;
    } else {
        v3_46_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_46_Rst_A() {
    v3_46_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_46_Rst_B() {
    v3_46_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_46_WEN_A() {
    v3_46_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_46_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_46_WEN_B = ap_const_lv4_F;
    } else {
        v3_46_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_47_Addr_A() {
    v3_47_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_47_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_47_Addr_A_orig() {
    v3_47_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_47_Addr_B() {
    v3_47_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_47_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_47_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_47_Addr_B_orig =  (sc_lv<32>) (v3_47_addr_1_reg_19846.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_47_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_47_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_47_Clk_A() {
    v3_47_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_47_Clk_B() {
    v3_47_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_47_Din_A() {
    v3_47_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_47_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_47_Din_B = reg_9578.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_47_Din_B = ap_const_lv32_0;
    } else {
        v3_47_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_47_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_47_EN_A = ap_const_logic_1;
    } else {
        v3_47_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_47_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_47_EN_B = ap_const_logic_1;
    } else {
        v3_47_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_47_Rst_A() {
    v3_47_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_47_Rst_B() {
    v3_47_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_47_WEN_A() {
    v3_47_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_47_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_47_WEN_B = ap_const_lv4_F;
    } else {
        v3_47_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_48_Addr_A() {
    v3_48_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_48_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_48_Addr_A_orig() {
    v3_48_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_48_Addr_B() {
    v3_48_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_48_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_48_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_48_Addr_B_orig =  (sc_lv<32>) (v3_48_addr_1_reg_19852.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_48_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_48_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_48_Clk_A() {
    v3_48_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_48_Clk_B() {
    v3_48_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_48_Din_A() {
    v3_48_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_48_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_48_Din_B = reg_9584.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_48_Din_B = ap_const_lv32_0;
    } else {
        v3_48_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_48_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_48_EN_A = ap_const_logic_1;
    } else {
        v3_48_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_48_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_48_EN_B = ap_const_logic_1;
    } else {
        v3_48_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_48_Rst_A() {
    v3_48_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_48_Rst_B() {
    v3_48_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_48_WEN_A() {
    v3_48_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_48_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_48_WEN_B = ap_const_lv4_F;
    } else {
        v3_48_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_49_Addr_A() {
    v3_49_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_49_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_49_Addr_A_orig() {
    v3_49_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_49_Addr_B() {
    v3_49_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_49_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_49_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_49_Addr_B_orig =  (sc_lv<32>) (v3_49_addr_1_reg_19858.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_49_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_49_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_49_Clk_A() {
    v3_49_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_49_Clk_B() {
    v3_49_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_49_Din_A() {
    v3_49_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_49_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_49_Din_B = reg_9590.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_49_Din_B = ap_const_lv32_0;
    } else {
        v3_49_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_49_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_49_EN_A = ap_const_logic_1;
    } else {
        v3_49_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_49_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_49_EN_B = ap_const_logic_1;
    } else {
        v3_49_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_49_Rst_A() {
    v3_49_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_49_Rst_B() {
    v3_49_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_49_WEN_A() {
    v3_49_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_49_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_49_WEN_B = ap_const_lv4_F;
    } else {
        v3_49_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_4_Addr_A() {
    v3_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_4_Addr_A_orig() {
    v3_4_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_4_Addr_B() {
    v3_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_4_Addr_B_orig =  (sc_lv<32>) (v3_4_addr_1_reg_19513.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_4_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_4_Clk_A() {
    v3_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_4_Clk_B() {
    v3_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_4_Din_A() {
    v3_4_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_4_Din_B = reg_8876.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_4_Din_B = ap_const_lv32_0;
    } else {
        v3_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_4_EN_A = ap_const_logic_1;
    } else {
        v3_4_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_4_EN_B = ap_const_logic_1;
    } else {
        v3_4_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_4_Rst_A() {
    v3_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_4_Rst_B() {
    v3_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_4_WEN_A() {
    v3_4_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_4_WEN_B = ap_const_lv4_F;
    } else {
        v3_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_50_Addr_A() {
    v3_50_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_50_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_50_Addr_A_orig() {
    v3_50_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_50_Addr_B() {
    v3_50_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_50_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_50_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_50_Addr_B_orig =  (sc_lv<32>) (v3_50_addr_1_reg_19864.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_50_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_50_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_50_Clk_A() {
    v3_50_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_50_Clk_B() {
    v3_50_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_50_Din_A() {
    v3_50_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_50_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_50_Din_B = reg_9596.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_50_Din_B = ap_const_lv32_0;
    } else {
        v3_50_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_50_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_50_EN_A = ap_const_logic_1;
    } else {
        v3_50_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_50_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_50_EN_B = ap_const_logic_1;
    } else {
        v3_50_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_50_Rst_A() {
    v3_50_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_50_Rst_B() {
    v3_50_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_50_WEN_A() {
    v3_50_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_50_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_50_WEN_B = ap_const_lv4_F;
    } else {
        v3_50_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_51_Addr_A() {
    v3_51_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_51_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_51_Addr_A_orig() {
    v3_51_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_51_Addr_B() {
    v3_51_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_51_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_51_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_51_Addr_B_orig =  (sc_lv<32>) (v3_51_addr_1_reg_19870.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_51_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_51_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_51_Clk_A() {
    v3_51_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_51_Clk_B() {
    v3_51_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_51_Din_A() {
    v3_51_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_51_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_51_Din_B = reg_9602.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_51_Din_B = ap_const_lv32_0;
    } else {
        v3_51_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_51_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_51_EN_A = ap_const_logic_1;
    } else {
        v3_51_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_51_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_51_EN_B = ap_const_logic_1;
    } else {
        v3_51_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_51_Rst_A() {
    v3_51_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_51_Rst_B() {
    v3_51_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_51_WEN_A() {
    v3_51_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_51_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_51_WEN_B = ap_const_lv4_F;
    } else {
        v3_51_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_52_Addr_A() {
    v3_52_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_52_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_52_Addr_A_orig() {
    v3_52_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_52_Addr_B() {
    v3_52_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_52_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_52_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_52_Addr_B_orig =  (sc_lv<32>) (v3_52_addr_1_reg_19876.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_52_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_52_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_52_Clk_A() {
    v3_52_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_52_Clk_B() {
    v3_52_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_52_Din_A() {
    v3_52_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_52_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_52_Din_B = reg_9608.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_52_Din_B = ap_const_lv32_0;
    } else {
        v3_52_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_52_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_52_EN_A = ap_const_logic_1;
    } else {
        v3_52_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_52_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_52_EN_B = ap_const_logic_1;
    } else {
        v3_52_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_52_Rst_A() {
    v3_52_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_52_Rst_B() {
    v3_52_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_52_WEN_A() {
    v3_52_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_52_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_52_WEN_B = ap_const_lv4_F;
    } else {
        v3_52_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_53_Addr_A() {
    v3_53_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_53_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_53_Addr_A_orig() {
    v3_53_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_53_Addr_B() {
    v3_53_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_53_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_53_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_53_Addr_B_orig =  (sc_lv<32>) (v3_53_addr_1_reg_19882.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_53_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_53_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_53_Clk_A() {
    v3_53_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_53_Clk_B() {
    v3_53_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_53_Din_A() {
    v3_53_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_53_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_53_Din_B = reg_9614.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_53_Din_B = ap_const_lv32_0;
    } else {
        v3_53_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_53_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_53_EN_A = ap_const_logic_1;
    } else {
        v3_53_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_53_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_53_EN_B = ap_const_logic_1;
    } else {
        v3_53_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_53_Rst_A() {
    v3_53_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_53_Rst_B() {
    v3_53_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_53_WEN_A() {
    v3_53_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_53_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_53_WEN_B = ap_const_lv4_F;
    } else {
        v3_53_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_54_Addr_A() {
    v3_54_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_54_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_54_Addr_A_orig() {
    v3_54_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_54_Addr_B() {
    v3_54_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_54_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_54_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_54_Addr_B_orig =  (sc_lv<32>) (v3_54_addr_1_reg_19888.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_54_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_54_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_54_Clk_A() {
    v3_54_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_54_Clk_B() {
    v3_54_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_54_Din_A() {
    v3_54_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_54_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_54_Din_B = reg_9620.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_54_Din_B = ap_const_lv32_0;
    } else {
        v3_54_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_54_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_54_EN_A = ap_const_logic_1;
    } else {
        v3_54_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_54_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_54_EN_B = ap_const_logic_1;
    } else {
        v3_54_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_54_Rst_A() {
    v3_54_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_54_Rst_B() {
    v3_54_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_54_WEN_A() {
    v3_54_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_54_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_54_WEN_B = ap_const_lv4_F;
    } else {
        v3_54_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_55_Addr_A() {
    v3_55_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_55_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_55_Addr_A_orig() {
    v3_55_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_55_Addr_B() {
    v3_55_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_55_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_55_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_55_Addr_B_orig =  (sc_lv<32>) (v3_55_addr_1_reg_19894.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_55_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_55_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_55_Clk_A() {
    v3_55_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_55_Clk_B() {
    v3_55_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_55_Din_A() {
    v3_55_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_55_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_55_Din_B = reg_9626.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_55_Din_B = ap_const_lv32_0;
    } else {
        v3_55_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_55_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_55_EN_A = ap_const_logic_1;
    } else {
        v3_55_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_55_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_55_EN_B = ap_const_logic_1;
    } else {
        v3_55_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_55_Rst_A() {
    v3_55_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_55_Rst_B() {
    v3_55_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_55_WEN_A() {
    v3_55_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_55_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_55_WEN_B = ap_const_lv4_F;
    } else {
        v3_55_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_56_Addr_A() {
    v3_56_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_56_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_56_Addr_A_orig() {
    v3_56_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_56_Addr_B() {
    v3_56_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_56_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_56_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_56_Addr_B_orig =  (sc_lv<32>) (v3_56_addr_1_reg_19900.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_56_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_56_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_56_Clk_A() {
    v3_56_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_56_Clk_B() {
    v3_56_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_56_Din_A() {
    v3_56_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_56_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_56_Din_B = reg_9632.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_56_Din_B = ap_const_lv32_0;
    } else {
        v3_56_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_56_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_56_EN_A = ap_const_logic_1;
    } else {
        v3_56_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_56_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_56_EN_B = ap_const_logic_1;
    } else {
        v3_56_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_56_Rst_A() {
    v3_56_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_56_Rst_B() {
    v3_56_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_56_WEN_A() {
    v3_56_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_56_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_56_WEN_B = ap_const_lv4_F;
    } else {
        v3_56_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_57_Addr_A() {
    v3_57_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_57_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_57_Addr_A_orig() {
    v3_57_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_57_Addr_B() {
    v3_57_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_57_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_57_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_57_Addr_B_orig =  (sc_lv<32>) (v3_57_addr_1_reg_19906.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_57_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_57_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_57_Clk_A() {
    v3_57_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_57_Clk_B() {
    v3_57_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_57_Din_A() {
    v3_57_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_57_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_57_Din_B = reg_9638.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_57_Din_B = ap_const_lv32_0;
    } else {
        v3_57_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_57_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_57_EN_A = ap_const_logic_1;
    } else {
        v3_57_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_57_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_57_EN_B = ap_const_logic_1;
    } else {
        v3_57_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_57_Rst_A() {
    v3_57_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_57_Rst_B() {
    v3_57_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_57_WEN_A() {
    v3_57_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_57_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_57_WEN_B = ap_const_lv4_F;
    } else {
        v3_57_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_58_Addr_A() {
    v3_58_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_58_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_58_Addr_A_orig() {
    v3_58_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_58_Addr_B() {
    v3_58_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_58_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_58_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_58_Addr_B_orig =  (sc_lv<32>) (v3_58_addr_1_reg_19912.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_58_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_58_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_58_Clk_A() {
    v3_58_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_58_Clk_B() {
    v3_58_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_58_Din_A() {
    v3_58_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_58_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_58_Din_B = reg_9644.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_58_Din_B = ap_const_lv32_0;
    } else {
        v3_58_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_58_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_58_EN_A = ap_const_logic_1;
    } else {
        v3_58_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_58_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_58_EN_B = ap_const_logic_1;
    } else {
        v3_58_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_58_Rst_A() {
    v3_58_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_58_Rst_B() {
    v3_58_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_58_WEN_A() {
    v3_58_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_58_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_58_WEN_B = ap_const_lv4_F;
    } else {
        v3_58_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_59_Addr_A() {
    v3_59_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_59_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_59_Addr_A_orig() {
    v3_59_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_59_Addr_B() {
    v3_59_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_59_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_59_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_59_Addr_B_orig =  (sc_lv<32>) (v3_59_addr_1_reg_19918.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_59_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_59_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_59_Clk_A() {
    v3_59_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_59_Clk_B() {
    v3_59_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_59_Din_A() {
    v3_59_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_59_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_59_Din_B = reg_9650.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_59_Din_B = ap_const_lv32_0;
    } else {
        v3_59_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_59_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_59_EN_A = ap_const_logic_1;
    } else {
        v3_59_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_59_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_59_EN_B = ap_const_logic_1;
    } else {
        v3_59_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_59_Rst_A() {
    v3_59_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_59_Rst_B() {
    v3_59_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_59_WEN_A() {
    v3_59_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_59_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_59_WEN_B = ap_const_lv4_F;
    } else {
        v3_59_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_5_Addr_A() {
    v3_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_5_Addr_A_orig() {
    v3_5_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_5_Addr_B() {
    v3_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_5_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_5_Addr_B_orig =  (sc_lv<32>) (v3_5_addr_1_reg_19519.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_5_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_5_Clk_A() {
    v3_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_5_Clk_B() {
    v3_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_5_Din_A() {
    v3_5_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_5_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_5_Din_B = reg_8882.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_5_Din_B = ap_const_lv32_0;
    } else {
        v3_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_5_EN_A = ap_const_logic_1;
    } else {
        v3_5_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_5_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_5_EN_B = ap_const_logic_1;
    } else {
        v3_5_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_5_Rst_A() {
    v3_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_5_Rst_B() {
    v3_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_5_WEN_A() {
    v3_5_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_5_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_5_WEN_B = ap_const_lv4_F;
    } else {
        v3_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_60_Addr_A() {
    v3_60_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_60_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_60_Addr_A_orig() {
    v3_60_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_60_Addr_B() {
    v3_60_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_60_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_60_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_60_Addr_B_orig =  (sc_lv<32>) (v3_60_addr_1_reg_19924.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_60_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_60_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_60_Clk_A() {
    v3_60_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_60_Clk_B() {
    v3_60_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_60_Din_A() {
    v3_60_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_60_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_60_Din_B = reg_9656.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_60_Din_B = ap_const_lv32_0;
    } else {
        v3_60_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_60_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_60_EN_A = ap_const_logic_1;
    } else {
        v3_60_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_60_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_60_EN_B = ap_const_logic_1;
    } else {
        v3_60_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_60_Rst_A() {
    v3_60_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_60_Rst_B() {
    v3_60_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_60_WEN_A() {
    v3_60_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_60_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_60_WEN_B = ap_const_lv4_F;
    } else {
        v3_60_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_61_Addr_A() {
    v3_61_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_61_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_61_Addr_A_orig() {
    v3_61_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_61_Addr_B() {
    v3_61_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_61_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_61_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_61_Addr_B_orig =  (sc_lv<32>) (v3_61_addr_1_reg_19930.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_61_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_61_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_61_Clk_A() {
    v3_61_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_61_Clk_B() {
    v3_61_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_61_Din_A() {
    v3_61_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_61_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_61_Din_B = reg_9662.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_61_Din_B = ap_const_lv32_0;
    } else {
        v3_61_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_61_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_61_EN_A = ap_const_logic_1;
    } else {
        v3_61_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_61_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_61_EN_B = ap_const_logic_1;
    } else {
        v3_61_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_61_Rst_A() {
    v3_61_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_61_Rst_B() {
    v3_61_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_61_WEN_A() {
    v3_61_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_61_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_61_WEN_B = ap_const_lv4_F;
    } else {
        v3_61_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_62_Addr_A() {
    v3_62_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_62_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_62_Addr_A_orig() {
    v3_62_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_62_Addr_B() {
    v3_62_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_62_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_62_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_62_Addr_B_orig =  (sc_lv<32>) (v3_62_addr_1_reg_19936.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_62_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_62_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_62_Clk_A() {
    v3_62_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_62_Clk_B() {
    v3_62_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_62_Din_A() {
    v3_62_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_62_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_62_Din_B = reg_9668.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_62_Din_B = ap_const_lv32_0;
    } else {
        v3_62_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_62_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_62_EN_A = ap_const_logic_1;
    } else {
        v3_62_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_62_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_62_EN_B = ap_const_logic_1;
    } else {
        v3_62_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_62_Rst_A() {
    v3_62_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_62_Rst_B() {
    v3_62_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_62_WEN_A() {
    v3_62_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_62_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_62_WEN_B = ap_const_lv4_F;
    } else {
        v3_62_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_63_Addr_A() {
    v3_63_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_63_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_63_Addr_A_orig() {
    v3_63_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_63_Addr_B() {
    v3_63_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_63_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_63_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_63_Addr_B_orig =  (sc_lv<32>) (v3_63_addr_1_reg_19942.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_63_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_63_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_63_Clk_A() {
    v3_63_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_63_Clk_B() {
    v3_63_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_63_Din_A() {
    v3_63_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_63_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_63_Din_B = reg_9674.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_63_Din_B = ap_const_lv32_0;
    } else {
        v3_63_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_63_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_63_EN_A = ap_const_logic_1;
    } else {
        v3_63_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_63_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_63_EN_B = ap_const_logic_1;
    } else {
        v3_63_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_63_Rst_A() {
    v3_63_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_63_Rst_B() {
    v3_63_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_63_WEN_A() {
    v3_63_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_63_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_63_WEN_B = ap_const_lv4_F;
    } else {
        v3_63_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_64_Addr_A() {
    v3_64_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_64_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_64_Addr_A_orig() {
    v3_64_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_64_Addr_B() {
    v3_64_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_64_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_64_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_64_Addr_B_orig =  (sc_lv<32>) (v3_64_addr_1_reg_19948.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_64_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_64_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_64_Clk_A() {
    v3_64_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_64_Clk_B() {
    v3_64_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_64_Din_A() {
    v3_64_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_64_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        v3_64_Din_B = reg_9680.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_64_Din_B = ap_const_lv32_0;
    } else {
        v3_64_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_64_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v3_64_EN_A = ap_const_logic_1;
    } else {
        v3_64_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_64_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())))) {
        v3_64_EN_B = ap_const_logic_1;
    } else {
        v3_64_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_64_Rst_A() {
    v3_64_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_64_Rst_B() {
    v3_64_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_64_WEN_A() {
    v3_64_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_64_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())))) {
        v3_64_WEN_B = ap_const_lv4_F;
    } else {
        v3_64_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_6_Addr_A() {
    v3_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_6_Addr_A_orig() {
    v3_6_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_6_Addr_B() {
    v3_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_6_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_6_Addr_B_orig =  (sc_lv<32>) (v3_6_addr_1_reg_19525.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_6_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_6_Clk_A() {
    v3_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_6_Clk_B() {
    v3_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_6_Din_A() {
    v3_6_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_6_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_6_Din_B = reg_8888.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_6_Din_B = ap_const_lv32_0;
    } else {
        v3_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_6_EN_A = ap_const_logic_1;
    } else {
        v3_6_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_6_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_6_EN_B = ap_const_logic_1;
    } else {
        v3_6_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_6_Rst_A() {
    v3_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_6_Rst_B() {
    v3_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_6_WEN_A() {
    v3_6_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_6_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_6_WEN_B = ap_const_lv4_F;
    } else {
        v3_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_7_Addr_A() {
    v3_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_7_Addr_A_orig() {
    v3_7_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_7_Addr_B() {
    v3_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_7_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_7_Addr_B_orig =  (sc_lv<32>) (v3_7_addr_1_reg_19531.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_7_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_7_Clk_A() {
    v3_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_7_Clk_B() {
    v3_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_7_Din_A() {
    v3_7_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_7_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_7_Din_B = reg_8894.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_7_Din_B = ap_const_lv32_0;
    } else {
        v3_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_7_EN_A = ap_const_logic_1;
    } else {
        v3_7_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_7_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_7_EN_B = ap_const_logic_1;
    } else {
        v3_7_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_7_Rst_A() {
    v3_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_7_Rst_B() {
    v3_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_7_WEN_A() {
    v3_7_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_7_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_7_WEN_B = ap_const_lv4_F;
    } else {
        v3_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_8_Addr_A() {
    v3_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_8_Addr_A_orig() {
    v3_8_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_8_Addr_B() {
    v3_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_8_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_8_Addr_B_orig =  (sc_lv<32>) (v3_8_addr_1_reg_19537.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_8_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_8_Clk_A() {
    v3_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_8_Clk_B() {
    v3_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_8_Din_A() {
    v3_8_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_8_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_8_Din_B = reg_8900.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_8_Din_B = ap_const_lv32_0;
    } else {
        v3_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_8_EN_A = ap_const_logic_1;
    } else {
        v3_8_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_8_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_8_EN_B = ap_const_logic_1;
    } else {
        v3_8_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_8_Rst_A() {
    v3_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_8_Rst_B() {
    v3_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_8_WEN_A() {
    v3_8_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_8_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_8_WEN_B = ap_const_lv4_F;
    } else {
        v3_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v3_9_Addr_A() {
    v3_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_9_Addr_A_orig() {
    v3_9_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_asdse::thread_v3_9_Addr_B() {
    v3_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v3_9_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_9_Addr_B_orig =  (sc_lv<32>) (v3_9_addr_1_reg_19543.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_9_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_9_Clk_A() {
    v3_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_9_Clk_B() {
    v3_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v3_9_Din_A() {
    v3_9_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v3_9_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_9_Din_B = reg_8906.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_9_Din_B = ap_const_lv32_0;
    } else {
        v3_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_asdse::thread_v3_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_9_EN_A = ap_const_logic_1;
    } else {
        v3_9_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_9_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_9_EN_B = ap_const_logic_1;
    } else {
        v3_9_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v3_9_Rst_A() {
    v3_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_9_Rst_B() {
    v3_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v3_9_WEN_A() {
    v3_9_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v3_9_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln57_fu_10202_p2.read())))) {
        v3_9_WEN_B = ap_const_lv4_F;
    } else {
        v3_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v49_1_fu_10877_p3() {
    v49_1_fu_10877_p3 = (!select_ln125_1_reg_10901.read()[0].is_01())? sc_lv<32>(): ((select_ln125_1_reg_10901.read()[0].to_bool())? ap_const_lv32_0: v4_4_Dout_A.read());
}

void kernel_bicg_asdse::thread_v4_0_Addr_A() {
    v4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_0_Addr_A_orig() {
    v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v4_0_Addr_B() {
    v4_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_0_Addr_B_orig() {
    v4_0_Addr_B_orig =  (sc_lv<32>) (v4_0_addr_reg_12614_pp1_iter33_reg.read());
}

void kernel_bicg_asdse::thread_v4_0_Clk_A() {
    v4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_0_Clk_B() {
    v4_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_0_Din_A() {
    v4_0_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v4_0_Din_B() {
    v4_0_Din_B = reg_9074.read();
}

void kernel_bicg_asdse::thread_v4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v4_0_EN_A = ap_const_logic_1;
    } else {
        v4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()))) {
        v4_0_EN_B = ap_const_logic_1;
    } else {
        v4_0_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_0_Rst_A() {
    v4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_0_Rst_B() {
    v4_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_0_WEN_A() {
    v4_0_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v4_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter33_reg.read()))) {
        v4_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v4_1_Addr_A() {
    v4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_1_Addr_A_orig() {
    v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v4_1_Addr_B() {
    v4_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_1_Addr_B_orig() {
    v4_1_Addr_B_orig =  (sc_lv<32>) (v4_1_addr_reg_12630_pp1_iter33_reg.read());
}

void kernel_bicg_asdse::thread_v4_1_Clk_A() {
    v4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_1_Clk_B() {
    v4_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_1_Din_A() {
    v4_1_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v4_1_Din_B() {
    v4_1_Din_B = reg_9080.read();
}

void kernel_bicg_asdse::thread_v4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v4_1_EN_A = ap_const_logic_1;
    } else {
        v4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()))) {
        v4_1_EN_B = ap_const_logic_1;
    } else {
        v4_1_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_1_Rst_A() {
    v4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_1_Rst_B() {
    v4_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_1_WEN_A() {
    v4_1_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v4_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter33_reg.read()))) {
        v4_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v4_2_Addr_A() {
    v4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_2_Addr_A_orig() {
    v4_2_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v4_2_Addr_B() {
    v4_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_2_Addr_B_orig() {
    v4_2_Addr_B_orig =  (sc_lv<32>) (v4_2_addr_reg_12641_pp1_iter33_reg.read());
}

void kernel_bicg_asdse::thread_v4_2_Clk_A() {
    v4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_2_Clk_B() {
    v4_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_2_Din_A() {
    v4_2_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v4_2_Din_B() {
    v4_2_Din_B = reg_9086.read();
}

void kernel_bicg_asdse::thread_v4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v4_2_EN_A = ap_const_logic_1;
    } else {
        v4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()))) {
        v4_2_EN_B = ap_const_logic_1;
    } else {
        v4_2_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_2_Rst_A() {
    v4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_2_Rst_B() {
    v4_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_2_WEN_A() {
    v4_2_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v4_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter33_reg.read()))) {
        v4_2_WEN_B = ap_const_lv4_F;
    } else {
        v4_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v4_3_Addr_A() {
    v4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_3_Addr_A_orig() {
    v4_3_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v4_3_Addr_B() {
    v4_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_3_Addr_B_orig() {
    v4_3_Addr_B_orig =  (sc_lv<32>) (v4_3_addr_reg_12652_pp1_iter33_reg.read());
}

void kernel_bicg_asdse::thread_v4_3_Clk_A() {
    v4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_3_Clk_B() {
    v4_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_3_Din_A() {
    v4_3_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v4_3_Din_B() {
    v4_3_Din_B = reg_9902.read();
}

void kernel_bicg_asdse::thread_v4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v4_3_EN_A = ap_const_logic_1;
    } else {
        v4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()))) {
        v4_3_EN_B = ap_const_logic_1;
    } else {
        v4_3_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_3_Rst_A() {
    v4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_3_Rst_B() {
    v4_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_3_WEN_A() {
    v4_3_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v4_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter33_reg.read()))) {
        v4_3_WEN_B = ap_const_lv4_F;
    } else {
        v4_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v4_4_Addr_A() {
    v4_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_4_Addr_A_orig() {
    v4_4_Addr_A_orig =  (sc_lv<32>) (zext_ln128_fu_10468_p1.read());
}

void kernel_bicg_asdse::thread_v4_4_Addr_B() {
    v4_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v4_4_Addr_B_orig() {
    v4_4_Addr_B_orig =  (sc_lv<32>) (v4_4_addr_reg_12663_pp1_iter33_reg.read());
}

void kernel_bicg_asdse::thread_v4_4_Clk_A() {
    v4_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_4_Clk_B() {
    v4_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v4_4_Din_A() {
    v4_4_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v4_4_Din_B() {
    v4_4_Din_B = reg_9908.read();
}

void kernel_bicg_asdse::thread_v4_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v4_4_EN_A = ap_const_logic_1;
    } else {
        v4_4_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()))) {
        v4_4_EN_B = ap_const_logic_1;
    } else {
        v4_4_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v4_4_Rst_A() {
    v4_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_4_Rst_B() {
    v4_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v4_4_WEN_A() {
    v4_4_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v4_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter33.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln125_reg_10892_pp1_iter33_reg.read()))) {
        v4_4_WEN_B = ap_const_lv4_F;
    } else {
        v4_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_bicg_asdse::thread_v5_0_Addr_A() {
    v5_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_0_Addr_A_orig() {
    v5_0_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_0_Clk_A() {
    v5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_0_Din_A() {
    v5_0_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_0_EN_A = ap_const_logic_1;
    } else {
        v5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_0_Rst_A() {
    v5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_0_WEN_A() {
    v5_0_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_10_Addr_A() {
    v5_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_10_Addr_A_orig() {
    v5_10_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_10_Clk_A() {
    v5_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_10_Din_A() {
    v5_10_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_10_EN_A = ap_const_logic_1;
    } else {
        v5_10_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_10_Rst_A() {
    v5_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_10_WEN_A() {
    v5_10_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_11_Addr_A() {
    v5_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_11_Addr_A_orig() {
    v5_11_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_11_Clk_A() {
    v5_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_11_Din_A() {
    v5_11_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_11_EN_A = ap_const_logic_1;
    } else {
        v5_11_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_11_Rst_A() {
    v5_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_11_WEN_A() {
    v5_11_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_12_Addr_A() {
    v5_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_12_Addr_A_orig() {
    v5_12_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_12_Clk_A() {
    v5_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_12_Din_A() {
    v5_12_Din_A = ap_const_lv32_0;
}

void kernel_bicg_asdse::thread_v5_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v5_12_EN_A = ap_const_logic_1;
    } else {
        v5_12_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_asdse::thread_v5_12_Rst_A() {
    v5_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_asdse::thread_v5_12_WEN_A() {
    v5_12_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_asdse::thread_v5_13_Addr_A() {
    v5_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_asdse::thread_v5_13_Addr_A_orig() {
    v5_13_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_fu_10395_p1.read());
}

void kernel_bicg_asdse::thread_v5_13_Clk_A() {
    v5_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_asdse::thread_v5_13_Din_A() {
    v5_13_Din_A = ap_const_lv32_0;
}

}


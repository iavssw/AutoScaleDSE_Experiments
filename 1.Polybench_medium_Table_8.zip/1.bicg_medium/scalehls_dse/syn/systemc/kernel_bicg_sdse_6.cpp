#include "kernel_bicg_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_bicg_sdse::thread_v2_2_59_Clk_A() {
    v2_2_59_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_59_Din_A() {
    v2_2_59_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_59_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_59_EN_A = ap_const_logic_1;
    } else {
        v2_2_59_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_59_Rst_A() {
    v2_2_59_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_59_WEN_A() {
    v2_2_59_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_5_Addr_A() {
    v2_2_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_5_Addr_A_orig() {
    v2_2_5_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_5_Clk_A() {
    v2_2_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_5_Din_A() {
    v2_2_5_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_5_EN_A = ap_const_logic_1;
    } else {
        v2_2_5_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_5_Rst_A() {
    v2_2_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_5_WEN_A() {
    v2_2_5_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_60_Addr_A() {
    v2_2_60_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_60_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_60_Addr_A_orig() {
    v2_2_60_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_60_Clk_A() {
    v2_2_60_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_60_Din_A() {
    v2_2_60_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_60_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_60_EN_A = ap_const_logic_1;
    } else {
        v2_2_60_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_60_Rst_A() {
    v2_2_60_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_60_WEN_A() {
    v2_2_60_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_61_Addr_A() {
    v2_2_61_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_61_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_61_Addr_A_orig() {
    v2_2_61_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_61_Clk_A() {
    v2_2_61_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_61_Din_A() {
    v2_2_61_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_61_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_61_EN_A = ap_const_logic_1;
    } else {
        v2_2_61_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_61_Rst_A() {
    v2_2_61_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_61_WEN_A() {
    v2_2_61_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_62_Addr_A() {
    v2_2_62_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_62_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_62_Addr_A_orig() {
    v2_2_62_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_62_Clk_A() {
    v2_2_62_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_62_Din_A() {
    v2_2_62_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_62_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_62_EN_A = ap_const_logic_1;
    } else {
        v2_2_62_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_62_Rst_A() {
    v2_2_62_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_62_WEN_A() {
    v2_2_62_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_63_Addr_A() {
    v2_2_63_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_63_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_63_Addr_A_orig() {
    v2_2_63_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_63_Clk_A() {
    v2_2_63_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_63_Din_A() {
    v2_2_63_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_63_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_63_EN_A = ap_const_logic_1;
    } else {
        v2_2_63_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_63_Rst_A() {
    v2_2_63_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_63_WEN_A() {
    v2_2_63_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_64_Addr_A() {
    v2_2_64_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_64_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_64_Addr_A_orig() {
    v2_2_64_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_64_Clk_A() {
    v2_2_64_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_64_Din_A() {
    v2_2_64_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_64_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_64_EN_A = ap_const_logic_1;
    } else {
        v2_2_64_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_64_Rst_A() {
    v2_2_64_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_64_WEN_A() {
    v2_2_64_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_6_Addr_A() {
    v2_2_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_6_Addr_A_orig() {
    v2_2_6_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_6_Clk_A() {
    v2_2_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_6_Din_A() {
    v2_2_6_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_6_EN_A = ap_const_logic_1;
    } else {
        v2_2_6_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_6_Rst_A() {
    v2_2_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_6_WEN_A() {
    v2_2_6_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_7_Addr_A() {
    v2_2_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_7_Addr_A_orig() {
    v2_2_7_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_7_Clk_A() {
    v2_2_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_7_Din_A() {
    v2_2_7_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_7_EN_A = ap_const_logic_1;
    } else {
        v2_2_7_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_7_Rst_A() {
    v2_2_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_7_WEN_A() {
    v2_2_7_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_8_Addr_A() {
    v2_2_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_8_Addr_A_orig() {
    v2_2_8_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_8_Clk_A() {
    v2_2_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_8_Din_A() {
    v2_2_8_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_8_EN_A = ap_const_logic_1;
    } else {
        v2_2_8_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_8_Rst_A() {
    v2_2_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_8_WEN_A() {
    v2_2_8_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_9_Addr_A() {
    v2_2_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_9_Addr_A_orig() {
    v2_2_9_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_9_Clk_A() {
    v2_2_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_9_Din_A() {
    v2_2_9_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_9_EN_A = ap_const_logic_1;
    } else {
        v2_2_9_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_9_Rst_A() {
    v2_2_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_9_WEN_A() {
    v2_2_9_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_0_Addr_A() {
    v2_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_0_Addr_A_orig() {
    v2_3_0_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_0_Clk_A() {
    v2_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_0_Din_A() {
    v2_3_0_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_0_EN_A = ap_const_logic_1;
    } else {
        v2_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_0_Rst_A() {
    v2_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_0_WEN_A() {
    v2_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_10_Addr_A() {
    v2_3_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_10_Addr_A_orig() {
    v2_3_10_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_10_Clk_A() {
    v2_3_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_10_Din_A() {
    v2_3_10_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_10_EN_A = ap_const_logic_1;
    } else {
        v2_3_10_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_10_Rst_A() {
    v2_3_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_10_WEN_A() {
    v2_3_10_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_11_Addr_A() {
    v2_3_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_11_Addr_A_orig() {
    v2_3_11_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_11_Clk_A() {
    v2_3_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_11_Din_A() {
    v2_3_11_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_11_EN_A = ap_const_logic_1;
    } else {
        v2_3_11_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_11_Rst_A() {
    v2_3_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_11_WEN_A() {
    v2_3_11_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_12_Addr_A() {
    v2_3_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_12_Addr_A_orig() {
    v2_3_12_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_12_Clk_A() {
    v2_3_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_12_Din_A() {
    v2_3_12_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_12_EN_A = ap_const_logic_1;
    } else {
        v2_3_12_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_12_Rst_A() {
    v2_3_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_12_WEN_A() {
    v2_3_12_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_13_Addr_A() {
    v2_3_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_13_Addr_A_orig() {
    v2_3_13_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_13_Clk_A() {
    v2_3_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_13_Din_A() {
    v2_3_13_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_13_EN_A = ap_const_logic_1;
    } else {
        v2_3_13_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_13_Rst_A() {
    v2_3_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_13_WEN_A() {
    v2_3_13_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_14_Addr_A() {
    v2_3_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_14_Addr_A_orig() {
    v2_3_14_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_14_Clk_A() {
    v2_3_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_14_Din_A() {
    v2_3_14_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_14_EN_A = ap_const_logic_1;
    } else {
        v2_3_14_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_14_Rst_A() {
    v2_3_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_14_WEN_A() {
    v2_3_14_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_15_Addr_A() {
    v2_3_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_15_Addr_A_orig() {
    v2_3_15_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_15_Clk_A() {
    v2_3_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_15_Din_A() {
    v2_3_15_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_15_EN_A = ap_const_logic_1;
    } else {
        v2_3_15_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_15_Rst_A() {
    v2_3_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_15_WEN_A() {
    v2_3_15_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_16_Addr_A() {
    v2_3_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_16_Addr_A_orig() {
    v2_3_16_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_16_Clk_A() {
    v2_3_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_16_Din_A() {
    v2_3_16_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_16_EN_A = ap_const_logic_1;
    } else {
        v2_3_16_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_16_Rst_A() {
    v2_3_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_16_WEN_A() {
    v2_3_16_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_17_Addr_A() {
    v2_3_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_17_Addr_A_orig() {
    v2_3_17_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_17_Clk_A() {
    v2_3_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_17_Din_A() {
    v2_3_17_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_17_EN_A = ap_const_logic_1;
    } else {
        v2_3_17_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_17_Rst_A() {
    v2_3_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_17_WEN_A() {
    v2_3_17_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_18_Addr_A() {
    v2_3_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_18_Addr_A_orig() {
    v2_3_18_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_18_Clk_A() {
    v2_3_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_18_Din_A() {
    v2_3_18_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_18_EN_A = ap_const_logic_1;
    } else {
        v2_3_18_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_18_Rst_A() {
    v2_3_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_18_WEN_A() {
    v2_3_18_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_19_Addr_A() {
    v2_3_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_19_Addr_A_orig() {
    v2_3_19_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_19_Clk_A() {
    v2_3_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_19_Din_A() {
    v2_3_19_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_19_EN_A = ap_const_logic_1;
    } else {
        v2_3_19_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_19_Rst_A() {
    v2_3_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_19_WEN_A() {
    v2_3_19_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_1_Addr_A() {
    v2_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_1_Addr_A_orig() {
    v2_3_1_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_1_Clk_A() {
    v2_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_1_Din_A() {
    v2_3_1_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_1_EN_A = ap_const_logic_1;
    } else {
        v2_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_1_Rst_A() {
    v2_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_1_WEN_A() {
    v2_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_20_Addr_A() {
    v2_3_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_20_Addr_A_orig() {
    v2_3_20_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_20_Clk_A() {
    v2_3_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_20_Din_A() {
    v2_3_20_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_20_EN_A = ap_const_logic_1;
    } else {
        v2_3_20_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_20_Rst_A() {
    v2_3_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_20_WEN_A() {
    v2_3_20_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_21_Addr_A() {
    v2_3_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_21_Addr_A_orig() {
    v2_3_21_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_21_Clk_A() {
    v2_3_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_21_Din_A() {
    v2_3_21_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_21_EN_A = ap_const_logic_1;
    } else {
        v2_3_21_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_21_Rst_A() {
    v2_3_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_21_WEN_A() {
    v2_3_21_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_22_Addr_A() {
    v2_3_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_22_Addr_A_orig() {
    v2_3_22_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_22_Clk_A() {
    v2_3_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_22_Din_A() {
    v2_3_22_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_22_EN_A = ap_const_logic_1;
    } else {
        v2_3_22_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_22_Rst_A() {
    v2_3_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_22_WEN_A() {
    v2_3_22_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_23_Addr_A() {
    v2_3_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_23_Addr_A_orig() {
    v2_3_23_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_23_Clk_A() {
    v2_3_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_23_Din_A() {
    v2_3_23_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_23_EN_A = ap_const_logic_1;
    } else {
        v2_3_23_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_23_Rst_A() {
    v2_3_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_23_WEN_A() {
    v2_3_23_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_24_Addr_A() {
    v2_3_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_24_Addr_A_orig() {
    v2_3_24_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_24_Clk_A() {
    v2_3_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_24_Din_A() {
    v2_3_24_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_24_EN_A = ap_const_logic_1;
    } else {
        v2_3_24_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_24_Rst_A() {
    v2_3_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_24_WEN_A() {
    v2_3_24_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_25_Addr_A() {
    v2_3_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_25_Addr_A_orig() {
    v2_3_25_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_25_Clk_A() {
    v2_3_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_25_Din_A() {
    v2_3_25_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_25_EN_A = ap_const_logic_1;
    } else {
        v2_3_25_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_25_Rst_A() {
    v2_3_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_25_WEN_A() {
    v2_3_25_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_26_Addr_A() {
    v2_3_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_26_Addr_A_orig() {
    v2_3_26_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_26_Clk_A() {
    v2_3_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_26_Din_A() {
    v2_3_26_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_26_EN_A = ap_const_logic_1;
    } else {
        v2_3_26_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_26_Rst_A() {
    v2_3_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_26_WEN_A() {
    v2_3_26_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_27_Addr_A() {
    v2_3_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_27_Addr_A_orig() {
    v2_3_27_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_27_Clk_A() {
    v2_3_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_27_Din_A() {
    v2_3_27_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_27_EN_A = ap_const_logic_1;
    } else {
        v2_3_27_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_27_Rst_A() {
    v2_3_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_27_WEN_A() {
    v2_3_27_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_28_Addr_A() {
    v2_3_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_28_Addr_A_orig() {
    v2_3_28_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_28_Clk_A() {
    v2_3_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_28_Din_A() {
    v2_3_28_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_28_EN_A = ap_const_logic_1;
    } else {
        v2_3_28_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_28_Rst_A() {
    v2_3_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_28_WEN_A() {
    v2_3_28_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_29_Addr_A() {
    v2_3_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_29_Addr_A_orig() {
    v2_3_29_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_29_Clk_A() {
    v2_3_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_29_Din_A() {
    v2_3_29_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_29_EN_A = ap_const_logic_1;
    } else {
        v2_3_29_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_29_Rst_A() {
    v2_3_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_29_WEN_A() {
    v2_3_29_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_2_Addr_A() {
    v2_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_2_Addr_A_orig() {
    v2_3_2_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_2_Clk_A() {
    v2_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_2_Din_A() {
    v2_3_2_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_2_EN_A = ap_const_logic_1;
    } else {
        v2_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_2_Rst_A() {
    v2_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_2_WEN_A() {
    v2_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_30_Addr_A() {
    v2_3_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_30_Addr_A_orig() {
    v2_3_30_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_30_Clk_A() {
    v2_3_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_30_Din_A() {
    v2_3_30_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_30_EN_A = ap_const_logic_1;
    } else {
        v2_3_30_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_30_Rst_A() {
    v2_3_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_30_WEN_A() {
    v2_3_30_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_31_Addr_A() {
    v2_3_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_31_Addr_A_orig() {
    v2_3_31_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_31_Clk_A() {
    v2_3_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_31_Din_A() {
    v2_3_31_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_31_EN_A = ap_const_logic_1;
    } else {
        v2_3_31_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_31_Rst_A() {
    v2_3_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_31_WEN_A() {
    v2_3_31_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_32_Addr_A() {
    v2_3_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_32_Addr_A_orig() {
    v2_3_32_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_32_Clk_A() {
    v2_3_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_32_Din_A() {
    v2_3_32_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_32_EN_A = ap_const_logic_1;
    } else {
        v2_3_32_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_32_Rst_A() {
    v2_3_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_32_WEN_A() {
    v2_3_32_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_33_Addr_A() {
    v2_3_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_33_Addr_A_orig() {
    v2_3_33_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_33_Clk_A() {
    v2_3_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_33_Din_A() {
    v2_3_33_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_33_EN_A = ap_const_logic_1;
    } else {
        v2_3_33_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_33_Rst_A() {
    v2_3_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_33_WEN_A() {
    v2_3_33_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_34_Addr_A() {
    v2_3_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_34_Addr_A_orig() {
    v2_3_34_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_34_Clk_A() {
    v2_3_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_34_Din_A() {
    v2_3_34_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_34_EN_A = ap_const_logic_1;
    } else {
        v2_3_34_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_34_Rst_A() {
    v2_3_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_34_WEN_A() {
    v2_3_34_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_35_Addr_A() {
    v2_3_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_35_Addr_A_orig() {
    v2_3_35_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_35_Clk_A() {
    v2_3_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_35_Din_A() {
    v2_3_35_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_35_EN_A = ap_const_logic_1;
    } else {
        v2_3_35_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_35_Rst_A() {
    v2_3_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_35_WEN_A() {
    v2_3_35_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_36_Addr_A() {
    v2_3_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_36_Addr_A_orig() {
    v2_3_36_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_36_Clk_A() {
    v2_3_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_36_Din_A() {
    v2_3_36_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_36_EN_A = ap_const_logic_1;
    } else {
        v2_3_36_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_36_Rst_A() {
    v2_3_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_36_WEN_A() {
    v2_3_36_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_37_Addr_A() {
    v2_3_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_37_Addr_A_orig() {
    v2_3_37_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_37_Clk_A() {
    v2_3_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_37_Din_A() {
    v2_3_37_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_37_EN_A = ap_const_logic_1;
    } else {
        v2_3_37_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_37_Rst_A() {
    v2_3_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_37_WEN_A() {
    v2_3_37_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_38_Addr_A() {
    v2_3_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_38_Addr_A_orig() {
    v2_3_38_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_38_Clk_A() {
    v2_3_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_38_Din_A() {
    v2_3_38_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_38_EN_A = ap_const_logic_1;
    } else {
        v2_3_38_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_38_Rst_A() {
    v2_3_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_38_WEN_A() {
    v2_3_38_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_39_Addr_A() {
    v2_3_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_39_Addr_A_orig() {
    v2_3_39_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_39_Clk_A() {
    v2_3_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_39_Din_A() {
    v2_3_39_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_39_EN_A = ap_const_logic_1;
    } else {
        v2_3_39_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_39_Rst_A() {
    v2_3_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_39_WEN_A() {
    v2_3_39_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_3_Addr_A() {
    v2_3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_3_Addr_A_orig() {
    v2_3_3_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_3_Clk_A() {
    v2_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_3_Din_A() {
    v2_3_3_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_3_EN_A = ap_const_logic_1;
    } else {
        v2_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_3_Rst_A() {
    v2_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_3_WEN_A() {
    v2_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_40_Addr_A() {
    v2_3_40_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_40_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_40_Addr_A_orig() {
    v2_3_40_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_40_Clk_A() {
    v2_3_40_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_40_Din_A() {
    v2_3_40_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_40_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_40_EN_A = ap_const_logic_1;
    } else {
        v2_3_40_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_40_Rst_A() {
    v2_3_40_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_40_WEN_A() {
    v2_3_40_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_41_Addr_A() {
    v2_3_41_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_41_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_41_Addr_A_orig() {
    v2_3_41_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_41_Clk_A() {
    v2_3_41_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_41_Din_A() {
    v2_3_41_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_41_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_41_EN_A = ap_const_logic_1;
    } else {
        v2_3_41_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_41_Rst_A() {
    v2_3_41_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_41_WEN_A() {
    v2_3_41_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_42_Addr_A() {
    v2_3_42_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_42_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_42_Addr_A_orig() {
    v2_3_42_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_42_Clk_A() {
    v2_3_42_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_42_Din_A() {
    v2_3_42_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_42_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_42_EN_A = ap_const_logic_1;
    } else {
        v2_3_42_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_42_Rst_A() {
    v2_3_42_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_42_WEN_A() {
    v2_3_42_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_43_Addr_A() {
    v2_3_43_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_43_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_43_Addr_A_orig() {
    v2_3_43_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_43_Clk_A() {
    v2_3_43_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_43_Din_A() {
    v2_3_43_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_43_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_43_EN_A = ap_const_logic_1;
    } else {
        v2_3_43_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_43_Rst_A() {
    v2_3_43_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_43_WEN_A() {
    v2_3_43_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_44_Addr_A() {
    v2_3_44_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_44_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_44_Addr_A_orig() {
    v2_3_44_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_44_Clk_A() {
    v2_3_44_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_44_Din_A() {
    v2_3_44_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_44_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_44_EN_A = ap_const_logic_1;
    } else {
        v2_3_44_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_44_Rst_A() {
    v2_3_44_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_44_WEN_A() {
    v2_3_44_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_45_Addr_A() {
    v2_3_45_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_45_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_45_Addr_A_orig() {
    v2_3_45_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_45_Clk_A() {
    v2_3_45_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_45_Din_A() {
    v2_3_45_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_45_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_45_EN_A = ap_const_logic_1;
    } else {
        v2_3_45_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_45_Rst_A() {
    v2_3_45_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_45_WEN_A() {
    v2_3_45_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_46_Addr_A() {
    v2_3_46_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_46_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_46_Addr_A_orig() {
    v2_3_46_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_46_Clk_A() {
    v2_3_46_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_46_Din_A() {
    v2_3_46_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_46_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_46_EN_A = ap_const_logic_1;
    } else {
        v2_3_46_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_46_Rst_A() {
    v2_3_46_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_46_WEN_A() {
    v2_3_46_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_47_Addr_A() {
    v2_3_47_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_47_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_47_Addr_A_orig() {
    v2_3_47_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_47_Clk_A() {
    v2_3_47_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_47_Din_A() {
    v2_3_47_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_47_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_47_EN_A = ap_const_logic_1;
    } else {
        v2_3_47_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_47_Rst_A() {
    v2_3_47_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_47_WEN_A() {
    v2_3_47_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_48_Addr_A() {
    v2_3_48_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_48_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_48_Addr_A_orig() {
    v2_3_48_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_48_Clk_A() {
    v2_3_48_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_48_Din_A() {
    v2_3_48_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_48_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_48_EN_A = ap_const_logic_1;
    } else {
        v2_3_48_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_48_Rst_A() {
    v2_3_48_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_48_WEN_A() {
    v2_3_48_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_49_Addr_A() {
    v2_3_49_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_49_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_49_Addr_A_orig() {
    v2_3_49_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_49_Clk_A() {
    v2_3_49_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_49_Din_A() {
    v2_3_49_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_49_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_49_EN_A = ap_const_logic_1;
    } else {
        v2_3_49_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_49_Rst_A() {
    v2_3_49_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_49_WEN_A() {
    v2_3_49_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_4_Addr_A() {
    v2_3_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_4_Addr_A_orig() {
    v2_3_4_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_4_Clk_A() {
    v2_3_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_4_Din_A() {
    v2_3_4_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_4_EN_A = ap_const_logic_1;
    } else {
        v2_3_4_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_4_Rst_A() {
    v2_3_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_4_WEN_A() {
    v2_3_4_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_50_Addr_A() {
    v2_3_50_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_50_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_50_Addr_A_orig() {
    v2_3_50_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_50_Clk_A() {
    v2_3_50_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_50_Din_A() {
    v2_3_50_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_50_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_50_EN_A = ap_const_logic_1;
    } else {
        v2_3_50_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_50_Rst_A() {
    v2_3_50_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_50_WEN_A() {
    v2_3_50_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_51_Addr_A() {
    v2_3_51_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_51_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_51_Addr_A_orig() {
    v2_3_51_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_51_Clk_A() {
    v2_3_51_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_51_Din_A() {
    v2_3_51_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_51_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_51_EN_A = ap_const_logic_1;
    } else {
        v2_3_51_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_51_Rst_A() {
    v2_3_51_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_51_WEN_A() {
    v2_3_51_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_52_Addr_A() {
    v2_3_52_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_52_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_52_Addr_A_orig() {
    v2_3_52_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_52_Clk_A() {
    v2_3_52_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_52_Din_A() {
    v2_3_52_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_52_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_52_EN_A = ap_const_logic_1;
    } else {
        v2_3_52_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_52_Rst_A() {
    v2_3_52_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_52_WEN_A() {
    v2_3_52_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_53_Addr_A() {
    v2_3_53_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_53_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_53_Addr_A_orig() {
    v2_3_53_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_53_Clk_A() {
    v2_3_53_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_53_Din_A() {
    v2_3_53_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_53_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_53_EN_A = ap_const_logic_1;
    } else {
        v2_3_53_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_53_Rst_A() {
    v2_3_53_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_53_WEN_A() {
    v2_3_53_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_54_Addr_A() {
    v2_3_54_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_54_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_54_Addr_A_orig() {
    v2_3_54_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_54_Clk_A() {
    v2_3_54_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_54_Din_A() {
    v2_3_54_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_54_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_54_EN_A = ap_const_logic_1;
    } else {
        v2_3_54_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_54_Rst_A() {
    v2_3_54_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_54_WEN_A() {
    v2_3_54_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_55_Addr_A() {
    v2_3_55_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_55_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_55_Addr_A_orig() {
    v2_3_55_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_55_Clk_A() {
    v2_3_55_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_55_Din_A() {
    v2_3_55_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_55_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_55_EN_A = ap_const_logic_1;
    } else {
        v2_3_55_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_55_Rst_A() {
    v2_3_55_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_55_WEN_A() {
    v2_3_55_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_56_Addr_A() {
    v2_3_56_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_56_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_56_Addr_A_orig() {
    v2_3_56_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_56_Clk_A() {
    v2_3_56_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_56_Din_A() {
    v2_3_56_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_56_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_56_EN_A = ap_const_logic_1;
    } else {
        v2_3_56_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_56_Rst_A() {
    v2_3_56_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_56_WEN_A() {
    v2_3_56_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_57_Addr_A() {
    v2_3_57_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_57_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_57_Addr_A_orig() {
    v2_3_57_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_57_Clk_A() {
    v2_3_57_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_57_Din_A() {
    v2_3_57_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_57_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_57_EN_A = ap_const_logic_1;
    } else {
        v2_3_57_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_57_Rst_A() {
    v2_3_57_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_57_WEN_A() {
    v2_3_57_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_58_Addr_A() {
    v2_3_58_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_58_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_58_Addr_A_orig() {
    v2_3_58_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_58_Clk_A() {
    v2_3_58_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_58_Din_A() {
    v2_3_58_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_58_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_58_EN_A = ap_const_logic_1;
    } else {
        v2_3_58_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_58_Rst_A() {
    v2_3_58_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_58_WEN_A() {
    v2_3_58_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_59_Addr_A() {
    v2_3_59_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_59_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_59_Addr_A_orig() {
    v2_3_59_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_59_Clk_A() {
    v2_3_59_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_59_Din_A() {
    v2_3_59_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_59_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_59_EN_A = ap_const_logic_1;
    } else {
        v2_3_59_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_59_Rst_A() {
    v2_3_59_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_59_WEN_A() {
    v2_3_59_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_5_Addr_A() {
    v2_3_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_5_Addr_A_orig() {
    v2_3_5_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_5_Clk_A() {
    v2_3_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_5_Din_A() {
    v2_3_5_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_5_EN_A = ap_const_logic_1;
    } else {
        v2_3_5_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_5_Rst_A() {
    v2_3_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_5_WEN_A() {
    v2_3_5_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_60_Addr_A() {
    v2_3_60_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_60_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_60_Addr_A_orig() {
    v2_3_60_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_60_Clk_A() {
    v2_3_60_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_60_Din_A() {
    v2_3_60_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_60_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_60_EN_A = ap_const_logic_1;
    } else {
        v2_3_60_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_60_Rst_A() {
    v2_3_60_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_60_WEN_A() {
    v2_3_60_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_61_Addr_A() {
    v2_3_61_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_61_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_61_Addr_A_orig() {
    v2_3_61_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_61_Clk_A() {
    v2_3_61_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_61_Din_A() {
    v2_3_61_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_61_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_61_EN_A = ap_const_logic_1;
    } else {
        v2_3_61_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_61_Rst_A() {
    v2_3_61_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_61_WEN_A() {
    v2_3_61_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_62_Addr_A() {
    v2_3_62_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_62_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_62_Addr_A_orig() {
    v2_3_62_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_62_Clk_A() {
    v2_3_62_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_62_Din_A() {
    v2_3_62_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_62_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_62_EN_A = ap_const_logic_1;
    } else {
        v2_3_62_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_62_Rst_A() {
    v2_3_62_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_62_WEN_A() {
    v2_3_62_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_63_Addr_A() {
    v2_3_63_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_63_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_63_Addr_A_orig() {
    v2_3_63_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_63_Clk_A() {
    v2_3_63_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_63_Din_A() {
    v2_3_63_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_63_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_63_EN_A = ap_const_logic_1;
    } else {
        v2_3_63_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_63_Rst_A() {
    v2_3_63_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_63_WEN_A() {
    v2_3_63_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_64_Addr_A() {
    v2_3_64_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_64_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_64_Addr_A_orig() {
    v2_3_64_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_64_Clk_A() {
    v2_3_64_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_64_Din_A() {
    v2_3_64_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_64_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_64_EN_A = ap_const_logic_1;
    } else {
        v2_3_64_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_64_Rst_A() {
    v2_3_64_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_64_WEN_A() {
    v2_3_64_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_6_Addr_A() {
    v2_3_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_6_Addr_A_orig() {
    v2_3_6_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_6_Clk_A() {
    v2_3_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_6_Din_A() {
    v2_3_6_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_6_EN_A = ap_const_logic_1;
    } else {
        v2_3_6_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_6_Rst_A() {
    v2_3_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_6_WEN_A() {
    v2_3_6_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_7_Addr_A() {
    v2_3_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_7_Addr_A_orig() {
    v2_3_7_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_7_Clk_A() {
    v2_3_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_7_Din_A() {
    v2_3_7_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_7_EN_A = ap_const_logic_1;
    } else {
        v2_3_7_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_7_Rst_A() {
    v2_3_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_7_WEN_A() {
    v2_3_7_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_8_Addr_A() {
    v2_3_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_8_Addr_A_orig() {
    v2_3_8_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_8_Clk_A() {
    v2_3_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_8_Din_A() {
    v2_3_8_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_8_EN_A = ap_const_logic_1;
    } else {
        v2_3_8_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_8_Rst_A() {
    v2_3_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_8_WEN_A() {
    v2_3_8_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_3_9_Addr_A() {
    v2_3_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_3_9_Addr_A_orig() {
    v2_3_9_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_3_9_Clk_A() {
    v2_3_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_3_9_Din_A() {
    v2_3_9_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_3_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_3_9_EN_A = ap_const_logic_1;
    } else {
        v2_3_9_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_3_9_Rst_A() {
    v2_3_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_3_9_WEN_A() {
    v2_3_9_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_0_Addr_A() {
    v2_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_0_Addr_A_orig() {
    v2_4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_0_Clk_A() {
    v2_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_0_Din_A() {
    v2_4_0_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_0_EN_A = ap_const_logic_1;
    } else {
        v2_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_0_Rst_A() {
    v2_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_0_WEN_A() {
    v2_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_10_Addr_A() {
    v2_4_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_10_Addr_A_orig() {
    v2_4_10_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_10_Clk_A() {
    v2_4_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_10_Din_A() {
    v2_4_10_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_10_EN_A = ap_const_logic_1;
    } else {
        v2_4_10_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_10_Rst_A() {
    v2_4_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_10_WEN_A() {
    v2_4_10_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_11_Addr_A() {
    v2_4_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_11_Addr_A_orig() {
    v2_4_11_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_11_Clk_A() {
    v2_4_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_11_Din_A() {
    v2_4_11_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_11_EN_A = ap_const_logic_1;
    } else {
        v2_4_11_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_11_Rst_A() {
    v2_4_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_11_WEN_A() {
    v2_4_11_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_12_Addr_A() {
    v2_4_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_12_Addr_A_orig() {
    v2_4_12_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_12_Clk_A() {
    v2_4_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_12_Din_A() {
    v2_4_12_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_12_EN_A = ap_const_logic_1;
    } else {
        v2_4_12_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_12_Rst_A() {
    v2_4_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_12_WEN_A() {
    v2_4_12_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_13_Addr_A() {
    v2_4_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_13_Addr_A_orig() {
    v2_4_13_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_13_Clk_A() {
    v2_4_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_13_Din_A() {
    v2_4_13_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_13_EN_A = ap_const_logic_1;
    } else {
        v2_4_13_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_13_Rst_A() {
    v2_4_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_13_WEN_A() {
    v2_4_13_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_14_Addr_A() {
    v2_4_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_14_Addr_A_orig() {
    v2_4_14_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_14_Clk_A() {
    v2_4_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_14_Din_A() {
    v2_4_14_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_14_EN_A = ap_const_logic_1;
    } else {
        v2_4_14_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_14_Rst_A() {
    v2_4_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_14_WEN_A() {
    v2_4_14_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_15_Addr_A() {
    v2_4_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_15_Addr_A_orig() {
    v2_4_15_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_15_Clk_A() {
    v2_4_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_15_Din_A() {
    v2_4_15_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_15_EN_A = ap_const_logic_1;
    } else {
        v2_4_15_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_15_Rst_A() {
    v2_4_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_15_WEN_A() {
    v2_4_15_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_16_Addr_A() {
    v2_4_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_16_Addr_A_orig() {
    v2_4_16_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_16_Clk_A() {
    v2_4_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_16_Din_A() {
    v2_4_16_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_16_EN_A = ap_const_logic_1;
    } else {
        v2_4_16_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_16_Rst_A() {
    v2_4_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_16_WEN_A() {
    v2_4_16_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_17_Addr_A() {
    v2_4_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_17_Addr_A_orig() {
    v2_4_17_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_17_Clk_A() {
    v2_4_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_17_Din_A() {
    v2_4_17_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_17_EN_A = ap_const_logic_1;
    } else {
        v2_4_17_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_17_Rst_A() {
    v2_4_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_17_WEN_A() {
    v2_4_17_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_18_Addr_A() {
    v2_4_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_18_Addr_A_orig() {
    v2_4_18_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_18_Clk_A() {
    v2_4_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_18_Din_A() {
    v2_4_18_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_18_EN_A = ap_const_logic_1;
    } else {
        v2_4_18_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_18_Rst_A() {
    v2_4_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_18_WEN_A() {
    v2_4_18_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_19_Addr_A() {
    v2_4_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_19_Addr_A_orig() {
    v2_4_19_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_19_Clk_A() {
    v2_4_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_19_Din_A() {
    v2_4_19_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_19_EN_A = ap_const_logic_1;
    } else {
        v2_4_19_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_19_Rst_A() {
    v2_4_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_19_WEN_A() {
    v2_4_19_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_1_Addr_A() {
    v2_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_1_Addr_A_orig() {
    v2_4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_1_Clk_A() {
    v2_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_1_Din_A() {
    v2_4_1_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_1_EN_A = ap_const_logic_1;
    } else {
        v2_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_1_Rst_A() {
    v2_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_1_WEN_A() {
    v2_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_20_Addr_A() {
    v2_4_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_20_Addr_A_orig() {
    v2_4_20_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_20_Clk_A() {
    v2_4_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_20_Din_A() {
    v2_4_20_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_20_EN_A = ap_const_logic_1;
    } else {
        v2_4_20_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_20_Rst_A() {
    v2_4_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_20_WEN_A() {
    v2_4_20_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_21_Addr_A() {
    v2_4_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_21_Addr_A_orig() {
    v2_4_21_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_21_Clk_A() {
    v2_4_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_21_Din_A() {
    v2_4_21_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_21_EN_A = ap_const_logic_1;
    } else {
        v2_4_21_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_21_Rst_A() {
    v2_4_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_21_WEN_A() {
    v2_4_21_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_22_Addr_A() {
    v2_4_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_22_Addr_A_orig() {
    v2_4_22_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_22_Clk_A() {
    v2_4_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_22_Din_A() {
    v2_4_22_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_22_EN_A = ap_const_logic_1;
    } else {
        v2_4_22_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_22_Rst_A() {
    v2_4_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_22_WEN_A() {
    v2_4_22_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_23_Addr_A() {
    v2_4_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_23_Addr_A_orig() {
    v2_4_23_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_23_Clk_A() {
    v2_4_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_23_Din_A() {
    v2_4_23_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_23_EN_A = ap_const_logic_1;
    } else {
        v2_4_23_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_23_Rst_A() {
    v2_4_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_23_WEN_A() {
    v2_4_23_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_24_Addr_A() {
    v2_4_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_24_Addr_A_orig() {
    v2_4_24_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_24_Clk_A() {
    v2_4_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_24_Din_A() {
    v2_4_24_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_24_EN_A = ap_const_logic_1;
    } else {
        v2_4_24_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_24_Rst_A() {
    v2_4_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_24_WEN_A() {
    v2_4_24_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_25_Addr_A() {
    v2_4_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_25_Addr_A_orig() {
    v2_4_25_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_25_Clk_A() {
    v2_4_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_25_Din_A() {
    v2_4_25_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_25_EN_A = ap_const_logic_1;
    } else {
        v2_4_25_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_25_Rst_A() {
    v2_4_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_25_WEN_A() {
    v2_4_25_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_26_Addr_A() {
    v2_4_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_26_Addr_A_orig() {
    v2_4_26_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_26_Clk_A() {
    v2_4_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_26_Din_A() {
    v2_4_26_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_26_EN_A = ap_const_logic_1;
    } else {
        v2_4_26_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_26_Rst_A() {
    v2_4_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_26_WEN_A() {
    v2_4_26_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_27_Addr_A() {
    v2_4_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_27_Addr_A_orig() {
    v2_4_27_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_27_Clk_A() {
    v2_4_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_27_Din_A() {
    v2_4_27_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_27_EN_A = ap_const_logic_1;
    } else {
        v2_4_27_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_27_Rst_A() {
    v2_4_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_27_WEN_A() {
    v2_4_27_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_28_Addr_A() {
    v2_4_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_28_Addr_A_orig() {
    v2_4_28_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_28_Clk_A() {
    v2_4_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_28_Din_A() {
    v2_4_28_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_28_EN_A = ap_const_logic_1;
    } else {
        v2_4_28_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_28_Rst_A() {
    v2_4_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_28_WEN_A() {
    v2_4_28_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_29_Addr_A() {
    v2_4_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_29_Addr_A_orig() {
    v2_4_29_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_29_Clk_A() {
    v2_4_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_29_Din_A() {
    v2_4_29_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_29_EN_A = ap_const_logic_1;
    } else {
        v2_4_29_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_29_Rst_A() {
    v2_4_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_29_WEN_A() {
    v2_4_29_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_2_Addr_A() {
    v2_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_2_Addr_A_orig() {
    v2_4_2_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_2_Clk_A() {
    v2_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_2_Din_A() {
    v2_4_2_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_2_EN_A = ap_const_logic_1;
    } else {
        v2_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_2_Rst_A() {
    v2_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_2_WEN_A() {
    v2_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_30_Addr_A() {
    v2_4_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_30_Addr_A_orig() {
    v2_4_30_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_30_Clk_A() {
    v2_4_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_30_Din_A() {
    v2_4_30_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_30_EN_A = ap_const_logic_1;
    } else {
        v2_4_30_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_30_Rst_A() {
    v2_4_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_30_WEN_A() {
    v2_4_30_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_31_Addr_A() {
    v2_4_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_31_Addr_A_orig() {
    v2_4_31_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_31_Clk_A() {
    v2_4_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_31_Din_A() {
    v2_4_31_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_31_EN_A = ap_const_logic_1;
    } else {
        v2_4_31_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_31_Rst_A() {
    v2_4_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_31_WEN_A() {
    v2_4_31_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_32_Addr_A() {
    v2_4_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_32_Addr_A_orig() {
    v2_4_32_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_32_Clk_A() {
    v2_4_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_32_Din_A() {
    v2_4_32_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_32_EN_A = ap_const_logic_1;
    } else {
        v2_4_32_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_32_Rst_A() {
    v2_4_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_32_WEN_A() {
    v2_4_32_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_33_Addr_A() {
    v2_4_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_33_Addr_A_orig() {
    v2_4_33_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_33_Clk_A() {
    v2_4_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_33_Din_A() {
    v2_4_33_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_33_EN_A = ap_const_logic_1;
    } else {
        v2_4_33_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_33_Rst_A() {
    v2_4_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_33_WEN_A() {
    v2_4_33_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_34_Addr_A() {
    v2_4_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_34_Addr_A_orig() {
    v2_4_34_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_34_Clk_A() {
    v2_4_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_34_Din_A() {
    v2_4_34_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_34_EN_A = ap_const_logic_1;
    } else {
        v2_4_34_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_34_Rst_A() {
    v2_4_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_34_WEN_A() {
    v2_4_34_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_35_Addr_A() {
    v2_4_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_35_Addr_A_orig() {
    v2_4_35_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_35_Clk_A() {
    v2_4_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_35_Din_A() {
    v2_4_35_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_35_EN_A = ap_const_logic_1;
    } else {
        v2_4_35_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_35_Rst_A() {
    v2_4_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_35_WEN_A() {
    v2_4_35_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_36_Addr_A() {
    v2_4_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_36_Addr_A_orig() {
    v2_4_36_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_36_Clk_A() {
    v2_4_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_36_Din_A() {
    v2_4_36_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_36_EN_A = ap_const_logic_1;
    } else {
        v2_4_36_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_36_Rst_A() {
    v2_4_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_36_WEN_A() {
    v2_4_36_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_37_Addr_A() {
    v2_4_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_37_Addr_A_orig() {
    v2_4_37_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_37_Clk_A() {
    v2_4_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_37_Din_A() {
    v2_4_37_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_37_EN_A = ap_const_logic_1;
    } else {
        v2_4_37_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_37_Rst_A() {
    v2_4_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_37_WEN_A() {
    v2_4_37_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_38_Addr_A() {
    v2_4_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_38_Addr_A_orig() {
    v2_4_38_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_38_Clk_A() {
    v2_4_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_38_Din_A() {
    v2_4_38_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_38_EN_A = ap_const_logic_1;
    } else {
        v2_4_38_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_38_Rst_A() {
    v2_4_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_38_WEN_A() {
    v2_4_38_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_39_Addr_A() {
    v2_4_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_39_Addr_A_orig() {
    v2_4_39_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_39_Clk_A() {
    v2_4_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_39_Din_A() {
    v2_4_39_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_39_EN_A = ap_const_logic_1;
    } else {
        v2_4_39_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_39_Rst_A() {
    v2_4_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_39_WEN_A() {
    v2_4_39_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_3_Addr_A() {
    v2_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_3_Addr_A_orig() {
    v2_4_3_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_3_Clk_A() {
    v2_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_3_Din_A() {
    v2_4_3_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_3_EN_A = ap_const_logic_1;
    } else {
        v2_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_3_Rst_A() {
    v2_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_3_WEN_A() {
    v2_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_40_Addr_A() {
    v2_4_40_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_40_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_40_Addr_A_orig() {
    v2_4_40_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_40_Clk_A() {
    v2_4_40_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_40_Din_A() {
    v2_4_40_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_40_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_40_EN_A = ap_const_logic_1;
    } else {
        v2_4_40_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_40_Rst_A() {
    v2_4_40_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_40_WEN_A() {
    v2_4_40_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_41_Addr_A() {
    v2_4_41_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_41_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_41_Addr_A_orig() {
    v2_4_41_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_41_Clk_A() {
    v2_4_41_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_41_Din_A() {
    v2_4_41_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_41_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_41_EN_A = ap_const_logic_1;
    } else {
        v2_4_41_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_41_Rst_A() {
    v2_4_41_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_41_WEN_A() {
    v2_4_41_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_42_Addr_A() {
    v2_4_42_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_42_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_42_Addr_A_orig() {
    v2_4_42_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_42_Clk_A() {
    v2_4_42_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_42_Din_A() {
    v2_4_42_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_42_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_42_EN_A = ap_const_logic_1;
    } else {
        v2_4_42_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_42_Rst_A() {
    v2_4_42_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_42_WEN_A() {
    v2_4_42_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_43_Addr_A() {
    v2_4_43_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_43_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_43_Addr_A_orig() {
    v2_4_43_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_43_Clk_A() {
    v2_4_43_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_43_Din_A() {
    v2_4_43_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_43_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_43_EN_A = ap_const_logic_1;
    } else {
        v2_4_43_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_43_Rst_A() {
    v2_4_43_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_43_WEN_A() {
    v2_4_43_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_44_Addr_A() {
    v2_4_44_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_44_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_44_Addr_A_orig() {
    v2_4_44_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_44_Clk_A() {
    v2_4_44_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_44_Din_A() {
    v2_4_44_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_44_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_44_EN_A = ap_const_logic_1;
    } else {
        v2_4_44_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_44_Rst_A() {
    v2_4_44_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_44_WEN_A() {
    v2_4_44_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_45_Addr_A() {
    v2_4_45_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_45_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_45_Addr_A_orig() {
    v2_4_45_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_45_Clk_A() {
    v2_4_45_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_45_Din_A() {
    v2_4_45_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_45_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_45_EN_A = ap_const_logic_1;
    } else {
        v2_4_45_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_45_Rst_A() {
    v2_4_45_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_45_WEN_A() {
    v2_4_45_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_46_Addr_A() {
    v2_4_46_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_46_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_46_Addr_A_orig() {
    v2_4_46_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_46_Clk_A() {
    v2_4_46_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_46_Din_A() {
    v2_4_46_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_46_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_46_EN_A = ap_const_logic_1;
    } else {
        v2_4_46_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_46_Rst_A() {
    v2_4_46_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_46_WEN_A() {
    v2_4_46_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_47_Addr_A() {
    v2_4_47_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_47_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_47_Addr_A_orig() {
    v2_4_47_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_47_Clk_A() {
    v2_4_47_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_47_Din_A() {
    v2_4_47_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_47_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_47_EN_A = ap_const_logic_1;
    } else {
        v2_4_47_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_47_Rst_A() {
    v2_4_47_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_47_WEN_A() {
    v2_4_47_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_48_Addr_A() {
    v2_4_48_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_48_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_48_Addr_A_orig() {
    v2_4_48_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_48_Clk_A() {
    v2_4_48_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_48_Din_A() {
    v2_4_48_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_48_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_48_EN_A = ap_const_logic_1;
    } else {
        v2_4_48_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_48_Rst_A() {
    v2_4_48_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_48_WEN_A() {
    v2_4_48_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_49_Addr_A() {
    v2_4_49_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_49_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_49_Addr_A_orig() {
    v2_4_49_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_49_Clk_A() {
    v2_4_49_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_49_Din_A() {
    v2_4_49_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_49_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_49_EN_A = ap_const_logic_1;
    } else {
        v2_4_49_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_49_Rst_A() {
    v2_4_49_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_49_WEN_A() {
    v2_4_49_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_4_Addr_A() {
    v2_4_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_4_Addr_A_orig() {
    v2_4_4_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_4_Clk_A() {
    v2_4_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_4_Din_A() {
    v2_4_4_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_4_EN_A = ap_const_logic_1;
    } else {
        v2_4_4_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_4_Rst_A() {
    v2_4_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_4_WEN_A() {
    v2_4_4_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_50_Addr_A() {
    v2_4_50_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_50_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_50_Addr_A_orig() {
    v2_4_50_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_50_Clk_A() {
    v2_4_50_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_50_Din_A() {
    v2_4_50_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_50_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_50_EN_A = ap_const_logic_1;
    } else {
        v2_4_50_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_50_Rst_A() {
    v2_4_50_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_50_WEN_A() {
    v2_4_50_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_51_Addr_A() {
    v2_4_51_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_51_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_51_Addr_A_orig() {
    v2_4_51_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_51_Clk_A() {
    v2_4_51_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_51_Din_A() {
    v2_4_51_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_51_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_51_EN_A = ap_const_logic_1;
    } else {
        v2_4_51_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_51_Rst_A() {
    v2_4_51_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_51_WEN_A() {
    v2_4_51_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_52_Addr_A() {
    v2_4_52_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_52_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_52_Addr_A_orig() {
    v2_4_52_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_52_Clk_A() {
    v2_4_52_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_52_Din_A() {
    v2_4_52_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_52_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_52_EN_A = ap_const_logic_1;
    } else {
        v2_4_52_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_52_Rst_A() {
    v2_4_52_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_52_WEN_A() {
    v2_4_52_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_53_Addr_A() {
    v2_4_53_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_53_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_53_Addr_A_orig() {
    v2_4_53_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_53_Clk_A() {
    v2_4_53_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_53_Din_A() {
    v2_4_53_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_53_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_53_EN_A = ap_const_logic_1;
    } else {
        v2_4_53_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_53_Rst_A() {
    v2_4_53_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_53_WEN_A() {
    v2_4_53_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_54_Addr_A() {
    v2_4_54_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_54_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_54_Addr_A_orig() {
    v2_4_54_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_54_Clk_A() {
    v2_4_54_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_54_Din_A() {
    v2_4_54_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_54_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_54_EN_A = ap_const_logic_1;
    } else {
        v2_4_54_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_54_Rst_A() {
    v2_4_54_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_54_WEN_A() {
    v2_4_54_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_55_Addr_A() {
    v2_4_55_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_55_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_55_Addr_A_orig() {
    v2_4_55_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_55_Clk_A() {
    v2_4_55_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_55_Din_A() {
    v2_4_55_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_55_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_55_EN_A = ap_const_logic_1;
    } else {
        v2_4_55_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_55_Rst_A() {
    v2_4_55_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_55_WEN_A() {
    v2_4_55_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_56_Addr_A() {
    v2_4_56_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_56_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_56_Addr_A_orig() {
    v2_4_56_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_56_Clk_A() {
    v2_4_56_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_56_Din_A() {
    v2_4_56_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_56_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_56_EN_A = ap_const_logic_1;
    } else {
        v2_4_56_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_56_Rst_A() {
    v2_4_56_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_56_WEN_A() {
    v2_4_56_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_57_Addr_A() {
    v2_4_57_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_57_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_57_Addr_A_orig() {
    v2_4_57_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_57_Clk_A() {
    v2_4_57_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_57_Din_A() {
    v2_4_57_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_57_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_57_EN_A = ap_const_logic_1;
    } else {
        v2_4_57_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_57_Rst_A() {
    v2_4_57_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_57_WEN_A() {
    v2_4_57_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_58_Addr_A() {
    v2_4_58_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_58_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_58_Addr_A_orig() {
    v2_4_58_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_58_Clk_A() {
    v2_4_58_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_58_Din_A() {
    v2_4_58_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_58_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_58_EN_A = ap_const_logic_1;
    } else {
        v2_4_58_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_58_Rst_A() {
    v2_4_58_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_58_WEN_A() {
    v2_4_58_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_59_Addr_A() {
    v2_4_59_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_59_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_59_Addr_A_orig() {
    v2_4_59_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_59_Clk_A() {
    v2_4_59_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_59_Din_A() {
    v2_4_59_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_59_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_59_EN_A = ap_const_logic_1;
    } else {
        v2_4_59_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_59_Rst_A() {
    v2_4_59_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_59_WEN_A() {
    v2_4_59_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_5_Addr_A() {
    v2_4_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_5_Addr_A_orig() {
    v2_4_5_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_5_Clk_A() {
    v2_4_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_5_Din_A() {
    v2_4_5_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_5_EN_A = ap_const_logic_1;
    } else {
        v2_4_5_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_5_Rst_A() {
    v2_4_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_5_WEN_A() {
    v2_4_5_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_60_Addr_A() {
    v2_4_60_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_60_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_60_Addr_A_orig() {
    v2_4_60_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_60_Clk_A() {
    v2_4_60_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_60_Din_A() {
    v2_4_60_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_60_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_60_EN_A = ap_const_logic_1;
    } else {
        v2_4_60_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_60_Rst_A() {
    v2_4_60_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_60_WEN_A() {
    v2_4_60_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_61_Addr_A() {
    v2_4_61_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_61_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_61_Addr_A_orig() {
    v2_4_61_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_61_Clk_A() {
    v2_4_61_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_61_Din_A() {
    v2_4_61_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_61_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_61_EN_A = ap_const_logic_1;
    } else {
        v2_4_61_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_61_Rst_A() {
    v2_4_61_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_61_WEN_A() {
    v2_4_61_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_62_Addr_A() {
    v2_4_62_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_62_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_62_Addr_A_orig() {
    v2_4_62_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_62_Clk_A() {
    v2_4_62_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_62_Din_A() {
    v2_4_62_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_62_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_62_EN_A = ap_const_logic_1;
    } else {
        v2_4_62_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_62_Rst_A() {
    v2_4_62_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_62_WEN_A() {
    v2_4_62_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_63_Addr_A() {
    v2_4_63_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_63_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_63_Addr_A_orig() {
    v2_4_63_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_63_Clk_A() {
    v2_4_63_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_63_Din_A() {
    v2_4_63_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_63_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_63_EN_A = ap_const_logic_1;
    } else {
        v2_4_63_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_63_Rst_A() {
    v2_4_63_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_63_WEN_A() {
    v2_4_63_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_64_Addr_A() {
    v2_4_64_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_64_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_64_Addr_A_orig() {
    v2_4_64_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_64_Clk_A() {
    v2_4_64_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_64_Din_A() {
    v2_4_64_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_64_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_64_EN_A = ap_const_logic_1;
    } else {
        v2_4_64_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_64_Rst_A() {
    v2_4_64_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_64_WEN_A() {
    v2_4_64_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_6_Addr_A() {
    v2_4_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_6_Addr_A_orig() {
    v2_4_6_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_6_Clk_A() {
    v2_4_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_6_Din_A() {
    v2_4_6_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_6_EN_A = ap_const_logic_1;
    } else {
        v2_4_6_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_6_Rst_A() {
    v2_4_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_6_WEN_A() {
    v2_4_6_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_7_Addr_A() {
    v2_4_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_7_Addr_A_orig() {
    v2_4_7_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_7_Clk_A() {
    v2_4_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_7_Din_A() {
    v2_4_7_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_7_EN_A = ap_const_logic_1;
    } else {
        v2_4_7_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_7_Rst_A() {
    v2_4_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_7_WEN_A() {
    v2_4_7_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_8_Addr_A() {
    v2_4_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_8_Addr_A_orig() {
    v2_4_8_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_8_Clk_A() {
    v2_4_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_8_Din_A() {
    v2_4_8_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_8_EN_A = ap_const_logic_1;
    } else {
        v2_4_8_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_8_Rst_A() {
    v2_4_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_8_WEN_A() {
    v2_4_8_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_4_9_Addr_A() {
    v2_4_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_4_9_Addr_A_orig() {
    v2_4_9_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_4_9_Clk_A() {
    v2_4_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_4_9_Din_A() {
    v2_4_9_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_4_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_4_9_EN_A = ap_const_logic_1;
    } else {
        v2_4_9_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_4_9_Rst_A() {
    v2_4_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_4_9_WEN_A() {
    v2_4_9_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v31_1_fu_10863_p3() {
    v31_1_fu_10863_p3 = (!select_ln125_1_reg_10901.read()[0].is_01())? sc_lv<32>(): ((select_ln125_1_reg_10901.read()[0].to_bool())? ap_const_lv32_0: v4_2_Dout_A.read());
}

void kernel_bicg_sdse::thread_v39_1_fu_10870_p3() {
    v39_1_fu_10870_p3 = (!select_ln125_1_reg_10901.read()[0].is_01())? sc_lv<32>(): ((select_ln125_1_reg_10901.read()[0].to_bool())? ap_const_lv32_0: v4_3_Dout_A.read());
}

void kernel_bicg_sdse::thread_v3_0_Addr_A() {
    v3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v3_0_Addr_A_orig() {
    v3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln125_2_reg_10915_pp1_iter2_reg.read());
}

void kernel_bicg_sdse::thread_v3_0_Addr_B() {
    v3_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v3_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_0_Addr_B_orig =  (sc_lv<32>) (v3_0_addr_1_reg_19489.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_0_Addr_B_orig =  (sc_lv<32>) (zext_ln59_fu_10214_p1.read());
    } else {
        v3_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_sdse::thread_v3_0_Clk_A() {
    v3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v3_0_Clk_B() {
    v3_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v3_0_Din_A() {
    v3_0_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v3_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        v3_0_Din_B = reg_8852.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_0_Din_B = ap_const_lv32_0;
    } else {
        v3_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_bicg_sdse::thread_v3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v3_0_EN_A = ap_const_logic_1;
    } else {
        v3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v3_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        v3_0_EN_B = ap_const_logic_1;
    } else {
        v3_0_EN_B = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v3_0_Rst_A() {
    v3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v3_0_Rst_B() {
    v3_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v3_0_WEN_A() {
    v3_0_WEN_A = ap_const_lv4_0;
}

}


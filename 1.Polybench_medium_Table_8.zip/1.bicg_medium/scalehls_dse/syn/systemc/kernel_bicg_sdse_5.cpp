#include "kernel_bicg_sdse.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_bicg_sdse::thread_v2_0_47_Din_A() {
    v2_0_47_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_47_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_47_EN_A = ap_const_logic_1;
    } else {
        v2_0_47_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_47_Rst_A() {
    v2_0_47_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_47_WEN_A() {
    v2_0_47_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_48_Addr_A() {
    v2_0_48_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_48_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_48_Addr_A_orig() {
    v2_0_48_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_48_Clk_A() {
    v2_0_48_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_48_Din_A() {
    v2_0_48_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_48_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_48_EN_A = ap_const_logic_1;
    } else {
        v2_0_48_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_48_Rst_A() {
    v2_0_48_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_48_WEN_A() {
    v2_0_48_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_49_Addr_A() {
    v2_0_49_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_49_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_49_Addr_A_orig() {
    v2_0_49_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_49_Clk_A() {
    v2_0_49_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_49_Din_A() {
    v2_0_49_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_49_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_49_EN_A = ap_const_logic_1;
    } else {
        v2_0_49_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_49_Rst_A() {
    v2_0_49_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_49_WEN_A() {
    v2_0_49_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_4_Addr_A() {
    v2_0_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_4_Addr_A_orig() {
    v2_0_4_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_4_Clk_A() {
    v2_0_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_4_Din_A() {
    v2_0_4_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_4_EN_A = ap_const_logic_1;
    } else {
        v2_0_4_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_4_Rst_A() {
    v2_0_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_4_WEN_A() {
    v2_0_4_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_50_Addr_A() {
    v2_0_50_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_50_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_50_Addr_A_orig() {
    v2_0_50_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_50_Clk_A() {
    v2_0_50_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_50_Din_A() {
    v2_0_50_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_50_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_50_EN_A = ap_const_logic_1;
    } else {
        v2_0_50_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_50_Rst_A() {
    v2_0_50_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_50_WEN_A() {
    v2_0_50_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_51_Addr_A() {
    v2_0_51_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_51_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_51_Addr_A_orig() {
    v2_0_51_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_51_Clk_A() {
    v2_0_51_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_51_Din_A() {
    v2_0_51_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_51_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_51_EN_A = ap_const_logic_1;
    } else {
        v2_0_51_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_51_Rst_A() {
    v2_0_51_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_51_WEN_A() {
    v2_0_51_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_52_Addr_A() {
    v2_0_52_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_52_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_52_Addr_A_orig() {
    v2_0_52_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_52_Clk_A() {
    v2_0_52_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_52_Din_A() {
    v2_0_52_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_52_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_52_EN_A = ap_const_logic_1;
    } else {
        v2_0_52_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_52_Rst_A() {
    v2_0_52_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_52_WEN_A() {
    v2_0_52_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_53_Addr_A() {
    v2_0_53_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_53_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_53_Addr_A_orig() {
    v2_0_53_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_53_Clk_A() {
    v2_0_53_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_53_Din_A() {
    v2_0_53_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_53_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_53_EN_A = ap_const_logic_1;
    } else {
        v2_0_53_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_53_Rst_A() {
    v2_0_53_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_53_WEN_A() {
    v2_0_53_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_54_Addr_A() {
    v2_0_54_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_54_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_54_Addr_A_orig() {
    v2_0_54_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_54_Clk_A() {
    v2_0_54_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_54_Din_A() {
    v2_0_54_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_54_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_54_EN_A = ap_const_logic_1;
    } else {
        v2_0_54_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_54_Rst_A() {
    v2_0_54_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_54_WEN_A() {
    v2_0_54_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_55_Addr_A() {
    v2_0_55_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_55_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_55_Addr_A_orig() {
    v2_0_55_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_55_Clk_A() {
    v2_0_55_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_55_Din_A() {
    v2_0_55_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_55_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_55_EN_A = ap_const_logic_1;
    } else {
        v2_0_55_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_55_Rst_A() {
    v2_0_55_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_55_WEN_A() {
    v2_0_55_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_56_Addr_A() {
    v2_0_56_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_56_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_56_Addr_A_orig() {
    v2_0_56_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_56_Clk_A() {
    v2_0_56_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_56_Din_A() {
    v2_0_56_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_56_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_56_EN_A = ap_const_logic_1;
    } else {
        v2_0_56_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_56_Rst_A() {
    v2_0_56_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_56_WEN_A() {
    v2_0_56_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_57_Addr_A() {
    v2_0_57_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_57_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_57_Addr_A_orig() {
    v2_0_57_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_57_Clk_A() {
    v2_0_57_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_57_Din_A() {
    v2_0_57_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_57_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_57_EN_A = ap_const_logic_1;
    } else {
        v2_0_57_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_57_Rst_A() {
    v2_0_57_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_57_WEN_A() {
    v2_0_57_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_58_Addr_A() {
    v2_0_58_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_58_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_58_Addr_A_orig() {
    v2_0_58_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_58_Clk_A() {
    v2_0_58_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_58_Din_A() {
    v2_0_58_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_58_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_58_EN_A = ap_const_logic_1;
    } else {
        v2_0_58_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_58_Rst_A() {
    v2_0_58_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_58_WEN_A() {
    v2_0_58_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_59_Addr_A() {
    v2_0_59_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_59_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_59_Addr_A_orig() {
    v2_0_59_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_59_Clk_A() {
    v2_0_59_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_59_Din_A() {
    v2_0_59_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_59_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_59_EN_A = ap_const_logic_1;
    } else {
        v2_0_59_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_59_Rst_A() {
    v2_0_59_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_59_WEN_A() {
    v2_0_59_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_5_Addr_A() {
    v2_0_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_5_Addr_A_orig() {
    v2_0_5_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_5_Clk_A() {
    v2_0_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_5_Din_A() {
    v2_0_5_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_5_EN_A = ap_const_logic_1;
    } else {
        v2_0_5_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_5_Rst_A() {
    v2_0_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_5_WEN_A() {
    v2_0_5_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_60_Addr_A() {
    v2_0_60_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_60_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_60_Addr_A_orig() {
    v2_0_60_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_60_Clk_A() {
    v2_0_60_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_60_Din_A() {
    v2_0_60_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_60_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_60_EN_A = ap_const_logic_1;
    } else {
        v2_0_60_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_60_Rst_A() {
    v2_0_60_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_60_WEN_A() {
    v2_0_60_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_61_Addr_A() {
    v2_0_61_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_61_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_61_Addr_A_orig() {
    v2_0_61_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_61_Clk_A() {
    v2_0_61_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_61_Din_A() {
    v2_0_61_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_61_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_61_EN_A = ap_const_logic_1;
    } else {
        v2_0_61_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_61_Rst_A() {
    v2_0_61_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_61_WEN_A() {
    v2_0_61_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_62_Addr_A() {
    v2_0_62_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_62_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_62_Addr_A_orig() {
    v2_0_62_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_62_Clk_A() {
    v2_0_62_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_62_Din_A() {
    v2_0_62_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_62_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_62_EN_A = ap_const_logic_1;
    } else {
        v2_0_62_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_62_Rst_A() {
    v2_0_62_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_62_WEN_A() {
    v2_0_62_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_63_Addr_A() {
    v2_0_63_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_63_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_63_Addr_A_orig() {
    v2_0_63_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_63_Clk_A() {
    v2_0_63_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_63_Din_A() {
    v2_0_63_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_63_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_63_EN_A = ap_const_logic_1;
    } else {
        v2_0_63_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_63_Rst_A() {
    v2_0_63_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_63_WEN_A() {
    v2_0_63_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_64_Addr_A() {
    v2_0_64_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_64_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_64_Addr_A_orig() {
    v2_0_64_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_64_Clk_A() {
    v2_0_64_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_64_Din_A() {
    v2_0_64_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_64_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_64_EN_A = ap_const_logic_1;
    } else {
        v2_0_64_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_64_Rst_A() {
    v2_0_64_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_64_WEN_A() {
    v2_0_64_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_6_Addr_A() {
    v2_0_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_6_Addr_A_orig() {
    v2_0_6_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_6_Clk_A() {
    v2_0_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_6_Din_A() {
    v2_0_6_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_6_EN_A = ap_const_logic_1;
    } else {
        v2_0_6_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_6_Rst_A() {
    v2_0_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_6_WEN_A() {
    v2_0_6_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_7_Addr_A() {
    v2_0_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_7_Addr_A_orig() {
    v2_0_7_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_7_Clk_A() {
    v2_0_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_7_Din_A() {
    v2_0_7_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_7_EN_A = ap_const_logic_1;
    } else {
        v2_0_7_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_7_Rst_A() {
    v2_0_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_7_WEN_A() {
    v2_0_7_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_8_Addr_A() {
    v2_0_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_8_Addr_A_orig() {
    v2_0_8_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_8_Clk_A() {
    v2_0_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_8_Din_A() {
    v2_0_8_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_8_EN_A = ap_const_logic_1;
    } else {
        v2_0_8_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_8_Rst_A() {
    v2_0_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_8_WEN_A() {
    v2_0_8_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_0_9_Addr_A() {
    v2_0_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_0_9_Addr_A_orig() {
    v2_0_9_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_0_9_Clk_A() {
    v2_0_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_0_9_Din_A() {
    v2_0_9_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_0_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_0_9_EN_A = ap_const_logic_1;
    } else {
        v2_0_9_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_0_9_Rst_A() {
    v2_0_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_0_9_WEN_A() {
    v2_0_9_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_0_Addr_A() {
    v2_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_0_Addr_A_orig() {
    v2_1_0_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_0_Clk_A() {
    v2_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_0_Din_A() {
    v2_1_0_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_0_EN_A = ap_const_logic_1;
    } else {
        v2_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_0_Rst_A() {
    v2_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_0_WEN_A() {
    v2_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_10_Addr_A() {
    v2_1_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_10_Addr_A_orig() {
    v2_1_10_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_10_Clk_A() {
    v2_1_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_10_Din_A() {
    v2_1_10_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_10_EN_A = ap_const_logic_1;
    } else {
        v2_1_10_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_10_Rst_A() {
    v2_1_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_10_WEN_A() {
    v2_1_10_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_11_Addr_A() {
    v2_1_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_11_Addr_A_orig() {
    v2_1_11_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_11_Clk_A() {
    v2_1_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_11_Din_A() {
    v2_1_11_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_11_EN_A = ap_const_logic_1;
    } else {
        v2_1_11_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_11_Rst_A() {
    v2_1_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_11_WEN_A() {
    v2_1_11_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_12_Addr_A() {
    v2_1_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_12_Addr_A_orig() {
    v2_1_12_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_12_Clk_A() {
    v2_1_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_12_Din_A() {
    v2_1_12_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_12_EN_A = ap_const_logic_1;
    } else {
        v2_1_12_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_12_Rst_A() {
    v2_1_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_12_WEN_A() {
    v2_1_12_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_13_Addr_A() {
    v2_1_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_13_Addr_A_orig() {
    v2_1_13_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_13_Clk_A() {
    v2_1_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_13_Din_A() {
    v2_1_13_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_13_EN_A = ap_const_logic_1;
    } else {
        v2_1_13_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_13_Rst_A() {
    v2_1_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_13_WEN_A() {
    v2_1_13_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_14_Addr_A() {
    v2_1_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_14_Addr_A_orig() {
    v2_1_14_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_14_Clk_A() {
    v2_1_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_14_Din_A() {
    v2_1_14_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_14_EN_A = ap_const_logic_1;
    } else {
        v2_1_14_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_14_Rst_A() {
    v2_1_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_14_WEN_A() {
    v2_1_14_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_15_Addr_A() {
    v2_1_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_15_Addr_A_orig() {
    v2_1_15_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_15_Clk_A() {
    v2_1_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_15_Din_A() {
    v2_1_15_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_15_EN_A = ap_const_logic_1;
    } else {
        v2_1_15_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_15_Rst_A() {
    v2_1_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_15_WEN_A() {
    v2_1_15_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_16_Addr_A() {
    v2_1_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_16_Addr_A_orig() {
    v2_1_16_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_16_Clk_A() {
    v2_1_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_16_Din_A() {
    v2_1_16_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_16_EN_A = ap_const_logic_1;
    } else {
        v2_1_16_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_16_Rst_A() {
    v2_1_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_16_WEN_A() {
    v2_1_16_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_17_Addr_A() {
    v2_1_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_17_Addr_A_orig() {
    v2_1_17_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_17_Clk_A() {
    v2_1_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_17_Din_A() {
    v2_1_17_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_17_EN_A = ap_const_logic_1;
    } else {
        v2_1_17_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_17_Rst_A() {
    v2_1_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_17_WEN_A() {
    v2_1_17_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_18_Addr_A() {
    v2_1_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_18_Addr_A_orig() {
    v2_1_18_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_18_Clk_A() {
    v2_1_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_18_Din_A() {
    v2_1_18_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_18_EN_A = ap_const_logic_1;
    } else {
        v2_1_18_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_18_Rst_A() {
    v2_1_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_18_WEN_A() {
    v2_1_18_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_19_Addr_A() {
    v2_1_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_19_Addr_A_orig() {
    v2_1_19_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_19_Clk_A() {
    v2_1_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_19_Din_A() {
    v2_1_19_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_19_EN_A = ap_const_logic_1;
    } else {
        v2_1_19_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_19_Rst_A() {
    v2_1_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_19_WEN_A() {
    v2_1_19_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_1_Addr_A() {
    v2_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_1_Addr_A_orig() {
    v2_1_1_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_1_Clk_A() {
    v2_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_1_Din_A() {
    v2_1_1_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_1_EN_A = ap_const_logic_1;
    } else {
        v2_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_1_Rst_A() {
    v2_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_1_WEN_A() {
    v2_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_20_Addr_A() {
    v2_1_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_20_Addr_A_orig() {
    v2_1_20_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_20_Clk_A() {
    v2_1_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_20_Din_A() {
    v2_1_20_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_20_EN_A = ap_const_logic_1;
    } else {
        v2_1_20_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_20_Rst_A() {
    v2_1_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_20_WEN_A() {
    v2_1_20_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_21_Addr_A() {
    v2_1_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_21_Addr_A_orig() {
    v2_1_21_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_21_Clk_A() {
    v2_1_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_21_Din_A() {
    v2_1_21_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_21_EN_A = ap_const_logic_1;
    } else {
        v2_1_21_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_21_Rst_A() {
    v2_1_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_21_WEN_A() {
    v2_1_21_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_22_Addr_A() {
    v2_1_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_22_Addr_A_orig() {
    v2_1_22_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_22_Clk_A() {
    v2_1_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_22_Din_A() {
    v2_1_22_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_22_EN_A = ap_const_logic_1;
    } else {
        v2_1_22_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_22_Rst_A() {
    v2_1_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_22_WEN_A() {
    v2_1_22_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_23_Addr_A() {
    v2_1_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_23_Addr_A_orig() {
    v2_1_23_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_23_Clk_A() {
    v2_1_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_23_Din_A() {
    v2_1_23_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_23_EN_A = ap_const_logic_1;
    } else {
        v2_1_23_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_23_Rst_A() {
    v2_1_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_23_WEN_A() {
    v2_1_23_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_24_Addr_A() {
    v2_1_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_24_Addr_A_orig() {
    v2_1_24_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_24_Clk_A() {
    v2_1_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_24_Din_A() {
    v2_1_24_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_24_EN_A = ap_const_logic_1;
    } else {
        v2_1_24_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_24_Rst_A() {
    v2_1_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_24_WEN_A() {
    v2_1_24_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_25_Addr_A() {
    v2_1_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_25_Addr_A_orig() {
    v2_1_25_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_25_Clk_A() {
    v2_1_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_25_Din_A() {
    v2_1_25_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_25_EN_A = ap_const_logic_1;
    } else {
        v2_1_25_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_25_Rst_A() {
    v2_1_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_25_WEN_A() {
    v2_1_25_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_26_Addr_A() {
    v2_1_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_26_Addr_A_orig() {
    v2_1_26_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_26_Clk_A() {
    v2_1_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_26_Din_A() {
    v2_1_26_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_26_EN_A = ap_const_logic_1;
    } else {
        v2_1_26_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_26_Rst_A() {
    v2_1_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_26_WEN_A() {
    v2_1_26_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_27_Addr_A() {
    v2_1_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_27_Addr_A_orig() {
    v2_1_27_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_27_Clk_A() {
    v2_1_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_27_Din_A() {
    v2_1_27_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_27_EN_A = ap_const_logic_1;
    } else {
        v2_1_27_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_27_Rst_A() {
    v2_1_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_27_WEN_A() {
    v2_1_27_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_28_Addr_A() {
    v2_1_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_28_Addr_A_orig() {
    v2_1_28_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_28_Clk_A() {
    v2_1_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_28_Din_A() {
    v2_1_28_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_28_EN_A = ap_const_logic_1;
    } else {
        v2_1_28_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_28_Rst_A() {
    v2_1_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_28_WEN_A() {
    v2_1_28_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_29_Addr_A() {
    v2_1_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_29_Addr_A_orig() {
    v2_1_29_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_29_Clk_A() {
    v2_1_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_29_Din_A() {
    v2_1_29_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_29_EN_A = ap_const_logic_1;
    } else {
        v2_1_29_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_29_Rst_A() {
    v2_1_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_29_WEN_A() {
    v2_1_29_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_2_Addr_A() {
    v2_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_2_Addr_A_orig() {
    v2_1_2_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_2_Clk_A() {
    v2_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_2_Din_A() {
    v2_1_2_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_2_EN_A = ap_const_logic_1;
    } else {
        v2_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_2_Rst_A() {
    v2_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_2_WEN_A() {
    v2_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_30_Addr_A() {
    v2_1_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_30_Addr_A_orig() {
    v2_1_30_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_30_Clk_A() {
    v2_1_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_30_Din_A() {
    v2_1_30_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_30_EN_A = ap_const_logic_1;
    } else {
        v2_1_30_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_30_Rst_A() {
    v2_1_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_30_WEN_A() {
    v2_1_30_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_31_Addr_A() {
    v2_1_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_31_Addr_A_orig() {
    v2_1_31_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_31_Clk_A() {
    v2_1_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_31_Din_A() {
    v2_1_31_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_31_EN_A = ap_const_logic_1;
    } else {
        v2_1_31_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_31_Rst_A() {
    v2_1_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_31_WEN_A() {
    v2_1_31_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_32_Addr_A() {
    v2_1_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_32_Addr_A_orig() {
    v2_1_32_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_32_Clk_A() {
    v2_1_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_32_Din_A() {
    v2_1_32_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_32_EN_A = ap_const_logic_1;
    } else {
        v2_1_32_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_32_Rst_A() {
    v2_1_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_32_WEN_A() {
    v2_1_32_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_33_Addr_A() {
    v2_1_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_33_Addr_A_orig() {
    v2_1_33_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_33_Clk_A() {
    v2_1_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_33_Din_A() {
    v2_1_33_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_33_EN_A = ap_const_logic_1;
    } else {
        v2_1_33_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_33_Rst_A() {
    v2_1_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_33_WEN_A() {
    v2_1_33_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_34_Addr_A() {
    v2_1_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_34_Addr_A_orig() {
    v2_1_34_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_34_Clk_A() {
    v2_1_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_34_Din_A() {
    v2_1_34_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_34_EN_A = ap_const_logic_1;
    } else {
        v2_1_34_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_34_Rst_A() {
    v2_1_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_34_WEN_A() {
    v2_1_34_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_35_Addr_A() {
    v2_1_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_35_Addr_A_orig() {
    v2_1_35_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_35_Clk_A() {
    v2_1_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_35_Din_A() {
    v2_1_35_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_35_EN_A = ap_const_logic_1;
    } else {
        v2_1_35_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_35_Rst_A() {
    v2_1_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_35_WEN_A() {
    v2_1_35_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_36_Addr_A() {
    v2_1_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_36_Addr_A_orig() {
    v2_1_36_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_36_Clk_A() {
    v2_1_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_36_Din_A() {
    v2_1_36_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_36_EN_A = ap_const_logic_1;
    } else {
        v2_1_36_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_36_Rst_A() {
    v2_1_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_36_WEN_A() {
    v2_1_36_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_37_Addr_A() {
    v2_1_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_37_Addr_A_orig() {
    v2_1_37_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_37_Clk_A() {
    v2_1_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_37_Din_A() {
    v2_1_37_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_37_EN_A = ap_const_logic_1;
    } else {
        v2_1_37_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_37_Rst_A() {
    v2_1_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_37_WEN_A() {
    v2_1_37_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_38_Addr_A() {
    v2_1_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_38_Addr_A_orig() {
    v2_1_38_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_38_Clk_A() {
    v2_1_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_38_Din_A() {
    v2_1_38_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_38_EN_A = ap_const_logic_1;
    } else {
        v2_1_38_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_38_Rst_A() {
    v2_1_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_38_WEN_A() {
    v2_1_38_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_39_Addr_A() {
    v2_1_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_39_Addr_A_orig() {
    v2_1_39_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_39_Clk_A() {
    v2_1_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_39_Din_A() {
    v2_1_39_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_39_EN_A = ap_const_logic_1;
    } else {
        v2_1_39_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_39_Rst_A() {
    v2_1_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_39_WEN_A() {
    v2_1_39_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_3_Addr_A() {
    v2_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_3_Addr_A_orig() {
    v2_1_3_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_3_Clk_A() {
    v2_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_3_Din_A() {
    v2_1_3_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_3_EN_A = ap_const_logic_1;
    } else {
        v2_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_3_Rst_A() {
    v2_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_3_WEN_A() {
    v2_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_40_Addr_A() {
    v2_1_40_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_40_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_40_Addr_A_orig() {
    v2_1_40_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_40_Clk_A() {
    v2_1_40_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_40_Din_A() {
    v2_1_40_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_40_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_40_EN_A = ap_const_logic_1;
    } else {
        v2_1_40_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_40_Rst_A() {
    v2_1_40_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_40_WEN_A() {
    v2_1_40_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_41_Addr_A() {
    v2_1_41_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_41_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_41_Addr_A_orig() {
    v2_1_41_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_41_Clk_A() {
    v2_1_41_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_41_Din_A() {
    v2_1_41_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_41_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_41_EN_A = ap_const_logic_1;
    } else {
        v2_1_41_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_41_Rst_A() {
    v2_1_41_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_41_WEN_A() {
    v2_1_41_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_42_Addr_A() {
    v2_1_42_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_42_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_42_Addr_A_orig() {
    v2_1_42_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_42_Clk_A() {
    v2_1_42_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_42_Din_A() {
    v2_1_42_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_42_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_42_EN_A = ap_const_logic_1;
    } else {
        v2_1_42_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_42_Rst_A() {
    v2_1_42_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_42_WEN_A() {
    v2_1_42_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_43_Addr_A() {
    v2_1_43_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_43_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_43_Addr_A_orig() {
    v2_1_43_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_43_Clk_A() {
    v2_1_43_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_43_Din_A() {
    v2_1_43_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_43_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_43_EN_A = ap_const_logic_1;
    } else {
        v2_1_43_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_43_Rst_A() {
    v2_1_43_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_43_WEN_A() {
    v2_1_43_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_44_Addr_A() {
    v2_1_44_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_44_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_44_Addr_A_orig() {
    v2_1_44_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_44_Clk_A() {
    v2_1_44_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_44_Din_A() {
    v2_1_44_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_44_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_44_EN_A = ap_const_logic_1;
    } else {
        v2_1_44_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_44_Rst_A() {
    v2_1_44_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_44_WEN_A() {
    v2_1_44_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_45_Addr_A() {
    v2_1_45_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_45_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_45_Addr_A_orig() {
    v2_1_45_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_45_Clk_A() {
    v2_1_45_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_45_Din_A() {
    v2_1_45_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_45_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_45_EN_A = ap_const_logic_1;
    } else {
        v2_1_45_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_45_Rst_A() {
    v2_1_45_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_45_WEN_A() {
    v2_1_45_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_46_Addr_A() {
    v2_1_46_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_46_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_46_Addr_A_orig() {
    v2_1_46_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_46_Clk_A() {
    v2_1_46_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_46_Din_A() {
    v2_1_46_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_46_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_46_EN_A = ap_const_logic_1;
    } else {
        v2_1_46_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_46_Rst_A() {
    v2_1_46_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_46_WEN_A() {
    v2_1_46_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_47_Addr_A() {
    v2_1_47_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_47_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_47_Addr_A_orig() {
    v2_1_47_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_47_Clk_A() {
    v2_1_47_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_47_Din_A() {
    v2_1_47_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_47_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_47_EN_A = ap_const_logic_1;
    } else {
        v2_1_47_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_47_Rst_A() {
    v2_1_47_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_47_WEN_A() {
    v2_1_47_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_48_Addr_A() {
    v2_1_48_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_48_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_48_Addr_A_orig() {
    v2_1_48_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_48_Clk_A() {
    v2_1_48_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_48_Din_A() {
    v2_1_48_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_48_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_48_EN_A = ap_const_logic_1;
    } else {
        v2_1_48_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_48_Rst_A() {
    v2_1_48_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_48_WEN_A() {
    v2_1_48_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_49_Addr_A() {
    v2_1_49_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_49_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_49_Addr_A_orig() {
    v2_1_49_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_49_Clk_A() {
    v2_1_49_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_49_Din_A() {
    v2_1_49_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_49_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_49_EN_A = ap_const_logic_1;
    } else {
        v2_1_49_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_49_Rst_A() {
    v2_1_49_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_49_WEN_A() {
    v2_1_49_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_4_Addr_A() {
    v2_1_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_4_Addr_A_orig() {
    v2_1_4_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_4_Clk_A() {
    v2_1_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_4_Din_A() {
    v2_1_4_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_4_EN_A = ap_const_logic_1;
    } else {
        v2_1_4_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_4_Rst_A() {
    v2_1_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_4_WEN_A() {
    v2_1_4_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_50_Addr_A() {
    v2_1_50_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_50_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_50_Addr_A_orig() {
    v2_1_50_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_50_Clk_A() {
    v2_1_50_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_50_Din_A() {
    v2_1_50_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_50_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_50_EN_A = ap_const_logic_1;
    } else {
        v2_1_50_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_50_Rst_A() {
    v2_1_50_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_50_WEN_A() {
    v2_1_50_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_51_Addr_A() {
    v2_1_51_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_51_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_51_Addr_A_orig() {
    v2_1_51_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_51_Clk_A() {
    v2_1_51_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_51_Din_A() {
    v2_1_51_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_51_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_51_EN_A = ap_const_logic_1;
    } else {
        v2_1_51_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_51_Rst_A() {
    v2_1_51_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_51_WEN_A() {
    v2_1_51_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_52_Addr_A() {
    v2_1_52_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_52_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_52_Addr_A_orig() {
    v2_1_52_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_52_Clk_A() {
    v2_1_52_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_52_Din_A() {
    v2_1_52_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_52_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_52_EN_A = ap_const_logic_1;
    } else {
        v2_1_52_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_52_Rst_A() {
    v2_1_52_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_52_WEN_A() {
    v2_1_52_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_53_Addr_A() {
    v2_1_53_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_53_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_53_Addr_A_orig() {
    v2_1_53_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_53_Clk_A() {
    v2_1_53_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_53_Din_A() {
    v2_1_53_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_53_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_53_EN_A = ap_const_logic_1;
    } else {
        v2_1_53_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_53_Rst_A() {
    v2_1_53_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_53_WEN_A() {
    v2_1_53_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_54_Addr_A() {
    v2_1_54_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_54_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_54_Addr_A_orig() {
    v2_1_54_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_54_Clk_A() {
    v2_1_54_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_54_Din_A() {
    v2_1_54_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_54_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_54_EN_A = ap_const_logic_1;
    } else {
        v2_1_54_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_54_Rst_A() {
    v2_1_54_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_54_WEN_A() {
    v2_1_54_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_55_Addr_A() {
    v2_1_55_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_55_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_55_Addr_A_orig() {
    v2_1_55_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_55_Clk_A() {
    v2_1_55_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_55_Din_A() {
    v2_1_55_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_55_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_55_EN_A = ap_const_logic_1;
    } else {
        v2_1_55_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_55_Rst_A() {
    v2_1_55_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_55_WEN_A() {
    v2_1_55_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_56_Addr_A() {
    v2_1_56_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_56_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_56_Addr_A_orig() {
    v2_1_56_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_56_Clk_A() {
    v2_1_56_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_56_Din_A() {
    v2_1_56_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_56_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_56_EN_A = ap_const_logic_1;
    } else {
        v2_1_56_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_56_Rst_A() {
    v2_1_56_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_56_WEN_A() {
    v2_1_56_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_57_Addr_A() {
    v2_1_57_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_57_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_57_Addr_A_orig() {
    v2_1_57_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_57_Clk_A() {
    v2_1_57_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_57_Din_A() {
    v2_1_57_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_57_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_57_EN_A = ap_const_logic_1;
    } else {
        v2_1_57_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_57_Rst_A() {
    v2_1_57_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_57_WEN_A() {
    v2_1_57_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_58_Addr_A() {
    v2_1_58_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_58_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_58_Addr_A_orig() {
    v2_1_58_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_58_Clk_A() {
    v2_1_58_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_58_Din_A() {
    v2_1_58_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_58_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_58_EN_A = ap_const_logic_1;
    } else {
        v2_1_58_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_58_Rst_A() {
    v2_1_58_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_58_WEN_A() {
    v2_1_58_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_59_Addr_A() {
    v2_1_59_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_59_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_59_Addr_A_orig() {
    v2_1_59_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_59_Clk_A() {
    v2_1_59_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_59_Din_A() {
    v2_1_59_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_59_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_59_EN_A = ap_const_logic_1;
    } else {
        v2_1_59_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_59_Rst_A() {
    v2_1_59_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_59_WEN_A() {
    v2_1_59_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_5_Addr_A() {
    v2_1_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_5_Addr_A_orig() {
    v2_1_5_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_5_Clk_A() {
    v2_1_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_5_Din_A() {
    v2_1_5_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_5_EN_A = ap_const_logic_1;
    } else {
        v2_1_5_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_5_Rst_A() {
    v2_1_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_5_WEN_A() {
    v2_1_5_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_60_Addr_A() {
    v2_1_60_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_60_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_60_Addr_A_orig() {
    v2_1_60_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_60_Clk_A() {
    v2_1_60_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_60_Din_A() {
    v2_1_60_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_60_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_60_EN_A = ap_const_logic_1;
    } else {
        v2_1_60_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_60_Rst_A() {
    v2_1_60_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_60_WEN_A() {
    v2_1_60_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_61_Addr_A() {
    v2_1_61_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_61_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_61_Addr_A_orig() {
    v2_1_61_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_61_Clk_A() {
    v2_1_61_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_61_Din_A() {
    v2_1_61_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_61_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_61_EN_A = ap_const_logic_1;
    } else {
        v2_1_61_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_61_Rst_A() {
    v2_1_61_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_61_WEN_A() {
    v2_1_61_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_62_Addr_A() {
    v2_1_62_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_62_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_62_Addr_A_orig() {
    v2_1_62_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_62_Clk_A() {
    v2_1_62_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_62_Din_A() {
    v2_1_62_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_62_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_62_EN_A = ap_const_logic_1;
    } else {
        v2_1_62_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_62_Rst_A() {
    v2_1_62_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_62_WEN_A() {
    v2_1_62_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_63_Addr_A() {
    v2_1_63_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_63_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_63_Addr_A_orig() {
    v2_1_63_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_63_Clk_A() {
    v2_1_63_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_63_Din_A() {
    v2_1_63_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_63_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_63_EN_A = ap_const_logic_1;
    } else {
        v2_1_63_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_63_Rst_A() {
    v2_1_63_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_63_WEN_A() {
    v2_1_63_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_64_Addr_A() {
    v2_1_64_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_64_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_64_Addr_A_orig() {
    v2_1_64_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_64_Clk_A() {
    v2_1_64_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_64_Din_A() {
    v2_1_64_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_64_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_64_EN_A = ap_const_logic_1;
    } else {
        v2_1_64_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_64_Rst_A() {
    v2_1_64_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_64_WEN_A() {
    v2_1_64_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_6_Addr_A() {
    v2_1_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_6_Addr_A_orig() {
    v2_1_6_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_6_Clk_A() {
    v2_1_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_6_Din_A() {
    v2_1_6_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_6_EN_A = ap_const_logic_1;
    } else {
        v2_1_6_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_6_Rst_A() {
    v2_1_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_6_WEN_A() {
    v2_1_6_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_7_Addr_A() {
    v2_1_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_7_Addr_A_orig() {
    v2_1_7_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_7_Clk_A() {
    v2_1_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_7_Din_A() {
    v2_1_7_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_7_EN_A = ap_const_logic_1;
    } else {
        v2_1_7_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_7_Rst_A() {
    v2_1_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_7_WEN_A() {
    v2_1_7_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_8_Addr_A() {
    v2_1_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_8_Addr_A_orig() {
    v2_1_8_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_8_Clk_A() {
    v2_1_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_8_Din_A() {
    v2_1_8_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_8_EN_A = ap_const_logic_1;
    } else {
        v2_1_8_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_8_Rst_A() {
    v2_1_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_8_WEN_A() {
    v2_1_8_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_1_9_Addr_A() {
    v2_1_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_1_9_Addr_A_orig() {
    v2_1_9_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_1_9_Clk_A() {
    v2_1_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_1_9_Din_A() {
    v2_1_9_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_1_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_1_9_EN_A = ap_const_logic_1;
    } else {
        v2_1_9_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_1_9_Rst_A() {
    v2_1_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_1_9_WEN_A() {
    v2_1_9_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_0_Addr_A() {
    v2_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_0_Addr_A_orig() {
    v2_2_0_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_0_Clk_A() {
    v2_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_0_Din_A() {
    v2_2_0_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_0_EN_A = ap_const_logic_1;
    } else {
        v2_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_0_Rst_A() {
    v2_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_0_WEN_A() {
    v2_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_10_Addr_A() {
    v2_2_10_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_10_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_10_Addr_A_orig() {
    v2_2_10_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_10_Clk_A() {
    v2_2_10_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_10_Din_A() {
    v2_2_10_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_10_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_10_EN_A = ap_const_logic_1;
    } else {
        v2_2_10_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_10_Rst_A() {
    v2_2_10_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_10_WEN_A() {
    v2_2_10_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_11_Addr_A() {
    v2_2_11_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_11_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_11_Addr_A_orig() {
    v2_2_11_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_11_Clk_A() {
    v2_2_11_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_11_Din_A() {
    v2_2_11_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_11_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_11_EN_A = ap_const_logic_1;
    } else {
        v2_2_11_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_11_Rst_A() {
    v2_2_11_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_11_WEN_A() {
    v2_2_11_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_12_Addr_A() {
    v2_2_12_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_12_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_12_Addr_A_orig() {
    v2_2_12_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_12_Clk_A() {
    v2_2_12_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_12_Din_A() {
    v2_2_12_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_12_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_12_EN_A = ap_const_logic_1;
    } else {
        v2_2_12_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_12_Rst_A() {
    v2_2_12_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_12_WEN_A() {
    v2_2_12_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_13_Addr_A() {
    v2_2_13_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_13_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_13_Addr_A_orig() {
    v2_2_13_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_13_Clk_A() {
    v2_2_13_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_13_Din_A() {
    v2_2_13_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_13_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_13_EN_A = ap_const_logic_1;
    } else {
        v2_2_13_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_13_Rst_A() {
    v2_2_13_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_13_WEN_A() {
    v2_2_13_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_14_Addr_A() {
    v2_2_14_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_14_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_14_Addr_A_orig() {
    v2_2_14_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_14_Clk_A() {
    v2_2_14_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_14_Din_A() {
    v2_2_14_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_14_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_14_EN_A = ap_const_logic_1;
    } else {
        v2_2_14_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_14_Rst_A() {
    v2_2_14_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_14_WEN_A() {
    v2_2_14_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_15_Addr_A() {
    v2_2_15_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_15_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_15_Addr_A_orig() {
    v2_2_15_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_15_Clk_A() {
    v2_2_15_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_15_Din_A() {
    v2_2_15_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_15_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_15_EN_A = ap_const_logic_1;
    } else {
        v2_2_15_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_15_Rst_A() {
    v2_2_15_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_15_WEN_A() {
    v2_2_15_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_16_Addr_A() {
    v2_2_16_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_16_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_16_Addr_A_orig() {
    v2_2_16_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_16_Clk_A() {
    v2_2_16_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_16_Din_A() {
    v2_2_16_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_16_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_16_EN_A = ap_const_logic_1;
    } else {
        v2_2_16_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_16_Rst_A() {
    v2_2_16_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_16_WEN_A() {
    v2_2_16_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_17_Addr_A() {
    v2_2_17_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_17_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_17_Addr_A_orig() {
    v2_2_17_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_17_Clk_A() {
    v2_2_17_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_17_Din_A() {
    v2_2_17_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_17_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_17_EN_A = ap_const_logic_1;
    } else {
        v2_2_17_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_17_Rst_A() {
    v2_2_17_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_17_WEN_A() {
    v2_2_17_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_18_Addr_A() {
    v2_2_18_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_18_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_18_Addr_A_orig() {
    v2_2_18_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_18_Clk_A() {
    v2_2_18_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_18_Din_A() {
    v2_2_18_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_18_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_18_EN_A = ap_const_logic_1;
    } else {
        v2_2_18_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_18_Rst_A() {
    v2_2_18_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_18_WEN_A() {
    v2_2_18_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_19_Addr_A() {
    v2_2_19_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_19_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_19_Addr_A_orig() {
    v2_2_19_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_19_Clk_A() {
    v2_2_19_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_19_Din_A() {
    v2_2_19_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_19_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_19_EN_A = ap_const_logic_1;
    } else {
        v2_2_19_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_19_Rst_A() {
    v2_2_19_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_19_WEN_A() {
    v2_2_19_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_1_Addr_A() {
    v2_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_1_Addr_A_orig() {
    v2_2_1_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_1_Clk_A() {
    v2_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_1_Din_A() {
    v2_2_1_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_1_EN_A = ap_const_logic_1;
    } else {
        v2_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_1_Rst_A() {
    v2_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_1_WEN_A() {
    v2_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_20_Addr_A() {
    v2_2_20_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_20_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_20_Addr_A_orig() {
    v2_2_20_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_20_Clk_A() {
    v2_2_20_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_20_Din_A() {
    v2_2_20_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_20_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_20_EN_A = ap_const_logic_1;
    } else {
        v2_2_20_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_20_Rst_A() {
    v2_2_20_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_20_WEN_A() {
    v2_2_20_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_21_Addr_A() {
    v2_2_21_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_21_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_21_Addr_A_orig() {
    v2_2_21_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_21_Clk_A() {
    v2_2_21_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_21_Din_A() {
    v2_2_21_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_21_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_21_EN_A = ap_const_logic_1;
    } else {
        v2_2_21_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_21_Rst_A() {
    v2_2_21_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_21_WEN_A() {
    v2_2_21_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_22_Addr_A() {
    v2_2_22_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_22_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_22_Addr_A_orig() {
    v2_2_22_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_22_Clk_A() {
    v2_2_22_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_22_Din_A() {
    v2_2_22_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_22_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_22_EN_A = ap_const_logic_1;
    } else {
        v2_2_22_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_22_Rst_A() {
    v2_2_22_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_22_WEN_A() {
    v2_2_22_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_23_Addr_A() {
    v2_2_23_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_23_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_23_Addr_A_orig() {
    v2_2_23_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_23_Clk_A() {
    v2_2_23_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_23_Din_A() {
    v2_2_23_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_23_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_23_EN_A = ap_const_logic_1;
    } else {
        v2_2_23_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_23_Rst_A() {
    v2_2_23_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_23_WEN_A() {
    v2_2_23_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_24_Addr_A() {
    v2_2_24_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_24_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_24_Addr_A_orig() {
    v2_2_24_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_24_Clk_A() {
    v2_2_24_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_24_Din_A() {
    v2_2_24_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_24_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_24_EN_A = ap_const_logic_1;
    } else {
        v2_2_24_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_24_Rst_A() {
    v2_2_24_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_24_WEN_A() {
    v2_2_24_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_25_Addr_A() {
    v2_2_25_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_25_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_25_Addr_A_orig() {
    v2_2_25_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_25_Clk_A() {
    v2_2_25_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_25_Din_A() {
    v2_2_25_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_25_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_25_EN_A = ap_const_logic_1;
    } else {
        v2_2_25_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_25_Rst_A() {
    v2_2_25_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_25_WEN_A() {
    v2_2_25_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_26_Addr_A() {
    v2_2_26_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_26_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_26_Addr_A_orig() {
    v2_2_26_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_26_Clk_A() {
    v2_2_26_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_26_Din_A() {
    v2_2_26_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_26_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_26_EN_A = ap_const_logic_1;
    } else {
        v2_2_26_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_26_Rst_A() {
    v2_2_26_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_26_WEN_A() {
    v2_2_26_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_27_Addr_A() {
    v2_2_27_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_27_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_27_Addr_A_orig() {
    v2_2_27_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_27_Clk_A() {
    v2_2_27_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_27_Din_A() {
    v2_2_27_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_27_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_27_EN_A = ap_const_logic_1;
    } else {
        v2_2_27_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_27_Rst_A() {
    v2_2_27_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_27_WEN_A() {
    v2_2_27_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_28_Addr_A() {
    v2_2_28_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_28_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_28_Addr_A_orig() {
    v2_2_28_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_28_Clk_A() {
    v2_2_28_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_28_Din_A() {
    v2_2_28_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_28_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_28_EN_A = ap_const_logic_1;
    } else {
        v2_2_28_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_28_Rst_A() {
    v2_2_28_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_28_WEN_A() {
    v2_2_28_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_29_Addr_A() {
    v2_2_29_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_29_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_29_Addr_A_orig() {
    v2_2_29_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_29_Clk_A() {
    v2_2_29_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_29_Din_A() {
    v2_2_29_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_29_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_29_EN_A = ap_const_logic_1;
    } else {
        v2_2_29_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_29_Rst_A() {
    v2_2_29_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_29_WEN_A() {
    v2_2_29_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_2_Addr_A() {
    v2_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_2_Addr_A_orig() {
    v2_2_2_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_2_Clk_A() {
    v2_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_2_Din_A() {
    v2_2_2_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_2_EN_A = ap_const_logic_1;
    } else {
        v2_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_2_Rst_A() {
    v2_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_2_WEN_A() {
    v2_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_30_Addr_A() {
    v2_2_30_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_30_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_30_Addr_A_orig() {
    v2_2_30_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_30_Clk_A() {
    v2_2_30_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_30_Din_A() {
    v2_2_30_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_30_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_30_EN_A = ap_const_logic_1;
    } else {
        v2_2_30_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_30_Rst_A() {
    v2_2_30_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_30_WEN_A() {
    v2_2_30_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_31_Addr_A() {
    v2_2_31_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_31_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_31_Addr_A_orig() {
    v2_2_31_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_31_Clk_A() {
    v2_2_31_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_31_Din_A() {
    v2_2_31_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_31_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_31_EN_A = ap_const_logic_1;
    } else {
        v2_2_31_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_31_Rst_A() {
    v2_2_31_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_31_WEN_A() {
    v2_2_31_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_32_Addr_A() {
    v2_2_32_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_32_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_32_Addr_A_orig() {
    v2_2_32_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_32_Clk_A() {
    v2_2_32_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_32_Din_A() {
    v2_2_32_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_32_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_32_EN_A = ap_const_logic_1;
    } else {
        v2_2_32_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_32_Rst_A() {
    v2_2_32_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_32_WEN_A() {
    v2_2_32_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_33_Addr_A() {
    v2_2_33_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_33_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_33_Addr_A_orig() {
    v2_2_33_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_33_Clk_A() {
    v2_2_33_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_33_Din_A() {
    v2_2_33_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_33_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_33_EN_A = ap_const_logic_1;
    } else {
        v2_2_33_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_33_Rst_A() {
    v2_2_33_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_33_WEN_A() {
    v2_2_33_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_34_Addr_A() {
    v2_2_34_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_34_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_34_Addr_A_orig() {
    v2_2_34_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_34_Clk_A() {
    v2_2_34_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_34_Din_A() {
    v2_2_34_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_34_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_34_EN_A = ap_const_logic_1;
    } else {
        v2_2_34_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_34_Rst_A() {
    v2_2_34_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_34_WEN_A() {
    v2_2_34_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_35_Addr_A() {
    v2_2_35_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_35_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_35_Addr_A_orig() {
    v2_2_35_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_35_Clk_A() {
    v2_2_35_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_35_Din_A() {
    v2_2_35_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_35_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_35_EN_A = ap_const_logic_1;
    } else {
        v2_2_35_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_35_Rst_A() {
    v2_2_35_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_35_WEN_A() {
    v2_2_35_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_36_Addr_A() {
    v2_2_36_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_36_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_36_Addr_A_orig() {
    v2_2_36_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_36_Clk_A() {
    v2_2_36_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_36_Din_A() {
    v2_2_36_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_36_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_36_EN_A = ap_const_logic_1;
    } else {
        v2_2_36_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_36_Rst_A() {
    v2_2_36_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_36_WEN_A() {
    v2_2_36_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_37_Addr_A() {
    v2_2_37_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_37_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_37_Addr_A_orig() {
    v2_2_37_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_37_Clk_A() {
    v2_2_37_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_37_Din_A() {
    v2_2_37_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_37_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_37_EN_A = ap_const_logic_1;
    } else {
        v2_2_37_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_37_Rst_A() {
    v2_2_37_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_37_WEN_A() {
    v2_2_37_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_38_Addr_A() {
    v2_2_38_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_38_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_38_Addr_A_orig() {
    v2_2_38_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_38_Clk_A() {
    v2_2_38_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_38_Din_A() {
    v2_2_38_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_38_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_38_EN_A = ap_const_logic_1;
    } else {
        v2_2_38_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_38_Rst_A() {
    v2_2_38_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_38_WEN_A() {
    v2_2_38_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_39_Addr_A() {
    v2_2_39_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_39_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_39_Addr_A_orig() {
    v2_2_39_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_39_Clk_A() {
    v2_2_39_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_39_Din_A() {
    v2_2_39_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_39_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_39_EN_A = ap_const_logic_1;
    } else {
        v2_2_39_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_39_Rst_A() {
    v2_2_39_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_39_WEN_A() {
    v2_2_39_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_3_Addr_A() {
    v2_2_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_3_Addr_A_orig() {
    v2_2_3_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_3_Clk_A() {
    v2_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_3_Din_A() {
    v2_2_3_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_3_EN_A = ap_const_logic_1;
    } else {
        v2_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_3_Rst_A() {
    v2_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_3_WEN_A() {
    v2_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_40_Addr_A() {
    v2_2_40_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_40_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_40_Addr_A_orig() {
    v2_2_40_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_40_Clk_A() {
    v2_2_40_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_40_Din_A() {
    v2_2_40_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_40_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_40_EN_A = ap_const_logic_1;
    } else {
        v2_2_40_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_40_Rst_A() {
    v2_2_40_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_40_WEN_A() {
    v2_2_40_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_41_Addr_A() {
    v2_2_41_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_41_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_41_Addr_A_orig() {
    v2_2_41_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_41_Clk_A() {
    v2_2_41_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_41_Din_A() {
    v2_2_41_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_41_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_41_EN_A = ap_const_logic_1;
    } else {
        v2_2_41_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_41_Rst_A() {
    v2_2_41_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_41_WEN_A() {
    v2_2_41_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_42_Addr_A() {
    v2_2_42_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_42_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_42_Addr_A_orig() {
    v2_2_42_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_42_Clk_A() {
    v2_2_42_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_42_Din_A() {
    v2_2_42_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_42_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_42_EN_A = ap_const_logic_1;
    } else {
        v2_2_42_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_42_Rst_A() {
    v2_2_42_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_42_WEN_A() {
    v2_2_42_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_43_Addr_A() {
    v2_2_43_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_43_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_43_Addr_A_orig() {
    v2_2_43_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_43_Clk_A() {
    v2_2_43_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_43_Din_A() {
    v2_2_43_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_43_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_43_EN_A = ap_const_logic_1;
    } else {
        v2_2_43_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_43_Rst_A() {
    v2_2_43_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_43_WEN_A() {
    v2_2_43_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_44_Addr_A() {
    v2_2_44_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_44_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_44_Addr_A_orig() {
    v2_2_44_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_44_Clk_A() {
    v2_2_44_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_44_Din_A() {
    v2_2_44_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_44_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_44_EN_A = ap_const_logic_1;
    } else {
        v2_2_44_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_44_Rst_A() {
    v2_2_44_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_44_WEN_A() {
    v2_2_44_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_45_Addr_A() {
    v2_2_45_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_45_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_45_Addr_A_orig() {
    v2_2_45_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_45_Clk_A() {
    v2_2_45_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_45_Din_A() {
    v2_2_45_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_45_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_45_EN_A = ap_const_logic_1;
    } else {
        v2_2_45_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_45_Rst_A() {
    v2_2_45_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_45_WEN_A() {
    v2_2_45_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_46_Addr_A() {
    v2_2_46_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_46_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_46_Addr_A_orig() {
    v2_2_46_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_46_Clk_A() {
    v2_2_46_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_46_Din_A() {
    v2_2_46_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_46_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_46_EN_A = ap_const_logic_1;
    } else {
        v2_2_46_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_46_Rst_A() {
    v2_2_46_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_46_WEN_A() {
    v2_2_46_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_47_Addr_A() {
    v2_2_47_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_47_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_47_Addr_A_orig() {
    v2_2_47_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_47_Clk_A() {
    v2_2_47_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_47_Din_A() {
    v2_2_47_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_47_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_47_EN_A = ap_const_logic_1;
    } else {
        v2_2_47_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_47_Rst_A() {
    v2_2_47_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_47_WEN_A() {
    v2_2_47_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_48_Addr_A() {
    v2_2_48_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_48_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_48_Addr_A_orig() {
    v2_2_48_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_48_Clk_A() {
    v2_2_48_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_48_Din_A() {
    v2_2_48_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_48_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_48_EN_A = ap_const_logic_1;
    } else {
        v2_2_48_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_48_Rst_A() {
    v2_2_48_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_48_WEN_A() {
    v2_2_48_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_49_Addr_A() {
    v2_2_49_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_49_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_49_Addr_A_orig() {
    v2_2_49_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_49_Clk_A() {
    v2_2_49_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_49_Din_A() {
    v2_2_49_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_49_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_49_EN_A = ap_const_logic_1;
    } else {
        v2_2_49_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_49_Rst_A() {
    v2_2_49_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_49_WEN_A() {
    v2_2_49_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_4_Addr_A() {
    v2_2_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_4_Addr_A_orig() {
    v2_2_4_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_4_Clk_A() {
    v2_2_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_4_Din_A() {
    v2_2_4_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_4_EN_A = ap_const_logic_1;
    } else {
        v2_2_4_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_4_Rst_A() {
    v2_2_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_4_WEN_A() {
    v2_2_4_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_50_Addr_A() {
    v2_2_50_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_50_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_50_Addr_A_orig() {
    v2_2_50_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_50_Clk_A() {
    v2_2_50_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_50_Din_A() {
    v2_2_50_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_50_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_50_EN_A = ap_const_logic_1;
    } else {
        v2_2_50_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_50_Rst_A() {
    v2_2_50_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_50_WEN_A() {
    v2_2_50_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_51_Addr_A() {
    v2_2_51_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_51_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_51_Addr_A_orig() {
    v2_2_51_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_51_Clk_A() {
    v2_2_51_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_51_Din_A() {
    v2_2_51_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_51_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_51_EN_A = ap_const_logic_1;
    } else {
        v2_2_51_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_51_Rst_A() {
    v2_2_51_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_51_WEN_A() {
    v2_2_51_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_52_Addr_A() {
    v2_2_52_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_52_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_52_Addr_A_orig() {
    v2_2_52_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_52_Clk_A() {
    v2_2_52_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_52_Din_A() {
    v2_2_52_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_52_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_52_EN_A = ap_const_logic_1;
    } else {
        v2_2_52_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_52_Rst_A() {
    v2_2_52_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_52_WEN_A() {
    v2_2_52_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_53_Addr_A() {
    v2_2_53_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_53_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_53_Addr_A_orig() {
    v2_2_53_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_53_Clk_A() {
    v2_2_53_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_53_Din_A() {
    v2_2_53_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_53_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_53_EN_A = ap_const_logic_1;
    } else {
        v2_2_53_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_53_Rst_A() {
    v2_2_53_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_53_WEN_A() {
    v2_2_53_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_54_Addr_A() {
    v2_2_54_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_54_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_54_Addr_A_orig() {
    v2_2_54_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_54_Clk_A() {
    v2_2_54_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_54_Din_A() {
    v2_2_54_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_54_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_54_EN_A = ap_const_logic_1;
    } else {
        v2_2_54_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_54_Rst_A() {
    v2_2_54_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_54_WEN_A() {
    v2_2_54_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_55_Addr_A() {
    v2_2_55_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_55_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_55_Addr_A_orig() {
    v2_2_55_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_55_Clk_A() {
    v2_2_55_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_55_Din_A() {
    v2_2_55_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_55_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_55_EN_A = ap_const_logic_1;
    } else {
        v2_2_55_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_55_Rst_A() {
    v2_2_55_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_55_WEN_A() {
    v2_2_55_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_56_Addr_A() {
    v2_2_56_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_56_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_56_Addr_A_orig() {
    v2_2_56_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_56_Clk_A() {
    v2_2_56_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_56_Din_A() {
    v2_2_56_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_56_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_56_EN_A = ap_const_logic_1;
    } else {
        v2_2_56_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_56_Rst_A() {
    v2_2_56_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_56_WEN_A() {
    v2_2_56_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_57_Addr_A() {
    v2_2_57_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_57_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_57_Addr_A_orig() {
    v2_2_57_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_57_Clk_A() {
    v2_2_57_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_57_Din_A() {
    v2_2_57_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_57_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_57_EN_A = ap_const_logic_1;
    } else {
        v2_2_57_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_57_Rst_A() {
    v2_2_57_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_57_WEN_A() {
    v2_2_57_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_58_Addr_A() {
    v2_2_58_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_58_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_58_Addr_A_orig() {
    v2_2_58_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

void kernel_bicg_sdse::thread_v2_2_58_Clk_A() {
    v2_2_58_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_bicg_sdse::thread_v2_2_58_Din_A() {
    v2_2_58_Din_A = ap_const_lv32_0;
}

void kernel_bicg_sdse::thread_v2_2_58_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_2_58_EN_A = ap_const_logic_1;
    } else {
        v2_2_58_EN_A = ap_const_logic_0;
    }
}

void kernel_bicg_sdse::thread_v2_2_58_Rst_A() {
    v2_2_58_Rst_A = ap_rst_n_inv.read();
}

void kernel_bicg_sdse::thread_v2_2_58_WEN_A() {
    v2_2_58_WEN_A = ap_const_lv4_0;
}

void kernel_bicg_sdse::thread_v2_2_59_Addr_A() {
    v2_2_59_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_59_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_bicg_sdse::thread_v2_2_59_Addr_A_orig() {
    v2_2_59_Addr_A_orig =  (sc_lv<32>) (sext_ln129_fu_10514_p1.read());
}

}


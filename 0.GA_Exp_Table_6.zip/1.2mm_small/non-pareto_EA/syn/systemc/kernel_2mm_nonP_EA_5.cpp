#include "kernel_2mm_nonP_EA.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_2mm_nonP_EA::thread_v4_4_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_4_7_EN_A = ap_const_logic_1;
    } else {
        v4_4_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_4_7_Rst_A() {
    v4_4_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_4_7_WEN_A() {
    v4_4_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_4_8_Addr_A() {
    v4_4_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_4_8_Addr_A_orig() {
    v4_4_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_4_8_Clk_A() {
    v4_4_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_4_8_Din_A() {
    v4_4_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_4_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_4_8_EN_A = ap_const_logic_1;
    } else {
        v4_4_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_4_8_Rst_A() {
    v4_4_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_4_8_WEN_A() {
    v4_4_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_4_9_Addr_A() {
    v4_4_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_4_9_Addr_A_orig() {
    v4_4_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_4_9_Clk_A() {
    v4_4_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_4_9_Din_A() {
    v4_4_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_4_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_4_9_EN_A = ap_const_logic_1;
    } else {
        v4_4_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_4_9_Rst_A() {
    v4_4_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_4_9_WEN_A() {
    v4_4_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_0_Addr_A() {
    v4_5_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_0_Addr_A_orig() {
    v4_5_0_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_0_Clk_A() {
    v4_5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_0_Din_A() {
    v4_5_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_0_EN_A = ap_const_logic_1;
    } else {
        v4_5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_0_Rst_A() {
    v4_5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_0_WEN_A() {
    v4_5_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_1_Addr_A() {
    v4_5_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_1_Addr_A_orig() {
    v4_5_1_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_1_Clk_A() {
    v4_5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_1_Din_A() {
    v4_5_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_1_EN_A = ap_const_logic_1;
    } else {
        v4_5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_1_Rst_A() {
    v4_5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_1_WEN_A() {
    v4_5_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_2_Addr_A() {
    v4_5_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_2_Addr_A_orig() {
    v4_5_2_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_2_Clk_A() {
    v4_5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_2_Din_A() {
    v4_5_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_2_EN_A = ap_const_logic_1;
    } else {
        v4_5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_2_Rst_A() {
    v4_5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_2_WEN_A() {
    v4_5_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_3_Addr_A() {
    v4_5_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_3_Addr_A_orig() {
    v4_5_3_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_3_Clk_A() {
    v4_5_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_3_Din_A() {
    v4_5_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_3_EN_A = ap_const_logic_1;
    } else {
        v4_5_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_3_Rst_A() {
    v4_5_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_3_WEN_A() {
    v4_5_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_4_Addr_A() {
    v4_5_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_4_Addr_A_orig() {
    v4_5_4_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_4_Clk_A() {
    v4_5_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_4_Din_A() {
    v4_5_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_4_EN_A = ap_const_logic_1;
    } else {
        v4_5_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_4_Rst_A() {
    v4_5_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_4_WEN_A() {
    v4_5_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_5_Addr_A() {
    v4_5_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_5_Addr_A_orig() {
    v4_5_5_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_5_Clk_A() {
    v4_5_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_5_Din_A() {
    v4_5_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_5_EN_A = ap_const_logic_1;
    } else {
        v4_5_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_5_Rst_A() {
    v4_5_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_5_WEN_A() {
    v4_5_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_6_Addr_A() {
    v4_5_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_6_Addr_A_orig() {
    v4_5_6_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_6_Clk_A() {
    v4_5_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_6_Din_A() {
    v4_5_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_6_EN_A = ap_const_logic_1;
    } else {
        v4_5_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_6_Rst_A() {
    v4_5_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_6_WEN_A() {
    v4_5_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_7_Addr_A() {
    v4_5_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_7_Addr_A_orig() {
    v4_5_7_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_7_Clk_A() {
    v4_5_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_7_Din_A() {
    v4_5_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_7_EN_A = ap_const_logic_1;
    } else {
        v4_5_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_7_Rst_A() {
    v4_5_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_7_WEN_A() {
    v4_5_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_8_Addr_A() {
    v4_5_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_8_Addr_A_orig() {
    v4_5_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_8_Clk_A() {
    v4_5_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_8_Din_A() {
    v4_5_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_8_EN_A = ap_const_logic_1;
    } else {
        v4_5_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_8_Rst_A() {
    v4_5_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_8_WEN_A() {
    v4_5_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_9_Addr_A() {
    v4_5_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_5_9_Addr_A_orig() {
    v4_5_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_5_9_Clk_A() {
    v4_5_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_9_Din_A() {
    v4_5_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_5_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_5_9_EN_A = ap_const_logic_1;
    } else {
        v4_5_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_5_9_Rst_A() {
    v4_5_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_5_9_WEN_A() {
    v4_5_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_0_Addr_A() {
    v4_6_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_0_Addr_A_orig() {
    v4_6_0_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_0_Clk_A() {
    v4_6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_0_Din_A() {
    v4_6_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_0_EN_A = ap_const_logic_1;
    } else {
        v4_6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_0_Rst_A() {
    v4_6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_0_WEN_A() {
    v4_6_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_1_Addr_A() {
    v4_6_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_1_Addr_A_orig() {
    v4_6_1_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_1_Clk_A() {
    v4_6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_1_Din_A() {
    v4_6_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_1_EN_A = ap_const_logic_1;
    } else {
        v4_6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_1_Rst_A() {
    v4_6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_1_WEN_A() {
    v4_6_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_2_Addr_A() {
    v4_6_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_2_Addr_A_orig() {
    v4_6_2_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_2_Clk_A() {
    v4_6_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_2_Din_A() {
    v4_6_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_2_EN_A = ap_const_logic_1;
    } else {
        v4_6_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_2_Rst_A() {
    v4_6_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_2_WEN_A() {
    v4_6_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_3_Addr_A() {
    v4_6_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_3_Addr_A_orig() {
    v4_6_3_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_3_Clk_A() {
    v4_6_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_3_Din_A() {
    v4_6_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_3_EN_A = ap_const_logic_1;
    } else {
        v4_6_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_3_Rst_A() {
    v4_6_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_3_WEN_A() {
    v4_6_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_4_Addr_A() {
    v4_6_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_4_Addr_A_orig() {
    v4_6_4_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_4_Clk_A() {
    v4_6_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_4_Din_A() {
    v4_6_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_4_EN_A = ap_const_logic_1;
    } else {
        v4_6_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_4_Rst_A() {
    v4_6_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_4_WEN_A() {
    v4_6_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_5_Addr_A() {
    v4_6_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_5_Addr_A_orig() {
    v4_6_5_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_5_Clk_A() {
    v4_6_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_5_Din_A() {
    v4_6_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_5_EN_A = ap_const_logic_1;
    } else {
        v4_6_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_5_Rst_A() {
    v4_6_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_5_WEN_A() {
    v4_6_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_6_Addr_A() {
    v4_6_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_6_Addr_A_orig() {
    v4_6_6_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_6_Clk_A() {
    v4_6_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_6_Din_A() {
    v4_6_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_6_EN_A = ap_const_logic_1;
    } else {
        v4_6_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_6_Rst_A() {
    v4_6_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_6_WEN_A() {
    v4_6_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_7_Addr_A() {
    v4_6_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_7_Addr_A_orig() {
    v4_6_7_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_7_Clk_A() {
    v4_6_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_7_Din_A() {
    v4_6_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_7_EN_A = ap_const_logic_1;
    } else {
        v4_6_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_7_Rst_A() {
    v4_6_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_7_WEN_A() {
    v4_6_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_8_Addr_A() {
    v4_6_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_8_Addr_A_orig() {
    v4_6_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_8_Clk_A() {
    v4_6_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_8_Din_A() {
    v4_6_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_8_EN_A = ap_const_logic_1;
    } else {
        v4_6_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_8_Rst_A() {
    v4_6_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_8_WEN_A() {
    v4_6_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_9_Addr_A() {
    v4_6_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v4_6_9_Addr_A_orig() {
    v4_6_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_reg_5433.read());
}

void kernel_2mm_nonP_EA::thread_v4_6_9_Clk_A() {
    v4_6_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_9_Din_A() {
    v4_6_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v4_6_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage1_11001.read()))) {
        v4_6_9_EN_A = ap_const_logic_1;
    } else {
        v4_6_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v4_6_9_Rst_A() {
    v4_6_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v4_6_9_WEN_A() {
    v4_6_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v51_1_fu_4048_p3() {
    v51_1_fu_4048_p3 = (!select_ln60_1_reg_5315_pp0_iter3_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln60_1_reg_5315_pp0_iter3_reg.read()[0].to_bool())? ap_const_lv32_0: v2_7_Dout_A.read());
}

void kernel_2mm_nonP_EA::thread_v56_1_fu_4055_p3() {
    v56_1_fu_4055_p3 = (!select_ln60_1_reg_5315_pp0_iter3_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln60_1_reg_5315_pp0_iter3_reg.read()[0].to_bool())? ap_const_lv32_0: v2_8_Dout_A.read());
}

void kernel_2mm_nonP_EA::thread_v5_0_0_Addr_A() {
    v5_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_0_0_Addr_A_orig() {
    v5_0_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_4569_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_0_0_Clk_A() {
    v5_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_0_Din_A() {
    v5_0_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_0_0_EN_A = ap_const_logic_1;
    } else {
        v5_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_0_0_Rst_A() {
    v5_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_0_0_WEN_A() {
    v5_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_1_Addr_A() {
    v5_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_0_1_Addr_A_orig() {
    v5_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_4569_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_0_1_Clk_A() {
    v5_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_1_Din_A() {
    v5_0_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_0_1_EN_A = ap_const_logic_1;
    } else {
        v5_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_0_1_Rst_A() {
    v5_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_0_1_WEN_A() {
    v5_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_2_Addr_A() {
    v5_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_0_2_Addr_A_orig() {
    v5_0_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_4583_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_0_2_Clk_A() {
    v5_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_2_Din_A() {
    v5_0_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_0_2_EN_A = ap_const_logic_1;
    } else {
        v5_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_0_2_Rst_A() {
    v5_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_0_2_WEN_A() {
    v5_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_3_Addr_A() {
    v5_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_0_3_Addr_A_orig() {
    v5_0_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_4583_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_0_3_Clk_A() {
    v5_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_3_Din_A() {
    v5_0_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_0_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_0_3_EN_A = ap_const_logic_1;
    } else {
        v5_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_0_3_Rst_A() {
    v5_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_0_3_WEN_A() {
    v5_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_0_Addr_A() {
    v5_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_1_0_Addr_A_orig() {
    v5_1_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_4569_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_1_0_Clk_A() {
    v5_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_0_Din_A() {
    v5_1_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_1_0_EN_A = ap_const_logic_1;
    } else {
        v5_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_1_0_Rst_A() {
    v5_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_1_0_WEN_A() {
    v5_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_1_Addr_A() {
    v5_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_1_1_Addr_A_orig() {
    v5_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_4569_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_1_1_Clk_A() {
    v5_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_1_Din_A() {
    v5_1_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_1_1_EN_A = ap_const_logic_1;
    } else {
        v5_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_1_1_Rst_A() {
    v5_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_1_1_WEN_A() {
    v5_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_2_Addr_A() {
    v5_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_1_2_Addr_A_orig() {
    v5_1_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_4583_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_1_2_Clk_A() {
    v5_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_2_Din_A() {
    v5_1_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_1_2_EN_A = ap_const_logic_1;
    } else {
        v5_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_1_2_Rst_A() {
    v5_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_1_2_WEN_A() {
    v5_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_3_Addr_A() {
    v5_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_1_3_Addr_A_orig() {
    v5_1_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_4583_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_1_3_Clk_A() {
    v5_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_3_Din_A() {
    v5_1_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_1_3_EN_A = ap_const_logic_1;
    } else {
        v5_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_1_3_Rst_A() {
    v5_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_1_3_WEN_A() {
    v5_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_0_Addr_A() {
    v5_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_2_0_Addr_A_orig() {
    v5_2_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_4569_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_2_0_Clk_A() {
    v5_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_0_Din_A() {
    v5_2_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_2_0_EN_A = ap_const_logic_1;
    } else {
        v5_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_2_0_Rst_A() {
    v5_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_2_0_WEN_A() {
    v5_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_1_Addr_A() {
    v5_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_2_1_Addr_A_orig() {
    v5_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_4569_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_2_1_Clk_A() {
    v5_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_1_Din_A() {
    v5_2_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_2_1_EN_A = ap_const_logic_1;
    } else {
        v5_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_2_1_Rst_A() {
    v5_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_2_1_WEN_A() {
    v5_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_2_Addr_A() {
    v5_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_2_2_Addr_A_orig() {
    v5_2_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_4583_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_2_2_Clk_A() {
    v5_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_2_Din_A() {
    v5_2_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_2_2_EN_A = ap_const_logic_1;
    } else {
        v5_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_2_2_Rst_A() {
    v5_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_2_2_WEN_A() {
    v5_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_3_Addr_A() {
    v5_2_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_2_3_Addr_A_orig() {
    v5_2_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_4583_p1.read());
}

void kernel_2mm_nonP_EA::thread_v5_2_3_Clk_A() {
    v5_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_3_Din_A() {
    v5_2_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_2_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_2_3_EN_A = ap_const_logic_1;
    } else {
        v5_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_2_3_Rst_A() {
    v5_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_2_3_WEN_A() {
    v5_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_0_Addr_A() {
    v5_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_3_0_Addr_A_orig() {
    v5_3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7021.read());
}

void kernel_2mm_nonP_EA::thread_v5_3_0_Clk_A() {
    v5_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_0_Din_A() {
    v5_3_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_3_0_EN_A = ap_const_logic_1;
    } else {
        v5_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_3_0_Rst_A() {
    v5_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_3_0_WEN_A() {
    v5_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_1_Addr_A() {
    v5_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_3_1_Addr_A_orig() {
    v5_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7021.read());
}

void kernel_2mm_nonP_EA::thread_v5_3_1_Clk_A() {
    v5_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_1_Din_A() {
    v5_3_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_3_1_EN_A = ap_const_logic_1;
    } else {
        v5_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_3_1_Rst_A() {
    v5_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_3_1_WEN_A() {
    v5_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_2_Addr_A() {
    v5_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_3_2_Addr_A_orig() {
    v5_3_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7039.read());
}

void kernel_2mm_nonP_EA::thread_v5_3_2_Clk_A() {
    v5_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_2_Din_A() {
    v5_3_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_3_2_EN_A = ap_const_logic_1;
    } else {
        v5_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_3_2_Rst_A() {
    v5_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_3_2_WEN_A() {
    v5_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_3_Addr_A() {
    v5_3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_3_3_Addr_A_orig() {
    v5_3_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7039.read());
}

void kernel_2mm_nonP_EA::thread_v5_3_3_Clk_A() {
    v5_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_3_Din_A() {
    v5_3_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_3_3_EN_A = ap_const_logic_1;
    } else {
        v5_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_3_3_Rst_A() {
    v5_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_3_3_WEN_A() {
    v5_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_0_Addr_A() {
    v5_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_4_0_Addr_A_orig() {
    v5_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7021.read());
}

void kernel_2mm_nonP_EA::thread_v5_4_0_Clk_A() {
    v5_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_0_Din_A() {
    v5_4_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_4_0_EN_A = ap_const_logic_1;
    } else {
        v5_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_4_0_Rst_A() {
    v5_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_4_0_WEN_A() {
    v5_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_1_Addr_A() {
    v5_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_4_1_Addr_A_orig() {
    v5_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7021.read());
}

void kernel_2mm_nonP_EA::thread_v5_4_1_Clk_A() {
    v5_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_1_Din_A() {
    v5_4_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_4_1_EN_A = ap_const_logic_1;
    } else {
        v5_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_4_1_Rst_A() {
    v5_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_4_1_WEN_A() {
    v5_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_2_Addr_A() {
    v5_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_4_2_Addr_A_orig() {
    v5_4_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7039.read());
}

void kernel_2mm_nonP_EA::thread_v5_4_2_Clk_A() {
    v5_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_2_Din_A() {
    v5_4_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_4_2_EN_A = ap_const_logic_1;
    } else {
        v5_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_4_2_Rst_A() {
    v5_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_4_2_WEN_A() {
    v5_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_3_Addr_A() {
    v5_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v5_4_3_Addr_A_orig() {
    v5_4_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7039.read());
}

void kernel_2mm_nonP_EA::thread_v5_4_3_Clk_A() {
    v5_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_3_Din_A() {
    v5_4_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v5_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0))) {
        v5_4_3_EN_A = ap_const_logic_1;
    } else {
        v5_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v5_4_3_Rst_A() {
    v5_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v5_4_3_WEN_A() {
    v5_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v61_1_fu_4062_p3() {
    v61_1_fu_4062_p3 = (!select_ln60_1_reg_5315_pp0_iter3_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln60_1_reg_5315_pp0_iter3_reg.read()[0].to_bool())? ap_const_lv32_0: v2_9_Dout_A.read());
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Addr_A() {
    v6_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Addr_A_orig() {
    v6_0_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Addr_B() {
    v6_0_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Addr_B_orig() {
    v6_0_0_Addr_B_orig =  (sc_lv<32>) (v6_0_0_addr_reg_6695_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Clk_A() {
    v6_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Clk_B() {
    v6_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Din_A() {
    v6_0_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Din_B() {
    v6_0_0_Din_B = reg_3567.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_0_0_EN_A = ap_const_logic_1;
    } else {
        v6_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_0_0_EN_B = ap_const_logic_1;
    } else {
        v6_0_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Rst_A() {
    v6_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_0_Rst_B() {
    v6_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_0_WEN_A() {
    v6_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_0_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Addr_A() {
    v6_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Addr_A_orig() {
    v6_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Addr_B() {
    v6_0_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Addr_B_orig() {
    v6_0_1_Addr_B_orig =  (sc_lv<32>) (v6_0_1_addr_reg_6701_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Clk_A() {
    v6_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Clk_B() {
    v6_0_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Din_A() {
    v6_0_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Din_B() {
    v6_0_1_Din_B = reg_3573.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_0_1_EN_A = ap_const_logic_1;
    } else {
        v6_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_0_1_EN_B = ap_const_logic_1;
    } else {
        v6_0_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Rst_A() {
    v6_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_1_Rst_B() {
    v6_0_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_1_WEN_A() {
    v6_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_0_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Addr_A() {
    v6_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Addr_A_orig() {
    v6_0_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Addr_B() {
    v6_0_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Addr_B_orig() {
    v6_0_2_Addr_B_orig =  (sc_lv<32>) (v6_0_2_addr_reg_6707_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Clk_A() {
    v6_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Clk_B() {
    v6_0_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Din_A() {
    v6_0_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Din_B() {
    v6_0_2_Din_B = reg_3579.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_0_2_EN_A = ap_const_logic_1;
    } else {
        v6_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_0_2_EN_B = ap_const_logic_1;
    } else {
        v6_0_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Rst_A() {
    v6_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_2_Rst_B() {
    v6_0_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_2_WEN_A() {
    v6_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_0_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Addr_A() {
    v6_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Addr_A_orig() {
    v6_0_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Addr_B() {
    v6_0_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Addr_B_orig() {
    v6_0_3_Addr_B_orig =  (sc_lv<32>) (v6_0_3_addr_reg_6713_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Clk_A() {
    v6_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Clk_B() {
    v6_0_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Din_A() {
    v6_0_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Din_B() {
    v6_0_3_Din_B = reg_3585.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_0_3_EN_A = ap_const_logic_1;
    } else {
        v6_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_0_3_EN_B = ap_const_logic_1;
    } else {
        v6_0_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Rst_A() {
    v6_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_3_Rst_B() {
    v6_0_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_0_3_WEN_A() {
    v6_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_0_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_0_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Addr_A() {
    v6_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Addr_A_orig() {
    v6_1_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Addr_B() {
    v6_1_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Addr_B_orig() {
    v6_1_0_Addr_B_orig =  (sc_lv<32>) (v6_1_0_addr_reg_6719_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Clk_A() {
    v6_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Clk_B() {
    v6_1_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Din_A() {
    v6_1_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Din_B() {
    v6_1_0_Din_B = reg_3591.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_1_0_EN_A = ap_const_logic_1;
    } else {
        v6_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_1_0_EN_B = ap_const_logic_1;
    } else {
        v6_1_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Rst_A() {
    v6_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_0_Rst_B() {
    v6_1_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_0_WEN_A() {
    v6_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_1_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Addr_A() {
    v6_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Addr_A_orig() {
    v6_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Addr_B() {
    v6_1_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Addr_B_orig() {
    v6_1_1_Addr_B_orig =  (sc_lv<32>) (v6_1_1_addr_reg_6725_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Clk_A() {
    v6_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Clk_B() {
    v6_1_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Din_A() {
    v6_1_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Din_B() {
    v6_1_1_Din_B = reg_3597.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_1_1_EN_A = ap_const_logic_1;
    } else {
        v6_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_1_1_EN_B = ap_const_logic_1;
    } else {
        v6_1_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Rst_A() {
    v6_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_1_Rst_B() {
    v6_1_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_1_WEN_A() {
    v6_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_1_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Addr_A() {
    v6_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Addr_A_orig() {
    v6_1_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Addr_B() {
    v6_1_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Addr_B_orig() {
    v6_1_2_Addr_B_orig =  (sc_lv<32>) (v6_1_2_addr_reg_6731_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Clk_A() {
    v6_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Clk_B() {
    v6_1_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Din_A() {
    v6_1_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Din_B() {
    v6_1_2_Din_B = reg_3603.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_1_2_EN_A = ap_const_logic_1;
    } else {
        v6_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_1_2_EN_B = ap_const_logic_1;
    } else {
        v6_1_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Rst_A() {
    v6_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_2_Rst_B() {
    v6_1_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_2_WEN_A() {
    v6_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_1_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Addr_A() {
    v6_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Addr_A_orig() {
    v6_1_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Addr_B() {
    v6_1_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Addr_B_orig() {
    v6_1_3_Addr_B_orig =  (sc_lv<32>) (v6_1_3_addr_reg_6737_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Clk_A() {
    v6_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Clk_B() {
    v6_1_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Din_A() {
    v6_1_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Din_B() {
    v6_1_3_Din_B = reg_3609.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_1_3_EN_A = ap_const_logic_1;
    } else {
        v6_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_1_3_EN_B = ap_const_logic_1;
    } else {
        v6_1_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Rst_A() {
    v6_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_3_Rst_B() {
    v6_1_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_1_3_WEN_A() {
    v6_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_1_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_1_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Addr_A() {
    v6_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Addr_A_orig() {
    v6_2_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Addr_B() {
    v6_2_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Addr_B_orig() {
    v6_2_0_Addr_B_orig =  (sc_lv<32>) (v6_2_0_addr_reg_6743_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Clk_A() {
    v6_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Clk_B() {
    v6_2_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Din_A() {
    v6_2_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Din_B() {
    v6_2_0_Din_B = reg_3615.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_2_0_EN_A = ap_const_logic_1;
    } else {
        v6_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_2_0_EN_B = ap_const_logic_1;
    } else {
        v6_2_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Rst_A() {
    v6_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_0_Rst_B() {
    v6_2_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_0_WEN_A() {
    v6_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_2_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Addr_A() {
    v6_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Addr_A_orig() {
    v6_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Addr_B() {
    v6_2_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Addr_B_orig() {
    v6_2_1_Addr_B_orig =  (sc_lv<32>) (v6_2_1_addr_reg_6749_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Clk_A() {
    v6_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Clk_B() {
    v6_2_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Din_A() {
    v6_2_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Din_B() {
    v6_2_1_Din_B = reg_3621.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_2_1_EN_A = ap_const_logic_1;
    } else {
        v6_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_2_1_EN_B = ap_const_logic_1;
    } else {
        v6_2_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Rst_A() {
    v6_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_1_Rst_B() {
    v6_2_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_1_WEN_A() {
    v6_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_2_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Addr_A() {
    v6_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Addr_A_orig() {
    v6_2_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Addr_B() {
    v6_2_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Addr_B_orig() {
    v6_2_2_Addr_B_orig =  (sc_lv<32>) (v6_2_2_addr_reg_6755_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Clk_A() {
    v6_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Clk_B() {
    v6_2_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Din_A() {
    v6_2_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Din_B() {
    v6_2_2_Din_B = reg_3627.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_2_2_EN_A = ap_const_logic_1;
    } else {
        v6_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_2_2_EN_B = ap_const_logic_1;
    } else {
        v6_2_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Rst_A() {
    v6_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_2_Rst_B() {
    v6_2_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_2_WEN_A() {
    v6_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_2_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Addr_A() {
    v6_2_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Addr_A_orig() {
    v6_2_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Addr_B() {
    v6_2_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Addr_B_orig() {
    v6_2_3_Addr_B_orig =  (sc_lv<32>) (v6_2_3_addr_reg_6761_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Clk_A() {
    v6_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Clk_B() {
    v6_2_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Din_A() {
    v6_2_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Din_B() {
    v6_2_3_Din_B = reg_3633.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_2_3_EN_A = ap_const_logic_1;
    } else {
        v6_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_2_3_EN_B = ap_const_logic_1;
    } else {
        v6_2_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Rst_A() {
    v6_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_3_Rst_B() {
    v6_2_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_2_3_WEN_A() {
    v6_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_2_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_2_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Addr_A() {
    v6_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Addr_A_orig() {
    v6_3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Addr_B() {
    v6_3_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Addr_B_orig() {
    v6_3_0_Addr_B_orig =  (sc_lv<32>) (v6_3_0_addr_reg_6767_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Clk_A() {
    v6_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Clk_B() {
    v6_3_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Din_A() {
    v6_3_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Din_B() {
    v6_3_0_Din_B = reg_3639.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_3_0_EN_A = ap_const_logic_1;
    } else {
        v6_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_3_0_EN_B = ap_const_logic_1;
    } else {
        v6_3_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Rst_A() {
    v6_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_0_Rst_B() {
    v6_3_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_0_WEN_A() {
    v6_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_3_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Addr_A() {
    v6_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Addr_A_orig() {
    v6_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Addr_B() {
    v6_3_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Addr_B_orig() {
    v6_3_1_Addr_B_orig =  (sc_lv<32>) (v6_3_1_addr_reg_6773_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Clk_A() {
    v6_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Clk_B() {
    v6_3_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Din_A() {
    v6_3_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Din_B() {
    v6_3_1_Din_B = reg_3645.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_3_1_EN_A = ap_const_logic_1;
    } else {
        v6_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_3_1_EN_B = ap_const_logic_1;
    } else {
        v6_3_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Rst_A() {
    v6_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_1_Rst_B() {
    v6_3_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_1_WEN_A() {
    v6_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_3_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Addr_A() {
    v6_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Addr_A_orig() {
    v6_3_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Addr_B() {
    v6_3_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Addr_B_orig() {
    v6_3_2_Addr_B_orig =  (sc_lv<32>) (v6_3_2_addr_reg_6779_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Clk_A() {
    v6_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Clk_B() {
    v6_3_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Din_A() {
    v6_3_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Din_B() {
    v6_3_2_Din_B = reg_3651.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_3_2_EN_A = ap_const_logic_1;
    } else {
        v6_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_3_2_EN_B = ap_const_logic_1;
    } else {
        v6_3_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Rst_A() {
    v6_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_2_Rst_B() {
    v6_3_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_2_WEN_A() {
    v6_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_3_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Addr_A() {
    v6_3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Addr_A_orig() {
    v6_3_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Addr_B() {
    v6_3_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Addr_B_orig() {
    v6_3_3_Addr_B_orig =  (sc_lv<32>) (v6_3_3_addr_reg_6785_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Clk_A() {
    v6_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Clk_B() {
    v6_3_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Din_A() {
    v6_3_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Din_B() {
    v6_3_3_Din_B = reg_3657.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_3_3_EN_A = ap_const_logic_1;
    } else {
        v6_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_3_3_EN_B = ap_const_logic_1;
    } else {
        v6_3_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Rst_A() {
    v6_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_3_Rst_B() {
    v6_3_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_3_3_WEN_A() {
    v6_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_3_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_3_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Addr_A() {
    v6_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Addr_A_orig() {
    v6_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Addr_B() {
    v6_4_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Addr_B_orig() {
    v6_4_0_Addr_B_orig =  (sc_lv<32>) (v6_4_0_addr_reg_6791_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Clk_A() {
    v6_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Clk_B() {
    v6_4_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Din_A() {
    v6_4_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Din_B() {
    v6_4_0_Din_B = reg_3663.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_4_0_EN_A = ap_const_logic_1;
    } else {
        v6_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_4_0_EN_B = ap_const_logic_1;
    } else {
        v6_4_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Rst_A() {
    v6_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_0_Rst_B() {
    v6_4_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_0_WEN_A() {
    v6_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_4_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Addr_A() {
    v6_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Addr_A_orig() {
    v6_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Addr_B() {
    v6_4_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Addr_B_orig() {
    v6_4_1_Addr_B_orig =  (sc_lv<32>) (v6_4_1_addr_reg_6797_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Clk_A() {
    v6_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Clk_B() {
    v6_4_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Din_A() {
    v6_4_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Din_B() {
    v6_4_1_Din_B = reg_3669.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_4_1_EN_A = ap_const_logic_1;
    } else {
        v6_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_4_1_EN_B = ap_const_logic_1;
    } else {
        v6_4_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Rst_A() {
    v6_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_1_Rst_B() {
    v6_4_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_1_WEN_A() {
    v6_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_4_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Addr_A() {
    v6_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Addr_A_orig() {
    v6_4_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Addr_B() {
    v6_4_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Addr_B_orig() {
    v6_4_2_Addr_B_orig =  (sc_lv<32>) (v6_4_2_addr_reg_6803_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Clk_A() {
    v6_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Clk_B() {
    v6_4_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Din_A() {
    v6_4_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Din_B() {
    v6_4_2_Din_B = reg_3675.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_4_2_EN_A = ap_const_logic_1;
    } else {
        v6_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_4_2_EN_B = ap_const_logic_1;
    } else {
        v6_4_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Rst_A() {
    v6_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_2_Rst_B() {
    v6_4_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_2_WEN_A() {
    v6_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_4_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Addr_A() {
    v6_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Addr_A_orig() {
    v6_4_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_4_fu_4315_p1.read());
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Addr_B() {
    v6_4_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Addr_B_orig() {
    v6_4_3_Addr_B_orig =  (sc_lv<32>) (v6_4_3_addr_reg_6809_pp1_iter6_reg.read());
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Clk_A() {
    v6_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Clk_B() {
    v6_4_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Din_A() {
    v6_4_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Din_B() {
    v6_4_3_Din_B = reg_3681.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_4_3_EN_A = ap_const_logic_1;
    } else {
        v6_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()))) {
        v6_4_3_EN_B = ap_const_logic_1;
    } else {
        v6_4_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Rst_A() {
    v6_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_3_Rst_B() {
    v6_4_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP_EA::thread_v6_4_3_WEN_A() {
    v6_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP_EA::thread_v6_4_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6580_pp1_iter6_reg.read()))) {
        v6_4_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP_EA::thread_v8_fu_3717_p2() {
    v8_fu_3717_p2 = (!ap_phi_mux_v8_0_phi_fu_2582_p4.read().is_01() || !ap_const_lv4_1.is_01())? sc_lv<4>(): (sc_biguint<4>(ap_phi_mux_v8_0_phi_fu_2582_p4.read()) + sc_biguint<4>(ap_const_lv4_1));
}

void kernel_2mm_nonP_EA::thread_v9_fu_3789_p2() {
    v9_fu_3789_p2 = (!select_ln60_fu_3729_p3.read().is_01() || !ap_const_lv6_1.is_01())? sc_lv<6>(): (sc_biguint<6>(select_ln60_fu_3729_p3.read()) + sc_biguint<6>(ap_const_lv6_1));
}

void kernel_2mm_nonP_EA::thread_xor_ln371_fu_4205_p2() {
    xor_ln371_fu_4205_p2 = (icmp_ln372_reg_6584.read() ^ ap_const_lv1_1);
}

void kernel_2mm_nonP_EA::thread_xor_ln60_fu_3771_p2() {
    xor_ln60_fu_3771_p2 = (icmp_ln61_fu_3723_p2.read() ^ ap_const_lv1_1);
}

void kernel_2mm_nonP_EA::thread_zext_ln371_1_fu_4155_p1() {
    zext_ln371_1_fu_4155_p1 = esl_zext<6,4>(v255_fu_4142_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln371_3_fu_4379_p1() {
    zext_ln371_3_fu_4379_p1 = esl_zext<9,6>(sext_ln371_fu_4375_p1.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln371_5_fu_4469_p1() {
    zext_ln371_5_fu_4469_p1 = esl_zext<9,6>(sext_ln371_1_fu_4465_p1.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln371_7_fu_4751_p1() {
    zext_ln371_7_fu_4751_p1 = esl_zext<9,6>(sext_ln371_2_fu_4747_p1.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln371_9_fu_4895_p1() {
    zext_ln371_9_fu_4895_p1 = esl_zext<9,6>(sext_ln371_3_fu_4891_p1.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln371_fu_4069_p1() {
    zext_ln371_fu_4069_p1 = esl_zext<6,4>(ap_phi_mux_v255_0_phi_fu_2638_p4.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln372_1_fu_4241_p1() {
    zext_ln372_1_fu_4241_p1 = esl_zext<6,4>(v256_fu_4222_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln372_2_fu_4521_p1() {
    zext_ln372_2_fu_4521_p1 = esl_zext<9,6>(select_ln372_1_fu_4515_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln372_3_fu_4804_p1() {
    zext_ln372_3_fu_4804_p1 = esl_zext<9,6>(select_ln372_2_fu_4797_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln372_4_fu_4925_p1() {
    zext_ln372_4_fu_4925_p1 = esl_zext<9,6>(select_ln372_3_reg_7257.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln372_5_fu_5035_p1() {
    zext_ln372_5_fu_5035_p1 = esl_zext<9,6>(select_ln372_4_reg_7263.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln372_6_fu_4407_p1() {
    zext_ln372_6_fu_4407_p1 = esl_zext<9,6>(select_ln372_5_fu_4400_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln372_fu_4116_p1() {
    zext_ln372_fu_4116_p1 = esl_zext<6,4>(ap_phi_mux_v256_0_phi_fu_2661_p4.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln375_1_fu_4257_p1() {
    zext_ln375_1_fu_4257_p1 = esl_zext<6,5>(shl_ln375_mid1_fu_4249_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln375_2_fu_4283_p1() {
    zext_ln375_2_fu_4283_p1 = esl_zext<9,8>(tmp_18_fu_4275_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln375_3_fu_4295_p1() {
    zext_ln375_3_fu_4295_p1 = esl_zext<9,6>(tmp_19_fu_4287_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln375_4_fu_4315_p1() {
    zext_ln375_4_fu_4315_p1 = esl_zext<64,9>(add_ln375_3_fu_4309_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln375_fu_4132_p1() {
    zext_ln375_fu_4132_p1 = esl_zext<6,5>(shl_ln2_fu_4124_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln377_1_fu_4533_p1() {
    zext_ln377_1_fu_4533_p1 = esl_zext<9,8>(tmp_13_fu_4525_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln377_2_fu_4548_p1() {
    zext_ln377_2_fu_4548_p1 = esl_zext<64,9>(add_ln377_3_fu_4543_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln377_fu_5000_p1() {
    zext_ln377_fu_5000_p1 = esl_zext<9,6>(sext_ln371_4_fu_4996_p1.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln378_1_fu_4305_p1() {
    zext_ln378_1_fu_4305_p1 = esl_zext<9,5>(select_ln372_fu_4233_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln378_3_fu_4569_p1() {
    zext_ln378_3_fu_4569_p1 = esl_zext<64,8>(grp_fu_5262_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln400_1_fu_4499_p1() {
    zext_ln400_1_fu_4499_p1 = esl_zext<9,6>(tmp_8_fu_4492_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln400_fu_4488_p1() {
    zext_ln400_fu_4488_p1 = esl_zext<9,8>(tmp_7_fu_4481_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln422_1_fu_4831_p1() {
    zext_ln422_1_fu_4831_p1 = esl_zext<64,9>(add_ln422_1_fu_4826_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln422_fu_4816_p1() {
    zext_ln422_fu_4816_p1 = esl_zext<9,8>(tmp_14_fu_4808_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln463_1_fu_4950_p1() {
    zext_ln463_1_fu_4950_p1 = esl_zext<64,9>(add_ln463_1_fu_4945_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln463_fu_4935_p1() {
    zext_ln463_fu_4935_p1 = esl_zext<9,8>(tmp_15_fu_4928_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln504_1_fu_5060_p1() {
    zext_ln504_1_fu_5060_p1 = esl_zext<64,9>(add_ln504_1_fu_5055_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln504_fu_5045_p1() {
    zext_ln504_fu_5045_p1 = esl_zext<9,8>(tmp_16_fu_5038_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln545_1_fu_4435_p1() {
    zext_ln545_1_fu_4435_p1 = esl_zext<64,9>(add_ln545_1_fu_4429_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln545_fu_4419_p1() {
    zext_ln545_fu_4419_p1 = esl_zext<9,8>(tmp_17_fu_4411_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln584_fu_4560_p1() {
    zext_ln584_fu_4560_p1 = esl_zext<64,9>(add_ln584_fu_4554_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln597_fu_4842_p1() {
    zext_ln597_fu_4842_p1 = esl_zext<64,9>(add_ln597_fu_4837_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln606_fu_4961_p1() {
    zext_ln606_fu_4961_p1 = esl_zext<64,9>(add_ln606_fu_4956_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln60_1_fu_3737_p1() {
    zext_ln60_1_fu_3737_p1 = esl_zext<7,4>(v8_fu_3717_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln60_fu_3687_p1() {
    zext_ln60_fu_3687_p1 = esl_zext<7,4>(ap_phi_mux_v8_0_phi_fu_2582_p4.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln615_fu_5071_p1() {
    zext_ln615_fu_5071_p1 = esl_zext<64,9>(add_ln615_fu_5066_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln624_fu_5131_p1() {
    zext_ln624_fu_5131_p1 = esl_zext<64,9>(add_ln624_fu_5127_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln633_fu_4786_p1() {
    zext_ln633_fu_4786_p1 = esl_zext<64,9>(add_ln633_fu_4781_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln646_fu_4919_p1() {
    zext_ln646_fu_4919_p1 = esl_zext<64,9>(add_ln646_fu_4915_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln64_1_fu_3841_p1() {
    zext_ln64_1_fu_3841_p1 = esl_zext<10,9>(tmp_4_fu_3834_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln64_2_fu_3852_p1() {
    zext_ln64_2_fu_3852_p1 = esl_zext<10,7>(tmp_5_fu_3845_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln64_3_fu_3868_p1() {
    zext_ln64_3_fu_3868_p1 = esl_zext<64,10>(add_ln64_1_fu_3862_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln64_fu_3956_p1() {
    zext_ln64_fu_3956_p1 = esl_zext<9,6>(select_ln64_1_reg_5344_pp0_iter3_reg.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln655_fu_5029_p1() {
    zext_ln655_fu_5029_p1 = esl_zext<64,9>(add_ln655_fu_5025_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln664_fu_5121_p1() {
    zext_ln664_fu_5121_p1 = esl_zext<64,9>(add_ln664_fu_5117_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln66_1_fu_3884_p1() {
    zext_ln66_1_fu_3884_p1 = esl_zext<7,4>(select_ln60_2_reg_5329_pp0_iter1_reg.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln66_2_fu_3894_p1() {
    zext_ln66_2_fu_3894_p1 = esl_zext<7,6>(tmp_2_fu_3887_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln66_3_fu_3913_p1() {
    zext_ln66_3_fu_3913_p1 = esl_zext<64,7>(add_ln66_1_fu_3907_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln66_fu_3831_p1() {
    zext_ln66_fu_3831_p1 = esl_zext<10,4>(select_ln60_2_reg_5329.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln673_fu_5233_p1() {
    zext_ln673_fu_5233_p1 = esl_zext<64,9>(add_ln673_fu_5229_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln682_fu_4909_p1() {
    zext_ln682_fu_4909_p1 = esl_zext<64,9>(add_ln682_fu_4904_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln68_1_fu_3904_p1() {
    zext_ln68_1_fu_3904_p1 = esl_zext<7,3>(select_ln64_reg_5337_pp0_iter1_reg.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln68_2_fu_3976_p1() {
    zext_ln68_2_fu_3976_p1 = esl_zext<9,3>(select_ln64_reg_5337_pp0_iter3_reg.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln68_3_fu_3985_p1() {
    zext_ln68_3_fu_3985_p1 = esl_zext<64,9>(add_ln68_1_fu_3979_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln68_fu_3966_p1() {
    zext_ln68_fu_3966_p1 = esl_zext<9,8>(tmp_3_fu_3959_p3.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln695_fu_5019_p1() {
    zext_ln695_fu_5019_p1 = esl_zext<64,9>(add_ln695_fu_5015_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln704_fu_5111_p1() {
    zext_ln704_fu_5111_p1 = esl_zext<64,9>(add_ln704_fu_5107_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln713_fu_5219_p1() {
    zext_ln713_fu_5219_p1 = esl_zext<64,9>(add_ln713_fu_5215_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln722_fu_5252_p1() {
    zext_ln722_fu_5252_p1 = esl_zext<64,9>(add_ln722_reg_7791.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln731_fu_5009_p1() {
    zext_ln731_fu_5009_p1 = esl_zext<64,9>(add_ln731_fu_5004_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln748_fu_5101_p1() {
    zext_ln748_fu_5101_p1 = esl_zext<64,9>(add_ln748_fu_5097_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln761_fu_5209_p1() {
    zext_ln761_fu_5209_p1 = esl_zext<64,9>(add_ln761_fu_5205_p2.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln774_fu_5247_p1() {
    zext_ln774_fu_5247_p1 = esl_zext<64,9>(add_ln774_reg_7776.read());
}

void kernel_2mm_nonP_EA::thread_zext_ln787_fu_5257_p1() {
    zext_ln787_fu_5257_p1 = esl_zext<64,9>(add_ln787_reg_7796.read());
}

}


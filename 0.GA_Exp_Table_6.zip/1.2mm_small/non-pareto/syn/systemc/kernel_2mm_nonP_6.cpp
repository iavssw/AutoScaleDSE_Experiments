#include "kernel_2mm_nonP.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_2mm_nonP::thread_v6_1_1_WEN_A() {
    v6_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_1_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_1_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_2_Addr_A() {
    v6_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_1_2_Addr_A_orig() {
    v6_1_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_1_2_Addr_B() {
    v6_1_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_1_2_Addr_B_orig() {
    v6_1_2_Addr_B_orig =  (sc_lv<32>) (v6_1_2_addr_reg_6867_pp1_iter10_reg.read());
}

void kernel_2mm_nonP::thread_v6_1_2_Clk_A() {
    v6_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_1_2_Clk_B() {
    v6_1_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_1_2_Din_A() {
    v6_1_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_1_2_Din_B() {
    v6_1_2_Din_B = v533_reg_8999.read();
}

void kernel_2mm_nonP::thread_v6_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_1_2_EN_A = ap_const_logic_1;
    } else {
        v6_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_1_2_EN_B = ap_const_logic_1;
    } else {
        v6_1_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_2_Rst_A() {
    v6_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_1_2_Rst_B() {
    v6_1_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_1_2_WEN_A() {
    v6_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_1_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_1_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_3_Addr_A() {
    v6_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_1_3_Addr_A_orig() {
    v6_1_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_1_3_Addr_B() {
    v6_1_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_1_3_Addr_B_orig() {
    v6_1_3_Addr_B_orig =  (sc_lv<32>) (v6_1_3_addr_reg_6873_pp1_iter10_reg.read());
}

void kernel_2mm_nonP::thread_v6_1_3_Clk_A() {
    v6_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_1_3_Clk_B() {
    v6_1_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_1_3_Din_A() {
    v6_1_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_1_3_Din_B() {
    v6_1_3_Din_B = v535_reg_9004.read();
}

void kernel_2mm_nonP::thread_v6_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_1_3_EN_A = ap_const_logic_1;
    } else {
        v6_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_1_3_EN_B = ap_const_logic_1;
    } else {
        v6_1_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_3_Rst_A() {
    v6_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_1_3_Rst_B() {
    v6_1_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_1_3_WEN_A() {
    v6_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_1_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_1_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_0_Addr_A() {
    v6_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_2_0_Addr_A_orig() {
    v6_2_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_2_0_Addr_B() {
    v6_2_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_2_0_Addr_B_orig() {
    v6_2_0_Addr_B_orig =  (sc_lv<32>) (v6_2_0_addr_reg_6879_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_2_0_Clk_A() {
    v6_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_2_0_Clk_B() {
    v6_2_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_2_0_Din_A() {
    v6_2_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_2_0_Din_B() {
    v6_2_0_Din_B = v538_reg_9009.read();
}

void kernel_2mm_nonP::thread_v6_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_2_0_EN_A = ap_const_logic_1;
    } else {
        v6_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_2_0_EN_B = ap_const_logic_1;
    } else {
        v6_2_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_0_Rst_A() {
    v6_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_2_0_Rst_B() {
    v6_2_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_2_0_WEN_A() {
    v6_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_2_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_2_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_1_Addr_A() {
    v6_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_2_1_Addr_A_orig() {
    v6_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_2_1_Addr_B() {
    v6_2_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_2_1_Addr_B_orig() {
    v6_2_1_Addr_B_orig =  (sc_lv<32>) (v6_2_1_addr_reg_6885_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_2_1_Clk_A() {
    v6_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_2_1_Clk_B() {
    v6_2_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_2_1_Din_A() {
    v6_2_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_2_1_Din_B() {
    v6_2_1_Din_B = v540_reg_9014.read();
}

void kernel_2mm_nonP::thread_v6_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_2_1_EN_A = ap_const_logic_1;
    } else {
        v6_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_2_1_EN_B = ap_const_logic_1;
    } else {
        v6_2_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_1_Rst_A() {
    v6_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_2_1_Rst_B() {
    v6_2_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_2_1_WEN_A() {
    v6_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_2_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_2_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_2_Addr_A() {
    v6_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_2_2_Addr_A_orig() {
    v6_2_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_2_2_Addr_B() {
    v6_2_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_2_2_Addr_B_orig() {
    v6_2_2_Addr_B_orig =  (sc_lv<32>) (v6_2_2_addr_reg_6891_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_2_2_Clk_A() {
    v6_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_2_2_Clk_B() {
    v6_2_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_2_2_Din_A() {
    v6_2_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_2_2_Din_B() {
    v6_2_2_Din_B = v542_reg_9019.read();
}

void kernel_2mm_nonP::thread_v6_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_2_2_EN_A = ap_const_logic_1;
    } else {
        v6_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_2_2_EN_B = ap_const_logic_1;
    } else {
        v6_2_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_2_Rst_A() {
    v6_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_2_2_Rst_B() {
    v6_2_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_2_2_WEN_A() {
    v6_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_2_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_2_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_3_Addr_A() {
    v6_2_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_2_3_Addr_A_orig() {
    v6_2_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_2_3_Addr_B() {
    v6_2_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_2_3_Addr_B_orig() {
    v6_2_3_Addr_B_orig =  (sc_lv<32>) (v6_2_3_addr_reg_6897_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_2_3_Clk_A() {
    v6_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_2_3_Clk_B() {
    v6_2_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_2_3_Din_A() {
    v6_2_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_2_3_Din_B() {
    v6_2_3_Din_B = v544_reg_9024.read();
}

void kernel_2mm_nonP::thread_v6_2_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_2_3_EN_A = ap_const_logic_1;
    } else {
        v6_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_2_3_EN_B = ap_const_logic_1;
    } else {
        v6_2_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_2_3_Rst_A() {
    v6_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_2_3_Rst_B() {
    v6_2_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_2_3_WEN_A() {
    v6_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_2_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_2_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_0_Addr_A() {
    v6_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_3_0_Addr_A_orig() {
    v6_3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_3_0_Addr_B() {
    v6_3_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_3_0_Addr_B_orig() {
    v6_3_0_Addr_B_orig =  (sc_lv<32>) (v6_3_0_addr_reg_6903_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_3_0_Clk_A() {
    v6_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_3_0_Clk_B() {
    v6_3_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_3_0_Din_A() {
    v6_3_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_3_0_Din_B() {
    v6_3_0_Din_B = v547_reg_9029.read();
}

void kernel_2mm_nonP::thread_v6_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_3_0_EN_A = ap_const_logic_1;
    } else {
        v6_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_3_0_EN_B = ap_const_logic_1;
    } else {
        v6_3_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_0_Rst_A() {
    v6_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_3_0_Rst_B() {
    v6_3_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_3_0_WEN_A() {
    v6_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_3_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_3_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_1_Addr_A() {
    v6_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_3_1_Addr_A_orig() {
    v6_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_3_1_Addr_B() {
    v6_3_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_3_1_Addr_B_orig() {
    v6_3_1_Addr_B_orig =  (sc_lv<32>) (v6_3_1_addr_reg_6909_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_3_1_Clk_A() {
    v6_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_3_1_Clk_B() {
    v6_3_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_3_1_Din_A() {
    v6_3_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_3_1_Din_B() {
    v6_3_1_Din_B = v549_reg_9034.read();
}

void kernel_2mm_nonP::thread_v6_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_3_1_EN_A = ap_const_logic_1;
    } else {
        v6_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_3_1_EN_B = ap_const_logic_1;
    } else {
        v6_3_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_1_Rst_A() {
    v6_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_3_1_Rst_B() {
    v6_3_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_3_1_WEN_A() {
    v6_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_3_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_3_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_2_Addr_A() {
    v6_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_3_2_Addr_A_orig() {
    v6_3_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_3_2_Addr_B() {
    v6_3_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_3_2_Addr_B_orig() {
    v6_3_2_Addr_B_orig =  (sc_lv<32>) (v6_3_2_addr_reg_6915_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_3_2_Clk_A() {
    v6_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_3_2_Clk_B() {
    v6_3_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_3_2_Din_A() {
    v6_3_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_3_2_Din_B() {
    v6_3_2_Din_B = reg_4058.read();
}

void kernel_2mm_nonP::thread_v6_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_3_2_EN_A = ap_const_logic_1;
    } else {
        v6_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_3_2_EN_B = ap_const_logic_1;
    } else {
        v6_3_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_2_Rst_A() {
    v6_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_3_2_Rst_B() {
    v6_3_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_3_2_WEN_A() {
    v6_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_3_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_3_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_3_Addr_A() {
    v6_3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_3_3_Addr_A_orig() {
    v6_3_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_3_3_Addr_B() {
    v6_3_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_3_3_Addr_B_orig() {
    v6_3_3_Addr_B_orig =  (sc_lv<32>) (v6_3_3_addr_reg_6921_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_3_3_Clk_A() {
    v6_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_3_3_Clk_B() {
    v6_3_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_3_3_Din_A() {
    v6_3_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_3_3_Din_B() {
    v6_3_3_Din_B = reg_4064.read();
}

void kernel_2mm_nonP::thread_v6_3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_3_3_EN_A = ap_const_logic_1;
    } else {
        v6_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_3_3_EN_B = ap_const_logic_1;
    } else {
        v6_3_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_3_3_Rst_A() {
    v6_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_3_3_Rst_B() {
    v6_3_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_3_3_WEN_A() {
    v6_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_3_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_3_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_0_Addr_A() {
    v6_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_4_0_Addr_A_orig() {
    v6_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_4_0_Addr_B() {
    v6_4_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_4_0_Addr_B_orig() {
    v6_4_0_Addr_B_orig =  (sc_lv<32>) (v6_4_0_addr_reg_6927_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_4_0_Clk_A() {
    v6_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_4_0_Clk_B() {
    v6_4_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_4_0_Din_A() {
    v6_4_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_4_0_Din_B() {
    v6_4_0_Din_B = reg_4070.read();
}

void kernel_2mm_nonP::thread_v6_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_4_0_EN_A = ap_const_logic_1;
    } else {
        v6_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_4_0_EN_B = ap_const_logic_1;
    } else {
        v6_4_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_0_Rst_A() {
    v6_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_4_0_Rst_B() {
    v6_4_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_4_0_WEN_A() {
    v6_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_4_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_4_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_1_Addr_A() {
    v6_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_4_1_Addr_A_orig() {
    v6_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_4_1_Addr_B() {
    v6_4_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_4_1_Addr_B_orig() {
    v6_4_1_Addr_B_orig =  (sc_lv<32>) (v6_4_1_addr_reg_6933_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_4_1_Clk_A() {
    v6_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_4_1_Clk_B() {
    v6_4_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_4_1_Din_A() {
    v6_4_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_4_1_Din_B() {
    v6_4_1_Din_B = reg_4076.read();
}

void kernel_2mm_nonP::thread_v6_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_4_1_EN_A = ap_const_logic_1;
    } else {
        v6_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_4_1_EN_B = ap_const_logic_1;
    } else {
        v6_4_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_1_Rst_A() {
    v6_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_4_1_Rst_B() {
    v6_4_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_4_1_WEN_A() {
    v6_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_4_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_4_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_2_Addr_A() {
    v6_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_4_2_Addr_A_orig() {
    v6_4_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_4_2_Addr_B() {
    v6_4_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_4_2_Addr_B_orig() {
    v6_4_2_Addr_B_orig =  (sc_lv<32>) (v6_4_2_addr_reg_6939_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_4_2_Clk_A() {
    v6_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_4_2_Clk_B() {
    v6_4_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_4_2_Din_A() {
    v6_4_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_4_2_Din_B() {
    v6_4_2_Din_B = reg_4082.read();
}

void kernel_2mm_nonP::thread_v6_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_4_2_EN_A = ap_const_logic_1;
    } else {
        v6_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_4_2_EN_B = ap_const_logic_1;
    } else {
        v6_4_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_2_Rst_A() {
    v6_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_4_2_Rst_B() {
    v6_4_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_4_2_WEN_A() {
    v6_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_4_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_4_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_3_Addr_A() {
    v6_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_4_3_Addr_A_orig() {
    v6_4_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_4_3_Addr_B() {
    v6_4_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_4_3_Addr_B_orig() {
    v6_4_3_Addr_B_orig =  (sc_lv<32>) (v6_4_3_addr_reg_6945_pp1_iter11_reg.read());
}

void kernel_2mm_nonP::thread_v6_4_3_Clk_A() {
    v6_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_4_3_Clk_B() {
    v6_4_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_4_3_Din_A() {
    v6_4_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_4_3_Din_B() {
    v6_4_3_Din_B = reg_4088.read();
}

void kernel_2mm_nonP::thread_v6_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_4_3_EN_A = ap_const_logic_1;
    } else {
        v6_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_4_3_EN_B = ap_const_logic_1;
    } else {
        v6_4_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_4_3_Rst_A() {
    v6_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_4_3_Rst_B() {
    v6_4_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_4_3_WEN_A() {
    v6_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_4_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_4_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v8_fu_4154_p2() {
    v8_fu_4154_p2 = (!ap_const_lv4_1.is_01() || !ap_phi_mux_v8_0_phi_fu_3347_p4.read().is_01())? sc_lv<4>(): (sc_biguint<4>(ap_const_lv4_1) + sc_biguint<4>(ap_phi_mux_v8_0_phi_fu_3347_p4.read()));
}

void kernel_2mm_nonP::thread_v9_fu_4252_p2() {
    v9_fu_4252_p2 = (!ap_const_lv6_1.is_01() || !select_ln60_fu_4166_p3.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_1) + sc_biguint<6>(select_ln60_fu_4166_p3.read()));
}

void kernel_2mm_nonP::thread_xor_ln371_fu_4690_p2() {
    xor_ln371_fu_4690_p2 = (icmp_ln372_reg_6746.read() ^ ap_const_lv1_1);
}

void kernel_2mm_nonP::thread_xor_ln60_fu_4234_p2() {
    xor_ln60_fu_4234_p2 = (icmp_ln61_fu_4160_p2.read() ^ ap_const_lv1_1);
}

void kernel_2mm_nonP::thread_zext_ln371_1_fu_4640_p1() {
    zext_ln371_1_fu_4640_p1 = esl_zext<6,4>(v255_fu_4627_p2.read());
}

void kernel_2mm_nonP::thread_zext_ln371_3_fu_5017_p1() {
    zext_ln371_3_fu_5017_p1 = esl_zext<7,6>(sext_ln371_fu_5014_p1.read());
}

void kernel_2mm_nonP::thread_zext_ln371_5_fu_5024_p1() {
    zext_ln371_5_fu_5024_p1 = esl_zext<7,6>(sext_ln371_1_fu_5021_p1.read());
}

void kernel_2mm_nonP::thread_zext_ln371_7_fu_5127_p1() {
    zext_ln371_7_fu_5127_p1 = esl_zext<7,6>(sext_ln371_2_fu_5123_p1.read());
}

void kernel_2mm_nonP::thread_zext_ln371_9_fu_5154_p1() {
    zext_ln371_9_fu_5154_p1 = esl_zext<7,6>(sext_ln371_3_fu_5150_p1.read());
}

void kernel_2mm_nonP::thread_zext_ln371_fu_4580_p1() {
    zext_ln371_fu_4580_p1 = esl_zext<6,4>(ap_phi_mux_v255_0_phi_fu_3404_p4.read());
}

void kernel_2mm_nonP::thread_zext_ln375_1_fu_4774_p1() {
    zext_ln375_1_fu_4774_p1 = esl_zext<64,9>(add_ln375_1_fu_4768_p2.read());
}

void kernel_2mm_nonP::thread_zext_ln375_fu_4754_p1() {
    zext_ln375_fu_4754_p1 = esl_zext<9,8>(tmp_14_fu_4746_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln377_1_fu_4846_p1() {
    zext_ln377_1_fu_4846_p1 = esl_zext<7,4>(select_ln377_1_reg_6815.read());
}

void kernel_2mm_nonP::thread_zext_ln377_2_fu_4742_p1() {
    zext_ln377_2_fu_4742_p1 = esl_zext<9,6>(tmp_13_fu_4734_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln377_3_fu_4849_p1() {
    zext_ln377_3_fu_4849_p1 = esl_zext<7,6>(tmp_13_reg_6821.read());
}

void kernel_2mm_nonP::thread_zext_ln377_4_fu_5033_p1() {
    zext_ln377_4_fu_5033_p1 = esl_zext<64,7>(add_ln377_3_fu_5028_p2.read());
}

void kernel_2mm_nonP::thread_zext_ln377_fu_5296_p1() {
    zext_ln377_fu_5296_p1 = esl_zext<7,6>(sext_ln371_4_fu_5292_p1.read());
}

void kernel_2mm_nonP::thread_zext_ln378_1_fu_4764_p1() {
    zext_ln378_1_fu_4764_p1 = esl_zext<9,5>(select_ln377_fu_4718_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln378_3_fu_5066_p1() {
    zext_ln378_3_fu_5066_p1 = esl_zext<64,8>(add_ln378_reg_7095.read());
}

void kernel_2mm_nonP::thread_zext_ln400_1_fu_4836_p1() {
    zext_ln400_1_fu_4836_p1 = esl_zext<9,6>(tmp_6_fu_4829_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln400_fu_4825_p1() {
    zext_ln400_fu_4825_p1 = esl_zext<9,8>(tmp_5_fu_4818_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln584_fu_5052_p1() {
    zext_ln584_fu_5052_p1 = esl_zext<64,7>(add_ln584_fu_5047_p2.read());
}

void kernel_2mm_nonP::thread_zext_ln60_1_fu_4174_p1() {
    zext_ln60_1_fu_4174_p1 = esl_zext<7,4>(v8_fu_4154_p2.read());
}

void kernel_2mm_nonP::thread_zext_ln60_fu_4094_p1() {
    zext_ln60_fu_4094_p1 = esl_zext<7,4>(ap_phi_mux_v8_0_phi_fu_3347_p4.read());
}

void kernel_2mm_nonP::thread_zext_ln633_fu_5180_p1() {
    zext_ln633_fu_5180_p1 = esl_zext<64,7>(add_ln633_fu_5175_p2.read());
}

void kernel_2mm_nonP::thread_zext_ln64_1_fu_4300_p1() {
    zext_ln64_1_fu_4300_p1 = esl_zext<10,7>(tmp_4_fu_4292_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln64_2_fu_4316_p1() {
    zext_ln64_2_fu_4316_p1 = esl_zext<64,10>(add_ln64_1_fu_4310_p2.read());
}

void kernel_2mm_nonP::thread_zext_ln64_3_fu_4468_p1() {
    zext_ln64_3_fu_4468_p1 = esl_zext<7,6>(select_ln64_3_fu_4461_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln64_fu_4288_p1() {
    zext_ln64_fu_4288_p1 = esl_zext<10,9>(tmp_3_fu_4280_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln66_1_fu_4212_p1() {
    zext_ln66_1_fu_4212_p1 = esl_zext<7,4>(select_ln60_2_fu_4200_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln66_2_fu_4224_p1() {
    zext_ln66_2_fu_4224_p1 = esl_zext<7,6>(tmp_1_fu_4216_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln66_3_fu_4337_p1() {
    zext_ln66_3_fu_4337_p1 = esl_zext<64,7>(add_ln66_1_fu_4331_p2.read());
}

void kernel_2mm_nonP::thread_zext_ln66_fu_4208_p1() {
    zext_ln66_fu_4208_p1 = esl_zext<10,4>(select_ln60_2_fu_4200_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln682_fu_5199_p1() {
    zext_ln682_fu_5199_p1 = esl_zext<64,7>(add_ln682_fu_5194_p2.read());
}

void kernel_2mm_nonP::thread_zext_ln68_2_fu_4327_p1() {
    zext_ln68_2_fu_4327_p1 = esl_zext<7,3>(select_ln64_fu_4264_p3.read());
}

void kernel_2mm_nonP::thread_zext_ln68_3_fu_4572_p1() {
    zext_ln68_3_fu_4572_p1 = esl_zext<64,7>(add_ln68_1_reg_5927_pp0_iter1_reg.read());
}

void kernel_2mm_nonP::thread_zext_ln731_fu_5305_p1() {
    zext_ln731_fu_5305_p1 = esl_zext<64,7>(add_ln731_fu_5300_p2.read());
}

}


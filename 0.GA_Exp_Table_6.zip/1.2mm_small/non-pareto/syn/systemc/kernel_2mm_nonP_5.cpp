#include "kernel_2mm_nonP.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_2mm_nonP::thread_v2_3_5_Din_B() {
    v2_3_5_Din_B = grp_fu_3516_p2.read();
}

void kernel_2mm_nonP::thread_v2_3_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v2_3_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0)))) {
        v2_3_5_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_7_EN_A.read();
    } else {
        v2_3_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_3_5_EN_B = ap_const_logic_1;
    } else {
        v2_3_5_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_5_Rst_A() {
    v2_3_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_5_Rst_B() {
    v2_3_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_5_WEN_A() {
    v2_3_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_3_5_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_3_5_WEN_B = ap_const_lv4_F;
    } else {
        v2_3_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0)))) {
        v2_3_6_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_7_Addr_A.read();
    } else {
        v2_3_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_3_6_Addr_A_orig() {
    v2_3_6_Addr_A_orig =  (sc_lv<32>) (zext_ln584_fu_5052_p1.read());
}

void kernel_2mm_nonP::thread_v2_3_6_Addr_B() {
    v2_3_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_3_6_Addr_B_orig() {
    v2_3_6_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_reg_6626.read());
}

void kernel_2mm_nonP::thread_v2_3_6_Clk_A() {
    v2_3_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_3_6_Clk_B() {
    v2_3_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_3_6_Din_A() {
    v2_3_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_3_6_Din_B() {
    v2_3_6_Din_B = grp_fu_3521_p2.read();
}

void kernel_2mm_nonP::thread_v2_3_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v2_3_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0)))) {
        v2_3_6_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_7_EN_A.read();
    } else {
        v2_3_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage15_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_3_6_EN_B = ap_const_logic_1;
    } else {
        v2_3_6_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_6_Rst_A() {
    v2_3_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_6_Rst_B() {
    v2_3_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_6_WEN_A() {
    v2_3_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_3_6_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage15_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_3_6_WEN_B = ap_const_lv4_F;
    } else {
        v2_3_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0)))) {
        v2_3_7_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_7_Addr_A.read();
    } else {
        v2_3_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_3_7_Addr_A_orig() {
    v2_3_7_Addr_A_orig =  (sc_lv<32>) (zext_ln633_fu_5180_p1.read());
}

void kernel_2mm_nonP::thread_v2_3_7_Addr_B() {
    v2_3_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_3_7_Addr_B_orig() {
    v2_3_7_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_reg_6626.read());
}

void kernel_2mm_nonP::thread_v2_3_7_Clk_A() {
    v2_3_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_3_7_Clk_B() {
    v2_3_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_3_7_Din_A() {
    v2_3_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_3_7_Din_B() {
    v2_3_7_Din_B = grp_fu_3516_p2.read();
}

void kernel_2mm_nonP::thread_v2_3_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v2_3_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0)))) {
        v2_3_7_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_7_EN_A.read();
    } else {
        v2_3_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_3_7_EN_B = ap_const_logic_1;
    } else {
        v2_3_7_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_7_Rst_A() {
    v2_3_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_7_Rst_B() {
    v2_3_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_7_WEN_A() {
    v2_3_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_3_7_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_3_7_WEN_B = ap_const_lv4_F;
    } else {
        v2_3_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0)))) {
        v2_3_8_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_7_Addr_A.read();
    } else {
        v2_3_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_3_8_Addr_A_orig() {
    v2_3_8_Addr_A_orig =  (sc_lv<32>) (zext_ln682_fu_5199_p1.read());
}

void kernel_2mm_nonP::thread_v2_3_8_Addr_B() {
    v2_3_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_3_8_Addr_B_orig() {
    v2_3_8_Addr_B_orig =  (sc_lv<32>) (v2_3_8_addr_reg_6715.read());
}

void kernel_2mm_nonP::thread_v2_3_8_Clk_A() {
    v2_3_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_3_8_Clk_B() {
    v2_3_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_3_8_Din_A() {
    v2_3_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_3_8_Din_B() {
    v2_3_8_Din_B = grp_fu_3516_p2.read();
}

void kernel_2mm_nonP::thread_v2_3_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v2_3_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0)))) {
        v2_3_8_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_7_EN_A.read();
    } else {
        v2_3_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_3_8_EN_B = ap_const_logic_1;
    } else {
        v2_3_8_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_8_Rst_A() {
    v2_3_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_8_Rst_B() {
    v2_3_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_8_WEN_A() {
    v2_3_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_3_8_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_3_8_WEN_B = ap_const_lv4_F;
    } else {
        v2_3_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage20.read(), ap_const_boolean_0)))) {
        v2_3_9_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_7_Addr_A.read();
    } else {
        v2_3_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_3_9_Addr_A_orig() {
    v2_3_9_Addr_A_orig =  (sc_lv<32>) (zext_ln731_fu_5305_p1.read());
}

void kernel_2mm_nonP::thread_v2_3_9_Addr_B() {
    v2_3_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_3_9_Addr_B_orig() {
    v2_3_9_Addr_B_orig =  (sc_lv<32>) (v2_3_9_addr_reg_6720.read());
}

void kernel_2mm_nonP::thread_v2_3_9_Clk_A() {
    v2_3_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_3_9_Clk_B() {
    v2_3_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_3_9_Din_A() {
    v2_3_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_3_9_Din_B() {
    v2_3_9_Din_B = grp_fu_3521_p2.read();
}

void kernel_2mm_nonP::thread_v2_3_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v2_3_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage20.read(), ap_const_boolean_0)))) {
        v2_3_9_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_7_EN_A.read();
    } else {
        v2_3_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage18_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_3_9_EN_B = ap_const_logic_1;
    } else {
        v2_3_9_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_3_9_Rst_A() {
    v2_3_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_9_Rst_B() {
    v2_3_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_3_9_WEN_A() {
    v2_3_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_3_9_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage18_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_3_9_WEN_B = ap_const_lv4_F;
    } else {
        v2_3_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v2_4_0_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_0_Addr_A_orig() {
    v2_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln377_4_fu_5033_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_0_Addr_B() {
    v2_4_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_0_Addr_B_orig() {
    v2_4_0_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_fu_4572_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_0_Clk_A() {
    v2_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_0_Clk_B() {
    v2_4_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_0_Din_A() {
    v2_4_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_0_Din_B() {
    v2_4_0_Din_B = grp_fu_3507_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v2_4_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v2_4_0_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_0_EN_B = ap_const_logic_1;
    } else {
        v2_4_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_0_Rst_A() {
    v2_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_0_Rst_B() {
    v2_4_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_0_WEN_A() {
    v2_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387.read(), ap_const_lv4_3))) {
        v2_4_0_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v2_4_1_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_1_Addr_A_orig() {
    v2_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln584_fu_5052_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_1_Addr_B() {
    v2_4_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_1_Addr_B_orig() {
    v2_4_1_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_reg_6626.read());
}

void kernel_2mm_nonP::thread_v2_4_1_Clk_A() {
    v2_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_1_Clk_B() {
    v2_4_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_1_Din_A() {
    v2_4_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_1_Din_B() {
    v2_4_1_Din_B = grp_fu_3521_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v2_4_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v2_4_1_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_1_EN_B = ap_const_logic_1;
    } else {
        v2_4_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_1_Rst_A() {
    v2_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_1_Rst_B() {
    v2_4_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_1_WEN_A() {
    v2_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387.read(), ap_const_lv4_3))) {
        v2_4_1_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage13.read(), ap_const_boolean_0)))) {
        v2_4_2_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_2_Addr_A_orig() {
    v2_4_2_Addr_A_orig =  (sc_lv<32>) (zext_ln633_fu_5180_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_2_Addr_B() {
    v2_4_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_2_Addr_B_orig() {
    v2_4_2_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_reg_6626.read());
}

void kernel_2mm_nonP::thread_v2_4_2_Clk_A() {
    v2_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_2_Clk_B() {
    v2_4_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_2_Din_A() {
    v2_4_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_2_Din_B() {
    v2_4_2_Din_B = grp_fu_3521_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v2_4_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage13.read(), ap_const_boolean_0)))) {
        v2_4_2_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage11_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_2_EN_B = ap_const_logic_1;
    } else {
        v2_4_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_2_Rst_A() {
    v2_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_2_Rst_B() {
    v2_4_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_2_WEN_A() {
    v2_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage11_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_4_2_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage13.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage14.read(), ap_const_boolean_0)))) {
        v2_4_3_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_3_Addr_A_orig() {
    v2_4_3_Addr_A_orig =  (sc_lv<32>) (zext_ln682_fu_5199_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_3_Addr_B() {
    v2_4_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_3_Addr_B_orig() {
    v2_4_3_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_reg_6626.read());
}

void kernel_2mm_nonP::thread_v2_4_3_Clk_A() {
    v2_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_3_Clk_B() {
    v2_4_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_3_Din_A() {
    v2_4_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_3_Din_B() {
    v2_4_3_Din_B = grp_fu_3521_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v2_4_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage14.read(), ap_const_boolean_0)))) {
        v2_4_3_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage12_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_3_EN_B = ap_const_logic_1;
    } else {
        v2_4_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_3_Rst_A() {
    v2_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_3_Rst_B() {
    v2_4_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_3_WEN_A() {
    v2_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage12_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_4_3_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage14.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage15.read(), ap_const_boolean_0)))) {
        v2_4_4_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_4_Addr_A_orig() {
    v2_4_4_Addr_A_orig =  (sc_lv<32>) (zext_ln731_fu_5305_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_4_Addr_B() {
    v2_4_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_4_Addr_B_orig() {
    v2_4_4_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_reg_6626.read());
}

void kernel_2mm_nonP::thread_v2_4_4_Clk_A() {
    v2_4_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_4_Clk_B() {
    v2_4_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_4_Din_A() {
    v2_4_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_4_Din_B() {
    v2_4_4_Din_B = grp_fu_3516_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v2_4_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage14.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage15.read(), ap_const_boolean_0)))) {
        v2_4_4_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage13_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_4_EN_B = ap_const_logic_1;
    } else {
        v2_4_4_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_4_Rst_A() {
    v2_4_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_4_Rst_B() {
    v2_4_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_4_WEN_A() {
    v2_4_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage13_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_4_4_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_5_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage15.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0)))) {
        v2_4_5_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_5_Addr_A_orig() {
    v2_4_5_Addr_A_orig =  (sc_lv<32>) (zext_ln377_4_fu_5033_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_5_Addr_B() {
    v2_4_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_5_Addr_B_orig() {
    v2_4_5_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_reg_6626.read());
}

void kernel_2mm_nonP::thread_v2_4_5_Clk_A() {
    v2_4_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_5_Clk_B() {
    v2_4_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_5_Din_A() {
    v2_4_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_5_Din_B() {
    v2_4_5_Din_B = grp_fu_3516_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v2_4_5_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0)))) {
        v2_4_5_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_5_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_5_EN_B = ap_const_logic_1;
    } else {
        v2_4_5_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_5_Rst_A() {
    v2_4_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_5_Rst_B() {
    v2_4_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_5_WEN_A() {
    v2_4_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_5_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_4_5_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_6_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0)))) {
        v2_4_6_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_6_Addr_A_orig() {
    v2_4_6_Addr_A_orig =  (sc_lv<32>) (zext_ln584_fu_5052_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_6_Addr_B() {
    v2_4_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_6_Addr_B_orig() {
    v2_4_6_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_reg_6626.read());
}

void kernel_2mm_nonP::thread_v2_4_6_Clk_A() {
    v2_4_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_6_Clk_B() {
    v2_4_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_6_Din_A() {
    v2_4_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_6_Din_B() {
    v2_4_6_Din_B = grp_fu_3521_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v2_4_6_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0)))) {
        v2_4_6_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_6_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage15_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_6_EN_B = ap_const_logic_1;
    } else {
        v2_4_6_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_6_Rst_A() {
    v2_4_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_6_Rst_B() {
    v2_4_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_6_WEN_A() {
    v2_4_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_6_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage15_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_4_6_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_7_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0)))) {
        v2_4_7_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_7_Addr_A_orig() {
    v2_4_7_Addr_A_orig =  (sc_lv<32>) (zext_ln633_fu_5180_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_7_Addr_B() {
    v2_4_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_7_Addr_B_orig() {
    v2_4_7_Addr_B_orig =  (sc_lv<32>) (zext_ln68_3_reg_6626.read());
}

void kernel_2mm_nonP::thread_v2_4_7_Clk_A() {
    v2_4_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_7_Clk_B() {
    v2_4_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_7_Din_A() {
    v2_4_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_7_Din_B() {
    v2_4_7_Din_B = grp_fu_3516_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v2_4_7_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0)))) {
        v2_4_7_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_7_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_7_EN_B = ap_const_logic_1;
    } else {
        v2_4_7_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_7_Rst_A() {
    v2_4_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_7_Rst_B() {
    v2_4_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_7_WEN_A() {
    v2_4_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_7_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_4_7_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_8_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0)))) {
        v2_4_8_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_8_Addr_A_orig() {
    v2_4_8_Addr_A_orig =  (sc_lv<32>) (zext_ln682_fu_5199_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_8_Addr_B() {
    v2_4_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_8_Addr_B_orig() {
    v2_4_8_Addr_B_orig =  (sc_lv<32>) (v2_4_8_addr_reg_6725.read());
}

void kernel_2mm_nonP::thread_v2_4_8_Clk_A() {
    v2_4_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_8_Clk_B() {
    v2_4_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_8_Din_A() {
    v2_4_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_8_Din_B() {
    v2_4_8_Din_B = grp_fu_3516_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v2_4_8_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0)))) {
        v2_4_8_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_8_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_8_EN_B = ap_const_logic_1;
    } else {
        v2_4_8_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_8_Rst_A() {
    v2_4_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_8_Rst_B() {
    v2_4_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_8_WEN_A() {
    v2_4_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_8_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_4_8_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_9_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage20.read(), ap_const_boolean_0)))) {
        v2_4_9_Addr_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_Addr_A.read();
    } else {
        v2_4_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_2mm_nonP::thread_v2_4_9_Addr_A_orig() {
    v2_4_9_Addr_A_orig =  (sc_lv<32>) (zext_ln731_fu_5305_p1.read());
}

void kernel_2mm_nonP::thread_v2_4_9_Addr_B() {
    v2_4_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v2_4_9_Addr_B_orig() {
    v2_4_9_Addr_B_orig =  (sc_lv<32>) (v2_4_9_addr_reg_6730.read());
}

void kernel_2mm_nonP::thread_v2_4_9_Clk_A() {
    v2_4_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_9_Clk_B() {
    v2_4_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v2_4_9_Din_A() {
    v2_4_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v2_4_9_Din_B() {
    v2_4_9_Din_B = grp_fu_3521_p2.read();
}

void kernel_2mm_nonP::thread_v2_4_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v2_4_9_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln60_reg_5474.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage20.read(), ap_const_boolean_0)))) {
        v2_4_9_EN_A = grp_aesl_mux_load_5_8_x_s_fu_3445_empty_8_EN_A.read();
    } else {
        v2_4_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_9_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage18_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        v2_4_9_EN_B = ap_const_logic_1;
    } else {
        v2_4_9_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v2_4_9_Rst_A() {
    v2_4_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_9_Rst_B() {
    v2_4_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v2_4_9_WEN_A() {
    v2_4_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v2_4_9_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage18_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_0) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_1) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_2) && 
         !esl_seteq<1,4,4>(select_ln64_2_reg_6387_pp0_iter1_reg.read(), ap_const_lv4_3))) {
        v2_4_9_WEN_B = ap_const_lv4_F;
    } else {
        v2_4_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v302_1_fu_4949_p3() {
    v302_1_fu_4949_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v302_reg_7120.read(): v299_reg_6998_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v306_fu_5225_p3() {
    v306_fu_5225_p3 = (!select_ln371_3_fu_5169_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_fu_5169_p3.read()[0].to_bool())? v2_2_0_load_reg_7511.read(): v2_2_5_load_reg_7516.read());
}

void kernel_2mm_nonP::thread_v308_1_fu_4954_p3() {
    v308_1_fu_4954_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v308_reg_7125.read(): v304_reg_7004_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v313_1_fu_4959_p3() {
    v313_1_fu_4959_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v313_reg_7130.read(): v310_reg_7010_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v318_1_fu_4964_p3() {
    v318_1_fu_4964_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v318_reg_7135.read(): v315_reg_7016_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v323_1_fu_4969_p3() {
    v323_1_fu_4969_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v323_reg_7140.read(): v320_reg_7022_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v327_fu_5231_p3() {
    v327_fu_5231_p3 = (!select_ln371_3_fu_5169_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_fu_5169_p3.read()[0].to_bool())? v2_3_0_load_reg_7521.read(): v2_3_5_load_reg_7526.read());
}

void kernel_2mm_nonP::thread_v329_1_fu_4974_p3() {
    v329_1_fu_4974_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v329_reg_7145.read(): v325_reg_7028_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v334_1_fu_4979_p3() {
    v334_1_fu_4979_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v334_reg_7150.read(): v331_reg_7034_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v339_1_fu_4984_p3() {
    v339_1_fu_4984_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v339_reg_7155.read(): v336_reg_7040_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v344_1_fu_4989_p3() {
    v344_1_fu_4989_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v344_reg_7160.read(): v341_reg_7046_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v348_fu_5237_p3() {
    v348_fu_5237_p3 = (!select_ln371_3_fu_5169_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_fu_5169_p3.read()[0].to_bool())? v2_4_0_load_reg_7531.read(): v2_4_5_load_reg_7536.read());
}

void kernel_2mm_nonP::thread_v350_1_fu_4994_p3() {
    v350_1_fu_4994_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v350_reg_7165.read(): v346_reg_7052_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v355_1_fu_4999_p3() {
    v355_1_fu_4999_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v355_reg_7170.read(): v352_reg_7058_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v360_1_fu_5004_p3() {
    v360_1_fu_5004_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v360_reg_7175.read(): v357_reg_7064_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v365_1_fu_5009_p3() {
    v365_1_fu_5009_p3 = (!select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln371_1_reg_6768_pp1_iter1_reg.read()[0].to_bool())? v365_reg_7180.read(): v362_reg_7070_pp1_iter1_reg.read());
}

void kernel_2mm_nonP::thread_v367_fu_5243_p3() {
    v367_fu_5243_p3 = (!select_ln371_3_fu_5169_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_fu_5169_p3.read()[0].to_bool())? v2_0_1_load_reg_7541.read(): v2_0_6_load_reg_7546.read());
}

void kernel_2mm_nonP::thread_v380_fu_5249_p3() {
    v380_fu_5249_p3 = (!select_ln371_3_fu_5169_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_fu_5169_p3.read()[0].to_bool())? v2_1_1_load_reg_7587.read(): v2_1_6_load_reg_7592.read());
}

void kernel_2mm_nonP::thread_v389_fu_5255_p3() {
    v389_fu_5255_p3 = (!select_ln371_3_fu_5169_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_fu_5169_p3.read()[0].to_bool())? v2_2_1_load_reg_7597.read(): v2_2_6_load_reg_7602.read());
}

void kernel_2mm_nonP::thread_v398_fu_5261_p3() {
    v398_fu_5261_p3 = (!select_ln371_3_fu_5169_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_fu_5169_p3.read()[0].to_bool())? v2_3_1_load_reg_7607.read(): v2_3_6_load_reg_7612.read());
}

void kernel_2mm_nonP::thread_v3_0_Addr_A() {
    v3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v3_0_Addr_A_orig() {
    v3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln64_2_fu_4316_p1.read());
}

void kernel_2mm_nonP::thread_v3_0_Clk_A() {
    v3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v3_0_Din_A() {
    v3_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v3_0_EN_A = ap_const_logic_1;
    } else {
        v3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v3_0_Rst_A() {
    v3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v3_0_WEN_A() {
    v3_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v3_1_Addr_A() {
    v3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v3_1_Addr_A_orig() {
    v3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln64_2_fu_4316_p1.read());
}

void kernel_2mm_nonP::thread_v3_1_Clk_A() {
    v3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v3_1_Din_A() {
    v3_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v3_1_EN_A = ap_const_logic_1;
    } else {
        v3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v3_1_Rst_A() {
    v3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v3_1_WEN_A() {
    v3_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v3_2_Addr_A() {
    v3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v3_2_Addr_A_orig() {
    v3_2_Addr_A_orig =  (sc_lv<32>) (zext_ln64_2_fu_4316_p1.read());
}

void kernel_2mm_nonP::thread_v3_2_Clk_A() {
    v3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v3_2_Din_A() {
    v3_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v3_2_EN_A = ap_const_logic_1;
    } else {
        v3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v3_2_Rst_A() {
    v3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v3_2_WEN_A() {
    v3_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v3_3_Addr_A() {
    v3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v3_3_Addr_A_orig() {
    v3_3_Addr_A_orig =  (sc_lv<32>) (zext_ln64_2_fu_4316_p1.read());
}

void kernel_2mm_nonP::thread_v3_3_Clk_A() {
    v3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v3_3_Din_A() {
    v3_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v3_3_EN_A = ap_const_logic_1;
    } else {
        v3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v3_3_Rst_A() {
    v3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v3_3_WEN_A() {
    v3_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v3_4_Addr_A() {
    v3_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v3_4_Addr_A_orig() {
    v3_4_Addr_A_orig =  (sc_lv<32>) (zext_ln64_2_fu_4316_p1.read());
}

void kernel_2mm_nonP::thread_v3_4_Clk_A() {
    v3_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v3_4_Din_A() {
    v3_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v3_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v3_4_EN_A = ap_const_logic_1;
    } else {
        v3_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v3_4_Rst_A() {
    v3_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v3_4_WEN_A() {
    v3_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v3_5_Addr_A() {
    v3_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v3_5_Addr_A_orig() {
    v3_5_Addr_A_orig =  (sc_lv<32>) (zext_ln64_2_fu_4316_p1.read());
}

void kernel_2mm_nonP::thread_v3_5_Clk_A() {
    v3_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v3_5_Din_A() {
    v3_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v3_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v3_5_EN_A = ap_const_logic_1;
    } else {
        v3_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v3_5_Rst_A() {
    v3_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v3_5_WEN_A() {
    v3_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v3_6_Addr_A() {
    v3_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v3_6_Addr_A_orig() {
    v3_6_Addr_A_orig =  (sc_lv<32>) (zext_ln64_2_fu_4316_p1.read());
}

void kernel_2mm_nonP::thread_v3_6_Clk_A() {
    v3_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v3_6_Din_A() {
    v3_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v3_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v3_6_EN_A = ap_const_logic_1;
    } else {
        v3_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v3_6_Rst_A() {
    v3_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v3_6_WEN_A() {
    v3_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v407_fu_5267_p3() {
    v407_fu_5267_p3 = (!select_ln371_3_fu_5169_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_fu_5169_p3.read()[0].to_bool())? v2_4_1_load_reg_7617.read(): v2_4_6_load_reg_7622.read());
}

void kernel_2mm_nonP::thread_v416_fu_5319_p3() {
    v416_fu_5319_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_0_2_Dout_A.read(): v2_0_7_Dout_A.read());
}

void kernel_2mm_nonP::thread_v429_fu_5326_p3() {
    v429_fu_5326_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_1_2_Dout_A.read(): v2_1_7_Dout_A.read());
}

void kernel_2mm_nonP::thread_v438_fu_5333_p3() {
    v438_fu_5333_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_2_2_Dout_A.read(): v2_2_7_Dout_A.read());
}

void kernel_2mm_nonP::thread_v447_fu_5340_p3() {
    v447_fu_5340_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_3_2_Dout_A.read(): v2_3_7_Dout_A.read());
}

void kernel_2mm_nonP::thread_v456_fu_5347_p3() {
    v456_fu_5347_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_4_2_Dout_A.read(): v2_4_7_Dout_A.read());
}

void kernel_2mm_nonP::thread_v465_fu_5354_p3() {
    v465_fu_5354_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_0_3_Dout_A.read(): v2_0_8_Dout_A.read());
}

void kernel_2mm_nonP::thread_v478_fu_5361_p3() {
    v478_fu_5361_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_1_3_Dout_A.read(): v2_1_8_Dout_A.read());
}

void kernel_2mm_nonP::thread_v487_fu_5368_p3() {
    v487_fu_5368_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_2_3_Dout_A.read(): v2_2_8_Dout_A.read());
}

void kernel_2mm_nonP::thread_v496_fu_5375_p3() {
    v496_fu_5375_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_3_3_Dout_A.read(): v2_3_8_Dout_A.read());
}

void kernel_2mm_nonP::thread_v4_0_0_Addr_A() {
    v4_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_0_Addr_A_orig() {
    v4_0_0_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_0_Clk_A() {
    v4_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_0_Din_A() {
    v4_0_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_0_EN_A = ap_const_logic_1;
    } else {
        v4_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_0_Rst_A() {
    v4_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_0_WEN_A() {
    v4_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_0_1_Addr_A() {
    v4_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_1_Addr_A_orig() {
    v4_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_1_Clk_A() {
    v4_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_1_Din_A() {
    v4_0_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_1_EN_A = ap_const_logic_1;
    } else {
        v4_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_1_Rst_A() {
    v4_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_1_WEN_A() {
    v4_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_0_2_Addr_A() {
    v4_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_2_Addr_A_orig() {
    v4_0_2_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_2_Clk_A() {
    v4_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_2_Din_A() {
    v4_0_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_2_EN_A = ap_const_logic_1;
    } else {
        v4_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_2_Rst_A() {
    v4_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_2_WEN_A() {
    v4_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_0_3_Addr_A() {
    v4_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_3_Addr_A_orig() {
    v4_0_3_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_3_Clk_A() {
    v4_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_3_Din_A() {
    v4_0_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_3_EN_A = ap_const_logic_1;
    } else {
        v4_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_3_Rst_A() {
    v4_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_3_WEN_A() {
    v4_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_0_4_Addr_A() {
    v4_0_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_4_Addr_A_orig() {
    v4_0_4_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_4_Clk_A() {
    v4_0_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_4_Din_A() {
    v4_0_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_4_EN_A = ap_const_logic_1;
    } else {
        v4_0_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_4_Rst_A() {
    v4_0_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_4_WEN_A() {
    v4_0_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_0_5_Addr_A() {
    v4_0_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_5_Addr_A_orig() {
    v4_0_5_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_5_Clk_A() {
    v4_0_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_5_Din_A() {
    v4_0_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_5_EN_A = ap_const_logic_1;
    } else {
        v4_0_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_5_Rst_A() {
    v4_0_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_5_WEN_A() {
    v4_0_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_0_6_Addr_A() {
    v4_0_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_6_Addr_A_orig() {
    v4_0_6_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_6_Clk_A() {
    v4_0_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_6_Din_A() {
    v4_0_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_6_EN_A = ap_const_logic_1;
    } else {
        v4_0_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_6_Rst_A() {
    v4_0_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_6_WEN_A() {
    v4_0_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_0_7_Addr_A() {
    v4_0_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_7_Addr_A_orig() {
    v4_0_7_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_7_Clk_A() {
    v4_0_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_7_Din_A() {
    v4_0_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_7_EN_A = ap_const_logic_1;
    } else {
        v4_0_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_7_Rst_A() {
    v4_0_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_7_WEN_A() {
    v4_0_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_0_8_Addr_A() {
    v4_0_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_8_Addr_A_orig() {
    v4_0_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_8_Clk_A() {
    v4_0_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_8_Din_A() {
    v4_0_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_8_EN_A = ap_const_logic_1;
    } else {
        v4_0_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_8_Rst_A() {
    v4_0_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_8_WEN_A() {
    v4_0_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_0_9_Addr_A() {
    v4_0_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_0_9_Addr_A_orig() {
    v4_0_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_0_9_Clk_A() {
    v4_0_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_0_9_Din_A() {
    v4_0_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_0_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_0_9_EN_A = ap_const_logic_1;
    } else {
        v4_0_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_0_9_Rst_A() {
    v4_0_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_0_9_WEN_A() {
    v4_0_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_0_Addr_A() {
    v4_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_0_Addr_A_orig() {
    v4_1_0_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_0_Clk_A() {
    v4_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_0_Din_A() {
    v4_1_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_0_EN_A = ap_const_logic_1;
    } else {
        v4_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_0_Rst_A() {
    v4_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_0_WEN_A() {
    v4_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_1_Addr_A() {
    v4_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_1_Addr_A_orig() {
    v4_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_1_Clk_A() {
    v4_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_1_Din_A() {
    v4_1_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_1_EN_A = ap_const_logic_1;
    } else {
        v4_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_1_Rst_A() {
    v4_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_1_WEN_A() {
    v4_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_2_Addr_A() {
    v4_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_2_Addr_A_orig() {
    v4_1_2_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_2_Clk_A() {
    v4_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_2_Din_A() {
    v4_1_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_2_EN_A = ap_const_logic_1;
    } else {
        v4_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_2_Rst_A() {
    v4_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_2_WEN_A() {
    v4_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_3_Addr_A() {
    v4_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_3_Addr_A_orig() {
    v4_1_3_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_3_Clk_A() {
    v4_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_3_Din_A() {
    v4_1_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_3_EN_A = ap_const_logic_1;
    } else {
        v4_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_3_Rst_A() {
    v4_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_3_WEN_A() {
    v4_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_4_Addr_A() {
    v4_1_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_4_Addr_A_orig() {
    v4_1_4_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_4_Clk_A() {
    v4_1_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_4_Din_A() {
    v4_1_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_4_EN_A = ap_const_logic_1;
    } else {
        v4_1_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_4_Rst_A() {
    v4_1_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_4_WEN_A() {
    v4_1_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_5_Addr_A() {
    v4_1_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_5_Addr_A_orig() {
    v4_1_5_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_5_Clk_A() {
    v4_1_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_5_Din_A() {
    v4_1_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_5_EN_A = ap_const_logic_1;
    } else {
        v4_1_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_5_Rst_A() {
    v4_1_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_5_WEN_A() {
    v4_1_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_6_Addr_A() {
    v4_1_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_6_Addr_A_orig() {
    v4_1_6_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_6_Clk_A() {
    v4_1_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_6_Din_A() {
    v4_1_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_6_EN_A = ap_const_logic_1;
    } else {
        v4_1_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_6_Rst_A() {
    v4_1_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_6_WEN_A() {
    v4_1_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_7_Addr_A() {
    v4_1_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_7_Addr_A_orig() {
    v4_1_7_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_7_Clk_A() {
    v4_1_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_7_Din_A() {
    v4_1_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_7_EN_A = ap_const_logic_1;
    } else {
        v4_1_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_7_Rst_A() {
    v4_1_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_7_WEN_A() {
    v4_1_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_8_Addr_A() {
    v4_1_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_8_Addr_A_orig() {
    v4_1_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_8_Clk_A() {
    v4_1_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_8_Din_A() {
    v4_1_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_8_EN_A = ap_const_logic_1;
    } else {
        v4_1_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_8_Rst_A() {
    v4_1_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_8_WEN_A() {
    v4_1_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_1_9_Addr_A() {
    v4_1_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_1_9_Addr_A_orig() {
    v4_1_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_1_9_Clk_A() {
    v4_1_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_1_9_Din_A() {
    v4_1_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_1_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_1_9_EN_A = ap_const_logic_1;
    } else {
        v4_1_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_1_9_Rst_A() {
    v4_1_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_1_9_WEN_A() {
    v4_1_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_0_Addr_A() {
    v4_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_0_Addr_A_orig() {
    v4_2_0_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_0_Clk_A() {
    v4_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_0_Din_A() {
    v4_2_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_0_EN_A = ap_const_logic_1;
    } else {
        v4_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_0_Rst_A() {
    v4_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_0_WEN_A() {
    v4_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_1_Addr_A() {
    v4_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_1_Addr_A_orig() {
    v4_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_1_Clk_A() {
    v4_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_1_Din_A() {
    v4_2_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_1_EN_A = ap_const_logic_1;
    } else {
        v4_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_1_Rst_A() {
    v4_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_1_WEN_A() {
    v4_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_2_Addr_A() {
    v4_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_2_Addr_A_orig() {
    v4_2_2_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_2_Clk_A() {
    v4_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_2_Din_A() {
    v4_2_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_2_EN_A = ap_const_logic_1;
    } else {
        v4_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_2_Rst_A() {
    v4_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_2_WEN_A() {
    v4_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_3_Addr_A() {
    v4_2_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_3_Addr_A_orig() {
    v4_2_3_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_3_Clk_A() {
    v4_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_3_Din_A() {
    v4_2_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_3_EN_A = ap_const_logic_1;
    } else {
        v4_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_3_Rst_A() {
    v4_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_3_WEN_A() {
    v4_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_4_Addr_A() {
    v4_2_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_4_Addr_A_orig() {
    v4_2_4_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_4_Clk_A() {
    v4_2_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_4_Din_A() {
    v4_2_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_4_EN_A = ap_const_logic_1;
    } else {
        v4_2_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_4_Rst_A() {
    v4_2_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_4_WEN_A() {
    v4_2_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_5_Addr_A() {
    v4_2_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_5_Addr_A_orig() {
    v4_2_5_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_5_Clk_A() {
    v4_2_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_5_Din_A() {
    v4_2_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_5_EN_A = ap_const_logic_1;
    } else {
        v4_2_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_5_Rst_A() {
    v4_2_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_5_WEN_A() {
    v4_2_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_6_Addr_A() {
    v4_2_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_6_Addr_A_orig() {
    v4_2_6_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_6_Clk_A() {
    v4_2_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_6_Din_A() {
    v4_2_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_6_EN_A = ap_const_logic_1;
    } else {
        v4_2_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_6_Rst_A() {
    v4_2_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_6_WEN_A() {
    v4_2_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_7_Addr_A() {
    v4_2_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_7_Addr_A_orig() {
    v4_2_7_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_7_Clk_A() {
    v4_2_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_7_Din_A() {
    v4_2_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_7_EN_A = ap_const_logic_1;
    } else {
        v4_2_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_7_Rst_A() {
    v4_2_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_7_WEN_A() {
    v4_2_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_8_Addr_A() {
    v4_2_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_8_Addr_A_orig() {
    v4_2_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_8_Clk_A() {
    v4_2_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_8_Din_A() {
    v4_2_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_8_EN_A = ap_const_logic_1;
    } else {
        v4_2_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_8_Rst_A() {
    v4_2_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_8_WEN_A() {
    v4_2_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_2_9_Addr_A() {
    v4_2_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_2_9_Addr_A_orig() {
    v4_2_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_2_9_Clk_A() {
    v4_2_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_2_9_Din_A() {
    v4_2_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_2_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_2_9_EN_A = ap_const_logic_1;
    } else {
        v4_2_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_2_9_Rst_A() {
    v4_2_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_2_9_WEN_A() {
    v4_2_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_0_Addr_A() {
    v4_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_0_Addr_A_orig() {
    v4_3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_0_Clk_A() {
    v4_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_0_Din_A() {
    v4_3_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_0_EN_A = ap_const_logic_1;
    } else {
        v4_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_0_Rst_A() {
    v4_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_0_WEN_A() {
    v4_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_1_Addr_A() {
    v4_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_1_Addr_A_orig() {
    v4_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_1_Clk_A() {
    v4_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_1_Din_A() {
    v4_3_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_1_EN_A = ap_const_logic_1;
    } else {
        v4_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_1_Rst_A() {
    v4_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_1_WEN_A() {
    v4_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_2_Addr_A() {
    v4_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_2_Addr_A_orig() {
    v4_3_2_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_2_Clk_A() {
    v4_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_2_Din_A() {
    v4_3_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_2_EN_A = ap_const_logic_1;
    } else {
        v4_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_2_Rst_A() {
    v4_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_2_WEN_A() {
    v4_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_3_Addr_A() {
    v4_3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_3_Addr_A_orig() {
    v4_3_3_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_3_Clk_A() {
    v4_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_3_Din_A() {
    v4_3_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_3_EN_A = ap_const_logic_1;
    } else {
        v4_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_3_Rst_A() {
    v4_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_3_WEN_A() {
    v4_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_4_Addr_A() {
    v4_3_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_4_Addr_A_orig() {
    v4_3_4_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_4_Clk_A() {
    v4_3_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_4_Din_A() {
    v4_3_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_4_EN_A = ap_const_logic_1;
    } else {
        v4_3_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_4_Rst_A() {
    v4_3_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_4_WEN_A() {
    v4_3_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_5_Addr_A() {
    v4_3_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_5_Addr_A_orig() {
    v4_3_5_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_5_Clk_A() {
    v4_3_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_5_Din_A() {
    v4_3_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_5_EN_A = ap_const_logic_1;
    } else {
        v4_3_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_5_Rst_A() {
    v4_3_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_5_WEN_A() {
    v4_3_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_6_Addr_A() {
    v4_3_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_6_Addr_A_orig() {
    v4_3_6_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_6_Clk_A() {
    v4_3_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_6_Din_A() {
    v4_3_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_6_EN_A = ap_const_logic_1;
    } else {
        v4_3_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_6_Rst_A() {
    v4_3_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_6_WEN_A() {
    v4_3_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_7_Addr_A() {
    v4_3_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_7_Addr_A_orig() {
    v4_3_7_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_7_Clk_A() {
    v4_3_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_7_Din_A() {
    v4_3_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_7_EN_A = ap_const_logic_1;
    } else {
        v4_3_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_7_Rst_A() {
    v4_3_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_7_WEN_A() {
    v4_3_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_8_Addr_A() {
    v4_3_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_8_Addr_A_orig() {
    v4_3_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_8_Clk_A() {
    v4_3_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_8_Din_A() {
    v4_3_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_8_EN_A = ap_const_logic_1;
    } else {
        v4_3_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_8_Rst_A() {
    v4_3_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_8_WEN_A() {
    v4_3_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_3_9_Addr_A() {
    v4_3_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_3_9_Addr_A_orig() {
    v4_3_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_3_9_Clk_A() {
    v4_3_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_3_9_Din_A() {
    v4_3_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_3_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_3_9_EN_A = ap_const_logic_1;
    } else {
        v4_3_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_3_9_Rst_A() {
    v4_3_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_3_9_WEN_A() {
    v4_3_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_0_Addr_A() {
    v4_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_0_Addr_A_orig() {
    v4_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_0_Clk_A() {
    v4_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_0_Din_A() {
    v4_4_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_0_EN_A = ap_const_logic_1;
    } else {
        v4_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_0_Rst_A() {
    v4_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_0_WEN_A() {
    v4_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_1_Addr_A() {
    v4_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_1_Addr_A_orig() {
    v4_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_1_Clk_A() {
    v4_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_1_Din_A() {
    v4_4_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_1_EN_A = ap_const_logic_1;
    } else {
        v4_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_1_Rst_A() {
    v4_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_1_WEN_A() {
    v4_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_2_Addr_A() {
    v4_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_2_Addr_A_orig() {
    v4_4_2_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_2_Clk_A() {
    v4_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_2_Din_A() {
    v4_4_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_2_EN_A = ap_const_logic_1;
    } else {
        v4_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_2_Rst_A() {
    v4_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_2_WEN_A() {
    v4_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_3_Addr_A() {
    v4_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_3_Addr_A_orig() {
    v4_4_3_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_3_Clk_A() {
    v4_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_3_Din_A() {
    v4_4_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_3_EN_A = ap_const_logic_1;
    } else {
        v4_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_3_Rst_A() {
    v4_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_3_WEN_A() {
    v4_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_4_Addr_A() {
    v4_4_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_4_Addr_A_orig() {
    v4_4_4_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_4_Clk_A() {
    v4_4_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_4_Din_A() {
    v4_4_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_4_EN_A = ap_const_logic_1;
    } else {
        v4_4_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_4_Rst_A() {
    v4_4_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_4_WEN_A() {
    v4_4_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_5_Addr_A() {
    v4_4_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_5_Addr_A_orig() {
    v4_4_5_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_5_Clk_A() {
    v4_4_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_5_Din_A() {
    v4_4_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_5_EN_A = ap_const_logic_1;
    } else {
        v4_4_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_5_Rst_A() {
    v4_4_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_5_WEN_A() {
    v4_4_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_6_Addr_A() {
    v4_4_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_6_Addr_A_orig() {
    v4_4_6_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_6_Clk_A() {
    v4_4_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_6_Din_A() {
    v4_4_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_6_EN_A = ap_const_logic_1;
    } else {
        v4_4_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_6_Rst_A() {
    v4_4_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_6_WEN_A() {
    v4_4_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_7_Addr_A() {
    v4_4_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_7_Addr_A_orig() {
    v4_4_7_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_7_Clk_A() {
    v4_4_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_7_Din_A() {
    v4_4_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_7_EN_A = ap_const_logic_1;
    } else {
        v4_4_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_7_Rst_A() {
    v4_4_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_7_WEN_A() {
    v4_4_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_8_Addr_A() {
    v4_4_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_8_Addr_A_orig() {
    v4_4_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_8_Clk_A() {
    v4_4_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_8_Din_A() {
    v4_4_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_8_EN_A = ap_const_logic_1;
    } else {
        v4_4_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_8_Rst_A() {
    v4_4_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_8_WEN_A() {
    v4_4_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_4_9_Addr_A() {
    v4_4_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_4_9_Addr_A_orig() {
    v4_4_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_4_9_Clk_A() {
    v4_4_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_4_9_Din_A() {
    v4_4_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_4_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_4_9_EN_A = ap_const_logic_1;
    } else {
        v4_4_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_4_9_Rst_A() {
    v4_4_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_4_9_WEN_A() {
    v4_4_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_0_Addr_A() {
    v4_5_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_0_Addr_A_orig() {
    v4_5_0_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_0_Clk_A() {
    v4_5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_0_Din_A() {
    v4_5_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_0_EN_A = ap_const_logic_1;
    } else {
        v4_5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_0_Rst_A() {
    v4_5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_0_WEN_A() {
    v4_5_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_1_Addr_A() {
    v4_5_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_1_Addr_A_orig() {
    v4_5_1_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_1_Clk_A() {
    v4_5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_1_Din_A() {
    v4_5_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_1_EN_A = ap_const_logic_1;
    } else {
        v4_5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_1_Rst_A() {
    v4_5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_1_WEN_A() {
    v4_5_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_2_Addr_A() {
    v4_5_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_2_Addr_A_orig() {
    v4_5_2_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_2_Clk_A() {
    v4_5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_2_Din_A() {
    v4_5_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_2_EN_A = ap_const_logic_1;
    } else {
        v4_5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_2_Rst_A() {
    v4_5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_2_WEN_A() {
    v4_5_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_3_Addr_A() {
    v4_5_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_3_Addr_A_orig() {
    v4_5_3_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_3_Clk_A() {
    v4_5_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_3_Din_A() {
    v4_5_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_3_EN_A = ap_const_logic_1;
    } else {
        v4_5_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_3_Rst_A() {
    v4_5_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_3_WEN_A() {
    v4_5_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_4_Addr_A() {
    v4_5_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_4_Addr_A_orig() {
    v4_5_4_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_4_Clk_A() {
    v4_5_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_4_Din_A() {
    v4_5_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_4_EN_A = ap_const_logic_1;
    } else {
        v4_5_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_4_Rst_A() {
    v4_5_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_4_WEN_A() {
    v4_5_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_5_Addr_A() {
    v4_5_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_5_Addr_A_orig() {
    v4_5_5_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_5_Clk_A() {
    v4_5_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_5_Din_A() {
    v4_5_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_5_EN_A = ap_const_logic_1;
    } else {
        v4_5_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_5_Rst_A() {
    v4_5_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_5_WEN_A() {
    v4_5_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_6_Addr_A() {
    v4_5_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_6_Addr_A_orig() {
    v4_5_6_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_6_Clk_A() {
    v4_5_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_6_Din_A() {
    v4_5_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_6_EN_A = ap_const_logic_1;
    } else {
        v4_5_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_6_Rst_A() {
    v4_5_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_6_WEN_A() {
    v4_5_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_7_Addr_A() {
    v4_5_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_7_Addr_A_orig() {
    v4_5_7_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_7_Clk_A() {
    v4_5_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_7_Din_A() {
    v4_5_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_7_EN_A = ap_const_logic_1;
    } else {
        v4_5_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_7_Rst_A() {
    v4_5_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_7_WEN_A() {
    v4_5_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_8_Addr_A() {
    v4_5_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_8_Addr_A_orig() {
    v4_5_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_8_Clk_A() {
    v4_5_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_8_Din_A() {
    v4_5_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_8_EN_A = ap_const_logic_1;
    } else {
        v4_5_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_8_Rst_A() {
    v4_5_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_8_WEN_A() {
    v4_5_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_5_9_Addr_A() {
    v4_5_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_5_9_Addr_A_orig() {
    v4_5_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_5_9_Clk_A() {
    v4_5_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_5_9_Din_A() {
    v4_5_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_5_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_5_9_EN_A = ap_const_logic_1;
    } else {
        v4_5_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_5_9_Rst_A() {
    v4_5_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_5_9_WEN_A() {
    v4_5_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_0_Addr_A() {
    v4_6_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_0_Addr_A_orig() {
    v4_6_0_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_0_Clk_A() {
    v4_6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_0_Din_A() {
    v4_6_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_0_EN_A = ap_const_logic_1;
    } else {
        v4_6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_0_Rst_A() {
    v4_6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_0_WEN_A() {
    v4_6_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_1_Addr_A() {
    v4_6_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_1_Addr_A_orig() {
    v4_6_1_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_1_Clk_A() {
    v4_6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_1_Din_A() {
    v4_6_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_1_EN_A = ap_const_logic_1;
    } else {
        v4_6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_1_Rst_A() {
    v4_6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_1_WEN_A() {
    v4_6_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_2_Addr_A() {
    v4_6_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_2_Addr_A_orig() {
    v4_6_2_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_2_Clk_A() {
    v4_6_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_2_Din_A() {
    v4_6_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_2_EN_A = ap_const_logic_1;
    } else {
        v4_6_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_2_Rst_A() {
    v4_6_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_2_WEN_A() {
    v4_6_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_3_Addr_A() {
    v4_6_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_3_Addr_A_orig() {
    v4_6_3_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_3_Clk_A() {
    v4_6_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_3_Din_A() {
    v4_6_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_3_EN_A = ap_const_logic_1;
    } else {
        v4_6_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_3_Rst_A() {
    v4_6_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_3_WEN_A() {
    v4_6_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_4_Addr_A() {
    v4_6_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_4_Addr_A_orig() {
    v4_6_4_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_4_Clk_A() {
    v4_6_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_4_Din_A() {
    v4_6_4_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_4_EN_A = ap_const_logic_1;
    } else {
        v4_6_4_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_4_Rst_A() {
    v4_6_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_4_WEN_A() {
    v4_6_4_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_5_Addr_A() {
    v4_6_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_5_Addr_A_orig() {
    v4_6_5_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_5_Clk_A() {
    v4_6_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_5_Din_A() {
    v4_6_5_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_5_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_5_EN_A = ap_const_logic_1;
    } else {
        v4_6_5_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_5_Rst_A() {
    v4_6_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_5_WEN_A() {
    v4_6_5_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_6_Addr_A() {
    v4_6_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_6_Addr_A_orig() {
    v4_6_6_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_6_Clk_A() {
    v4_6_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_6_Din_A() {
    v4_6_6_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_6_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_6_EN_A = ap_const_logic_1;
    } else {
        v4_6_6_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_6_Rst_A() {
    v4_6_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_6_WEN_A() {
    v4_6_6_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_7_Addr_A() {
    v4_6_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_7_Addr_A_orig() {
    v4_6_7_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_7_Clk_A() {
    v4_6_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_7_Din_A() {
    v4_6_7_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_7_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_7_EN_A = ap_const_logic_1;
    } else {
        v4_6_7_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_7_Rst_A() {
    v4_6_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_7_WEN_A() {
    v4_6_7_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_8_Addr_A() {
    v4_6_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_8_Addr_A_orig() {
    v4_6_8_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_8_Clk_A() {
    v4_6_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_8_Din_A() {
    v4_6_8_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_8_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_8_EN_A = ap_const_logic_1;
    } else {
        v4_6_8_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_8_Rst_A() {
    v4_6_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_8_WEN_A() {
    v4_6_8_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v4_6_9_Addr_A() {
    v4_6_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v4_6_9_Addr_A_orig() {
    v4_6_9_Addr_A_orig =  (sc_lv<32>) (zext_ln66_3_fu_4337_p1.read());
}

void kernel_2mm_nonP::thread_v4_6_9_Clk_A() {
    v4_6_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v4_6_9_Din_A() {
    v4_6_9_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v4_6_9_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v4_6_9_EN_A = ap_const_logic_1;
    } else {
        v4_6_9_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v4_6_9_Rst_A() {
    v4_6_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v4_6_9_WEN_A() {
    v4_6_9_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v505_fu_5382_p3() {
    v505_fu_5382_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_4_3_Dout_A.read(): v2_4_8_Dout_A.read());
}

void kernel_2mm_nonP::thread_v514_fu_5389_p3() {
    v514_fu_5389_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_0_4_Dout_A.read(): v2_0_9_Dout_A.read());
}

void kernel_2mm_nonP::thread_v527_fu_5396_p3() {
    v527_fu_5396_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_1_4_Dout_A.read(): v2_1_9_Dout_A.read());
}

void kernel_2mm_nonP::thread_v536_fu_5403_p3() {
    v536_fu_5403_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_2_4_Dout_A.read(): v2_2_9_Dout_A.read());
}

void kernel_2mm_nonP::thread_v545_fu_5410_p3() {
    v545_fu_5410_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_3_4_Dout_A.read(): v2_3_9_Dout_A.read());
}

void kernel_2mm_nonP::thread_v554_fu_5417_p3() {
    v554_fu_5417_p3 = (!select_ln371_3_reg_7647.read()[0].is_01())? sc_lv<32>(): ((select_ln371_3_reg_7647.read()[0].to_bool())? v2_4_4_Dout_A.read(): v2_4_9_Dout_A.read());
}

void kernel_2mm_nonP::thread_v5_0_0_Addr_A() {
    v5_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_0_0_Addr_A_orig() {
    v5_0_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_5066_p1.read());
}

void kernel_2mm_nonP::thread_v5_0_0_Clk_A() {
    v5_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_0_0_Din_A() {
    v5_0_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_0_0_EN_A = ap_const_logic_1;
    } else {
        v5_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_0_0_Rst_A() {
    v5_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_0_0_WEN_A() {
    v5_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_0_1_Addr_A() {
    v5_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_0_1_Addr_A_orig() {
    v5_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_5066_p1.read());
}

void kernel_2mm_nonP::thread_v5_0_1_Clk_A() {
    v5_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_0_1_Din_A() {
    v5_0_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_0_1_EN_A = ap_const_logic_1;
    } else {
        v5_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_0_1_Rst_A() {
    v5_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_0_1_WEN_A() {
    v5_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_0_2_Addr_A() {
    v5_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_0_2_Addr_A_orig() {
    v5_0_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_5073_p1.read());
}

void kernel_2mm_nonP::thread_v5_0_2_Clk_A() {
    v5_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_0_2_Din_A() {
    v5_0_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_0_2_EN_A = ap_const_logic_1;
    } else {
        v5_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_0_2_Rst_A() {
    v5_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_0_2_WEN_A() {
    v5_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_0_3_Addr_A() {
    v5_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_0_3_Addr_A_orig() {
    v5_0_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_5073_p1.read());
}

void kernel_2mm_nonP::thread_v5_0_3_Clk_A() {
    v5_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_0_3_Din_A() {
    v5_0_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_0_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_0_3_EN_A = ap_const_logic_1;
    } else {
        v5_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_0_3_Rst_A() {
    v5_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_0_3_WEN_A() {
    v5_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_1_0_Addr_A() {
    v5_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_1_0_Addr_A_orig() {
    v5_1_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_5066_p1.read());
}

void kernel_2mm_nonP::thread_v5_1_0_Clk_A() {
    v5_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_1_0_Din_A() {
    v5_1_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_1_0_EN_A = ap_const_logic_1;
    } else {
        v5_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_1_0_Rst_A() {
    v5_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_1_0_WEN_A() {
    v5_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_1_1_Addr_A() {
    v5_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_1_1_Addr_A_orig() {
    v5_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_fu_5066_p1.read());
}

void kernel_2mm_nonP::thread_v5_1_1_Clk_A() {
    v5_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_1_1_Din_A() {
    v5_1_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_1_1_EN_A = ap_const_logic_1;
    } else {
        v5_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_1_1_Rst_A() {
    v5_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_1_1_WEN_A() {
    v5_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_1_2_Addr_A() {
    v5_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_1_2_Addr_A_orig() {
    v5_1_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_5073_p1.read());
}

void kernel_2mm_nonP::thread_v5_1_2_Clk_A() {
    v5_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_1_2_Din_A() {
    v5_1_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_1_2_EN_A = ap_const_logic_1;
    } else {
        v5_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_1_2_Rst_A() {
    v5_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_1_2_WEN_A() {
    v5_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_1_3_Addr_A() {
    v5_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_1_3_Addr_A_orig() {
    v5_1_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_fu_5073_p1.read());
}

void kernel_2mm_nonP::thread_v5_1_3_Clk_A() {
    v5_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_1_3_Din_A() {
    v5_1_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_1_3_EN_A = ap_const_logic_1;
    } else {
        v5_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_1_3_Rst_A() {
    v5_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_1_3_WEN_A() {
    v5_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_2_0_Addr_A() {
    v5_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_2_0_Addr_A_orig() {
    v5_2_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7395.read());
}

void kernel_2mm_nonP::thread_v5_2_0_Clk_A() {
    v5_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_2_0_Din_A() {
    v5_2_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_2_0_EN_A = ap_const_logic_1;
    } else {
        v5_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_2_0_Rst_A() {
    v5_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_2_0_WEN_A() {
    v5_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_2_1_Addr_A() {
    v5_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_2_1_Addr_A_orig() {
    v5_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7395.read());
}

void kernel_2mm_nonP::thread_v5_2_1_Clk_A() {
    v5_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_2_1_Din_A() {
    v5_2_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_2_1_EN_A = ap_const_logic_1;
    } else {
        v5_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_2_1_Rst_A() {
    v5_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_2_1_WEN_A() {
    v5_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_2_2_Addr_A() {
    v5_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_2_2_Addr_A_orig() {
    v5_2_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7415.read());
}

void kernel_2mm_nonP::thread_v5_2_2_Clk_A() {
    v5_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_2_2_Din_A() {
    v5_2_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_2_2_EN_A = ap_const_logic_1;
    } else {
        v5_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_2_2_Rst_A() {
    v5_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_2_2_WEN_A() {
    v5_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_2_3_Addr_A() {
    v5_2_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_2_3_Addr_A_orig() {
    v5_2_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7415.read());
}

void kernel_2mm_nonP::thread_v5_2_3_Clk_A() {
    v5_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_2_3_Din_A() {
    v5_2_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_2_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_2_3_EN_A = ap_const_logic_1;
    } else {
        v5_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_2_3_Rst_A() {
    v5_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_2_3_WEN_A() {
    v5_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_3_0_Addr_A() {
    v5_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_3_0_Addr_A_orig() {
    v5_3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7395.read());
}

void kernel_2mm_nonP::thread_v5_3_0_Clk_A() {
    v5_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_3_0_Din_A() {
    v5_3_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_3_0_EN_A = ap_const_logic_1;
    } else {
        v5_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_3_0_Rst_A() {
    v5_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_3_0_WEN_A() {
    v5_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_3_1_Addr_A() {
    v5_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_3_1_Addr_A_orig() {
    v5_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7395.read());
}

void kernel_2mm_nonP::thread_v5_3_1_Clk_A() {
    v5_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_3_1_Din_A() {
    v5_3_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_3_1_EN_A = ap_const_logic_1;
    } else {
        v5_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_3_1_Rst_A() {
    v5_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_3_1_WEN_A() {
    v5_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_3_2_Addr_A() {
    v5_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_3_2_Addr_A_orig() {
    v5_3_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7415.read());
}

void kernel_2mm_nonP::thread_v5_3_2_Clk_A() {
    v5_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_3_2_Din_A() {
    v5_3_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_3_2_EN_A = ap_const_logic_1;
    } else {
        v5_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_3_2_Rst_A() {
    v5_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_3_2_WEN_A() {
    v5_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_3_3_Addr_A() {
    v5_3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_3_3_Addr_A_orig() {
    v5_3_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7415.read());
}

void kernel_2mm_nonP::thread_v5_3_3_Clk_A() {
    v5_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_3_3_Din_A() {
    v5_3_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_3_3_EN_A = ap_const_logic_1;
    } else {
        v5_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_3_3_Rst_A() {
    v5_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_3_3_WEN_A() {
    v5_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_4_0_Addr_A() {
    v5_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_4_0_Addr_A_orig() {
    v5_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7395.read());
}

void kernel_2mm_nonP::thread_v5_4_0_Clk_A() {
    v5_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_4_0_Din_A() {
    v5_4_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_4_0_EN_A = ap_const_logic_1;
    } else {
        v5_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_4_0_Rst_A() {
    v5_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_4_0_WEN_A() {
    v5_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_4_1_Addr_A() {
    v5_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_4_1_Addr_A_orig() {
    v5_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln378_3_reg_7395.read());
}

void kernel_2mm_nonP::thread_v5_4_1_Clk_A() {
    v5_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_4_1_Din_A() {
    v5_4_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_4_1_EN_A = ap_const_logic_1;
    } else {
        v5_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_4_1_Rst_A() {
    v5_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_4_1_WEN_A() {
    v5_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_4_2_Addr_A() {
    v5_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_4_2_Addr_A_orig() {
    v5_4_2_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7415.read());
}

void kernel_2mm_nonP::thread_v5_4_2_Clk_A() {
    v5_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_4_2_Din_A() {
    v5_4_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_4_2_EN_A = ap_const_logic_1;
    } else {
        v5_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_4_2_Rst_A() {
    v5_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_4_2_WEN_A() {
    v5_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v5_4_3_Addr_A() {
    v5_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v5_4_3_Addr_A_orig() {
    v5_4_3_Addr_A_orig =  (sc_lv<32>) (sext_ln400_reg_7415.read());
}

void kernel_2mm_nonP::thread_v5_4_3_Clk_A() {
    v5_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v5_4_3_Din_A() {
    v5_4_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v5_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter3.read()))) {
        v5_4_3_EN_A = ap_const_logic_1;
    } else {
        v5_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v5_4_3_Rst_A() {
    v5_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v5_4_3_WEN_A() {
    v5_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_0_0_Addr_A() {
    v6_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_0_0_Addr_A_orig() {
    v6_0_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_0_0_Addr_B() {
    v6_0_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_0_0_Addr_B_orig() {
    v6_0_0_Addr_B_orig =  (sc_lv<32>) (v6_0_0_addr_reg_6831_pp1_iter10_reg.read());
}

void kernel_2mm_nonP::thread_v6_0_0_Clk_A() {
    v6_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_0_0_Clk_B() {
    v6_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_0_0_Din_A() {
    v6_0_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_0_0_Din_B() {
    v6_0_0_Din_B = reg_4058.read();
}

void kernel_2mm_nonP::thread_v6_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_0_0_EN_A = ap_const_logic_1;
    } else {
        v6_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_0_0_EN_B = ap_const_logic_1;
    } else {
        v6_0_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_0_Rst_A() {
    v6_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_0_0_Rst_B() {
    v6_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_0_0_WEN_A() {
    v6_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_0_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_0_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_1_Addr_A() {
    v6_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_0_1_Addr_A_orig() {
    v6_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_0_1_Addr_B() {
    v6_0_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_0_1_Addr_B_orig() {
    v6_0_1_Addr_B_orig =  (sc_lv<32>) (v6_0_1_addr_reg_6837_pp1_iter10_reg.read());
}

void kernel_2mm_nonP::thread_v6_0_1_Clk_A() {
    v6_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_0_1_Clk_B() {
    v6_0_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_0_1_Din_A() {
    v6_0_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_0_1_Din_B() {
    v6_0_1_Din_B = reg_4064.read();
}

void kernel_2mm_nonP::thread_v6_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_0_1_EN_A = ap_const_logic_1;
    } else {
        v6_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_0_1_EN_B = ap_const_logic_1;
    } else {
        v6_0_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_1_Rst_A() {
    v6_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_0_1_Rst_B() {
    v6_0_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_0_1_WEN_A() {
    v6_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_0_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_0_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_2_Addr_A() {
    v6_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_0_2_Addr_A_orig() {
    v6_0_2_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_0_2_Addr_B() {
    v6_0_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_0_2_Addr_B_orig() {
    v6_0_2_Addr_B_orig =  (sc_lv<32>) (v6_0_2_addr_reg_6843_pp1_iter10_reg.read());
}

void kernel_2mm_nonP::thread_v6_0_2_Clk_A() {
    v6_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_0_2_Clk_B() {
    v6_0_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_0_2_Din_A() {
    v6_0_2_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_0_2_Din_B() {
    v6_0_2_Din_B = reg_4070.read();
}

void kernel_2mm_nonP::thread_v6_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_0_2_EN_A = ap_const_logic_1;
    } else {
        v6_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_0_2_EN_B = ap_const_logic_1;
    } else {
        v6_0_2_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_2_Rst_A() {
    v6_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_0_2_Rst_B() {
    v6_0_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_0_2_WEN_A() {
    v6_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_0_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_0_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_3_Addr_A() {
    v6_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_0_3_Addr_A_orig() {
    v6_0_3_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_0_3_Addr_B() {
    v6_0_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_0_3_Addr_B_orig() {
    v6_0_3_Addr_B_orig =  (sc_lv<32>) (v6_0_3_addr_reg_6849_pp1_iter10_reg.read());
}

void kernel_2mm_nonP::thread_v6_0_3_Clk_A() {
    v6_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_0_3_Clk_B() {
    v6_0_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_0_3_Din_A() {
    v6_0_3_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_0_3_Din_B() {
    v6_0_3_Din_B = reg_4076.read();
}

void kernel_2mm_nonP::thread_v6_0_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_0_3_EN_A = ap_const_logic_1;
    } else {
        v6_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_0_3_EN_B = ap_const_logic_1;
    } else {
        v6_0_3_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_0_3_Rst_A() {
    v6_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_0_3_Rst_B() {
    v6_0_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_0_3_WEN_A() {
    v6_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_0_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_0_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_0_Addr_A() {
    v6_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_1_0_Addr_A_orig() {
    v6_1_0_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_1_0_Addr_B() {
    v6_1_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_1_0_Addr_B_orig() {
    v6_1_0_Addr_B_orig =  (sc_lv<32>) (v6_1_0_addr_reg_6855_pp1_iter10_reg.read());
}

void kernel_2mm_nonP::thread_v6_1_0_Clk_A() {
    v6_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_1_0_Clk_B() {
    v6_1_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_1_0_Din_A() {
    v6_1_0_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_1_0_Din_B() {
    v6_1_0_Din_B = reg_4082.read();
}

void kernel_2mm_nonP::thread_v6_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_1_0_EN_A = ap_const_logic_1;
    } else {
        v6_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_1_0_EN_B = ap_const_logic_1;
    } else {
        v6_1_0_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_0_Rst_A() {
    v6_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_1_0_Rst_B() {
    v6_1_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_1_0_WEN_A() {
    v6_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_2mm_nonP::thread_v6_1_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln371_reg_6742_pp1_iter11_reg.read()))) {
        v6_1_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_1_Addr_A() {
    v6_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_1_1_Addr_A_orig() {
    v6_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln375_1_fu_4774_p1.read());
}

void kernel_2mm_nonP::thread_v6_1_1_Addr_B() {
    v6_1_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_2mm_nonP::thread_v6_1_1_Addr_B_orig() {
    v6_1_1_Addr_B_orig =  (sc_lv<32>) (v6_1_1_addr_reg_6861_pp1_iter10_reg.read());
}

void kernel_2mm_nonP::thread_v6_1_1_Clk_A() {
    v6_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_1_1_Clk_B() {
    v6_1_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_2mm_nonP::thread_v6_1_1_Din_A() {
    v6_1_1_Din_A = ap_const_lv32_0;
}

void kernel_2mm_nonP::thread_v6_1_1_Din_B() {
    v6_1_1_Din_B = reg_4088.read();
}

void kernel_2mm_nonP::thread_v6_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v6_1_1_EN_A = ap_const_logic_1;
    } else {
        v6_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter11.read()))) {
        v6_1_1_EN_B = ap_const_logic_1;
    } else {
        v6_1_1_EN_B = ap_const_logic_0;
    }
}

void kernel_2mm_nonP::thread_v6_1_1_Rst_A() {
    v6_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_2mm_nonP::thread_v6_1_1_Rst_B() {
    v6_1_1_Rst_B = ap_rst_n_inv.read();
}

}


// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XKERNEL_3MM_NONP_H
#define XKERNEL_3MM_NONP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xkernel_3mm_nonp_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Ctrl_BaseAddress;
} XKernel_3mm_nonp_Config;
#endif

typedef struct {
    u32 Ctrl_BaseAddress;
    u32 IsReady;
} XKernel_3mm_nonp;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XKernel_3mm_nonp_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XKernel_3mm_nonp_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XKernel_3mm_nonp_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XKernel_3mm_nonp_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XKernel_3mm_nonp_Initialize(XKernel_3mm_nonp *InstancePtr, u16 DeviceId);
XKernel_3mm_nonp_Config* XKernel_3mm_nonp_LookupConfig(u16 DeviceId);
int XKernel_3mm_nonp_CfgInitialize(XKernel_3mm_nonp *InstancePtr, XKernel_3mm_nonp_Config *ConfigPtr);
#else
int XKernel_3mm_nonp_Initialize(XKernel_3mm_nonp *InstancePtr, const char* InstanceName);
int XKernel_3mm_nonp_Release(XKernel_3mm_nonp *InstancePtr);
#endif

void XKernel_3mm_nonp_Start(XKernel_3mm_nonp *InstancePtr);
u32 XKernel_3mm_nonp_IsDone(XKernel_3mm_nonp *InstancePtr);
u32 XKernel_3mm_nonp_IsIdle(XKernel_3mm_nonp *InstancePtr);
u32 XKernel_3mm_nonp_IsReady(XKernel_3mm_nonp *InstancePtr);
void XKernel_3mm_nonp_EnableAutoRestart(XKernel_3mm_nonp *InstancePtr);
void XKernel_3mm_nonp_DisableAutoRestart(XKernel_3mm_nonp *InstancePtr);


void XKernel_3mm_nonp_InterruptGlobalEnable(XKernel_3mm_nonp *InstancePtr);
void XKernel_3mm_nonp_InterruptGlobalDisable(XKernel_3mm_nonp *InstancePtr);
void XKernel_3mm_nonp_InterruptEnable(XKernel_3mm_nonp *InstancePtr, u32 Mask);
void XKernel_3mm_nonp_InterruptDisable(XKernel_3mm_nonp *InstancePtr, u32 Mask);
void XKernel_3mm_nonp_InterruptClear(XKernel_3mm_nonp *InstancePtr, u32 Mask);
u32 XKernel_3mm_nonp_InterruptGetEnabled(XKernel_3mm_nonp *InstancePtr);
u32 XKernel_3mm_nonp_InterruptGetStatus(XKernel_3mm_nonp *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif

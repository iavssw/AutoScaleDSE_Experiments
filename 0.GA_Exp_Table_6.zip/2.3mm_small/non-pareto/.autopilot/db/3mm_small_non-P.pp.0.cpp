# 1 "2.3mm_small/3mm_small_non-P.cpp"
# 1 "2.3mm_small/3mm_small_non-P.cpp" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 152 "<built-in>" 3
# 1 "<command line>" 1







# 1 "C:/Xilinx/Vivado/2019.2/common/technology/autopilot\\etc/autopilot_ssdm_op.h" 1
# 157 "C:/Xilinx/Vivado/2019.2/common/technology/autopilot\\etc/autopilot_ssdm_op.h"
extern "C" {






    void _ssdm_op_IfRead(...) __attribute__ ((nothrow));
    void _ssdm_op_IfWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanWrite(...) __attribute__ ((nothrow));


    void _ssdm_StreamRead(...) __attribute__ ((nothrow));
    void _ssdm_StreamWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanWrite(...) __attribute__ ((nothrow));
    unsigned _ssdm_StreamSize(...) __attribute__ ((nothrow));




    void _ssdm_op_MemShiftRead(...) __attribute__ ((nothrow));

    void _ssdm_op_Wait(...) __attribute__ ((nothrow));
    void _ssdm_op_Poll(...) __attribute__ ((nothrow));

    void _ssdm_op_Return(...) __attribute__ ((nothrow));


    void _ssdm_op_SpecSynModule(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecTopModule(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDecl(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDef(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecPort(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecConnection(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecChannel(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecSensitive(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecModuleInst(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecPortMap(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecReset(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecPlatform(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecClockDomain(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecPowerDomain(...) __attribute__ ((nothrow));

    int _ssdm_op_SpecRegionBegin(...) __attribute__ ((nothrow));
    int _ssdm_op_SpecRegionEnd(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopName(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopTripCount(...) __attribute__ ((nothrow));

    int _ssdm_op_SpecStateBegin(...) __attribute__ ((nothrow));
    int _ssdm_op_SpecStateEnd(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecInterface(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecPipeline(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecDataflowPipeline(...) __attribute__ ((nothrow));


    void _ssdm_op_SpecLatency(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecParallel(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecProtocol(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecOccurrence(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecResource(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecResourceLimit(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecCHCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecFUCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecIFCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecIPCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecKeepValue(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecMemCore(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecExt(...) __attribute__ ((nothrow));




    void _ssdm_SpecArrayDimSize(...) __attribute__ ((nothrow));

    void _ssdm_RegionBegin(...) __attribute__ ((nothrow));
    void _ssdm_RegionEnd(...) __attribute__ ((nothrow));

    void _ssdm_Unroll(...) __attribute__ ((nothrow));
    void _ssdm_UnrollRegion(...) __attribute__ ((nothrow));

    void _ssdm_InlineAll(...) __attribute__ ((nothrow));
    void _ssdm_InlineLoop(...) __attribute__ ((nothrow));
    void _ssdm_Inline(...) __attribute__ ((nothrow));
    void _ssdm_InlineSelf(...) __attribute__ ((nothrow));
    void _ssdm_InlineRegion(...) __attribute__ ((nothrow));

    void _ssdm_SpecArrayMap(...) __attribute__ ((nothrow));
    void _ssdm_SpecArrayPartition(...) __attribute__ ((nothrow));
    void _ssdm_SpecArrayReshape(...) __attribute__ ((nothrow));

    void _ssdm_SpecStream(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecStable(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecStableContent(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecPipoDepth(...) __attribute__ ((nothrow));

    void _ssdm_SpecExpr(...) __attribute__ ((nothrow));
    void _ssdm_SpecExprBalance(...) __attribute__ ((nothrow));

    void _ssdm_SpecDependence(...) __attribute__ ((nothrow));

    void _ssdm_SpecLoopMerge(...) __attribute__ ((nothrow));
    void _ssdm_SpecLoopFlatten(...) __attribute__ ((nothrow));
    void _ssdm_SpecLoopRewind(...) __attribute__ ((nothrow));

    void _ssdm_SpecFuncInstantiation(...) __attribute__ ((nothrow));
    void _ssdm_SpecFuncBuffer(...) __attribute__ ((nothrow));
    void _ssdm_SpecFuncExtract(...) __attribute__ ((nothrow));
    void _ssdm_SpecConstant(...) __attribute__ ((nothrow));

    void _ssdm_DataPack(...) __attribute__ ((nothrow));
    void _ssdm_SpecDataPack(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecBitsMap(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecLicense(...) __attribute__ ((nothrow));

    void __xilinx_ip_top(...) __attribute__ ((nothrow));


}
# 9 "<command line>" 2
# 1 "<built-in>" 2
# 1 "2.3mm_small/3mm_small_non-P.cpp" 2
# 12 "2.3mm_small/3mm_small_non-P.cpp"
void kernel_3mm_nonP(
  float v0[40][60],
  float v1[60][50],
  float v2[50][80],
  float v3[80][70],
  float v4[40][50],
  float v5[50][70],
  float v6[40][70]
) {_ssdm_SpecArrayDimSize(v0, 40);_ssdm_SpecArrayDimSize(v1, 60);_ssdm_SpecArrayDimSize(v2, 50);_ssdm_SpecArrayDimSize(v3, 80);_ssdm_SpecArrayDimSize(v4, 40);_ssdm_SpecArrayDimSize(v5, 50);_ssdm_SpecArrayDimSize(v6, 40);
#pragma HLS interface s_axilite port=return bundle=ctrl
#pragma HLS interface bram port=&v0
#pragma HLS interface bram port=&v1
#pragma HLS interface bram port=&v2
#pragma HLS interface bram port=&v3
#pragma HLS interface bram port=&v4
#pragma HLS interface bram port=&v5
#pragma HLS interface bram port=&v6

#pragma HLS array_partition variable=&v0 cyclic factor=8 dim=1
#pragma HLS array_partition variable=&v0 cyclic factor=3 dim=2
#pragma HLS resource variable=&v0 core=ram_s2p_bram

#pragma HLS array_partition variable=&v1 cyclic factor=3 dim=1
#pragma HLS array_partition variable=&v1 cyclic factor=2 dim=2
#pragma HLS resource variable=&v1 core=ram_s2p_bram

#pragma HLS array_partition variable=&v2 cyclic factor=10 dim=1
#pragma HLS array_partition variable=&v2 cyclic factor=2 dim=2
#pragma HLS resource variable=&v2 core=ram_s2p_bram

#pragma HLS array_partition variable=&v3 cyclic factor=2 dim=1
#pragma HLS array_partition variable=&v3 cyclic factor=2 dim=2
#pragma HLS resource variable=&v3 core=ram_s2p_bram

#pragma HLS array_partition variable=&v4 cyclic factor=8 dim=1
#pragma HLS array_partition variable=&v4 cyclic factor=5 dim=2
#pragma HLS resource variable=&v4 core=ram_s2p_bram

#pragma HLS array_partition variable=&v5 cyclic factor=10 dim=1
#pragma HLS array_partition variable=&v5 cyclic factor=5 dim=2
#pragma HLS resource variable=&v5 core=ram_s2p_bram

#pragma HLS array_partition variable=&v6 cyclic factor=5 dim=1
#pragma HLS array_partition variable=&v6 cyclic factor=5 dim=2
#pragma HLS resource variable=&v6 core=ram_s2p_bram

 float v7 = 0;
  for (int v8 = 0; v8 < 20; v8 += 1) {
    for (int v9 = 0; v9 < 5; v9 += 1) {
      for (int v10 = 0; v10 < 25; v10 += 1) {
#pragma HLS pipeline II=1
 float v11 = v0[(v9 * 8)][(v8 * 3)];
        float v12 = v1[(v8 * 3)][(v10 * 2)];
        float v13 = v11 * v12;
        float v14 = v4[(v9 * 8)][(v10 * 2)];
        float v15;
        if ((v8 * 3) == 0) {
          v15 = v7;
        } else {
          v15 = v14;
        }
        float v16 = v15 + v13;
        float v17 = v1[(v8 * 3)][((v10 * 2) + 1)];
        float v18 = v11 * v17;
        float v19 = v4[(v9 * 8)][((v10 * 2) + 1)];
        float v20;
        if ((v8 * 3) == 0) {
          v20 = v7;
        } else {
          v20 = v19;
        }
        float v21 = v20 + v18;
        float v22 = v0[((v9 * 8) + 1)][(v8 * 3)];
        float v23 = v22 * v12;
        float v24 = v4[((v9 * 8) + 1)][(v10 * 2)];
        float v25;
        if ((v8 * 3) == 0) {
          v25 = v7;
        } else {
          v25 = v24;
        }
        float v26 = v25 + v23;
        float v27 = v22 * v17;
        float v28 = v4[((v9 * 8) + 1)][((v10 * 2) + 1)];
        float v29;
        if ((v8 * 3) == 0) {
          v29 = v7;
        } else {
          v29 = v28;
        }
        float v30 = v29 + v27;
        float v31 = v0[((v9 * 8) + 2)][(v8 * 3)];
        float v32 = v31 * v12;
        float v33 = v4[((v9 * 8) + 2)][(v10 * 2)];
        float v34;
        if ((v8 * 3) == 0) {
          v34 = v7;
        } else {
          v34 = v33;
        }
        float v35 = v34 + v32;
        float v36 = v31 * v17;
        float v37 = v4[((v9 * 8) + 2)][((v10 * 2) + 1)];
        float v38;
        if ((v8 * 3) == 0) {
          v38 = v7;
        } else {
          v38 = v37;
        }
        float v39 = v38 + v36;
        float v40 = v0[((v9 * 8) + 3)][(v8 * 3)];
        float v41 = v40 * v12;
        float v42 = v4[((v9 * 8) + 3)][(v10 * 2)];
        float v43;
        if ((v8 * 3) == 0) {
          v43 = v7;
        } else {
          v43 = v42;
        }
        float v44 = v43 + v41;
        float v45 = v40 * v17;
        float v46 = v4[((v9 * 8) + 3)][((v10 * 2) + 1)];
        float v47;
        if ((v8 * 3) == 0) {
          v47 = v7;
        } else {
          v47 = v46;
        }
        float v48 = v47 + v45;
        float v49 = v0[((v9 * 8) + 4)][(v8 * 3)];
        float v50 = v49 * v12;
        float v51 = v4[((v9 * 8) + 4)][(v10 * 2)];
        float v52;
        if ((v8 * 3) == 0) {
          v52 = v7;
        } else {
          v52 = v51;
        }
        float v53 = v52 + v50;
        float v54 = v49 * v17;
        float v55 = v4[((v9 * 8) + 4)][((v10 * 2) + 1)];
        float v56;
        if ((v8 * 3) == 0) {
          v56 = v7;
        } else {
          v56 = v55;
        }
        float v57 = v56 + v54;
        float v58 = v0[((v9 * 8) + 5)][(v8 * 3)];
        float v59 = v58 * v12;
        float v60 = v4[((v9 * 8) + 5)][(v10 * 2)];
        float v61;
        if ((v8 * 3) == 0) {
          v61 = v7;
        } else {
          v61 = v60;
        }
        float v62 = v61 + v59;
        float v63 = v58 * v17;
        float v64 = v4[((v9 * 8) + 5)][((v10 * 2) + 1)];
        float v65;
        if ((v8 * 3) == 0) {
          v65 = v7;
        } else {
          v65 = v64;
        }
        float v66 = v65 + v63;
        float v67 = v0[((v9 * 8) + 6)][(v8 * 3)];
        float v68 = v67 * v12;
        float v69 = v4[((v9 * 8) + 6)][(v10 * 2)];
        float v70;
        if ((v8 * 3) == 0) {
          v70 = v7;
        } else {
          v70 = v69;
        }
        float v71 = v70 + v68;
        float v72 = v67 * v17;
        float v73 = v4[((v9 * 8) + 6)][((v10 * 2) + 1)];
        float v74;
        if ((v8 * 3) == 0) {
          v74 = v7;
        } else {
          v74 = v73;
        }
        float v75 = v74 + v72;
        float v76 = v0[((v9 * 8) + 7)][(v8 * 3)];
        float v77 = v76 * v12;
        float v78 = v4[((v9 * 8) + 7)][(v10 * 2)];
        float v79;
        if ((v8 * 3) == 0) {
          v79 = v7;
        } else {
          v79 = v78;
        }
        float v80 = v79 + v77;
        float v81 = v76 * v17;
        float v82 = v4[((v9 * 8) + 7)][((v10 * 2) + 1)];
        float v83;
        if ((v8 * 3) == 0) {
          v83 = v7;
        } else {
          v83 = v82;
        }
        float v84 = v83 + v81;
        float v85 = v0[(v9 * 8)][((v8 * 3) + 1)];
        float v86 = v1[((v8 * 3) + 1)][(v10 * 2)];
        float v87 = v85 * v86;
        float v88 = v16 + v87;
        float v89 = v1[((v8 * 3) + 1)][((v10 * 2) + 1)];
        float v90 = v85 * v89;
        float v91 = v21 + v90;
        float v92 = v0[((v9 * 8) + 1)][((v8 * 3) + 1)];
        float v93 = v92 * v86;
        float v94 = v26 + v93;
        float v95 = v92 * v89;
        float v96 = v30 + v95;
        float v97 = v0[((v9 * 8) + 2)][((v8 * 3) + 1)];
        float v98 = v97 * v86;
        float v99 = v35 + v98;
        float v100 = v97 * v89;
        float v101 = v39 + v100;
        float v102 = v0[((v9 * 8) + 3)][((v8 * 3) + 1)];
        float v103 = v102 * v86;
        float v104 = v44 + v103;
        float v105 = v102 * v89;
        float v106 = v48 + v105;
        float v107 = v0[((v9 * 8) + 4)][((v8 * 3) + 1)];
        float v108 = v107 * v86;
        float v109 = v53 + v108;
        float v110 = v107 * v89;
        float v111 = v57 + v110;
        float v112 = v0[((v9 * 8) + 5)][((v8 * 3) + 1)];
        float v113 = v112 * v86;
        float v114 = v62 + v113;
        float v115 = v112 * v89;
        float v116 = v66 + v115;
        float v117 = v0[((v9 * 8) + 6)][((v8 * 3) + 1)];
        float v118 = v117 * v86;
        float v119 = v71 + v118;
        float v120 = v117 * v89;
        float v121 = v75 + v120;
        float v122 = v0[((v9 * 8) + 7)][((v8 * 3) + 1)];
        float v123 = v122 * v86;
        float v124 = v80 + v123;
        float v125 = v122 * v89;
        float v126 = v84 + v125;
        float v127 = v0[(v9 * 8)][((v8 * 3) + 2)];
        float v128 = v1[((v8 * 3) + 2)][(v10 * 2)];
        float v129 = v127 * v128;
        float v130 = v88 + v129;
        v4[(v9 * 8)][(v10 * 2)] = v130;
        float v131 = v1[((v8 * 3) + 2)][((v10 * 2) + 1)];
        float v132 = v127 * v131;
        float v133 = v91 + v132;
        v4[(v9 * 8)][((v10 * 2) + 1)] = v133;
        float v134 = v0[((v9 * 8) + 1)][((v8 * 3) + 2)];
        float v135 = v134 * v128;
        float v136 = v94 + v135;
        v4[((v9 * 8) + 1)][(v10 * 2)] = v136;
        float v137 = v134 * v131;
        float v138 = v96 + v137;
        v4[((v9 * 8) + 1)][((v10 * 2) + 1)] = v138;
        float v139 = v0[((v9 * 8) + 2)][((v8 * 3) + 2)];
        float v140 = v139 * v128;
        float v141 = v99 + v140;
        v4[((v9 * 8) + 2)][(v10 * 2)] = v141;
        float v142 = v139 * v131;
        float v143 = v101 + v142;
        v4[((v9 * 8) + 2)][((v10 * 2) + 1)] = v143;
        float v144 = v0[((v9 * 8) + 3)][((v8 * 3) + 2)];
        float v145 = v144 * v128;
        float v146 = v104 + v145;
        v4[((v9 * 8) + 3)][(v10 * 2)] = v146;
        float v147 = v144 * v131;
        float v148 = v106 + v147;
        v4[((v9 * 8) + 3)][((v10 * 2) + 1)] = v148;
        float v149 = v0[((v9 * 8) + 4)][((v8 * 3) + 2)];
        float v150 = v149 * v128;
        float v151 = v109 + v150;
        v4[((v9 * 8) + 4)][(v10 * 2)] = v151;
        float v152 = v149 * v131;
        float v153 = v111 + v152;
        v4[((v9 * 8) + 4)][((v10 * 2) + 1)] = v153;
        float v154 = v0[((v9 * 8) + 5)][((v8 * 3) + 2)];
        float v155 = v154 * v128;
        float v156 = v114 + v155;
        v4[((v9 * 8) + 5)][(v10 * 2)] = v156;
        float v157 = v154 * v131;
        float v158 = v116 + v157;
        v4[((v9 * 8) + 5)][((v10 * 2) + 1)] = v158;
        float v159 = v0[((v9 * 8) + 6)][((v8 * 3) + 2)];
        float v160 = v159 * v128;
        float v161 = v119 + v160;
        v4[((v9 * 8) + 6)][(v10 * 2)] = v161;
        float v162 = v159 * v131;
        float v163 = v121 + v162;
        v4[((v9 * 8) + 6)][((v10 * 2) + 1)] = v163;
        float v164 = v0[((v9 * 8) + 7)][((v8 * 3) + 2)];
        float v165 = v164 * v128;
        float v166 = v124 + v165;
        v4[((v9 * 8) + 7)][(v10 * 2)] = v166;
        float v167 = v164 * v131;
        float v168 = v126 + v167;
        v4[((v9 * 8) + 7)][((v10 * 2) + 1)] = v168;
      }
    }
  }
  for (int v169 = 0; v169 < 40; v169 += 1) {
    for (int v170 = 0; v170 < 5; v170 += 1) {
      for (int v171 = 0; v171 < 35; v171 += 1) {
#pragma HLS pipeline II=1
 float v172 = v2[(v170 * 10)][(v169 * 2)];
        float v173 = v3[(v169 * 2)][(v171 * 2)];
        float v174 = v172 * v173;
        float v175 = v5[(v170 * 10)][(v171 * 2)];
        float v176;
        if ((v169 * 2) == 0) {
          v176 = v7;
        } else {
          v176 = v175;
        }
        float v177 = v176 + v174;
        float v178 = v3[(v169 * 2)][((v171 * 2) + 1)];
        float v179 = v172 * v178;
        float v180 = v5[(v170 * 10)][((v171 * 2) + 1)];
        float v181;
        if ((v169 * 2) == 0) {
          v181 = v7;
        } else {
          v181 = v180;
        }
        float v182 = v181 + v179;
        float v183 = v2[((v170 * 10) + 1)][(v169 * 2)];
        float v184 = v183 * v173;
        float v185 = v5[((v170 * 10) + 1)][(v171 * 2)];
        float v186;
        if ((v169 * 2) == 0) {
          v186 = v7;
        } else {
          v186 = v185;
        }
        float v187 = v186 + v184;
        float v188 = v183 * v178;
        float v189 = v5[((v170 * 10) + 1)][((v171 * 2) + 1)];
        float v190;
        if ((v169 * 2) == 0) {
          v190 = v7;
        } else {
          v190 = v189;
        }
        float v191 = v190 + v188;
        float v192 = v2[((v170 * 10) + 2)][(v169 * 2)];
        float v193 = v192 * v173;
        float v194 = v5[((v170 * 10) + 2)][(v171 * 2)];
        float v195;
        if ((v169 * 2) == 0) {
          v195 = v7;
        } else {
          v195 = v194;
        }
        float v196 = v195 + v193;
        float v197 = v192 * v178;
        float v198 = v5[((v170 * 10) + 2)][((v171 * 2) + 1)];
        float v199;
        if ((v169 * 2) == 0) {
          v199 = v7;
        } else {
          v199 = v198;
        }
        float v200 = v199 + v197;
        float v201 = v2[((v170 * 10) + 3)][(v169 * 2)];
        float v202 = v201 * v173;
        float v203 = v5[((v170 * 10) + 3)][(v171 * 2)];
        float v204;
        if ((v169 * 2) == 0) {
          v204 = v7;
        } else {
          v204 = v203;
        }
        float v205 = v204 + v202;
        float v206 = v201 * v178;
        float v207 = v5[((v170 * 10) + 3)][((v171 * 2) + 1)];
        float v208;
        if ((v169 * 2) == 0) {
          v208 = v7;
        } else {
          v208 = v207;
        }
        float v209 = v208 + v206;
        float v210 = v2[((v170 * 10) + 4)][(v169 * 2)];
        float v211 = v210 * v173;
        float v212 = v5[((v170 * 10) + 4)][(v171 * 2)];
        float v213;
        if ((v169 * 2) == 0) {
          v213 = v7;
        } else {
          v213 = v212;
        }
        float v214 = v213 + v211;
        float v215 = v210 * v178;
        float v216 = v5[((v170 * 10) + 4)][((v171 * 2) + 1)];
        float v217;
        if ((v169 * 2) == 0) {
          v217 = v7;
        } else {
          v217 = v216;
        }
        float v218 = v217 + v215;
        float v219 = v2[((v170 * 10) + 5)][(v169 * 2)];
        float v220 = v219 * v173;
        float v221 = v5[((v170 * 10) + 5)][(v171 * 2)];
        float v222;
        if ((v169 * 2) == 0) {
          v222 = v7;
        } else {
          v222 = v221;
        }
        float v223 = v222 + v220;
        float v224 = v219 * v178;
        float v225 = v5[((v170 * 10) + 5)][((v171 * 2) + 1)];
        float v226;
        if ((v169 * 2) == 0) {
          v226 = v7;
        } else {
          v226 = v225;
        }
        float v227 = v226 + v224;
        float v228 = v2[((v170 * 10) + 6)][(v169 * 2)];
        float v229 = v228 * v173;
        float v230 = v5[((v170 * 10) + 6)][(v171 * 2)];
        float v231;
        if ((v169 * 2) == 0) {
          v231 = v7;
        } else {
          v231 = v230;
        }
        float v232 = v231 + v229;
        float v233 = v228 * v178;
        float v234 = v5[((v170 * 10) + 6)][((v171 * 2) + 1)];
        float v235;
        if ((v169 * 2) == 0) {
          v235 = v7;
        } else {
          v235 = v234;
        }
        float v236 = v235 + v233;
        float v237 = v2[((v170 * 10) + 7)][(v169 * 2)];
        float v238 = v237 * v173;
        float v239 = v5[((v170 * 10) + 7)][(v171 * 2)];
        float v240;
        if ((v169 * 2) == 0) {
          v240 = v7;
        } else {
          v240 = v239;
        }
        float v241 = v240 + v238;
        float v242 = v237 * v178;
        float v243 = v5[((v170 * 10) + 7)][((v171 * 2) + 1)];
        float v244;
        if ((v169 * 2) == 0) {
          v244 = v7;
        } else {
          v244 = v243;
        }
        float v245 = v244 + v242;
        float v246 = v2[((v170 * 10) + 8)][(v169 * 2)];
        float v247 = v246 * v173;
        float v248 = v5[((v170 * 10) + 8)][(v171 * 2)];
        float v249;
        if ((v169 * 2) == 0) {
          v249 = v7;
        } else {
          v249 = v248;
        }
        float v250 = v249 + v247;
        float v251 = v246 * v178;
        float v252 = v5[((v170 * 10) + 8)][((v171 * 2) + 1)];
        float v253;
        if ((v169 * 2) == 0) {
          v253 = v7;
        } else {
          v253 = v252;
        }
        float v254 = v253 + v251;
        float v255 = v2[((v170 * 10) + 9)][(v169 * 2)];
        float v256 = v255 * v173;
        float v257 = v5[((v170 * 10) + 9)][(v171 * 2)];
        float v258;
        if ((v169 * 2) == 0) {
          v258 = v7;
        } else {
          v258 = v257;
        }
        float v259 = v258 + v256;
        float v260 = v255 * v178;
        float v261 = v5[((v170 * 10) + 9)][((v171 * 2) + 1)];
        float v262;
        if ((v169 * 2) == 0) {
          v262 = v7;
        } else {
          v262 = v261;
        }
        float v263 = v262 + v260;
        float v264 = v2[(v170 * 10)][((v169 * 2) + 1)];
        float v265 = v3[((v169 * 2) + 1)][(v171 * 2)];
        float v266 = v264 * v265;
        float v267 = v177 + v266;
        v5[(v170 * 10)][(v171 * 2)] = v267;
        float v268 = v3[((v169 * 2) + 1)][((v171 * 2) + 1)];
        float v269 = v264 * v268;
        float v270 = v182 + v269;
        v5[(v170 * 10)][((v171 * 2) + 1)] = v270;
        float v271 = v2[((v170 * 10) + 1)][((v169 * 2) + 1)];
        float v272 = v271 * v265;
        float v273 = v187 + v272;
        v5[((v170 * 10) + 1)][(v171 * 2)] = v273;
        float v274 = v271 * v268;
        float v275 = v191 + v274;
        v5[((v170 * 10) + 1)][((v171 * 2) + 1)] = v275;
        float v276 = v2[((v170 * 10) + 2)][((v169 * 2) + 1)];
        float v277 = v276 * v265;
        float v278 = v196 + v277;
        v5[((v170 * 10) + 2)][(v171 * 2)] = v278;
        float v279 = v276 * v268;
        float v280 = v200 + v279;
        v5[((v170 * 10) + 2)][((v171 * 2) + 1)] = v280;
        float v281 = v2[((v170 * 10) + 3)][((v169 * 2) + 1)];
        float v282 = v281 * v265;
        float v283 = v205 + v282;
        v5[((v170 * 10) + 3)][(v171 * 2)] = v283;
        float v284 = v281 * v268;
        float v285 = v209 + v284;
        v5[((v170 * 10) + 3)][((v171 * 2) + 1)] = v285;
        float v286 = v2[((v170 * 10) + 4)][((v169 * 2) + 1)];
        float v287 = v286 * v265;
        float v288 = v214 + v287;
        v5[((v170 * 10) + 4)][(v171 * 2)] = v288;
        float v289 = v286 * v268;
        float v290 = v218 + v289;
        v5[((v170 * 10) + 4)][((v171 * 2) + 1)] = v290;
        float v291 = v2[((v170 * 10) + 5)][((v169 * 2) + 1)];
        float v292 = v291 * v265;
        float v293 = v223 + v292;
        v5[((v170 * 10) + 5)][(v171 * 2)] = v293;
        float v294 = v291 * v268;
        float v295 = v227 + v294;
        v5[((v170 * 10) + 5)][((v171 * 2) + 1)] = v295;
        float v296 = v2[((v170 * 10) + 6)][((v169 * 2) + 1)];
        float v297 = v296 * v265;
        float v298 = v232 + v297;
        v5[((v170 * 10) + 6)][(v171 * 2)] = v298;
        float v299 = v296 * v268;
        float v300 = v236 + v299;
        v5[((v170 * 10) + 6)][((v171 * 2) + 1)] = v300;
        float v301 = v2[((v170 * 10) + 7)][((v169 * 2) + 1)];
        float v302 = v301 * v265;
        float v303 = v241 + v302;
        v5[((v170 * 10) + 7)][(v171 * 2)] = v303;
        float v304 = v301 * v268;
        float v305 = v245 + v304;
        v5[((v170 * 10) + 7)][((v171 * 2) + 1)] = v305;
        float v306 = v2[((v170 * 10) + 8)][((v169 * 2) + 1)];
        float v307 = v306 * v265;
        float v308 = v250 + v307;
        v5[((v170 * 10) + 8)][(v171 * 2)] = v308;
        float v309 = v306 * v268;
        float v310 = v254 + v309;
        v5[((v170 * 10) + 8)][((v171 * 2) + 1)] = v310;
        float v311 = v2[((v170 * 10) + 9)][((v169 * 2) + 1)];
        float v312 = v311 * v265;
        float v313 = v259 + v312;
        v5[((v170 * 10) + 9)][(v171 * 2)] = v313;
        float v314 = v311 * v268;
        float v315 = v263 + v314;
        v5[((v170 * 10) + 9)][((v171 * 2) + 1)] = v315;
      }
    }
  }
  for (int v316 = 0; v316 < 10; v316 += 1) {
    for (int v317 = 0; v317 < 8; v317 += 1) {
      for (int v318 = 0; v318 < 14; v318 += 1) {
#pragma HLS pipeline II=3
 float v319 = v4[(v317 * 5)][(v316 * 5)];
        float v320 = v5[(v316 * 5)][(v318 * 5)];
        float v321 = v319 * v320;
        float v322 = v6[(v317 * 5)][(v318 * 5)];
        float v323;
        if ((v316 * 5) == 0) {
          v323 = v7;
        } else {
          v323 = v322;
        }
        float v324 = v323 + v321;
        float v325 = v5[(v316 * 5)][((v318 * 5) + 1)];
        float v326 = v319 * v325;
        float v327 = v6[(v317 * 5)][((v318 * 5) + 1)];
        float v328;
        if ((v316 * 5) == 0) {
          v328 = v7;
        } else {
          v328 = v327;
        }
        float v329 = v328 + v326;
        float v330 = v5[(v316 * 5)][((v318 * 5) + 2)];
        float v331 = v319 * v330;
        float v332 = v6[(v317 * 5)][((v318 * 5) + 2)];
        float v333;
        if ((v316 * 5) == 0) {
          v333 = v7;
        } else {
          v333 = v332;
        }
        float v334 = v333 + v331;
        float v335 = v5[(v316 * 5)][((v318 * 5) + 3)];
        float v336 = v319 * v335;
        float v337 = v6[(v317 * 5)][((v318 * 5) + 3)];
        float v338;
        if ((v316 * 5) == 0) {
          v338 = v7;
        } else {
          v338 = v337;
        }
        float v339 = v338 + v336;
        float v340 = v5[(v316 * 5)][((v318 * 5) + 4)];
        float v341 = v319 * v340;
        float v342 = v6[(v317 * 5)][((v318 * 5) + 4)];
        float v343;
        if ((v316 * 5) == 0) {
          v343 = v7;
        } else {
          v343 = v342;
        }
        float v344 = v343 + v341;
        float v345 = v4[((v317 * 5) + 1)][(v316 * 5)];
        float v346 = v345 * v320;
        float v347 = v6[((v317 * 5) + 1)][(v318 * 5)];
        float v348;
        if ((v316 * 5) == 0) {
          v348 = v7;
        } else {
          v348 = v347;
        }
        float v349 = v348 + v346;
        float v350 = v345 * v325;
        float v351 = v6[((v317 * 5) + 1)][((v318 * 5) + 1)];
        float v352;
        if ((v316 * 5) == 0) {
          v352 = v7;
        } else {
          v352 = v351;
        }
        float v353 = v352 + v350;
        float v354 = v345 * v330;
        float v355 = v6[((v317 * 5) + 1)][((v318 * 5) + 2)];
        float v356;
        if ((v316 * 5) == 0) {
          v356 = v7;
        } else {
          v356 = v355;
        }
        float v357 = v356 + v354;
        float v358 = v345 * v335;
        float v359 = v6[((v317 * 5) + 1)][((v318 * 5) + 3)];
        float v360;
        if ((v316 * 5) == 0) {
          v360 = v7;
        } else {
          v360 = v359;
        }
        float v361 = v360 + v358;
        float v362 = v345 * v340;
        float v363 = v6[((v317 * 5) + 1)][((v318 * 5) + 4)];
        float v364;
        if ((v316 * 5) == 0) {
          v364 = v7;
        } else {
          v364 = v363;
        }
        float v365 = v364 + v362;
        float v366 = v4[((v317 * 5) + 2)][(v316 * 5)];
        float v367 = v366 * v320;
        float v368 = v6[((v317 * 5) + 2)][(v318 * 5)];
        float v369;
        if ((v316 * 5) == 0) {
          v369 = v7;
        } else {
          v369 = v368;
        }
        float v370 = v369 + v367;
        float v371 = v366 * v325;
        float v372 = v6[((v317 * 5) + 2)][((v318 * 5) + 1)];
        float v373;
        if ((v316 * 5) == 0) {
          v373 = v7;
        } else {
          v373 = v372;
        }
        float v374 = v373 + v371;
        float v375 = v366 * v330;
        float v376 = v6[((v317 * 5) + 2)][((v318 * 5) + 2)];
        float v377;
        if ((v316 * 5) == 0) {
          v377 = v7;
        } else {
          v377 = v376;
        }
        float v378 = v377 + v375;
        float v379 = v366 * v335;
        float v380 = v6[((v317 * 5) + 2)][((v318 * 5) + 3)];
        float v381;
        if ((v316 * 5) == 0) {
          v381 = v7;
        } else {
          v381 = v380;
        }
        float v382 = v381 + v379;
        float v383 = v366 * v340;
        float v384 = v6[((v317 * 5) + 2)][((v318 * 5) + 4)];
        float v385;
        if ((v316 * 5) == 0) {
          v385 = v7;
        } else {
          v385 = v384;
        }
        float v386 = v385 + v383;
        float v387 = v4[((v317 * 5) + 3)][(v316 * 5)];
        float v388 = v387 * v320;
        float v389 = v6[((v317 * 5) + 3)][(v318 * 5)];
        float v390;
        if ((v316 * 5) == 0) {
          v390 = v7;
        } else {
          v390 = v389;
        }
        float v391 = v390 + v388;
        float v392 = v387 * v325;
        float v393 = v6[((v317 * 5) + 3)][((v318 * 5) + 1)];
        float v394;
        if ((v316 * 5) == 0) {
          v394 = v7;
        } else {
          v394 = v393;
        }
        float v395 = v394 + v392;
        float v396 = v387 * v330;
        float v397 = v6[((v317 * 5) + 3)][((v318 * 5) + 2)];
        float v398;
        if ((v316 * 5) == 0) {
          v398 = v7;
        } else {
          v398 = v397;
        }
        float v399 = v398 + v396;
        float v400 = v387 * v335;
        float v401 = v6[((v317 * 5) + 3)][((v318 * 5) + 3)];
        float v402;
        if ((v316 * 5) == 0) {
          v402 = v7;
        } else {
          v402 = v401;
        }
        float v403 = v402 + v400;
        float v404 = v387 * v340;
        float v405 = v6[((v317 * 5) + 3)][((v318 * 5) + 4)];
        float v406;
        if ((v316 * 5) == 0) {
          v406 = v7;
        } else {
          v406 = v405;
        }
        float v407 = v406 + v404;
        float v408 = v4[((v317 * 5) + 4)][(v316 * 5)];
        float v409 = v408 * v320;
        float v410 = v6[((v317 * 5) + 4)][(v318 * 5)];
        float v411;
        if ((v316 * 5) == 0) {
          v411 = v7;
        } else {
          v411 = v410;
        }
        float v412 = v411 + v409;
        float v413 = v408 * v325;
        float v414 = v6[((v317 * 5) + 4)][((v318 * 5) + 1)];
        float v415;
        if ((v316 * 5) == 0) {
          v415 = v7;
        } else {
          v415 = v414;
        }
        float v416 = v415 + v413;
        float v417 = v408 * v330;
        float v418 = v6[((v317 * 5) + 4)][((v318 * 5) + 2)];
        float v419;
        if ((v316 * 5) == 0) {
          v419 = v7;
        } else {
          v419 = v418;
        }
        float v420 = v419 + v417;
        float v421 = v408 * v335;
        float v422 = v6[((v317 * 5) + 4)][((v318 * 5) + 3)];
        float v423;
        if ((v316 * 5) == 0) {
          v423 = v7;
        } else {
          v423 = v422;
        }
        float v424 = v423 + v421;
        float v425 = v408 * v340;
        float v426 = v6[((v317 * 5) + 4)][((v318 * 5) + 4)];
        float v427;
        if ((v316 * 5) == 0) {
          v427 = v7;
        } else {
          v427 = v426;
        }
        float v428 = v427 + v425;
        float v429 = v4[(v317 * 5)][((v316 * 5) + 1)];
        float v430 = v5[((v316 * 5) + 1)][(v318 * 5)];
        float v431 = v429 * v430;
        float v432 = v324 + v431;
        float v433 = v5[((v316 * 5) + 1)][((v318 * 5) + 1)];
        float v434 = v429 * v433;
        float v435 = v329 + v434;
        float v436 = v5[((v316 * 5) + 1)][((v318 * 5) + 2)];
        float v437 = v429 * v436;
        float v438 = v334 + v437;
        float v439 = v5[((v316 * 5) + 1)][((v318 * 5) + 3)];
        float v440 = v429 * v439;
        float v441 = v339 + v440;
        float v442 = v5[((v316 * 5) + 1)][((v318 * 5) + 4)];
        float v443 = v429 * v442;
        float v444 = v344 + v443;
        float v445 = v4[((v317 * 5) + 1)][((v316 * 5) + 1)];
        float v446 = v445 * v430;
        float v447 = v349 + v446;
        float v448 = v445 * v433;
        float v449 = v353 + v448;
        float v450 = v445 * v436;
        float v451 = v357 + v450;
        float v452 = v445 * v439;
        float v453 = v361 + v452;
        float v454 = v445 * v442;
        float v455 = v365 + v454;
        float v456 = v4[((v317 * 5) + 2)][((v316 * 5) + 1)];
        float v457 = v456 * v430;
        float v458 = v370 + v457;
        float v459 = v456 * v433;
        float v460 = v374 + v459;
        float v461 = v456 * v436;
        float v462 = v378 + v461;
        float v463 = v456 * v439;
        float v464 = v382 + v463;
        float v465 = v456 * v442;
        float v466 = v386 + v465;
        float v467 = v4[((v317 * 5) + 3)][((v316 * 5) + 1)];
        float v468 = v467 * v430;
        float v469 = v391 + v468;
        float v470 = v467 * v433;
        float v471 = v395 + v470;
        float v472 = v467 * v436;
        float v473 = v399 + v472;
        float v474 = v467 * v439;
        float v475 = v403 + v474;
        float v476 = v467 * v442;
        float v477 = v407 + v476;
        float v478 = v4[((v317 * 5) + 4)][((v316 * 5) + 1)];
        float v479 = v478 * v430;
        float v480 = v412 + v479;
        float v481 = v478 * v433;
        float v482 = v416 + v481;
        float v483 = v478 * v436;
        float v484 = v420 + v483;
        float v485 = v478 * v439;
        float v486 = v424 + v485;
        float v487 = v478 * v442;
        float v488 = v428 + v487;
        float v489 = v4[(v317 * 5)][((v316 * 5) + 2)];
        float v490 = v5[((v316 * 5) + 2)][(v318 * 5)];
        float v491 = v489 * v490;
        float v492 = v432 + v491;
        float v493 = v5[((v316 * 5) + 2)][((v318 * 5) + 1)];
        float v494 = v489 * v493;
        float v495 = v435 + v494;
        float v496 = v5[((v316 * 5) + 2)][((v318 * 5) + 2)];
        float v497 = v489 * v496;
        float v498 = v438 + v497;
        float v499 = v5[((v316 * 5) + 2)][((v318 * 5) + 3)];
        float v500 = v489 * v499;
        float v501 = v441 + v500;
        float v502 = v5[((v316 * 5) + 2)][((v318 * 5) + 4)];
        float v503 = v489 * v502;
        float v504 = v444 + v503;
        float v505 = v4[((v317 * 5) + 1)][((v316 * 5) + 2)];
        float v506 = v505 * v490;
        float v507 = v447 + v506;
        float v508 = v505 * v493;
        float v509 = v449 + v508;
        float v510 = v505 * v496;
        float v511 = v451 + v510;
        float v512 = v505 * v499;
        float v513 = v453 + v512;
        float v514 = v505 * v502;
        float v515 = v455 + v514;
        float v516 = v4[((v317 * 5) + 2)][((v316 * 5) + 2)];
        float v517 = v516 * v490;
        float v518 = v458 + v517;
        float v519 = v516 * v493;
        float v520 = v460 + v519;
        float v521 = v516 * v496;
        float v522 = v462 + v521;
        float v523 = v516 * v499;
        float v524 = v464 + v523;
        float v525 = v516 * v502;
        float v526 = v466 + v525;
        float v527 = v4[((v317 * 5) + 3)][((v316 * 5) + 2)];
        float v528 = v527 * v490;
        float v529 = v469 + v528;
        float v530 = v527 * v493;
        float v531 = v471 + v530;
        float v532 = v527 * v496;
        float v533 = v473 + v532;
        float v534 = v527 * v499;
        float v535 = v475 + v534;
        float v536 = v527 * v502;
        float v537 = v477 + v536;
        float v538 = v4[((v317 * 5) + 4)][((v316 * 5) + 2)];
        float v539 = v538 * v490;
        float v540 = v480 + v539;
        float v541 = v538 * v493;
        float v542 = v482 + v541;
        float v543 = v538 * v496;
        float v544 = v484 + v543;
        float v545 = v538 * v499;
        float v546 = v486 + v545;
        float v547 = v538 * v502;
        float v548 = v488 + v547;
        float v549 = v4[(v317 * 5)][((v316 * 5) + 3)];
        float v550 = v5[((v316 * 5) + 3)][(v318 * 5)];
        float v551 = v549 * v550;
        float v552 = v492 + v551;
        float v553 = v5[((v316 * 5) + 3)][((v318 * 5) + 1)];
        float v554 = v549 * v553;
        float v555 = v495 + v554;
        float v556 = v5[((v316 * 5) + 3)][((v318 * 5) + 2)];
        float v557 = v549 * v556;
        float v558 = v498 + v557;
        float v559 = v5[((v316 * 5) + 3)][((v318 * 5) + 3)];
        float v560 = v549 * v559;
        float v561 = v501 + v560;
        float v562 = v5[((v316 * 5) + 3)][((v318 * 5) + 4)];
        float v563 = v549 * v562;
        float v564 = v504 + v563;
        float v565 = v4[((v317 * 5) + 1)][((v316 * 5) + 3)];
        float v566 = v565 * v550;
        float v567 = v507 + v566;
        float v568 = v565 * v553;
        float v569 = v509 + v568;
        float v570 = v565 * v556;
        float v571 = v511 + v570;
        float v572 = v565 * v559;
        float v573 = v513 + v572;
        float v574 = v565 * v562;
        float v575 = v515 + v574;
        float v576 = v4[((v317 * 5) + 2)][((v316 * 5) + 3)];
        float v577 = v576 * v550;
        float v578 = v518 + v577;
        float v579 = v576 * v553;
        float v580 = v520 + v579;
        float v581 = v576 * v556;
        float v582 = v522 + v581;
        float v583 = v576 * v559;
        float v584 = v524 + v583;
        float v585 = v576 * v562;
        float v586 = v526 + v585;
        float v587 = v4[((v317 * 5) + 3)][((v316 * 5) + 3)];
        float v588 = v587 * v550;
        float v589 = v529 + v588;
        float v590 = v587 * v553;
        float v591 = v531 + v590;
        float v592 = v587 * v556;
        float v593 = v533 + v592;
        float v594 = v587 * v559;
        float v595 = v535 + v594;
        float v596 = v587 * v562;
        float v597 = v537 + v596;
        float v598 = v4[((v317 * 5) + 4)][((v316 * 5) + 3)];
        float v599 = v598 * v550;
        float v600 = v540 + v599;
        float v601 = v598 * v553;
        float v602 = v542 + v601;
        float v603 = v598 * v556;
        float v604 = v544 + v603;
        float v605 = v598 * v559;
        float v606 = v546 + v605;
        float v607 = v598 * v562;
        float v608 = v548 + v607;
        float v609 = v4[(v317 * 5)][((v316 * 5) + 4)];
        float v610 = v5[((v316 * 5) + 4)][(v318 * 5)];
        float v611 = v609 * v610;
        float v612 = v552 + v611;
        v6[(v317 * 5)][(v318 * 5)] = v612;
        float v613 = v5[((v316 * 5) + 4)][((v318 * 5) + 1)];
        float v614 = v609 * v613;
        float v615 = v555 + v614;
        v6[(v317 * 5)][((v318 * 5) + 1)] = v615;
        float v616 = v5[((v316 * 5) + 4)][((v318 * 5) + 2)];
        float v617 = v609 * v616;
        float v618 = v558 + v617;
        v6[(v317 * 5)][((v318 * 5) + 2)] = v618;
        float v619 = v5[((v316 * 5) + 4)][((v318 * 5) + 3)];
        float v620 = v609 * v619;
        float v621 = v561 + v620;
        v6[(v317 * 5)][((v318 * 5) + 3)] = v621;
        float v622 = v5[((v316 * 5) + 4)][((v318 * 5) + 4)];
        float v623 = v609 * v622;
        float v624 = v564 + v623;
        v6[(v317 * 5)][((v318 * 5) + 4)] = v624;
        float v625 = v4[((v317 * 5) + 1)][((v316 * 5) + 4)];
        float v626 = v625 * v610;
        float v627 = v567 + v626;
        v6[((v317 * 5) + 1)][(v318 * 5)] = v627;
        float v628 = v625 * v613;
        float v629 = v569 + v628;
        v6[((v317 * 5) + 1)][((v318 * 5) + 1)] = v629;
        float v630 = v625 * v616;
        float v631 = v571 + v630;
        v6[((v317 * 5) + 1)][((v318 * 5) + 2)] = v631;
        float v632 = v625 * v619;
        float v633 = v573 + v632;
        v6[((v317 * 5) + 1)][((v318 * 5) + 3)] = v633;
        float v634 = v625 * v622;
        float v635 = v575 + v634;
        v6[((v317 * 5) + 1)][((v318 * 5) + 4)] = v635;
        float v636 = v4[((v317 * 5) + 2)][((v316 * 5) + 4)];
        float v637 = v636 * v610;
        float v638 = v578 + v637;
        v6[((v317 * 5) + 2)][(v318 * 5)] = v638;
        float v639 = v636 * v613;
        float v640 = v580 + v639;
        v6[((v317 * 5) + 2)][((v318 * 5) + 1)] = v640;
        float v641 = v636 * v616;
        float v642 = v582 + v641;
        v6[((v317 * 5) + 2)][((v318 * 5) + 2)] = v642;
        float v643 = v636 * v619;
        float v644 = v584 + v643;
        v6[((v317 * 5) + 2)][((v318 * 5) + 3)] = v644;
        float v645 = v636 * v622;
        float v646 = v586 + v645;
        v6[((v317 * 5) + 2)][((v318 * 5) + 4)] = v646;
        float v647 = v4[((v317 * 5) + 3)][((v316 * 5) + 4)];
        float v648 = v647 * v610;
        float v649 = v589 + v648;
        v6[((v317 * 5) + 3)][(v318 * 5)] = v649;
        float v650 = v647 * v613;
        float v651 = v591 + v650;
        v6[((v317 * 5) + 3)][((v318 * 5) + 1)] = v651;
        float v652 = v647 * v616;
        float v653 = v593 + v652;
        v6[((v317 * 5) + 3)][((v318 * 5) + 2)] = v653;
        float v654 = v647 * v619;
        float v655 = v595 + v654;
        v6[((v317 * 5) + 3)][((v318 * 5) + 3)] = v655;
        float v656 = v647 * v622;
        float v657 = v597 + v656;
        v6[((v317 * 5) + 3)][((v318 * 5) + 4)] = v657;
        float v658 = v4[((v317 * 5) + 4)][((v316 * 5) + 4)];
        float v659 = v658 * v610;
        float v660 = v600 + v659;
        v6[((v317 * 5) + 4)][(v318 * 5)] = v660;
        float v661 = v658 * v613;
        float v662 = v602 + v661;
        v6[((v317 * 5) + 4)][((v318 * 5) + 1)] = v662;
        float v663 = v658 * v616;
        float v664 = v604 + v663;
        v6[((v317 * 5) + 4)][((v318 * 5) + 2)] = v664;
        float v665 = v658 * v619;
        float v666 = v606 + v665;
        v6[((v317 * 5) + 4)][((v318 * 5) + 3)] = v666;
        float v667 = v658 * v622;
        float v668 = v608 + v667;
        v6[((v317 * 5) + 4)][((v318 * 5) + 4)] = v668;
      }
    }
  }
}

#include "kernel_3mm_nonP.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_3mm_nonP::thread_v333_1_fu_7700_p3() {
    v333_1_fu_7700_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_0_2_Dout_A.read());
}

void kernel_3mm_nonP::thread_v335_fu_7569_p3() {
    v335_fu_7569_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_0_3_load_reg_9501.read(): v5_5_3_load_reg_9506.read());
}

void kernel_3mm_nonP::thread_v338_1_fu_7707_p3() {
    v338_1_fu_7707_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_0_3_Dout_A.read());
}

void kernel_3mm_nonP::thread_v340_fu_7575_p3() {
    v340_fu_7575_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_0_4_load_reg_9511.read(): v5_5_4_load_reg_9516.read());
}

void kernel_3mm_nonP::thread_v343_1_fu_7714_p3() {
    v343_1_fu_7714_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_0_4_Dout_A.read());
}

void kernel_3mm_nonP::thread_v348_1_fu_7721_p3() {
    v348_1_fu_7721_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_1_0_Dout_A.read());
}

void kernel_3mm_nonP::thread_v352_1_fu_7728_p3() {
    v352_1_fu_7728_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_1_1_Dout_A.read());
}

void kernel_3mm_nonP::thread_v356_1_fu_7735_p3() {
    v356_1_fu_7735_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_1_2_Dout_A.read());
}

void kernel_3mm_nonP::thread_v360_1_fu_7742_p3() {
    v360_1_fu_7742_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_1_3_Dout_A.read());
}

void kernel_3mm_nonP::thread_v364_1_fu_7749_p3() {
    v364_1_fu_7749_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_1_4_Dout_A.read());
}

void kernel_3mm_nonP::thread_v369_1_fu_7756_p3() {
    v369_1_fu_7756_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_2_0_Dout_A.read());
}

void kernel_3mm_nonP::thread_v373_1_fu_7763_p3() {
    v373_1_fu_7763_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_2_1_Dout_A.read());
}

void kernel_3mm_nonP::thread_v377_1_fu_7770_p3() {
    v377_1_fu_7770_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_2_2_Dout_A.read());
}

void kernel_3mm_nonP::thread_v381_1_fu_7777_p3() {
    v381_1_fu_7777_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_2_3_Dout_A.read());
}

void kernel_3mm_nonP::thread_v385_1_fu_7784_p3() {
    v385_1_fu_7784_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_2_4_Dout_A.read());
}

void kernel_3mm_nonP::thread_v390_1_fu_7791_p3() {
    v390_1_fu_7791_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_3_0_Dout_A.read());
}

void kernel_3mm_nonP::thread_v394_1_fu_7798_p3() {
    v394_1_fu_7798_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_3_1_Dout_A.read());
}

void kernel_3mm_nonP::thread_v398_1_fu_7805_p3() {
    v398_1_fu_7805_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_3_2_Dout_A.read());
}

void kernel_3mm_nonP::thread_v3_0_0_Addr_A() {
    v3_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v3_0_0_Addr_A_orig() {
    v3_0_0_Addr_A_orig =  (sc_lv<32>) (sext_ln325_fu_6602_p1.read());
}

void kernel_3mm_nonP::thread_v3_0_0_Clk_A() {
    v3_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v3_0_0_Din_A() {
    v3_0_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v3_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v3_0_0_EN_A = ap_const_logic_1;
    } else {
        v3_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v3_0_0_Rst_A() {
    v3_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v3_0_0_WEN_A() {
    v3_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v3_0_1_Addr_A() {
    v3_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v3_0_1_Addr_A_orig() {
    v3_0_1_Addr_A_orig =  (sc_lv<32>) (sext_ln325_fu_6602_p1.read());
}

void kernel_3mm_nonP::thread_v3_0_1_Clk_A() {
    v3_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v3_0_1_Din_A() {
    v3_0_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v3_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v3_0_1_EN_A = ap_const_logic_1;
    } else {
        v3_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v3_0_1_Rst_A() {
    v3_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v3_0_1_WEN_A() {
    v3_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v3_1_0_Addr_A() {
    v3_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v3_1_0_Addr_A_orig() {
    v3_1_0_Addr_A_orig =  (sc_lv<32>) (sext_ln325_fu_6602_p1.read());
}

void kernel_3mm_nonP::thread_v3_1_0_Clk_A() {
    v3_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v3_1_0_Din_A() {
    v3_1_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v3_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v3_1_0_EN_A = ap_const_logic_1;
    } else {
        v3_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v3_1_0_Rst_A() {
    v3_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v3_1_0_WEN_A() {
    v3_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v3_1_1_Addr_A() {
    v3_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v3_1_1_Addr_A_orig() {
    v3_1_1_Addr_A_orig =  (sc_lv<32>) (sext_ln325_fu_6602_p1.read());
}

void kernel_3mm_nonP::thread_v3_1_1_Clk_A() {
    v3_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v3_1_1_Din_A() {
    v3_1_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v3_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v3_1_1_EN_A = ap_const_logic_1;
    } else {
        v3_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v3_1_1_Rst_A() {
    v3_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v3_1_1_WEN_A() {
    v3_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v402_1_fu_7812_p3() {
    v402_1_fu_7812_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_3_3_Dout_A.read());
}

void kernel_3mm_nonP::thread_v406_1_fu_7819_p3() {
    v406_1_fu_7819_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_3_4_Dout_A.read());
}

void kernel_3mm_nonP::thread_v411_1_fu_7826_p3() {
    v411_1_fu_7826_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_4_0_Dout_A.read());
}

void kernel_3mm_nonP::thread_v415_1_fu_7833_p3() {
    v415_1_fu_7833_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_4_1_Dout_A.read());
}

void kernel_3mm_nonP::thread_v419_1_fu_7840_p3() {
    v419_1_fu_7840_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_4_2_Dout_A.read());
}

void kernel_3mm_nonP::thread_v423_1_fu_7847_p3() {
    v423_1_fu_7847_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_4_3_Dout_A.read());
}

void kernel_3mm_nonP::thread_v427_1_fu_7854_p3() {
    v427_1_fu_7854_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_4_4_Dout_A.read());
}

void kernel_3mm_nonP::thread_v430_fu_7581_p3() {
    v430_fu_7581_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_1_0_load_reg_9569.read(): v5_6_0_load_reg_9574.read());
}

void kernel_3mm_nonP::thread_v433_fu_7587_p3() {
    v433_fu_7587_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_1_1_load_reg_9579.read(): v5_6_1_load_reg_9584.read());
}

void kernel_3mm_nonP::thread_v436_fu_7593_p3() {
    v436_fu_7593_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_1_2_load_reg_9589.read(): v5_6_2_load_reg_9594.read());
}

void kernel_3mm_nonP::thread_v439_fu_7599_p3() {
    v439_fu_7599_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_1_3_load_reg_9599.read(): v5_6_3_load_reg_9604.read());
}

void kernel_3mm_nonP::thread_v442_fu_7605_p3() {
    v442_fu_7605_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_1_4_load_reg_9609.read(): v5_6_4_load_reg_9614.read());
}

void kernel_3mm_nonP::thread_v490_fu_7611_p3() {
    v490_fu_7611_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_2_0_load_reg_9655.read(): v5_7_0_load_reg_9660.read());
}

void kernel_3mm_nonP::thread_v493_fu_7617_p3() {
    v493_fu_7617_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_2_1_load_reg_9665.read(): v5_7_1_load_reg_9670.read());
}

void kernel_3mm_nonP::thread_v496_fu_7993_p3() {
    v496_fu_7993_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_2_2_Dout_A.read(): v5_7_2_Dout_A.read());
}

void kernel_3mm_nonP::thread_v499_fu_8000_p3() {
    v499_fu_8000_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_2_3_Dout_A.read(): v5_7_3_Dout_A.read());
}

void kernel_3mm_nonP::thread_v4_0_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_0_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_0_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_0_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_0_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_0_0_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_0_Addr_B() {
    v4_0_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_0_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_0_0_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_0_0_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_0_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_0_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_0_Clk_A() {
    v4_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_0_Clk_B() {
    v4_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_0_Din_A() {
    v4_0_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_0_0_Din_B() {
    v4_0_0_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v4_0_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_0_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_0_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_0_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_0_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_0_0_EN_B = ap_const_logic_1;
    } else {
        v4_0_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_0_Rst_A() {
    v4_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_0_Rst_B() {
    v4_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_0_WEN_A() {
    v4_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_0_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_0_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_0_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_0_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_0_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_0_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_0_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_0_1_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_1_Addr_B() {
    v4_0_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_0_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_0_1_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_0_1_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_0_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_0_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_1_Clk_A() {
    v4_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_1_Clk_B() {
    v4_0_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_1_Din_A() {
    v4_0_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_0_1_Din_B() {
    v4_0_1_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v4_0_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_0_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_0_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_0_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_0_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_0_1_EN_B = ap_const_logic_1;
    } else {
        v4_0_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_1_Rst_A() {
    v4_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_1_Rst_B() {
    v4_0_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_1_WEN_A() {
    v4_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_0_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)))) {
        v4_0_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_0_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_0_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_0_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_0_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_0_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Addr_A.read();
    } else {
        v4_0_2_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_2_Addr_B() {
    v4_0_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_0_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_0_2_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_0_2_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_0_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_0_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_2_Clk_A() {
    v4_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_2_Clk_B() {
    v4_0_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_2_Din_A() {
    v4_0_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_0_2_Din_B() {
    v4_0_2_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v4_0_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_0_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_0_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_0_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_0_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_EN_A.read();
    } else {
        v4_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_0_2_EN_B = ap_const_logic_1;
    } else {
        v4_0_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_2_Rst_A() {
    v4_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_2_Rst_B() {
    v4_0_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_2_WEN_A() {
    v4_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_0_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)))) {
        v4_0_2_WEN_B = ap_const_lv4_F;
    } else {
        v4_0_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_0_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_0_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_0_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_0_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_0_3_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_3_Addr_B() {
    v4_0_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_0_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_0_3_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_0_3_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_0_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_0_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_3_Clk_A() {
    v4_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_3_Clk_B() {
    v4_0_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_3_Din_A() {
    v4_0_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_0_3_Din_B() {
    v4_0_3_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v4_0_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_0_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_0_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_0_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_0_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_0_3_EN_B = ap_const_logic_1;
    } else {
        v4_0_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_3_Rst_A() {
    v4_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_3_Rst_B() {
    v4_0_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_3_WEN_A() {
    v4_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_0_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)))) {
        v4_0_3_WEN_B = ap_const_lv4_F;
    } else {
        v4_0_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_0_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_0_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_0_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_0_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_0_4_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_4_Addr_B() {
    v4_0_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_0_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_0_4_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_0_4_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_0_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_0_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_0_4_Clk_A() {
    v4_0_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_4_Clk_B() {
    v4_0_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_0_4_Din_A() {
    v4_0_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_0_4_Din_B() {
    v4_0_4_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v4_0_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_0_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_0_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_0_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_0_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_0_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_0_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_0_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_0_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_0_4_EN_B = ap_const_logic_1;
    } else {
        v4_0_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_0_4_Rst_A() {
    v4_0_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_4_Rst_B() {
    v4_0_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_0_4_WEN_A() {
    v4_0_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_0_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_0_4_WEN_B = ap_const_lv4_F;
    } else {
        v4_0_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_1_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_1_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_1_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_1_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_1_0_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_0_Addr_B() {
    v4_1_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_1_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_0_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_0_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_1_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_0_Clk_A() {
    v4_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_0_Clk_B() {
    v4_1_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_0_Din_A() {
    v4_1_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_1_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_0_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_0_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_1_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_1_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_1_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_1_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_1_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_1_0_EN_B = ap_const_logic_1;
    } else {
        v4_1_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_0_Rst_A() {
    v4_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_0_Rst_B() {
    v4_1_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_0_WEN_A() {
    v4_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_1_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_1_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_1_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_1_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_1_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_1_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_1_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_1_1_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_1_Addr_B() {
    v4_1_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_1_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_1_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_1_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_1_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_1_Clk_A() {
    v4_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_1_Clk_B() {
    v4_1_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_1_Din_A() {
    v4_1_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_1_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_1_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_1_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_1_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_1_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_1_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_1_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_1_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_1_1_EN_B = ap_const_logic_1;
    } else {
        v4_1_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_1_Rst_A() {
    v4_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_1_Rst_B() {
    v4_1_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_1_WEN_A() {
    v4_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_1_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)))) {
        v4_1_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_1_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_1_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_1_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_1_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_1_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Addr_A.read();
    } else {
        v4_1_2_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_2_Addr_B() {
    v4_1_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_1_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_2_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_2_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_1_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_2_Clk_A() {
    v4_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_2_Clk_B() {
    v4_1_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_2_Din_A() {
    v4_1_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_1_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_2_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_2_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_1_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_1_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_1_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_1_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_1_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_EN_A.read();
    } else {
        v4_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_1_2_EN_B = ap_const_logic_1;
    } else {
        v4_1_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_2_Rst_A() {
    v4_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_2_Rst_B() {
    v4_1_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_2_WEN_A() {
    v4_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_1_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)))) {
        v4_1_2_WEN_B = ap_const_lv4_F;
    } else {
        v4_1_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_1_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_1_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_1_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_1_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_1_3_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_3_Addr_B() {
    v4_1_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_1_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_3_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_3_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_1_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_3_Clk_A() {
    v4_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_3_Clk_B() {
    v4_1_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_3_Din_A() {
    v4_1_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_1_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_3_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_3_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_1_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_1_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_1_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_1_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_1_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_1_3_EN_B = ap_const_logic_1;
    } else {
        v4_1_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_3_Rst_A() {
    v4_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_3_Rst_B() {
    v4_1_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_3_WEN_A() {
    v4_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_1_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)))) {
        v4_1_3_WEN_B = ap_const_lv4_F;
    } else {
        v4_1_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_1_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_1_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_1_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_1_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_1_4_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_4_Addr_B() {
    v4_1_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_1_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_4_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_4_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_fu_6366_p1.read());
        } else {
            v4_1_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_4_Clk_A() {
    v4_1_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_4_Clk_B() {
    v4_1_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_1_4_Din_A() {
    v4_1_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_1_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_1_4_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            v4_1_4_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_1_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_1_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_1_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_1_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_1_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_1_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_1_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_1_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_1_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_1_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_1_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_1_4_EN_B = ap_const_logic_1;
    } else {
        v4_1_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_1_4_Rst_A() {
    v4_1_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_4_Rst_B() {
    v4_1_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_1_4_WEN_A() {
    v4_1_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_1_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_1_4_WEN_B = ap_const_lv4_F;
    } else {
        v4_1_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_2_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_2_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_2_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_2_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_2_0_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_0_Addr_B() {
    v4_2_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_2_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_0_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_0_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_2_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_0_Clk_A() {
    v4_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_0_Clk_B() {
    v4_2_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_0_Din_A() {
    v4_2_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_2_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_0_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_0_Din_B = grp_fu_5006_p2.read();
        } else {
            v4_2_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_2_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_2_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_2_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_2_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_2_0_EN_B = ap_const_logic_1;
    } else {
        v4_2_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_0_Rst_A() {
    v4_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_0_Rst_B() {
    v4_2_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_0_WEN_A() {
    v4_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_2_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)))) {
        v4_2_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_2_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_2_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_2_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_2_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_2_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_2_1_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_1_Addr_B() {
    v4_2_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_2_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_1_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_1_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_2_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_1_Clk_A() {
    v4_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_1_Clk_B() {
    v4_2_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_1_Din_A() {
    v4_2_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_2_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_1_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_1_Din_B = grp_fu_5006_p2.read();
        } else {
            v4_2_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_2_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_2_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_2_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_2_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_2_1_EN_B = ap_const_logic_1;
    } else {
        v4_2_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_1_Rst_A() {
    v4_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_1_Rst_B() {
    v4_2_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_1_WEN_A() {
    v4_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_2_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)))) {
        v4_2_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_2_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_2_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_2_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_2_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_2_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Addr_A.read();
    } else {
        v4_2_2_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_2_Addr_B() {
    v4_2_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_2_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_2_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_2_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_2_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_2_Clk_A() {
    v4_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_2_Clk_B() {
    v4_2_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_2_Din_A() {
    v4_2_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_2_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_2_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_2_Din_B = grp_fu_5006_p2.read();
        } else {
            v4_2_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_2_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_2_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_2_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_2_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_EN_A.read();
    } else {
        v4_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_2_2_EN_B = ap_const_logic_1;
    } else {
        v4_2_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_2_Rst_A() {
    v4_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_2_Rst_B() {
    v4_2_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_2_WEN_A() {
    v4_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_2_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)))) {
        v4_2_2_WEN_B = ap_const_lv4_F;
    } else {
        v4_2_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_2_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_2_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_2_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_2_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_2_3_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_3_Addr_B() {
    v4_2_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_2_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_3_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_3_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_2_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_3_Clk_A() {
    v4_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_3_Clk_B() {
    v4_2_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_3_Din_A() {
    v4_2_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_2_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_3_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_3_Din_B = grp_fu_5006_p2.read();
        } else {
            v4_2_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_2_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_2_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_2_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_2_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_2_3_EN_B = ap_const_logic_1;
    } else {
        v4_2_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_3_Rst_A() {
    v4_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_3_Rst_B() {
    v4_2_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_3_WEN_A() {
    v4_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_2_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_2_3_WEN_B = ap_const_lv4_F;
    } else {
        v4_2_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_2_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_2_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_2_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_2_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_2_4_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_4_Addr_B() {
    v4_2_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_2_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_2_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_4_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_4_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_2_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_4_Clk_A() {
    v4_2_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_4_Clk_B() {
    v4_2_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_2_4_Din_A() {
    v4_2_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_2_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_2_4_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_2_4_Din_B = grp_fu_5006_p2.read();
        } else {
            v4_2_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_2_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_2_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_2_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_2_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_2_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_2_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_2_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_2_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_2_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_2_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_2_4_EN_B = ap_const_logic_1;
    } else {
        v4_2_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_2_4_Rst_A() {
    v4_2_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_4_Rst_B() {
    v4_2_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_2_4_WEN_A() {
    v4_2_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_2_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_2_4_WEN_B = ap_const_lv4_F;
    } else {
        v4_2_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_3_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_3_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_3_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_3_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_3_0_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_0_Addr_B() {
    v4_3_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_3_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_0_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_0_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_3_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_0_Clk_A() {
    v4_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_0_Clk_B() {
    v4_3_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_0_Din_A() {
    v4_3_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_3_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_0_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_0_Din_B = grp_fu_5010_p2.read();
        } else {
            v4_3_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_3_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_3_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_3_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_3_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_3_0_EN_B = ap_const_logic_1;
    } else {
        v4_3_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_0_Rst_A() {
    v4_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_0_Rst_B() {
    v4_3_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_0_WEN_A() {
    v4_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_3_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)))) {
        v4_3_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_3_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_3_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_3_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_3_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_3_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_3_1_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_1_Addr_B() {
    v4_3_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_3_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_1_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_1_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_3_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_1_Clk_A() {
    v4_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_1_Clk_B() {
    v4_3_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_1_Din_A() {
    v4_3_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_3_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_1_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_1_Din_B = grp_fu_5010_p2.read();
        } else {
            v4_3_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_3_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_3_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_3_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_3_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_3_1_EN_B = ap_const_logic_1;
    } else {
        v4_3_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_1_Rst_A() {
    v4_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_1_Rst_B() {
    v4_3_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_1_WEN_A() {
    v4_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_3_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)))) {
        v4_3_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_3_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_3_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_3_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_3_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_3_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Addr_A.read();
    } else {
        v4_3_2_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_2_Addr_B() {
    v4_3_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_3_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_2_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_2_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_3_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_2_Clk_A() {
    v4_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_2_Clk_B() {
    v4_3_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_2_Din_A() {
    v4_3_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_3_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_2_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_2_Din_B = grp_fu_5010_p2.read();
        } else {
            v4_3_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_3_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_3_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_3_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_3_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_EN_A.read();
    } else {
        v4_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_3_2_EN_B = ap_const_logic_1;
    } else {
        v4_3_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_2_Rst_A() {
    v4_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_2_Rst_B() {
    v4_3_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_2_WEN_A() {
    v4_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_3_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)))) {
        v4_3_2_WEN_B = ap_const_lv4_F;
    } else {
        v4_3_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_3_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_3_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_3_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_3_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_3_3_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_3_Addr_B() {
    v4_3_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_3_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_3_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_3_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_3_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_3_Clk_A() {
    v4_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_3_Clk_B() {
    v4_3_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_3_Din_A() {
    v4_3_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_3_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_3_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_3_Din_B = grp_fu_5010_p2.read();
        } else {
            v4_3_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_3_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_3_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_3_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_3_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_3_3_EN_B = ap_const_logic_1;
    } else {
        v4_3_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_3_Rst_A() {
    v4_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_3_Rst_B() {
    v4_3_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_3_WEN_A() {
    v4_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_3_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_3_3_WEN_B = ap_const_lv4_F;
    } else {
        v4_3_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_3_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_3_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_3_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_3_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_3_4_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_4_Addr_B() {
    v4_3_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_3_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_3_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_4_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_fu_6393_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_4_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_3_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_4_Clk_A() {
    v4_3_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_4_Clk_B() {
    v4_3_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_3_4_Din_A() {
    v4_3_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_3_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_3_4_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_3_4_Din_B = grp_fu_5010_p2.read();
        } else {
            v4_3_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_3_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_3_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        v4_3_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_3_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_3_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_3_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_3_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_3_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_3_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_3_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_3_4_EN_B = ap_const_logic_1;
    } else {
        v4_3_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_3_4_Rst_A() {
    v4_3_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_4_Rst_B() {
    v4_3_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_3_4_WEN_A() {
    v4_3_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_3_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_3_4_WEN_B = ap_const_lv4_F;
    } else {
        v4_3_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_0_Addr_A() {
    if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_4_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_4_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_4_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_4_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_4_0_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_0_Addr_B() {
    v4_4_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_4_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_0_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_0_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_4_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_0_Clk_A() {
    v4_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_0_Clk_B() {
    v4_4_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_0_Din_A() {
    v4_4_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_4_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_0_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_0_Din_B = grp_fu_5014_p2.read();
        } else {
            v4_4_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_0_EN_A() {
    if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_4_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_4_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_4_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_4_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_4_0_EN_B = ap_const_logic_1;
    } else {
        v4_4_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_0_Rst_A() {
    v4_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_0_Rst_B() {
    v4_4_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_0_WEN_A() {
    v4_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_4_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_4_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_4_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_4_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_4_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_4_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_4_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_4_1_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_1_Addr_B() {
    v4_4_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_4_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_1_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_1_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_4_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_1_Clk_A() {
    v4_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_1_Clk_B() {
    v4_4_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_1_Din_A() {
    v4_4_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_4_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_1_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_1_Din_B = grp_fu_5014_p2.read();
        } else {
            v4_4_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_4_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_4_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_4_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_4_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_4_1_EN_B = ap_const_logic_1;
    } else {
        v4_4_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_1_Rst_A() {
    v4_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_1_Rst_B() {
    v4_4_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_1_WEN_A() {
    v4_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_4_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)))) {
        v4_4_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_4_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_4_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_4_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_4_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Addr_A.read();
    } else {
        v4_4_2_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_2_Addr_B() {
    v4_4_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_4_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_2_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_2_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_4_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_2_Clk_A() {
    v4_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_2_Clk_B() {
    v4_4_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_2_Din_A() {
    v4_4_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_4_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_2_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_2_Din_B = grp_fu_5014_p2.read();
        } else {
            v4_4_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_4_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_4_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_4_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_4_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_EN_A.read();
    } else {
        v4_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_4_2_EN_B = ap_const_logic_1;
    } else {
        v4_4_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_2_Rst_A() {
    v4_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_2_Rst_B() {
    v4_4_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_2_WEN_A() {
    v4_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_4_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)))) {
        v4_4_2_WEN_B = ap_const_lv4_F;
    } else {
        v4_4_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_4_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_4_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_4_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_4_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Addr_A.read();
    } else {
        v4_4_3_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_3_Addr_B() {
    v4_4_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_4_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_3_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_3_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_4_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_3_Clk_A() {
    v4_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_3_Clk_B() {
    v4_4_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_3_Din_A() {
    v4_4_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_4_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_3_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_3_Din_B = grp_fu_5014_p2.read();
        } else {
            v4_4_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_4_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_4_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_4_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_4_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_EN_A.read();
    } else {
        v4_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_4_3_EN_B = ap_const_logic_1;
    } else {
        v4_4_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_3_Rst_A() {
    v4_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_3_Rst_B() {
    v4_4_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_3_WEN_A() {
    v4_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_4_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)))) {
        v4_4_3_WEN_B = ap_const_lv4_F;
    } else {
        v4_4_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_4_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_4_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_4_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_4_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Addr_A.read();
    } else {
        v4_4_4_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_4_Addr_B() {
    v4_4_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_4_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_4_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_4_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_4_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_4_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_4_Clk_A() {
    v4_4_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_4_Clk_B() {
    v4_4_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_4_4_Din_A() {
    v4_4_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_4_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_4_4_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_4_4_Din_B = grp_fu_5014_p2.read();
        } else {
            v4_4_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_4_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_4_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_4_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_4_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_4_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_4_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_4_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_4_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_4_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_EN_A.read();
    } else {
        v4_4_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_4_4_EN_B = ap_const_logic_1;
    } else {
        v4_4_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_4_4_Rst_A() {
    v4_4_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_4_Rst_B() {
    v4_4_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_4_4_WEN_A() {
    v4_4_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_4_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_4_4_WEN_B = ap_const_lv4_F;
    } else {
        v4_4_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_0_Addr_A() {
    if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_5_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_5_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_5_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_5_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else {
        v4_5_0_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_0_Addr_B() {
    v4_5_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_5_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_0_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_0_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_5_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_0_Clk_A() {
    v4_5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_0_Clk_B() {
    v4_5_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_0_Din_A() {
    v4_5_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_5_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_0_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_0_Din_B = grp_fu_5018_p2.read();
        } else {
            v4_5_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_0_EN_A() {
    if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_5_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_5_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_5_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_5_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else {
        v4_5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_5_0_EN_B = ap_const_logic_1;
    } else {
        v4_5_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_0_Rst_A() {
    v4_5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_0_Rst_B() {
    v4_5_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_0_WEN_A() {
    v4_5_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_5_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_5_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_5_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_5_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_5_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_5_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_5_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else {
        v4_5_1_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_1_Addr_B() {
    v4_5_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_5_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_1_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_1_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_5_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_1_Clk_A() {
    v4_5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_1_Clk_B() {
    v4_5_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_1_Din_A() {
    v4_5_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_5_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_1_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_1_Din_B = grp_fu_5018_p2.read();
        } else {
            v4_5_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_5_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_5_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_5_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_5_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else {
        v4_5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_5_1_EN_B = ap_const_logic_1;
    } else {
        v4_5_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_1_Rst_A() {
    v4_5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_1_Rst_B() {
    v4_5_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_1_WEN_A() {
    v4_5_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_5_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)))) {
        v4_5_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_5_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_5_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_5_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_5_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_5_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Addr_A.read();
    } else {
        v4_5_2_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_2_Addr_B() {
    v4_5_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_5_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_2_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_2_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_5_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_2_Clk_A() {
    v4_5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_2_Clk_B() {
    v4_5_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_2_Din_A() {
    v4_5_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_5_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_2_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_2_Din_B = grp_fu_5018_p2.read();
        } else {
            v4_5_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_5_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_5_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_5_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_5_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_EN_A.read();
    } else {
        v4_5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_5_2_EN_B = ap_const_logic_1;
    } else {
        v4_5_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_2_Rst_A() {
    v4_5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_2_Rst_B() {
    v4_5_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_2_WEN_A() {
    v4_5_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_5_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)))) {
        v4_5_2_WEN_B = ap_const_lv4_F;
    } else {
        v4_5_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_5_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_5_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_5_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_5_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Addr_A.read();
    } else {
        v4_5_3_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_3_Addr_B() {
    v4_5_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_5_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_3_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_3_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_5_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_3_Clk_A() {
    v4_5_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_3_Clk_B() {
    v4_5_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_3_Din_A() {
    v4_5_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_5_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_3_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_3_Din_B = grp_fu_5018_p2.read();
        } else {
            v4_5_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_5_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_5_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_5_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_5_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_EN_A.read();
    } else {
        v4_5_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_5_3_EN_B = ap_const_logic_1;
    } else {
        v4_5_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_3_Rst_A() {
    v4_5_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_3_Rst_B() {
    v4_5_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_3_WEN_A() {
    v4_5_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_5_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)))) {
        v4_5_3_WEN_B = ap_const_lv4_F;
    } else {
        v4_5_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_5_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_5_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_5_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_5_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Addr_A.read();
    } else {
        v4_5_4_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_4_Addr_B() {
    v4_5_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_5_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_5_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_4_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_4_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_5_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_4_Clk_A() {
    v4_5_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_4_Clk_B() {
    v4_5_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_5_4_Din_A() {
    v4_5_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_5_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_5_4_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_5_4_Din_B = grp_fu_5018_p2.read();
        } else {
            v4_5_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_5_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_5_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_5_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_5_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_5_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_5_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_5_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_5_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_5_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_EN_A.read();
    } else {
        v4_5_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_5_4_EN_B = ap_const_logic_1;
    } else {
        v4_5_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_5_4_Rst_A() {
    v4_5_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_4_Rst_B() {
    v4_5_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_5_4_WEN_A() {
    v4_5_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_5_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_5_4_WEN_B = ap_const_lv4_F;
    } else {
        v4_5_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_0_Addr_A() {
    if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_6_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_6_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_6_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_6_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else {
        v4_6_0_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_0_Addr_B() {
    v4_6_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_6_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_0_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_0_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_6_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_0_Clk_A() {
    v4_6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_0_Clk_B() {
    v4_6_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_0_Din_A() {
    v4_6_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_6_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_0_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_0_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_6_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_0_EN_A() {
    if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_6_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_6_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_6_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_6_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else {
        v4_6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_6_0_EN_B = ap_const_logic_1;
    } else {
        v4_6_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_0_Rst_A() {
    v4_6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_0_Rst_B() {
    v4_6_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_0_WEN_A() {
    v4_6_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_6_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_6_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_6_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_6_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_6_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_6_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_6_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else {
        v4_6_1_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_1_Addr_B() {
    v4_6_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_6_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_1_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_1_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_6_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_1_Clk_A() {
    v4_6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_1_Clk_B() {
    v4_6_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_1_Din_A() {
    v4_6_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_6_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_1_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_1_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_6_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_6_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_6_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_6_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_6_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else {
        v4_6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_6_1_EN_B = ap_const_logic_1;
    } else {
        v4_6_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_1_Rst_A() {
    v4_6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_1_Rst_B() {
    v4_6_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_1_WEN_A() {
    v4_6_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_6_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)))) {
        v4_6_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_6_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_6_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_6_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_6_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_6_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Addr_A.read();
    } else {
        v4_6_2_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_2_Addr_B() {
    v4_6_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_6_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_2_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_2_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_6_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_2_Clk_A() {
    v4_6_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_2_Clk_B() {
    v4_6_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_2_Din_A() {
    v4_6_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_6_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_2_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_2_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_6_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_6_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_6_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_6_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_6_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_EN_A.read();
    } else {
        v4_6_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_6_2_EN_B = ap_const_logic_1;
    } else {
        v4_6_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_2_Rst_A() {
    v4_6_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_2_Rst_B() {
    v4_6_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_2_WEN_A() {
    v4_6_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_6_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)))) {
        v4_6_2_WEN_B = ap_const_lv4_F;
    } else {
        v4_6_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_6_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_6_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_6_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_6_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Addr_A.read();
    } else {
        v4_6_3_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_3_Addr_B() {
    v4_6_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_6_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_3_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_3_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_6_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_3_Clk_A() {
    v4_6_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_3_Clk_B() {
    v4_6_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_3_Din_A() {
    v4_6_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_6_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_3_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_3_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_6_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_6_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_6_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_6_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_6_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_EN_A.read();
    } else {
        v4_6_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_6_3_EN_B = ap_const_logic_1;
    } else {
        v4_6_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_3_Rst_A() {
    v4_6_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_3_Rst_B() {
    v4_6_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_3_WEN_A() {
    v4_6_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_6_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)))) {
        v4_6_3_WEN_B = ap_const_lv4_F;
    } else {
        v4_6_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_6_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_6_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_6_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_6_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Addr_A.read();
    } else {
        v4_6_4_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_4_Addr_B() {
    v4_6_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_6_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_6_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_4_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_4_Addr_B_orig =  (sc_lv<32>) (zext_ln66_4_reg_8612.read());
        } else {
            v4_6_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_4_Clk_A() {
    v4_6_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_4_Clk_B() {
    v4_6_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_6_4_Din_A() {
    v4_6_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_6_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_6_4_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            v4_6_4_Din_B = grp_fu_5023_p2.read();
        } else {
            v4_6_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_6_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_6_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_6_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_6_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_6_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_6_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_6_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_6_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_6_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_EN_A.read();
    } else {
        v4_6_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_6_4_EN_B = ap_const_logic_1;
    } else {
        v4_6_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_6_4_Rst_A() {
    v4_6_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_4_Rst_B() {
    v4_6_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_6_4_WEN_A() {
    v4_6_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_6_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_6_4_WEN_B = ap_const_lv4_F;
    } else {
        v4_6_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_0_Addr_A() {
    if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_0_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_7_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_7_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_7_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_7_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_0_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else {
        v4_7_0_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_0_Addr_B() {
    v4_7_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_7_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_7_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_7_0_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_7_0_Addr_B_orig =  (sc_lv<32>) (v4_7_0_addr_reg_8651.read());
        } else {
            v4_7_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_7_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_0_Clk_A() {
    v4_7_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_0_Clk_B() {
    v4_7_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_0_Din_A() {
    v4_7_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_7_0_Din_B() {
    v4_7_0_Din_B = grp_fu_5018_p2.read();
}

void kernel_3mm_nonP::thread_v4_7_0_EN_A() {
    if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_0_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_7_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_7_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_7_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_7_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_0_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else {
        v4_7_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_7_0_EN_B = ap_const_logic_1;
    } else {
        v4_7_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_0_Rst_A() {
    v4_7_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_0_Rst_B() {
    v4_7_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_0_WEN_A() {
    v4_7_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_7_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_7_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_7_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_1_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_7_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_7_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_7_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_7_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_1_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else {
        v4_7_1_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_1_Addr_B() {
    v4_7_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_7_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_7_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_7_1_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_7_1_Addr_B_orig =  (sc_lv<32>) (v4_7_1_addr_reg_8656.read());
        } else {
            v4_7_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_7_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_1_Clk_A() {
    v4_7_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_1_Clk_B() {
    v4_7_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_1_Din_A() {
    v4_7_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_7_1_Din_B() {
    v4_7_1_Din_B = grp_fu_5018_p2.read();
}

void kernel_3mm_nonP::thread_v4_7_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_1_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_7_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_7_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_7_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_7_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_1_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else {
        v4_7_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_7_1_EN_B = ap_const_logic_1;
    } else {
        v4_7_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_1_Rst_A() {
    v4_7_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_1_Rst_B() {
    v4_7_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_1_WEN_A() {
    v4_7_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_7_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0)))) {
        v4_7_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_7_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_2_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_7_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_7_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_7_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_7_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_2_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Addr_A.read();
    } else {
        v4_7_2_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_2_Addr_B() {
    v4_7_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_7_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_7_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_7_2_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_7_2_Addr_B_orig =  (sc_lv<32>) (v4_7_2_addr_reg_8661.read());
        } else {
            v4_7_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_7_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_2_Clk_A() {
    v4_7_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_2_Clk_B() {
    v4_7_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_2_Din_A() {
    v4_7_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_7_2_Din_B() {
    v4_7_2_Din_B = grp_fu_5018_p2.read();
}

void kernel_3mm_nonP::thread_v4_7_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_2_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        v4_7_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        v4_7_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v4_7_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        v4_7_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_2_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_EN_A.read();
    } else {
        v4_7_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_7_2_EN_B = ap_const_logic_1;
    } else {
        v4_7_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_2_Rst_A() {
    v4_7_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_2_Rst_B() {
    v4_7_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_2_WEN_A() {
    v4_7_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_7_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1)))) {
        v4_7_2_WEN_B = ap_const_lv4_F;
    } else {
        v4_7_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_3_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_7_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_7_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_7_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_7_3_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Addr_A.read();
    } else {
        v4_7_3_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_3_Addr_B() {
    v4_7_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_7_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_7_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_7_3_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_7_3_Addr_B_orig =  (sc_lv<32>) (v4_7_3_addr_reg_8666.read());
        } else {
            v4_7_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_7_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_3_Clk_A() {
    v4_7_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_3_Clk_B() {
    v4_7_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_3_Din_A() {
    v4_7_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_7_3_Din_B() {
    v4_7_3_Din_B = grp_fu_5018_p2.read();
}

void kernel_3mm_nonP::thread_v4_7_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_3_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_7_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_7_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_7_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_7_3_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_EN_A.read();
    } else {
        v4_7_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_7_3_EN_B = ap_const_logic_1;
    } else {
        v4_7_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_3_Rst_A() {
    v4_7_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_3_Rst_B() {
    v4_7_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_3_WEN_A() {
    v4_7_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_7_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2)))) {
        v4_7_3_WEN_B = ap_const_lv4_F;
    } else {
        v4_7_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_4_Addr_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_7_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_7_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_7_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_7_4_Addr_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Addr_A.read();
    } else {
        v4_7_4_Addr_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_4_Addr_B() {
    v4_7_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_7_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v4_7_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
            v4_7_4_Addr_B_orig =  (sc_lv<32>) (zext_ln76_2_reg_8676.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            v4_7_4_Addr_B_orig =  (sc_lv<32>) (v4_7_4_addr_reg_8671.read());
        } else {
            v4_7_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v4_7_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v4_7_4_Clk_A() {
    v4_7_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_4_Clk_B() {
    v4_7_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v4_7_4_Din_A() {
    v4_7_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v4_7_4_Din_B() {
    v4_7_4_Din_B = grp_fu_5018_p2.read();
}

void kernel_3mm_nonP::thread_v4_7_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        v4_7_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_EN_A.read();
    } else if (((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        v4_7_4_EN_A = grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        v4_7_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        v4_7_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v4_7_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        v4_7_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        v4_7_4_EN_A = grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_EN_A.read();
    } else {
        v4_7_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        v4_7_4_EN_B = ap_const_logic_1;
    } else {
        v4_7_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v4_7_4_Rst_A() {
    v4_7_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_4_Rst_B() {
    v4_7_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v4_7_4_WEN_A() {
    v4_7_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v4_7_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln66_reg_8520.read(), ap_const_lv4_3)))) {
        v4_7_4_WEN_B = ap_const_lv4_F;
    } else {
        v4_7_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v502_fu_8007_p3() {
    v502_fu_8007_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_2_4_Dout_A.read(): v5_7_4_Dout_A.read());
}

void kernel_3mm_nonP::thread_v550_fu_8027_p3() {
    v550_fu_8027_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_3_0_Dout_A.read(): v5_8_0_Dout_A.read());
}

void kernel_3mm_nonP::thread_v553_fu_8034_p3() {
    v553_fu_8034_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_3_1_Dout_A.read(): v5_8_1_Dout_A.read());
}

void kernel_3mm_nonP::thread_v556_fu_8041_p3() {
    v556_fu_8041_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_3_2_Dout_A.read(): v5_8_2_Dout_A.read());
}

void kernel_3mm_nonP::thread_v559_fu_8048_p3() {
    v559_fu_8048_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_3_3_Dout_A.read(): v5_8_3_Dout_A.read());
}

void kernel_3mm_nonP::thread_v562_fu_8055_p3() {
    v562_fu_8055_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_3_4_Dout_A.read(): v5_8_4_Dout_A.read());
}

void kernel_3mm_nonP::thread_v5_0_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Addr_A.read();
    } else {
        v5_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_0_0_Addr_A_orig() {
    v5_0_0_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_0_0_Addr_B() {
    v5_0_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_0_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_0_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_0_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_0_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_0_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_0_0_Clk_A() {
    v5_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_0_Clk_B() {
    v5_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_0_Din_A() {
    v5_0_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_0_0_Din_B() {
    v5_0_0_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v5_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_0_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_EN_A.read();
    } else {
        v5_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_0_0_EN_B = ap_const_logic_1;
    } else {
        v5_0_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_0_Rst_A() {
    v5_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_0_Rst_B() {
    v5_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_0_WEN_A() {
    v5_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_0_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_0_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_0_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Addr_A.read();
    } else {
        v5_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_0_1_Addr_A_orig() {
    v5_0_1_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_0_1_Addr_B() {
    v5_0_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_0_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_0_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_0_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_0_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_0_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_0_1_Clk_A() {
    v5_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_1_Clk_B() {
    v5_0_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_1_Din_A() {
    v5_0_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_0_1_Din_B() {
    v5_0_1_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v5_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_0_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_EN_A.read();
    } else {
        v5_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_0_1_EN_B = ap_const_logic_1;
    } else {
        v5_0_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_1_Rst_A() {
    v5_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_1_Rst_B() {
    v5_0_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_1_WEN_A() {
    v5_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_0_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_0_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_0_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Addr_A.read();
    } else {
        v5_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_0_2_Addr_A_orig() {
    v5_0_2_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_0_2_Addr_B() {
    v5_0_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_0_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_0_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_0_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_0_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_0_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_0_2_Clk_A() {
    v5_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_2_Clk_B() {
    v5_0_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_2_Din_A() {
    v5_0_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_0_2_Din_B() {
    v5_0_2_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v5_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_0_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_EN_A.read();
    } else {
        v5_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_0_2_EN_B = ap_const_logic_1;
    } else {
        v5_0_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_2_Rst_A() {
    v5_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_2_Rst_B() {
    v5_0_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_2_WEN_A() {
    v5_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_0_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_0_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_0_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Addr_A.read();
    } else {
        v5_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_0_3_Addr_A_orig() {
    v5_0_3_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_0_3_Addr_B() {
    v5_0_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_0_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_0_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_0_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_0_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_0_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_0_3_Clk_A() {
    v5_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_3_Clk_B() {
    v5_0_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_3_Din_A() {
    v5_0_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_0_3_Din_B() {
    v5_0_3_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v5_0_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_0_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_EN_A.read();
    } else {
        v5_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_0_3_EN_B = ap_const_logic_1;
    } else {
        v5_0_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_3_Rst_A() {
    v5_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_3_Rst_B() {
    v5_0_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_3_WEN_A() {
    v5_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_0_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_0_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_0_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Addr_A.read();
    } else {
        v5_0_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_0_4_Addr_A_orig() {
    v5_0_4_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_0_4_Addr_B() {
    v5_0_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_0_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_0_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_0_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_0_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_0_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_0_4_Clk_A() {
    v5_0_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_4_Clk_B() {
    v5_0_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_0_4_Din_A() {
    v5_0_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_0_4_Din_B() {
    v5_0_4_Din_B = grp_fu_5002_p2.read();
}

void kernel_3mm_nonP::thread_v5_0_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_0_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_0_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_0_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_EN_A.read();
    } else {
        v5_0_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_0_4_EN_B = ap_const_logic_1;
    } else {
        v5_0_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_0_4_Rst_A() {
    v5_0_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_4_Rst_B() {
    v5_0_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_0_4_WEN_A() {
    v5_0_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_0_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_0_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_0_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Addr_A.read();
    } else {
        v5_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_1_0_Addr_A_orig() {
    v5_1_0_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_1_0_Addr_B() {
    v5_1_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_1_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_1_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_0_Clk_A() {
    v5_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_0_Clk_B() {
    v5_1_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_0_Din_A() {
    v5_1_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_1_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_0_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_0_Din_B = grp_fu_5111_p2.read();
        } else {
            v5_1_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_1_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_EN_A.read();
    } else {
        v5_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_1_0_EN_B = ap_const_logic_1;
    } else {
        v5_1_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_0_Rst_A() {
    v5_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_0_Rst_B() {
    v5_1_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_0_WEN_A() {
    v5_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_1_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_1_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_1_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Addr_A.read();
    } else {
        v5_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_1_1_Addr_A_orig() {
    v5_1_1_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_1_1_Addr_B() {
    v5_1_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_1_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_1_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_1_Clk_A() {
    v5_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_1_Clk_B() {
    v5_1_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_1_Din_A() {
    v5_1_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_1_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_1_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_1_Din_B = grp_fu_5111_p2.read();
        } else {
            v5_1_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_1_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_EN_A.read();
    } else {
        v5_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_1_1_EN_B = ap_const_logic_1;
    } else {
        v5_1_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_1_Rst_A() {
    v5_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_1_Rst_B() {
    v5_1_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_1_WEN_A() {
    v5_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_1_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_1_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_1_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Addr_A.read();
    } else {
        v5_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_1_2_Addr_A_orig() {
    v5_1_2_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_1_2_Addr_B() {
    v5_1_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_1_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_1_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_2_Clk_A() {
    v5_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_2_Clk_B() {
    v5_1_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_2_Din_A() {
    v5_1_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_1_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_2_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_2_Din_B = grp_fu_5111_p2.read();
        } else {
            v5_1_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_1_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_EN_A.read();
    } else {
        v5_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_1_2_EN_B = ap_const_logic_1;
    } else {
        v5_1_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_2_Rst_A() {
    v5_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_2_Rst_B() {
    v5_1_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_2_WEN_A() {
    v5_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_1_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_1_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_1_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Addr_A.read();
    } else {
        v5_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_1_3_Addr_A_orig() {
    v5_1_3_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_1_3_Addr_B() {
    v5_1_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_1_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_1_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_3_Clk_A() {
    v5_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_3_Clk_B() {
    v5_1_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_3_Din_A() {
    v5_1_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_1_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_3_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_3_Din_B = grp_fu_5111_p2.read();
        } else {
            v5_1_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_1_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_EN_A.read();
    } else {
        v5_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_1_3_EN_B = ap_const_logic_1;
    } else {
        v5_1_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_3_Rst_A() {
    v5_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_3_Rst_B() {
    v5_1_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_3_WEN_A() {
    v5_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_1_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_1_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_1_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Addr_A.read();
    } else {
        v5_1_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_1_4_Addr_A_orig() {
    v5_1_4_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_1_4_Addr_B() {
    v5_1_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_1_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_1_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_4_Clk_A() {
    v5_1_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_4_Clk_B() {
    v5_1_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_1_4_Din_A() {
    v5_1_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_1_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_1_4_Din_B = grp_fu_5006_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_1_4_Din_B = grp_fu_5111_p2.read();
        } else {
            v5_1_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_1_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_1_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_1_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_1_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_1_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_EN_A.read();
    } else {
        v5_1_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_1_4_EN_B = ap_const_logic_1;
    } else {
        v5_1_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_1_4_Rst_A() {
    v5_1_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_4_Rst_B() {
    v5_1_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_1_4_WEN_A() {
    v5_1_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_1_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_1_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_1_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Addr_A.read();
    } else {
        v5_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_2_0_Addr_A_orig() {
    v5_2_0_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_fu_7511_p1.read());
}

void kernel_3mm_nonP::thread_v5_2_0_Addr_B() {
    v5_2_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_2_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_2_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_0_Clk_A() {
    v5_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_0_Clk_B() {
    v5_2_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_0_Din_A() {
    v5_2_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_2_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_0_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_0_Din_B = grp_fu_5121_p2.read();
        } else {
            v5_2_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_2_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_EN_A.read();
    } else {
        v5_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_2_0_EN_B = ap_const_logic_1;
    } else {
        v5_2_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_0_Rst_A() {
    v5_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_0_Rst_B() {
    v5_2_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_0_WEN_A() {
    v5_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_2_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_2_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_2_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Addr_A.read();
    } else {
        v5_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_2_1_Addr_A_orig() {
    v5_2_1_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_fu_7511_p1.read());
}

void kernel_3mm_nonP::thread_v5_2_1_Addr_B() {
    v5_2_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_2_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_2_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_1_Clk_A() {
    v5_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_1_Clk_B() {
    v5_2_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_1_Din_A() {
    v5_2_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_2_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_1_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_1_Din_B = grp_fu_5121_p2.read();
        } else {
            v5_2_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_2_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_EN_A.read();
    } else {
        v5_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_2_1_EN_B = ap_const_logic_1;
    } else {
        v5_2_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_1_Rst_A() {
    v5_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_1_Rst_B() {
    v5_2_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_1_WEN_A() {
    v5_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_2_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_2_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_2_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Addr_A.read();
    } else {
        v5_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_2_2_Addr_A_orig() {
    v5_2_2_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_reg_9539.read());
}

void kernel_3mm_nonP::thread_v5_2_2_Addr_B() {
    v5_2_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_2_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_2_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_2_Clk_A() {
    v5_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_2_Clk_B() {
    v5_2_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_2_Din_A() {
    v5_2_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_2_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_2_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_2_Din_B = grp_fu_5121_p2.read();
        } else {
            v5_2_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0))) {
        v5_2_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_EN_A.read();
    } else {
        v5_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_2_2_EN_B = ap_const_logic_1;
    } else {
        v5_2_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_2_Rst_A() {
    v5_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_2_Rst_B() {
    v5_2_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_2_WEN_A() {
    v5_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_2_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_2_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_2_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Addr_A.read();
    } else {
        v5_2_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_2_3_Addr_A_orig() {
    v5_2_3_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_reg_9539.read());
}

void kernel_3mm_nonP::thread_v5_2_3_Addr_B() {
    v5_2_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_2_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_2_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_3_Clk_A() {
    v5_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_3_Clk_B() {
    v5_2_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_3_Din_A() {
    v5_2_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_2_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_3_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_3_Din_B = grp_fu_5121_p2.read();
        } else {
            v5_2_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0))) {
        v5_2_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_EN_A.read();
    } else {
        v5_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_2_3_EN_B = ap_const_logic_1;
    } else {
        v5_2_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_3_Rst_A() {
    v5_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_3_Rst_B() {
    v5_2_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_3_WEN_A() {
    v5_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_2_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_2_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_2_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Addr_A.read();
    } else {
        v5_2_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_2_4_Addr_A_orig() {
    v5_2_4_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_reg_9539.read());
}

void kernel_3mm_nonP::thread_v5_2_4_Addr_B() {
    v5_2_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_2_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_fu_6758_p1.read());
        } else {
            v5_2_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_4_Clk_A() {
    v5_2_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_4_Clk_B() {
    v5_2_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_2_4_Din_A() {
    v5_2_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_2_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_2_4_Din_B = grp_fu_5010_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
            v5_2_4_Din_B = grp_fu_5121_p2.read();
        } else {
            v5_2_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_2_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_2_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0))) {
        v5_2_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_2_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_2_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_EN_A.read();
    } else {
        v5_2_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_2_4_EN_B = ap_const_logic_1;
    } else {
        v5_2_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_2_4_Rst_A() {
    v5_2_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_4_Rst_B() {
    v5_2_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_2_4_WEN_A() {
    v5_2_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_2_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_2_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_2_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Addr_A.read();
    } else {
        v5_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_3_0_Addr_A_orig() {
    v5_3_0_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_3_0_Addr_B() {
    v5_3_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_3_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_3_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_0_Clk_A() {
    v5_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_0_Clk_B() {
    v5_3_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_0_Din_A() {
    v5_3_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_3_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_0_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_0_Din_B = grp_fu_5006_p2.read();
        } else {
            v5_3_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_3_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_EN_A.read();
    } else {
        v5_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_3_0_EN_B = ap_const_logic_1;
    } else {
        v5_3_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_0_Rst_A() {
    v5_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_0_Rst_B() {
    v5_3_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_0_WEN_A() {
    v5_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_3_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_3_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_3_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Addr_A.read();
    } else {
        v5_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_3_1_Addr_A_orig() {
    v5_3_1_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_3_1_Addr_B() {
    v5_3_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_3_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_3_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_1_Clk_A() {
    v5_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_1_Clk_B() {
    v5_3_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_1_Din_A() {
    v5_3_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_3_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_1_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_1_Din_B = grp_fu_5006_p2.read();
        } else {
            v5_3_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_3_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_EN_A.read();
    } else {
        v5_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_3_1_EN_B = ap_const_logic_1;
    } else {
        v5_3_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_1_Rst_A() {
    v5_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_1_Rst_B() {
    v5_3_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_1_WEN_A() {
    v5_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_3_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_3_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_3_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Addr_A.read();
    } else {
        v5_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_3_2_Addr_A_orig() {
    v5_3_2_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_3_2_Addr_B() {
    v5_3_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_3_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_3_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_2_Clk_A() {
    v5_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_2_Clk_B() {
    v5_3_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_2_Din_A() {
    v5_3_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_3_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_2_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_2_Din_B = grp_fu_5006_p2.read();
        } else {
            v5_3_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_3_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_EN_A.read();
    } else {
        v5_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_3_2_EN_B = ap_const_logic_1;
    } else {
        v5_3_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_2_Rst_A() {
    v5_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_2_Rst_B() {
    v5_3_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_2_WEN_A() {
    v5_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_3_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_3_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_3_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Addr_A.read();
    } else {
        v5_3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_3_3_Addr_A_orig() {
    v5_3_3_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_3_3_Addr_B() {
    v5_3_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_3_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_3_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_3_Clk_A() {
    v5_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_3_Clk_B() {
    v5_3_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_3_Din_A() {
    v5_3_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_3_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_3_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_3_Din_B = grp_fu_5006_p2.read();
        } else {
            v5_3_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_3_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_EN_A.read();
    } else {
        v5_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_3_3_EN_B = ap_const_logic_1;
    } else {
        v5_3_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_3_Rst_A() {
    v5_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_3_Rst_B() {
    v5_3_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_3_WEN_A() {
    v5_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_3_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_3_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_3_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Addr_A.read();
    } else {
        v5_3_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_3_4_Addr_A_orig() {
    v5_3_4_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_3_4_Addr_B() {
    v5_3_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_3_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_3_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_4_Clk_A() {
    v5_3_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_4_Clk_B() {
    v5_3_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_3_4_Din_A() {
    v5_3_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_3_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_3_4_Din_B = grp_fu_5014_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_3_4_Din_B = grp_fu_5006_p2.read();
        } else {
            v5_3_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_3_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_3_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_3_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_3_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_3_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_EN_A.read();
    } else {
        v5_3_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_3_4_EN_B = ap_const_logic_1;
    } else {
        v5_3_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_3_4_Rst_A() {
    v5_3_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_4_Rst_B() {
    v5_3_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_3_4_WEN_A() {
    v5_3_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_3_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_3_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_3_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Addr_A.read();
    } else {
        v5_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_4_0_Addr_A_orig() {
    v5_4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_4_0_Addr_B() {
    v5_4_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_4_0_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_4_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_0_Clk_A() {
    v5_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_0_Clk_B() {
    v5_4_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_0_Din_A() {
    v5_4_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_4_0_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_0_Din_B = grp_fu_5018_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_0_Din_B = grp_fu_5010_p2.read();
        } else {
            v5_4_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_4_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_EN_A.read();
    } else {
        v5_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_4_0_EN_B = ap_const_logic_1;
    } else {
        v5_4_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_0_Rst_A() {
    v5_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_0_Rst_B() {
    v5_4_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_0_WEN_A() {
    v5_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_4_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_4_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_4_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Addr_A.read();
    } else {
        v5_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_4_1_Addr_A_orig() {
    v5_4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_4_1_Addr_B() {
    v5_4_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_4_1_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_4_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_1_Clk_A() {
    v5_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_1_Clk_B() {
    v5_4_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_1_Din_A() {
    v5_4_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_4_1_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_1_Din_B = grp_fu_5018_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_1_Din_B = grp_fu_5010_p2.read();
        } else {
            v5_4_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_4_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_EN_A.read();
    } else {
        v5_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_4_1_EN_B = ap_const_logic_1;
    } else {
        v5_4_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_1_Rst_A() {
    v5_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_1_Rst_B() {
    v5_4_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_1_WEN_A() {
    v5_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_4_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_4_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Addr_A.read();
    } else {
        v5_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_4_2_Addr_A_orig() {
    v5_4_2_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_4_2_Addr_B() {
    v5_4_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_4_2_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_4_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_2_Clk_A() {
    v5_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_2_Clk_B() {
    v5_4_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_2_Din_A() {
    v5_4_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_4_2_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_2_Din_B = grp_fu_5018_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_2_Din_B = grp_fu_5010_p2.read();
        } else {
            v5_4_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_4_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_EN_A.read();
    } else {
        v5_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_4_2_EN_B = ap_const_logic_1;
    } else {
        v5_4_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_2_Rst_A() {
    v5_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_2_Rst_B() {
    v5_4_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_2_WEN_A() {
    v5_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_4_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_4_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_4_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Addr_A.read();
    } else {
        v5_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_4_3_Addr_A_orig() {
    v5_4_3_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_4_3_Addr_B() {
    v5_4_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_4_3_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_4_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_3_Clk_A() {
    v5_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_3_Clk_B() {
    v5_4_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_3_Din_A() {
    v5_4_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_4_3_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_3_Din_B = grp_fu_5018_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_3_Din_B = grp_fu_5010_p2.read();
        } else {
            v5_4_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_4_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_EN_A.read();
    } else {
        v5_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_4_3_EN_B = ap_const_logic_1;
    } else {
        v5_4_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_3_Rst_A() {
    v5_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_3_Rst_B() {
    v5_4_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_3_WEN_A() {
    v5_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_4_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_4_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_4_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Addr_A.read();
    } else {
        v5_4_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_4_4_Addr_A_orig() {
    v5_4_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_4_4_Addr_B() {
    v5_4_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_4_4_Addr_B_orig() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_fu_6790_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
        } else {
            v5_4_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_4_Clk_A() {
    v5_4_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_4_Clk_B() {
    v5_4_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_4_4_Din_A() {
    v5_4_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_4_4_Din_B() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
            v5_4_4_Din_B = grp_fu_5018_p2.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
            v5_4_4_Din_B = grp_fu_5010_p2.read();
        } else {
            v5_4_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        v5_4_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_4_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_4_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)))) {
        v5_4_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        v5_4_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_EN_A.read();
    } else {
        v5_4_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_4_4_EN_B = ap_const_logic_1;
    } else {
        v5_4_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_4_4_Rst_A() {
    v5_4_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_4_Rst_B() {
    v5_4_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_4_4_WEN_A() {
    v5_4_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_4_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_4_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_4_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Addr_A.read();
    } else {
        v5_5_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_5_0_Addr_A_orig() {
    v5_5_0_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_5_0_Addr_B() {
    v5_5_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_5_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_5_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_0_Clk_A() {
    v5_5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_5_0_Clk_B() {
    v5_5_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_5_0_Din_A() {
    v5_5_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_5_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_0_Din_B = grp_fu_5006_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_0_Din_B = grp_fu_5014_p2.read();
    } else {
        v5_5_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_5_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_EN_A.read();
    } else {
        v5_5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_5_0_EN_B = ap_const_logic_1;
    } else {
        v5_5_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_0_Rst_A() {
    v5_5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_0_Rst_B() {
    v5_5_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_0_WEN_A() {
    v5_5_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_5_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_5_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_5_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Addr_A.read();
    } else {
        v5_5_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_5_1_Addr_A_orig() {
    v5_5_1_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_5_1_Addr_B() {
    v5_5_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_5_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_5_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_1_Clk_A() {
    v5_5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_5_1_Clk_B() {
    v5_5_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_5_1_Din_A() {
    v5_5_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_5_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_1_Din_B = grp_fu_5006_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_1_Din_B = grp_fu_5014_p2.read();
    } else {
        v5_5_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_5_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_EN_A.read();
    } else {
        v5_5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_5_1_EN_B = ap_const_logic_1;
    } else {
        v5_5_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_1_Rst_A() {
    v5_5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_1_Rst_B() {
    v5_5_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_1_WEN_A() {
    v5_5_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_5_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_5_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_5_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Addr_A.read();
    } else {
        v5_5_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_5_2_Addr_A_orig() {
    v5_5_2_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_5_2_Addr_B() {
    v5_5_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_5_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_5_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_2_Clk_A() {
    v5_5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_5_2_Clk_B() {
    v5_5_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_5_2_Din_A() {
    v5_5_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_5_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_2_Din_B = grp_fu_5006_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_2_Din_B = grp_fu_5014_p2.read();
    } else {
        v5_5_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_5_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_EN_A.read();
    } else {
        v5_5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_5_2_EN_B = ap_const_logic_1;
    } else {
        v5_5_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_2_Rst_A() {
    v5_5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_2_Rst_B() {
    v5_5_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_2_WEN_A() {
    v5_5_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_5_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_5_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_5_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Addr_A.read();
    } else {
        v5_5_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_5_3_Addr_A_orig() {
    v5_5_3_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_5_3_Addr_B() {
    v5_5_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_5_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_5_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_3_Clk_A() {
    v5_5_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_5_3_Clk_B() {
    v5_5_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_5_3_Din_A() {
    v5_5_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_5_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_3_Din_B = grp_fu_5006_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_3_Din_B = grp_fu_5014_p2.read();
    } else {
        v5_5_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_5_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_EN_A.read();
    } else {
        v5_5_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_5_3_EN_B = ap_const_logic_1;
    } else {
        v5_5_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_3_Rst_A() {
    v5_5_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_3_Rst_B() {
    v5_5_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_3_WEN_A() {
    v5_5_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_5_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_5_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_5_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Addr_A.read();
    } else {
        v5_5_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_5_4_Addr_A_orig() {
    v5_5_4_Addr_A_orig =  (sc_lv<32>) (sext_ln596_1_fu_7392_p1.read());
}

void kernel_3mm_nonP::thread_v5_5_4_Addr_B() {
    v5_5_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_5_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_5_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_4_Clk_A() {
    v5_5_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_5_4_Clk_B() {
    v5_5_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

}


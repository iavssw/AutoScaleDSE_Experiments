#include "kernel_3mm_nonP.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_3mm_nonP::thread_v5_5_4_Din_A() {
    v5_5_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_5_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_5_4_Din_B = grp_fu_5006_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_5_4_Din_B = grp_fu_5014_p2.read();
    } else {
        v5_5_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_5_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_5_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_5_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_5_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_EN_A.read();
    } else {
        v5_5_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_5_4_EN_B = ap_const_logic_1;
    } else {
        v5_5_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_5_4_Rst_A() {
    v5_5_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_4_Rst_B() {
    v5_5_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_5_4_WEN_A() {
    v5_5_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_5_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_5_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_5_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Addr_A.read();
    } else {
        v5_6_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_6_0_Addr_A_orig() {
    v5_6_0_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_6_0_Addr_B() {
    v5_6_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_6_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_6_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_0_Clk_A() {
    v5_6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_0_Clk_B() {
    v5_6_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_0_Din_A() {
    v5_6_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_6_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_0_Din_B = grp_fu_5010_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_0_Din_B = grp_fu_5018_p2.read();
    } else {
        v5_6_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_6_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_EN_A.read();
    } else {
        v5_6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_6_0_EN_B = ap_const_logic_1;
    } else {
        v5_6_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_0_Rst_A() {
    v5_6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_0_Rst_B() {
    v5_6_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_0_WEN_A() {
    v5_6_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_6_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_6_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_6_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Addr_A.read();
    } else {
        v5_6_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_6_1_Addr_A_orig() {
    v5_6_1_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_6_1_Addr_B() {
    v5_6_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_6_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_6_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_1_Clk_A() {
    v5_6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_1_Clk_B() {
    v5_6_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_1_Din_A() {
    v5_6_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_6_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_1_Din_B = grp_fu_5010_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_1_Din_B = grp_fu_5018_p2.read();
    } else {
        v5_6_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_6_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_EN_A.read();
    } else {
        v5_6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_6_1_EN_B = ap_const_logic_1;
    } else {
        v5_6_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_1_Rst_A() {
    v5_6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_1_Rst_B() {
    v5_6_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_1_WEN_A() {
    v5_6_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_6_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_6_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_6_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Addr_A.read();
    } else {
        v5_6_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_6_2_Addr_A_orig() {
    v5_6_2_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_6_2_Addr_B() {
    v5_6_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_6_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_6_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_2_Clk_A() {
    v5_6_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_2_Clk_B() {
    v5_6_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_2_Din_A() {
    v5_6_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_6_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_2_Din_B = grp_fu_5010_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_2_Din_B = grp_fu_5018_p2.read();
    } else {
        v5_6_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_6_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_EN_A.read();
    } else {
        v5_6_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_6_2_EN_B = ap_const_logic_1;
    } else {
        v5_6_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_2_Rst_A() {
    v5_6_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_2_Rst_B() {
    v5_6_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_2_WEN_A() {
    v5_6_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_6_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_6_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_6_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Addr_A.read();
    } else {
        v5_6_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_6_3_Addr_A_orig() {
    v5_6_3_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_6_3_Addr_B() {
    v5_6_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_6_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_6_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_3_Clk_A() {
    v5_6_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_3_Clk_B() {
    v5_6_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_3_Din_A() {
    v5_6_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_6_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_3_Din_B = grp_fu_5010_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_3_Din_B = grp_fu_5018_p2.read();
    } else {
        v5_6_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_6_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_EN_A.read();
    } else {
        v5_6_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_6_3_EN_B = ap_const_logic_1;
    } else {
        v5_6_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_3_Rst_A() {
    v5_6_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_3_Rst_B() {
    v5_6_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_3_WEN_A() {
    v5_6_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_6_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_6_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_6_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Addr_A.read();
    } else {
        v5_6_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_6_4_Addr_A_orig() {
    v5_6_4_Addr_A_orig =  (sc_lv<32>) (sext_ln831_1_fu_7464_p1.read());
}

void kernel_3mm_nonP::thread_v5_6_4_Addr_B() {
    v5_6_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_6_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_6_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_4_Clk_A() {
    v5_6_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_4_Clk_B() {
    v5_6_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_6_4_Din_A() {
    v5_6_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_6_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_6_4_Din_B = grp_fu_5010_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_6_4_Din_B = grp_fu_5018_p2.read();
    } else {
        v5_6_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_6_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_6_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_6_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_6_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_EN_A.read();
    } else {
        v5_6_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_6_4_EN_B = ap_const_logic_1;
    } else {
        v5_6_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_6_4_Rst_A() {
    v5_6_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_4_Rst_B() {
    v5_6_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_6_4_WEN_A() {
    v5_6_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_6_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_6_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_6_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Addr_A.read();
    } else {
        v5_7_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_7_0_Addr_A_orig() {
    v5_7_0_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_fu_7511_p1.read());
}

void kernel_3mm_nonP::thread_v5_7_0_Addr_B() {
    v5_7_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_7_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_7_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_0_Clk_A() {
    v5_7_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_0_Clk_B() {
    v5_7_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_0_Din_A() {
    v5_7_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_7_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_0_Din_B = grp_fu_5014_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_0_Din_B = grp_fu_5023_p2.read();
    } else {
        v5_7_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_7_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_EN_A.read();
    } else {
        v5_7_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_7_0_EN_B = ap_const_logic_1;
    } else {
        v5_7_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_0_Rst_A() {
    v5_7_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_0_Rst_B() {
    v5_7_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_0_WEN_A() {
    v5_7_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_7_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_7_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_7_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Addr_A.read();
    } else {
        v5_7_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_7_1_Addr_A_orig() {
    v5_7_1_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_fu_7511_p1.read());
}

void kernel_3mm_nonP::thread_v5_7_1_Addr_B() {
    v5_7_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_7_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_7_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_1_Clk_A() {
    v5_7_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_1_Clk_B() {
    v5_7_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_1_Din_A() {
    v5_7_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_7_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_1_Din_B = grp_fu_5014_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_1_Din_B = grp_fu_5023_p2.read();
    } else {
        v5_7_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()))) {
        v5_7_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_EN_A.read();
    } else {
        v5_7_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_7_1_EN_B = ap_const_logic_1;
    } else {
        v5_7_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_1_Rst_A() {
    v5_7_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_1_Rst_B() {
    v5_7_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_1_WEN_A() {
    v5_7_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_7_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_7_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_7_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Addr_A.read();
    } else {
        v5_7_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_7_2_Addr_A_orig() {
    v5_7_2_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_reg_9539.read());
}

void kernel_3mm_nonP::thread_v5_7_2_Addr_B() {
    v5_7_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_7_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_7_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_2_Clk_A() {
    v5_7_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_2_Clk_B() {
    v5_7_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_2_Din_A() {
    v5_7_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_7_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_2_Din_B = grp_fu_5014_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_2_Din_B = grp_fu_5023_p2.read();
    } else {
        v5_7_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0))) {
        v5_7_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_EN_A.read();
    } else {
        v5_7_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_7_2_EN_B = ap_const_logic_1;
    } else {
        v5_7_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_2_Rst_A() {
    v5_7_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_2_Rst_B() {
    v5_7_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_2_WEN_A() {
    v5_7_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_7_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_7_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_7_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Addr_A.read();
    } else {
        v5_7_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_7_3_Addr_A_orig() {
    v5_7_3_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_reg_9539.read());
}

void kernel_3mm_nonP::thread_v5_7_3_Addr_B() {
    v5_7_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_7_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_7_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_3_Clk_A() {
    v5_7_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_3_Clk_B() {
    v5_7_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_3_Din_A() {
    v5_7_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_7_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_3_Din_B = grp_fu_5014_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_3_Din_B = grp_fu_5023_p2.read();
    } else {
        v5_7_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0))) {
        v5_7_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_EN_A.read();
    } else {
        v5_7_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_7_3_EN_B = ap_const_logic_1;
    } else {
        v5_7_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_3_Rst_A() {
    v5_7_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_3_Rst_B() {
    v5_7_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_3_WEN_A() {
    v5_7_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_7_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_7_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_7_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Addr_A.read();
    } else {
        v5_7_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_7_4_Addr_A_orig() {
    v5_7_4_Addr_A_orig =  (sc_lv<32>) (sext_ln891_1_reg_9539.read());
}

void kernel_3mm_nonP::thread_v5_7_4_Addr_B() {
    v5_7_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_7_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_7_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_4_Clk_A() {
    v5_7_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_4_Clk_B() {
    v5_7_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_7_4_Din_A() {
    v5_7_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_7_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_7_4_Din_B = grp_fu_5014_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_7_4_Din_B = grp_fu_5023_p2.read();
    } else {
        v5_7_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_7_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0))) {
        v5_7_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_7_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_7_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_EN_A.read();
    } else {
        v5_7_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_7_4_EN_B = ap_const_logic_1;
    } else {
        v5_7_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_7_4_Rst_A() {
    v5_7_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_4_Rst_B() {
    v5_7_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_7_4_WEN_A() {
    v5_7_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_7_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_7_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_7_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Addr_A.read();
    } else {
        v5_8_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_8_0_Addr_A_orig() {
    v5_8_0_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_8_0_Addr_B() {
    v5_8_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_8_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_8_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_0_Clk_A() {
    v5_8_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_0_Clk_B() {
    v5_8_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_0_Din_A() {
    v5_8_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_8_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_0_Din_B = grp_fu_5018_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_0_Din_B = grp_fu_5111_p2.read();
    } else {
        v5_8_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_8_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_EN_A.read();
    } else {
        v5_8_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_8_0_EN_B = ap_const_logic_1;
    } else {
        v5_8_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_0_Rst_A() {
    v5_8_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_0_Rst_B() {
    v5_8_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_0_WEN_A() {
    v5_8_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_8_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_8_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_8_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Addr_A.read();
    } else {
        v5_8_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_8_1_Addr_A_orig() {
    v5_8_1_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_8_1_Addr_B() {
    v5_8_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_8_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_8_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_1_Clk_A() {
    v5_8_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_1_Clk_B() {
    v5_8_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_1_Din_A() {
    v5_8_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_8_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_1_Din_B = grp_fu_5018_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_1_Din_B = grp_fu_5111_p2.read();
    } else {
        v5_8_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_8_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_EN_A.read();
    } else {
        v5_8_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_8_1_EN_B = ap_const_logic_1;
    } else {
        v5_8_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_1_Rst_A() {
    v5_8_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_1_Rst_B() {
    v5_8_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_1_WEN_A() {
    v5_8_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_8_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_8_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_8_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Addr_A.read();
    } else {
        v5_8_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_8_2_Addr_A_orig() {
    v5_8_2_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_8_2_Addr_B() {
    v5_8_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_8_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_8_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_2_Clk_A() {
    v5_8_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_2_Clk_B() {
    v5_8_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_2_Din_A() {
    v5_8_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_8_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_2_Din_B = grp_fu_5018_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_2_Din_B = grp_fu_5111_p2.read();
    } else {
        v5_8_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_8_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_EN_A.read();
    } else {
        v5_8_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_8_2_EN_B = ap_const_logic_1;
    } else {
        v5_8_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_2_Rst_A() {
    v5_8_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_2_Rst_B() {
    v5_8_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_2_WEN_A() {
    v5_8_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_8_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_8_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_8_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Addr_A.read();
    } else {
        v5_8_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_8_3_Addr_A_orig() {
    v5_8_3_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_8_3_Addr_B() {
    v5_8_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_8_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_8_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_3_Clk_A() {
    v5_8_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_3_Clk_B() {
    v5_8_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_3_Din_A() {
    v5_8_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_8_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_3_Din_B = grp_fu_5018_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_3_Din_B = grp_fu_5111_p2.read();
    } else {
        v5_8_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_8_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_EN_A.read();
    } else {
        v5_8_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_8_3_EN_B = ap_const_logic_1;
    } else {
        v5_8_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_3_Rst_A() {
    v5_8_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_3_Rst_B() {
    v5_8_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_3_WEN_A() {
    v5_8_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_8_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_8_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_8_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Addr_A.read();
    } else {
        v5_8_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_8_4_Addr_A_orig() {
    v5_8_4_Addr_A_orig =  (sc_lv<32>) (sext_ln951_1_fu_7974_p1.read());
}

void kernel_3mm_nonP::thread_v5_8_4_Addr_B() {
    v5_8_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_8_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_8_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_4_Clk_A() {
    v5_8_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_4_Clk_B() {
    v5_8_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_8_4_Din_A() {
    v5_8_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_8_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_8_4_Din_B = grp_fu_5018_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_8_4_Din_B = grp_fu_5111_p2.read();
    } else {
        v5_8_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_8_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0))) {
        v5_8_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_8_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_8_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_EN_A.read();
    } else {
        v5_8_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_8_4_EN_B = ap_const_logic_1;
    } else {
        v5_8_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_8_4_Rst_A() {
    v5_8_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_4_Rst_B() {
    v5_8_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_8_4_WEN_A() {
    v5_8_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_8_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_8_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_8_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_0_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_0_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Addr_A.read();
    } else {
        v5_9_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_9_0_Addr_A_orig() {
    v5_9_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_9_0_Addr_B() {
    v5_9_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_9_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_0_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_0_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_9_0_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_0_Clk_A() {
    v5_9_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_0_Clk_B() {
    v5_9_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_0_Din_A() {
    v5_9_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_9_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_0_Din_B = grp_fu_5023_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_0_Din_B = grp_fu_5121_p2.read();
    } else {
        v5_9_0_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_9_0_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_0_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_EN_A.read();
    } else {
        v5_9_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_9_0_EN_B = ap_const_logic_1;
    } else {
        v5_9_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_0_Rst_A() {
    v5_9_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_0_Rst_B() {
    v5_9_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_0_WEN_A() {
    v5_9_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_9_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_9_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_9_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_1_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_1_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Addr_A.read();
    } else {
        v5_9_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_9_1_Addr_A_orig() {
    v5_9_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_9_1_Addr_B() {
    v5_9_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_9_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_1_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_1_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_9_1_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_1_Clk_A() {
    v5_9_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_1_Clk_B() {
    v5_9_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_1_Din_A() {
    v5_9_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_9_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_1_Din_B = grp_fu_5023_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_1_Din_B = grp_fu_5121_p2.read();
    } else {
        v5_9_1_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_9_1_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_1_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_EN_A.read();
    } else {
        v5_9_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_9_1_EN_B = ap_const_logic_1;
    } else {
        v5_9_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_1_Rst_A() {
    v5_9_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_1_Rst_B() {
    v5_9_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_1_WEN_A() {
    v5_9_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_9_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0)))) {
        v5_9_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_9_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_2_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_2_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Addr_A.read();
    } else {
        v5_9_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_9_2_Addr_A_orig() {
    v5_9_2_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_9_2_Addr_B() {
    v5_9_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_9_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_2_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_2_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_9_2_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_2_Clk_A() {
    v5_9_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_2_Clk_B() {
    v5_9_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_2_Din_A() {
    v5_9_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_9_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_2_Din_B = grp_fu_5023_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_2_Din_B = grp_fu_5121_p2.read();
    } else {
        v5_9_2_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_9_2_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_2_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_EN_A.read();
    } else {
        v5_9_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_9_2_EN_B = ap_const_logic_1;
    } else {
        v5_9_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_2_Rst_A() {
    v5_9_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_2_Rst_B() {
    v5_9_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_2_WEN_A() {
    v5_9_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_9_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1)))) {
        v5_9_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_9_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_3_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_3_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Addr_A.read();
    } else {
        v5_9_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_9_3_Addr_A_orig() {
    v5_9_3_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_9_3_Addr_B() {
    v5_9_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_9_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_3_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_3_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_9_3_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_3_Clk_A() {
    v5_9_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_3_Clk_B() {
    v5_9_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_3_Din_A() {
    v5_9_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_9_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_3_Din_B = grp_fu_5023_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_3_Din_B = grp_fu_5121_p2.read();
    } else {
        v5_9_3_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_9_3_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_3_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_EN_A.read();
    } else {
        v5_9_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_9_3_EN_B = ap_const_logic_1;
    } else {
        v5_9_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_3_Rst_A() {
    v5_9_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_3_Rst_B() {
    v5_9_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_3_WEN_A() {
    v5_9_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_9_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2)))) {
        v5_9_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_9_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_4_Addr_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Addr_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_4_Addr_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Addr_A.read();
    } else {
        v5_9_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
    }
}

void kernel_3mm_nonP::thread_v5_9_4_Addr_A_orig() {
    v5_9_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_1_fu_8014_p1.read());
}

void kernel_3mm_nonP::thread_v5_9_4_Addr_B() {
    v5_9_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v5_9_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_4_Addr_B_orig =  (sc_lv<32>) (zext_ln337_2_reg_9151.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_4_Addr_B_orig =  (sc_lv<32>) (zext_ln327_4_reg_9107.read());
    } else {
        v5_9_4_Addr_B_orig =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_4_Clk_A() {
    v5_9_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_4_Clk_B() {
    v5_9_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v5_9_4_Din_A() {
    v5_9_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v5_9_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        v5_9_4_Din_B = grp_fu_5023_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        v5_9_4_Din_B = grp_fu_5121_p2.read();
    } else {
        v5_9_4_Din_B =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_v5_9_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0))) {
        v5_9_4_EN_A = ap_const_logic_1;
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)))) {
        v5_9_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_EN_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        v5_9_4_EN_A = grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_EN_A.read();
    } else {
        v5_9_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read())))) {
        v5_9_4_EN_B = ap_const_logic_1;
    } else {
        v5_9_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v5_9_4_Rst_A() {
    v5_9_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_4_Rst_B() {
    v5_9_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v5_9_4_WEN_A() {
    v5_9_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v5_9_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,4,4>(trunc_ln327_reg_9016.read(), ap_const_lv4_3)))) {
        v5_9_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_9_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v610_fu_8062_p3() {
    v610_fu_8062_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_4_0_Dout_A.read(): v5_9_0_Dout_A.read());
}

void kernel_3mm_nonP::thread_v613_fu_8069_p3() {
    v613_fu_8069_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_4_1_Dout_A.read(): v5_9_1_Dout_A.read());
}

void kernel_3mm_nonP::thread_v616_fu_8076_p3() {
    v616_fu_8076_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_4_2_Dout_A.read(): v5_9_2_Dout_A.read());
}

void kernel_3mm_nonP::thread_v619_fu_8083_p3() {
    v619_fu_8083_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_4_3_Dout_A.read(): v5_9_3_Dout_A.read());
}

void kernel_3mm_nonP::thread_v622_fu_8090_p3() {
    v622_fu_8090_p3 = (!select_ln591_3_reg_9802.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_reg_9802.read()[0].to_bool())? v5_4_4_Dout_A.read(): v5_9_4_Dout_A.read());
}

void kernel_3mm_nonP::thread_v6_0_0_Addr_A() {
    v6_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_0_Addr_A_orig() {
    v6_0_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_0_0_Addr_B() {
    v6_0_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_0_Addr_B_orig() {
    v6_0_0_Addr_B_orig =  (sc_lv<32>) (v6_0_0_addr_reg_9959_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_0_0_Clk_A() {
    v6_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_0_Clk_B() {
    v6_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_0_Din_A() {
    v6_0_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_0_0_Din_B() {
    v6_0_0_Din_B = reg_5727.read();
}

void kernel_3mm_nonP::thread_v6_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_0_EN_A = ap_const_logic_1;
    } else {
        v6_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_0_0_EN_B = ap_const_logic_1;
    } else {
        v6_0_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_0_Rst_A() {
    v6_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_0_Rst_B() {
    v6_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_0_WEN_A() {
    v6_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_0_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_0_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_1_Addr_A() {
    v6_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_1_Addr_A_orig() {
    v6_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_0_1_Addr_B() {
    v6_0_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_1_Addr_B_orig() {
    v6_0_1_Addr_B_orig =  (sc_lv<32>) (v6_0_1_addr_reg_9965_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_0_1_Clk_A() {
    v6_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_1_Clk_B() {
    v6_0_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_1_Din_A() {
    v6_0_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_0_1_Din_B() {
    v6_0_1_Din_B = reg_5734.read();
}

void kernel_3mm_nonP::thread_v6_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_1_EN_A = ap_const_logic_1;
    } else {
        v6_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_0_1_EN_B = ap_const_logic_1;
    } else {
        v6_0_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_1_Rst_A() {
    v6_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_1_Rst_B() {
    v6_0_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_1_WEN_A() {
    v6_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_0_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_0_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_2_Addr_A() {
    v6_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_2_Addr_A_orig() {
    v6_0_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_0_2_Addr_B() {
    v6_0_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_2_Addr_B_orig() {
    v6_0_2_Addr_B_orig =  (sc_lv<32>) (v6_0_2_addr_reg_9971_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_0_2_Clk_A() {
    v6_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_2_Clk_B() {
    v6_0_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_2_Din_A() {
    v6_0_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_0_2_Din_B() {
    v6_0_2_Din_B = reg_5741.read();
}

void kernel_3mm_nonP::thread_v6_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_2_EN_A = ap_const_logic_1;
    } else {
        v6_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_0_2_EN_B = ap_const_logic_1;
    } else {
        v6_0_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_2_Rst_A() {
    v6_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_2_Rst_B() {
    v6_0_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_2_WEN_A() {
    v6_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_0_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_0_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_3_Addr_A() {
    v6_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_3_Addr_A_orig() {
    v6_0_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_0_3_Addr_B() {
    v6_0_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_3_Addr_B_orig() {
    v6_0_3_Addr_B_orig =  (sc_lv<32>) (v6_0_3_addr_reg_9977_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_0_3_Clk_A() {
    v6_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_3_Clk_B() {
    v6_0_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_3_Din_A() {
    v6_0_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_0_3_Din_B() {
    v6_0_3_Din_B = reg_5770.read();
}

void kernel_3mm_nonP::thread_v6_0_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_3_EN_A = ap_const_logic_1;
    } else {
        v6_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_0_3_EN_B = ap_const_logic_1;
    } else {
        v6_0_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_3_Rst_A() {
    v6_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_3_Rst_B() {
    v6_0_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_3_WEN_A() {
    v6_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_0_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_0_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_4_Addr_A() {
    v6_0_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_4_Addr_A_orig() {
    v6_0_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_0_4_Addr_B() {
    v6_0_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_0_4_Addr_B_orig() {
    v6_0_4_Addr_B_orig =  (sc_lv<32>) (v6_0_4_addr_reg_9983_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_0_4_Clk_A() {
    v6_0_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_4_Clk_B() {
    v6_0_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_0_4_Din_A() {
    v6_0_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_0_4_Din_B() {
    v6_0_4_Din_B = reg_5892.read();
}

void kernel_3mm_nonP::thread_v6_0_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_4_EN_A = ap_const_logic_1;
    } else {
        v6_0_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_0_4_EN_B = ap_const_logic_1;
    } else {
        v6_0_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_0_4_Rst_A() {
    v6_0_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_4_Rst_B() {
    v6_0_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_0_4_WEN_A() {
    v6_0_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_0_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_0_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_0_Addr_A() {
    v6_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_0_Addr_A_orig() {
    v6_1_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_1_0_Addr_B() {
    v6_1_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_0_Addr_B_orig() {
    v6_1_0_Addr_B_orig =  (sc_lv<32>) (v6_1_0_addr_reg_9989_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_1_0_Clk_A() {
    v6_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_0_Clk_B() {
    v6_1_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_0_Din_A() {
    v6_1_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_1_0_Din_B() {
    v6_1_0_Din_B = reg_5899.read();
}

void kernel_3mm_nonP::thread_v6_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_0_EN_A = ap_const_logic_1;
    } else {
        v6_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_1_0_EN_B = ap_const_logic_1;
    } else {
        v6_1_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_0_Rst_A() {
    v6_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_0_Rst_B() {
    v6_1_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_0_WEN_A() {
    v6_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_1_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_1_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_1_Addr_A() {
    v6_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_1_Addr_A_orig() {
    v6_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_1_1_Addr_B() {
    v6_1_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_1_Addr_B_orig() {
    v6_1_1_Addr_B_orig =  (sc_lv<32>) (v6_1_1_addr_reg_9995_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_1_1_Clk_A() {
    v6_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_1_Clk_B() {
    v6_1_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_1_Din_A() {
    v6_1_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_1_1_Din_B() {
    v6_1_1_Din_B = reg_5906.read();
}

void kernel_3mm_nonP::thread_v6_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_1_EN_A = ap_const_logic_1;
    } else {
        v6_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_1_1_EN_B = ap_const_logic_1;
    } else {
        v6_1_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_1_Rst_A() {
    v6_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_1_Rst_B() {
    v6_1_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_1_WEN_A() {
    v6_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_1_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_1_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_2_Addr_A() {
    v6_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_2_Addr_A_orig() {
    v6_1_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_1_2_Addr_B() {
    v6_1_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_2_Addr_B_orig() {
    v6_1_2_Addr_B_orig =  (sc_lv<32>) (v6_1_2_addr_reg_10001_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_1_2_Clk_A() {
    v6_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_2_Clk_B() {
    v6_1_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_2_Din_A() {
    v6_1_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_1_2_Din_B() {
    v6_1_2_Din_B = reg_5913.read();
}

void kernel_3mm_nonP::thread_v6_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_2_EN_A = ap_const_logic_1;
    } else {
        v6_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_1_2_EN_B = ap_const_logic_1;
    } else {
        v6_1_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_2_Rst_A() {
    v6_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_2_Rst_B() {
    v6_1_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_2_WEN_A() {
    v6_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_1_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_1_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_3_Addr_A() {
    v6_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_3_Addr_A_orig() {
    v6_1_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_1_3_Addr_B() {
    v6_1_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_3_Addr_B_orig() {
    v6_1_3_Addr_B_orig =  (sc_lv<32>) (v6_1_3_addr_reg_10007_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_1_3_Clk_A() {
    v6_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_3_Clk_B() {
    v6_1_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_3_Din_A() {
    v6_1_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_1_3_Din_B() {
    v6_1_3_Din_B = reg_5920.read();
}

void kernel_3mm_nonP::thread_v6_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_3_EN_A = ap_const_logic_1;
    } else {
        v6_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_1_3_EN_B = ap_const_logic_1;
    } else {
        v6_1_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_3_Rst_A() {
    v6_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_3_Rst_B() {
    v6_1_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_3_WEN_A() {
    v6_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_1_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_1_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_4_Addr_A() {
    v6_1_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_4_Addr_A_orig() {
    v6_1_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_1_4_Addr_B() {
    v6_1_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_1_4_Addr_B_orig() {
    v6_1_4_Addr_B_orig =  (sc_lv<32>) (v6_1_4_addr_reg_10013_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_1_4_Clk_A() {
    v6_1_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_4_Clk_B() {
    v6_1_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_1_4_Din_A() {
    v6_1_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_1_4_Din_B() {
    v6_1_4_Din_B = reg_5927.read();
}

void kernel_3mm_nonP::thread_v6_1_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_4_EN_A = ap_const_logic_1;
    } else {
        v6_1_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_1_4_EN_B = ap_const_logic_1;
    } else {
        v6_1_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_1_4_Rst_A() {
    v6_1_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_4_Rst_B() {
    v6_1_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_1_4_WEN_A() {
    v6_1_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_1_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_1_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_0_Addr_A() {
    v6_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_0_Addr_A_orig() {
    v6_2_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_2_0_Addr_B() {
    v6_2_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_0_Addr_B_orig() {
    v6_2_0_Addr_B_orig =  (sc_lv<32>) (v6_2_0_addr_reg_10019_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_2_0_Clk_A() {
    v6_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_0_Clk_B() {
    v6_2_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_0_Din_A() {
    v6_2_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_2_0_Din_B() {
    v6_2_0_Din_B = reg_5934.read();
}

void kernel_3mm_nonP::thread_v6_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_0_EN_A = ap_const_logic_1;
    } else {
        v6_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_2_0_EN_B = ap_const_logic_1;
    } else {
        v6_2_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_0_Rst_A() {
    v6_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_0_Rst_B() {
    v6_2_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_0_WEN_A() {
    v6_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_2_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_2_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_1_Addr_A() {
    v6_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_1_Addr_A_orig() {
    v6_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_2_1_Addr_B() {
    v6_2_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_1_Addr_B_orig() {
    v6_2_1_Addr_B_orig =  (sc_lv<32>) (v6_2_1_addr_reg_10025_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_2_1_Clk_A() {
    v6_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_1_Clk_B() {
    v6_2_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_1_Din_A() {
    v6_2_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_2_1_Din_B() {
    v6_2_1_Din_B = reg_5941.read();
}

void kernel_3mm_nonP::thread_v6_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_1_EN_A = ap_const_logic_1;
    } else {
        v6_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_2_1_EN_B = ap_const_logic_1;
    } else {
        v6_2_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_1_Rst_A() {
    v6_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_1_Rst_B() {
    v6_2_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_1_WEN_A() {
    v6_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_2_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_2_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_2_Addr_A() {
    v6_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_2_Addr_A_orig() {
    v6_2_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_2_2_Addr_B() {
    v6_2_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_2_Addr_B_orig() {
    v6_2_2_Addr_B_orig =  (sc_lv<32>) (v6_2_2_addr_reg_10031_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_2_2_Clk_A() {
    v6_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_2_Clk_B() {
    v6_2_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_2_Din_A() {
    v6_2_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_2_2_Din_B() {
    v6_2_2_Din_B = reg_5948.read();
}

void kernel_3mm_nonP::thread_v6_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_2_EN_A = ap_const_logic_1;
    } else {
        v6_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_2_2_EN_B = ap_const_logic_1;
    } else {
        v6_2_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_2_Rst_A() {
    v6_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_2_Rst_B() {
    v6_2_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_2_WEN_A() {
    v6_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_2_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_2_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_3_Addr_A() {
    v6_2_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_3_Addr_A_orig() {
    v6_2_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_2_3_Addr_B() {
    v6_2_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_3_Addr_B_orig() {
    v6_2_3_Addr_B_orig =  (sc_lv<32>) (v6_2_3_addr_reg_10037_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_2_3_Clk_A() {
    v6_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_3_Clk_B() {
    v6_2_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_3_Din_A() {
    v6_2_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_2_3_Din_B() {
    v6_2_3_Din_B = reg_5727.read();
}

void kernel_3mm_nonP::thread_v6_2_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_3_EN_A = ap_const_logic_1;
    } else {
        v6_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_2_3_EN_B = ap_const_logic_1;
    } else {
        v6_2_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_3_Rst_A() {
    v6_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_3_Rst_B() {
    v6_2_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_3_WEN_A() {
    v6_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_2_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_2_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_4_Addr_A() {
    v6_2_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_4_Addr_A_orig() {
    v6_2_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_2_4_Addr_B() {
    v6_2_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_2_4_Addr_B_orig() {
    v6_2_4_Addr_B_orig =  (sc_lv<32>) (v6_2_4_addr_reg_10043_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_2_4_Clk_A() {
    v6_2_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_4_Clk_B() {
    v6_2_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_2_4_Din_A() {
    v6_2_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_2_4_Din_B() {
    v6_2_4_Din_B = reg_5734.read();
}

void kernel_3mm_nonP::thread_v6_2_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_4_EN_A = ap_const_logic_1;
    } else {
        v6_2_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_2_4_EN_B = ap_const_logic_1;
    } else {
        v6_2_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_2_4_Rst_A() {
    v6_2_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_4_Rst_B() {
    v6_2_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_2_4_WEN_A() {
    v6_2_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_2_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_2_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_0_Addr_A() {
    v6_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_0_Addr_A_orig() {
    v6_3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_3_0_Addr_B() {
    v6_3_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_0_Addr_B_orig() {
    v6_3_0_Addr_B_orig =  (sc_lv<32>) (v6_3_0_addr_reg_10049_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_3_0_Clk_A() {
    v6_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_0_Clk_B() {
    v6_3_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_0_Din_A() {
    v6_3_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_3_0_Din_B() {
    v6_3_0_Din_B = reg_5741.read();
}

void kernel_3mm_nonP::thread_v6_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_0_EN_A = ap_const_logic_1;
    } else {
        v6_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_3_0_EN_B = ap_const_logic_1;
    } else {
        v6_3_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_0_Rst_A() {
    v6_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_0_Rst_B() {
    v6_3_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_0_WEN_A() {
    v6_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_3_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_3_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_1_Addr_A() {
    v6_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_1_Addr_A_orig() {
    v6_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_3_1_Addr_B() {
    v6_3_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_1_Addr_B_orig() {
    v6_3_1_Addr_B_orig =  (sc_lv<32>) (v6_3_1_addr_reg_10055_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_3_1_Clk_A() {
    v6_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_1_Clk_B() {
    v6_3_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_1_Din_A() {
    v6_3_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_3_1_Din_B() {
    v6_3_1_Din_B = reg_5770.read();
}

void kernel_3mm_nonP::thread_v6_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_1_EN_A = ap_const_logic_1;
    } else {
        v6_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_3_1_EN_B = ap_const_logic_1;
    } else {
        v6_3_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_1_Rst_A() {
    v6_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_1_Rst_B() {
    v6_3_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_1_WEN_A() {
    v6_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_3_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_3_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_2_Addr_A() {
    v6_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_2_Addr_A_orig() {
    v6_3_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_3_2_Addr_B() {
    v6_3_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_2_Addr_B_orig() {
    v6_3_2_Addr_B_orig =  (sc_lv<32>) (v6_3_2_addr_reg_10061_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_3_2_Clk_A() {
    v6_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_2_Clk_B() {
    v6_3_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_2_Din_A() {
    v6_3_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_3_2_Din_B() {
    v6_3_2_Din_B = reg_5892.read();
}

void kernel_3mm_nonP::thread_v6_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_2_EN_A = ap_const_logic_1;
    } else {
        v6_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_3_2_EN_B = ap_const_logic_1;
    } else {
        v6_3_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_2_Rst_A() {
    v6_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_2_Rst_B() {
    v6_3_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_2_WEN_A() {
    v6_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_3_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_3_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_3_Addr_A() {
    v6_3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_3_Addr_A_orig() {
    v6_3_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_3_3_Addr_B() {
    v6_3_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_3_Addr_B_orig() {
    v6_3_3_Addr_B_orig =  (sc_lv<32>) (v6_3_3_addr_reg_10067_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_3_3_Clk_A() {
    v6_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_3_Clk_B() {
    v6_3_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_3_Din_A() {
    v6_3_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_3_3_Din_B() {
    v6_3_3_Din_B = reg_5899.read();
}

void kernel_3mm_nonP::thread_v6_3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_3_EN_A = ap_const_logic_1;
    } else {
        v6_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_3_3_EN_B = ap_const_logic_1;
    } else {
        v6_3_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_3_Rst_A() {
    v6_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_3_Rst_B() {
    v6_3_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_3_WEN_A() {
    v6_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_3_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_3_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_4_Addr_A() {
    v6_3_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_4_Addr_A_orig() {
    v6_3_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_3_4_Addr_B() {
    v6_3_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_3_4_Addr_B_orig() {
    v6_3_4_Addr_B_orig =  (sc_lv<32>) (v6_3_4_addr_reg_10073_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_3_4_Clk_A() {
    v6_3_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_4_Clk_B() {
    v6_3_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_3_4_Din_A() {
    v6_3_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_3_4_Din_B() {
    v6_3_4_Din_B = reg_5906.read();
}

void kernel_3mm_nonP::thread_v6_3_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_4_EN_A = ap_const_logic_1;
    } else {
        v6_3_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_3_4_EN_B = ap_const_logic_1;
    } else {
        v6_3_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_3_4_Rst_A() {
    v6_3_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_4_Rst_B() {
    v6_3_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_3_4_WEN_A() {
    v6_3_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_3_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_3_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_0_Addr_A() {
    v6_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_0_Addr_A_orig() {
    v6_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_4_0_Addr_B() {
    v6_4_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_0_Addr_B_orig() {
    v6_4_0_Addr_B_orig =  (sc_lv<32>) (v6_4_0_addr_reg_10079_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_4_0_Clk_A() {
    v6_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_0_Clk_B() {
    v6_4_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_0_Din_A() {
    v6_4_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_4_0_Din_B() {
    v6_4_0_Din_B = reg_5913.read();
}

void kernel_3mm_nonP::thread_v6_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_0_EN_A = ap_const_logic_1;
    } else {
        v6_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_4_0_EN_B = ap_const_logic_1;
    } else {
        v6_4_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_0_Rst_A() {
    v6_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_0_Rst_B() {
    v6_4_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_0_WEN_A() {
    v6_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_4_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_4_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_1_Addr_A() {
    v6_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_1_Addr_A_orig() {
    v6_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_4_1_Addr_B() {
    v6_4_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_1_Addr_B_orig() {
    v6_4_1_Addr_B_orig =  (sc_lv<32>) (v6_4_1_addr_reg_10085_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_4_1_Clk_A() {
    v6_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_1_Clk_B() {
    v6_4_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_1_Din_A() {
    v6_4_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_4_1_Din_B() {
    v6_4_1_Din_B = reg_5920.read();
}

void kernel_3mm_nonP::thread_v6_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_1_EN_A = ap_const_logic_1;
    } else {
        v6_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_4_1_EN_B = ap_const_logic_1;
    } else {
        v6_4_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_1_Rst_A() {
    v6_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_1_Rst_B() {
    v6_4_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_1_WEN_A() {
    v6_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_4_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_4_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_2_Addr_A() {
    v6_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_2_Addr_A_orig() {
    v6_4_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_4_2_Addr_B() {
    v6_4_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_2_Addr_B_orig() {
    v6_4_2_Addr_B_orig =  (sc_lv<32>) (v6_4_2_addr_reg_10091_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_4_2_Clk_A() {
    v6_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_2_Clk_B() {
    v6_4_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_2_Din_A() {
    v6_4_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_4_2_Din_B() {
    v6_4_2_Din_B = reg_5927.read();
}

void kernel_3mm_nonP::thread_v6_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_2_EN_A = ap_const_logic_1;
    } else {
        v6_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_4_2_EN_B = ap_const_logic_1;
    } else {
        v6_4_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_2_Rst_A() {
    v6_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_2_Rst_B() {
    v6_4_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_2_WEN_A() {
    v6_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_4_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_4_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_3_Addr_A() {
    v6_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_3_Addr_A_orig() {
    v6_4_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_4_3_Addr_B() {
    v6_4_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_3_Addr_B_orig() {
    v6_4_3_Addr_B_orig =  (sc_lv<32>) (v6_4_3_addr_reg_10097_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_4_3_Clk_A() {
    v6_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_3_Clk_B() {
    v6_4_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_3_Din_A() {
    v6_4_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_4_3_Din_B() {
    v6_4_3_Din_B = reg_5934.read();
}

void kernel_3mm_nonP::thread_v6_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_3_EN_A = ap_const_logic_1;
    } else {
        v6_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_4_3_EN_B = ap_const_logic_1;
    } else {
        v6_4_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_3_Rst_A() {
    v6_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_3_Rst_B() {
    v6_4_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_3_WEN_A() {
    v6_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_4_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_4_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_4_Addr_A() {
    v6_4_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_4_Addr_A_orig() {
    v6_4_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_1_fu_7657_p1.read());
}

void kernel_3mm_nonP::thread_v6_4_4_Addr_B() {
    v6_4_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v6_4_4_Addr_B_orig() {
    v6_4_4_Addr_B_orig =  (sc_lv<32>) (v6_4_4_addr_reg_10103_pp2_iter3_reg.read());
}

void kernel_3mm_nonP::thread_v6_4_4_Clk_A() {
    v6_4_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_4_Clk_B() {
    v6_4_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v6_4_4_Din_A() {
    v6_4_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v6_4_4_Din_B() {
    v6_4_4_Din_B = reg_5941.read();
}

void kernel_3mm_nonP::thread_v6_4_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_4_EN_A = ap_const_logic_1;
    } else {
        v6_4_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()))) {
        v6_4_4_EN_B = ap_const_logic_1;
    } else {
        v6_4_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v6_4_4_Rst_A() {
    v6_4_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_4_Rst_B() {
    v6_4_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v6_4_4_WEN_A() {
    v6_4_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v6_4_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter3_reg.read()))) {
        v6_4_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP::thread_v8_fu_6029_p2() {
    v8_fu_6029_p2 = (!ap_const_lv5_1.is_01() || !ap_phi_mux_v8_0_phi_fu_4317_p4.read().is_01())? sc_lv<5>(): (sc_biguint<5>(ap_const_lv5_1) + sc_biguint<5>(ap_phi_mux_v8_0_phi_fu_4317_p4.read()));
}

void kernel_3mm_nonP::thread_v9_fu_6109_p2() {
    v9_fu_6109_p2 = (!ap_const_lv3_1.is_01() || !select_ln59_fu_6041_p3.read().is_01())? sc_lv<3>(): (sc_biguint<3>(ap_const_lv3_1) + sc_biguint<3>(select_ln59_fu_6041_p3.read()));
}

void kernel_3mm_nonP::thread_xor_ln329_fu_6484_p2() {
    xor_ln329_fu_6484_p2 = (icmp_ln321_fu_6434_p2.read() ^ ap_const_lv1_1);
}

void kernel_3mm_nonP::thread_xor_ln591_fu_7168_p2() {
    xor_ln591_fu_7168_p2 = (icmp_ln592_reg_9205.read() ^ ap_const_lv1_1);
}

void kernel_3mm_nonP::thread_xor_ln59_fu_6091_p2() {
    xor_ln59_fu_6091_p2 = (icmp_ln60_fu_6035_p2.read() ^ ap_const_lv1_1);
}

void kernel_3mm_nonP::thread_zext_ln1011_fu_7959_p1() {
    zext_ln1011_fu_7959_p1 = esl_zext<8,7>(sext_ln1011_fu_7955_p1.read());
}

void kernel_3mm_nonP::thread_zext_ln324_1_fu_6550_p1() {
    zext_ln324_1_fu_6550_p1 = esl_zext<9,6>(tmp_9_fu_6542_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln324_2_fu_6566_p1() {
    zext_ln324_2_fu_6566_p1 = esl_zext<64,9>(add_ln324_1_fu_6560_p2.read());
}

void kernel_3mm_nonP::thread_zext_ln324_fu_6538_p1() {
    zext_ln324_fu_6538_p1 = esl_zext<9,8>(tmp_8_fu_6530_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln325_fu_6476_p1() {
    zext_ln325_fu_6476_p1 = esl_zext<9,6>(select_ln329_2_fu_6468_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln327_1_fu_6735_p1() {
    zext_ln327_1_fu_6735_p1 = esl_zext<8,4>(tmp_11_fu_6728_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln327_3_fu_6748_p1() {
    zext_ln327_3_fu_6748_p1 = esl_zext<8,7>(sext_ln327_fu_6745_p1.read());
}

void kernel_3mm_nonP::thread_zext_ln327_4_fu_6758_p1() {
    zext_ln327_4_fu_6758_p1 = esl_zext<64,8>(add_ln327_fu_6752_p2.read());
}

void kernel_3mm_nonP::thread_zext_ln327_fu_6724_p1() {
    zext_ln327_fu_6724_p1 = esl_zext<8,7>(tmp_10_fu_6717_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln337_1_fu_6780_p1() {
    zext_ln337_1_fu_6780_p1 = esl_zext<8,7>(sext_ln337_fu_6777_p1.read());
}

void kernel_3mm_nonP::thread_zext_ln337_2_fu_6790_p1() {
    zext_ln337_2_fu_6790_p1 = esl_zext<64,8>(add_ln337_reg_9146.read());
}

void kernel_3mm_nonP::thread_zext_ln591_1_fu_6882_p1() {
    zext_ln591_1_fu_6882_p1 = esl_zext<6,4>(v316_fu_6862_p2.read());
}

void kernel_3mm_nonP::thread_zext_ln591_fu_6818_p1() {
    zext_ln591_fu_6818_p1 = esl_zext<6,4>(ap_phi_mux_v316_0_phi_fu_4428_p4.read());
}

void kernel_3mm_nonP::thread_zext_ln592_1_fu_7203_p1() {
    zext_ln592_1_fu_7203_p1 = esl_zext<6,4>(v317_fu_7185_p2.read());
}

void kernel_3mm_nonP::thread_zext_ln592_fu_6950_p1() {
    zext_ln592_fu_6950_p1 = esl_zext<6,4>(v317_0_reg_4446.read());
}

void kernel_3mm_nonP::thread_zext_ln595_1_fu_7219_p1() {
    zext_ln595_1_fu_7219_p1 = esl_zext<6,5>(shl_ln595_1_mid1_fu_7211_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln595_fu_6961_p1() {
    zext_ln595_fu_6961_p1 = esl_zext<6,5>(shl_ln595_1_fu_6954_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln596_1_fu_7382_p1() {
    zext_ln596_1_fu_7382_p1 = esl_zext<8,4>(select_ln592_fu_7195_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln596_fu_7091_p1() {
    zext_ln596_fu_7091_p1 = esl_zext<8,7>(sext_ln596_fu_7087_p1.read());
}

void kernel_3mm_nonP::thread_zext_ln598_1_fu_7657_p1() {
    zext_ln598_1_fu_7657_p1 = esl_zext<64,8>(add_ln598_fu_7652_p2.read());
}

void kernel_3mm_nonP::thread_zext_ln598_fu_7642_p1() {
    zext_ln598_fu_7642_p1 = esl_zext<8,5>(tmp_34_fu_7635_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln59_1_fu_6049_p1() {
    zext_ln59_1_fu_6049_p1 = esl_zext<7,5>(v8_fu_6029_p2.read());
}

void kernel_3mm_nonP::thread_zext_ln59_fu_5999_p1() {
    zext_ln59_fu_5999_p1 = esl_zext<7,5>(ap_phi_mux_v8_0_phi_fu_4317_p4.read());
}

void kernel_3mm_nonP::thread_zext_ln63_1_fu_6157_p1() {
    zext_ln63_1_fu_6157_p1 = esl_zext<8,5>(tmp_3_fu_6149_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln63_2_fu_6173_p1() {
    zext_ln63_2_fu_6173_p1 = esl_zext<64,8>(add_ln63_1_fu_6167_p2.read());
}

void kernel_3mm_nonP::thread_zext_ln63_fu_6145_p1() {
    zext_ln63_fu_6145_p1 = esl_zext<8,7>(tmp_2_fu_6137_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln64_fu_6083_p1() {
    zext_ln64_fu_6083_p1 = esl_zext<8,5>(select_ln59_2_fu_6075_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln66_1_fu_6343_p1() {
    zext_ln66_1_fu_6343_p1 = esl_zext<7,4>(tmp_5_fu_6336_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln66_3_fu_6356_p1() {
    zext_ln66_3_fu_6356_p1 = esl_zext<7,6>(sext_ln66_fu_6353_p1.read());
}

void kernel_3mm_nonP::thread_zext_ln66_4_fu_6366_p1() {
    zext_ln66_4_fu_6366_p1 = esl_zext<64,7>(add_ln66_1_fu_6360_p2.read());
}

void kernel_3mm_nonP::thread_zext_ln66_fu_6332_p1() {
    zext_ln66_fu_6332_p1 = esl_zext<7,6>(tmp_4_fu_6325_p3.read());
}

void kernel_3mm_nonP::thread_zext_ln76_1_fu_6383_p1() {
    zext_ln76_1_fu_6383_p1 = esl_zext<7,6>(sext_ln76_fu_6380_p1.read());
}

void kernel_3mm_nonP::thread_zext_ln76_2_fu_6393_p1() {
    zext_ln76_2_fu_6393_p1 = esl_zext<64,7>(add_ln76_reg_8646.read());
}

void kernel_3mm_nonP::thread_zext_ln831_fu_7424_p1() {
    zext_ln831_fu_7424_p1 = esl_zext<8,7>(sext_ln831_fu_7420_p1.read());
}

void kernel_3mm_nonP::thread_zext_ln891_fu_7496_p1() {
    zext_ln891_fu_7496_p1 = esl_zext<8,7>(sext_ln891_fu_7492_p1.read());
}

void kernel_3mm_nonP::thread_zext_ln951_fu_7904_p1() {
    zext_ln951_fu_7904_p1 = esl_zext<8,7>(sext_ln951_fu_7900_p1.read());
}

}


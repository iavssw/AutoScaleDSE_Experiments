#include "kernel_3mm_nonP.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_3mm_nonP::thread_add_ln1011_fu_7988_p2() {
    add_ln1011_fu_7988_p2 = (!sub_ln1011_fu_7963_p2.read().is_01() || !zext_ln596_1_reg_9347_pp2_iter1_reg.read().is_01())? sc_lv<8>(): (sc_biguint<8>(sub_ln1011_fu_7963_p2.read()) + sc_biguint<8>(zext_ln596_1_reg_9347_pp2_iter1_reg.read()));
}

void kernel_3mm_nonP::thread_add_ln320_fu_6422_p2() {
    add_ln320_fu_6422_p2 = (!ap_phi_mux_indvar_flatten78_phi_fu_4361_p4.read().is_01() || !ap_const_lv13_1.is_01())? sc_lv<13>(): (sc_biguint<13>(ap_phi_mux_indvar_flatten78_phi_fu_4361_p4.read()) + sc_biguint<13>(ap_const_lv13_1));
}

void kernel_3mm_nonP::thread_add_ln321_1_fu_6621_p2() {
    add_ln321_1_fu_6621_p2 = (!ap_phi_mux_indvar_flatten64_phi_fu_4383_p4.read().is_01() || !ap_const_lv9_1.is_01())? sc_lv<9>(): (sc_biguint<9>(ap_phi_mux_indvar_flatten64_phi_fu_4383_p4.read()) + sc_biguint<9>(ap_const_lv9_1));
}

void kernel_3mm_nonP::thread_add_ln324_1_fu_6560_p2() {
    add_ln324_1_fu_6560_p2 = (!zext_ln325_fu_6476_p1.read().is_01() || !add_ln324_fu_6554_p2.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln325_fu_6476_p1.read()) + sc_biguint<9>(add_ln324_fu_6554_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln324_fu_6554_p2() {
    add_ln324_fu_6554_p2 = (!zext_ln324_fu_6538_p1.read().is_01() || !zext_ln324_1_fu_6550_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln324_fu_6538_p1.read()) + sc_biguint<9>(zext_ln324_1_fu_6550_p1.read()));
}

void kernel_3mm_nonP::thread_add_ln327_fu_6752_p2() {
    add_ln327_fu_6752_p2 = (!zext_ln327_3_fu_6748_p1.read().is_01() || !sub_ln327_fu_6739_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln327_3_fu_6748_p1.read()) + sc_biguint<8>(sub_ln327_fu_6739_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln337_fu_6784_p2() {
    add_ln337_fu_6784_p2 = (!zext_ln337_1_fu_6780_p1.read().is_01() || !sub_ln327_fu_6739_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln337_1_fu_6780_p1.read()) + sc_biguint<8>(sub_ln327_fu_6739_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln591_1_fu_7434_p2() {
    add_ln591_1_fu_7434_p2 = (!ap_const_lv6_2.is_01() || !select_ln591_2_reg_9231.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_2) + sc_biguint<6>(select_ln591_2_reg_9231.read()));
}

void kernel_3mm_nonP::thread_add_ln591_2_fu_7861_p2() {
    add_ln591_2_fu_7861_p2 = (!ap_const_lv6_3.is_01() || !select_ln591_2_reg_9231_pp2_iter1_reg.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_3) + sc_biguint<6>(select_ln591_2_reg_9231_pp2_iter1_reg.read()));
}

void kernel_3mm_nonP::thread_add_ln591_3_fu_7914_p2() {
    add_ln591_3_fu_7914_p2 = (!ap_const_lv6_4.is_01() || !select_ln591_2_reg_9231_pp2_iter1_reg.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_4) + sc_biguint<6>(select_ln591_2_reg_9231_pp2_iter1_reg.read()));
}

void kernel_3mm_nonP::thread_add_ln591_4_fu_7529_p2() {
    add_ln591_4_fu_7529_p2 = (!ap_const_lv11_1.is_01() || !indvar_flatten183_reg_4412.read().is_01())? sc_lv<11>(): (sc_biguint<11>(ap_const_lv11_1) + sc_biguint<11>(indvar_flatten183_reg_4412.read()));
}

void kernel_3mm_nonP::thread_add_ln591_fu_7101_p2() {
    add_ln591_fu_7101_p2 = (!ap_const_lv6_1.is_01() || !select_ln591_2_reg_9231.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_1) + sc_biguint<6>(select_ln591_2_reg_9231.read()));
}

void kernel_3mm_nonP::thread_add_ln592_1_fu_6936_p2() {
    add_ln592_1_fu_6936_p2 = (!ap_const_lv8_1.is_01() || !ap_phi_mux_indvar_flatten85_phi_fu_4439_p4.read().is_01())? sc_lv<8>(): (sc_biguint<8>(ap_const_lv8_1) + sc_biguint<8>(ap_phi_mux_indvar_flatten85_phi_fu_4439_p4.read()));
}

void kernel_3mm_nonP::thread_add_ln595_1_fu_6972_p2() {
    add_ln595_1_fu_6972_p2 = (!zext_ln595_fu_6961_p1.read().is_01() || !zext_ln592_fu_6950_p1.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln595_fu_6961_p1.read()) + sc_biguint<6>(zext_ln592_fu_6950_p1.read()));
}

void kernel_3mm_nonP::thread_add_ln595_2_fu_6978_p2() {
    add_ln595_2_fu_6978_p2 = (!trunc_ln595_reg_9190.read().is_01() || !trunc_ln595_1_fu_6965_p3.read().is_01())? sc_lv<3>(): (sc_biguint<3>(trunc_ln595_reg_9190.read()) + sc_biguint<3>(trunc_ln595_1_fu_6965_p3.read()));
}

void kernel_3mm_nonP::thread_add_ln595_3_fu_6894_p2() {
    add_ln595_3_fu_6894_p2 = (!zext_ln591_1_fu_6882_p1.read().is_01() || !shl_ln595_mid1_fu_6886_p3.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln591_1_fu_6882_p1.read()) + sc_biguint<6>(shl_ln595_mid1_fu_6886_p3.read()));
}

void kernel_3mm_nonP::thread_add_ln595_4_fu_7235_p2() {
    add_ln595_4_fu_7235_p2 = (!zext_ln595_1_fu_7219_p1.read().is_01() || !zext_ln592_1_fu_7203_p1.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln595_1_fu_7219_p1.read()) + sc_biguint<6>(zext_ln592_1_fu_7203_p1.read()));
}

void kernel_3mm_nonP::thread_add_ln595_5_fu_7241_p2() {
    add_ln595_5_fu_7241_p2 = (!trunc_ln595_4_fu_7207_p1.read().is_01() || !trunc_ln595_1_mid1_fu_7227_p3.read().is_01())? sc_lv<3>(): (sc_biguint<3>(trunc_ln595_4_fu_7207_p1.read()) + sc_biguint<3>(trunc_ln595_1_mid1_fu_7227_p3.read()));
}

void kernel_3mm_nonP::thread_add_ln595_fu_6830_p2() {
    add_ln595_fu_6830_p2 = (!zext_ln591_fu_6818_p1.read().is_01() || !shl_ln3_fu_6822_p3.read().is_01())? sc_lv<6>(): (sc_biguint<6>(zext_ln591_fu_6818_p1.read()) + sc_biguint<6>(shl_ln3_fu_6822_p3.read()));
}

void kernel_3mm_nonP::thread_add_ln596_fu_7386_p2() {
    add_ln596_fu_7386_p2 = (!sub_ln596_fu_7095_p2.read().is_01() || !zext_ln596_1_fu_7382_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(sub_ln596_fu_7095_p2.read()) + sc_biguint<8>(zext_ln596_1_fu_7382_p1.read()));
}

void kernel_3mm_nonP::thread_add_ln598_fu_7652_p2() {
    add_ln598_fu_7652_p2 = (!sub_ln598_fu_7646_p2.read().is_01() || !zext_ln596_1_reg_9347.read().is_01())? sc_lv<8>(): (sc_biguint<8>(sub_ln598_fu_7646_p2.read()) + sc_biguint<8>(zext_ln596_1_reg_9347.read()));
}

void kernel_3mm_nonP::thread_add_ln59_fu_6023_p2() {
    add_ln59_fu_6023_p2 = (!ap_phi_mux_indvar_flatten37_phi_fu_4306_p4.read().is_01() || !ap_const_lv12_1.is_01())? sc_lv<12>(): (sc_biguint<12>(ap_phi_mux_indvar_flatten37_phi_fu_4306_p4.read()) + sc_biguint<12>(ap_const_lv12_1));
}

void kernel_3mm_nonP::thread_add_ln60_1_fu_6264_p2() {
    add_ln60_1_fu_6264_p2 = (!ap_phi_mux_indvar_flatten_phi_fu_4328_p4.read().is_01() || !ap_const_lv8_1.is_01())? sc_lv<8>(): (sc_biguint<8>(ap_phi_mux_indvar_flatten_phi_fu_4328_p4.read()) + sc_biguint<8>(ap_const_lv8_1));
}

void kernel_3mm_nonP::thread_add_ln63_1_fu_6167_p2() {
    add_ln63_1_fu_6167_p2 = (!zext_ln64_fu_6083_p1.read().is_01() || !add_ln63_fu_6161_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln64_fu_6083_p1.read()) + sc_biguint<8>(add_ln63_fu_6161_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln63_fu_6161_p2() {
    add_ln63_fu_6161_p2 = (!zext_ln63_fu_6145_p1.read().is_01() || !zext_ln63_1_fu_6157_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln63_fu_6145_p1.read()) + sc_biguint<8>(zext_ln63_1_fu_6157_p1.read()));
}

void kernel_3mm_nonP::thread_add_ln646_1_fu_7258_p2() {
    add_ln646_1_fu_7258_p2 = (!ap_const_lv6_1.is_01() || !add_ln595_4_fu_7235_p2.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_1) + sc_biguint<6>(add_ln595_4_fu_7235_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln646_fu_6983_p2() {
    add_ln646_fu_6983_p2 = (!ap_const_lv6_1.is_01() || !add_ln595_1_fu_6972_p2.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_1) + sc_biguint<6>(add_ln595_1_fu_6972_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln66_1_fu_6360_p2() {
    add_ln66_1_fu_6360_p2 = (!zext_ln66_3_fu_6356_p1.read().is_01() || !add_ln66_fu_6347_p2.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln66_3_fu_6356_p1.read()) + sc_biguint<7>(add_ln66_fu_6347_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln66_fu_6347_p2() {
    add_ln66_fu_6347_p2 = (!zext_ln66_fu_6332_p1.read().is_01() || !zext_ln66_1_fu_6343_p1.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln66_fu_6332_p1.read()) + sc_biguint<7>(zext_ln66_1_fu_6343_p1.read()));
}

void kernel_3mm_nonP::thread_add_ln692_1_fu_7264_p2() {
    add_ln692_1_fu_7264_p2 = (!ap_const_lv6_2.is_01() || !add_ln595_4_fu_7235_p2.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_2) + sc_biguint<6>(add_ln595_4_fu_7235_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln692_fu_6989_p2() {
    add_ln692_fu_6989_p2 = (!ap_const_lv6_2.is_01() || !add_ln595_1_fu_6972_p2.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_2) + sc_biguint<6>(add_ln595_1_fu_6972_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln738_1_fu_7270_p2() {
    add_ln738_1_fu_7270_p2 = (!ap_const_lv6_3.is_01() || !add_ln595_4_fu_7235_p2.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_3) + sc_biguint<6>(add_ln595_4_fu_7235_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln738_fu_6995_p2() {
    add_ln738_fu_6995_p2 = (!ap_const_lv6_3.is_01() || !add_ln595_1_fu_6972_p2.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_3) + sc_biguint<6>(add_ln595_1_fu_6972_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln76_fu_6387_p2() {
    add_ln76_fu_6387_p2 = (!zext_ln76_1_fu_6383_p1.read().is_01() || !add_ln66_fu_6347_p2.read().is_01())? sc_lv<7>(): (sc_biguint<7>(zext_ln76_1_fu_6383_p1.read()) + sc_biguint<7>(add_ln66_fu_6347_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln784_1_fu_7276_p2() {
    add_ln784_1_fu_7276_p2 = (!ap_const_lv6_4.is_01() || !add_ln595_4_fu_7235_p2.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_4) + sc_biguint<6>(add_ln595_4_fu_7235_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln784_fu_7001_p2() {
    add_ln784_fu_7001_p2 = (!ap_const_lv6_4.is_01() || !add_ln595_1_fu_6972_p2.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_4) + sc_biguint<6>(add_ln595_1_fu_6972_p2.read()));
}

void kernel_3mm_nonP::thread_add_ln831_fu_7459_p2() {
    add_ln831_fu_7459_p2 = (!sub_ln831_fu_7428_p2.read().is_01() || !zext_ln596_1_reg_9347.read().is_01())? sc_lv<8>(): (sc_biguint<8>(sub_ln831_fu_7428_p2.read()) + sc_biguint<8>(zext_ln596_1_reg_9347.read()));
}

void kernel_3mm_nonP::thread_add_ln891_fu_7506_p2() {
    add_ln891_fu_7506_p2 = (!sub_ln891_fu_7500_p2.read().is_01() || !zext_ln596_1_reg_9347.read().is_01())? sc_lv<8>(): (sc_biguint<8>(sub_ln891_fu_7500_p2.read()) + sc_biguint<8>(zext_ln596_1_reg_9347.read()));
}

void kernel_3mm_nonP::thread_add_ln951_fu_7969_p2() {
    add_ln951_fu_7969_p2 = (!sub_ln951_fu_7908_p2.read().is_01() || !zext_ln596_1_reg_9347_pp2_iter1_reg.read().is_01())? sc_lv<8>(): (sc_biguint<8>(sub_ln951_fu_7908_p2.read()) + sc_biguint<8>(zext_ln596_1_reg_9347_pp2_iter1_reg.read()));
}

void kernel_3mm_nonP::thread_and_ln329_fu_6496_p2() {
    and_ln329_fu_6496_p2 = (icmp_ln322_fu_6490_p2.read() & xor_ln329_fu_6484_p2.read());
}

void kernel_3mm_nonP::thread_and_ln591_fu_7179_p2() {
    and_ln591_fu_7179_p2 = (icmp_ln593_fu_7173_p2.read() & xor_ln591_fu_7168_p2.read());
}

void kernel_3mm_nonP::thread_and_ln59_fu_6103_p2() {
    and_ln59_fu_6103_p2 = (icmp_ln61_fu_6097_p2.read() & xor_ln59_fu_6091_p2.read());
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage0() {
    ap_CS_fsm_pp0_stage0 = ap_CS_fsm.read()[1];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage1() {
    ap_CS_fsm_pp0_stage1 = ap_CS_fsm.read()[2];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage10() {
    ap_CS_fsm_pp0_stage10 = ap_CS_fsm.read()[11];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage11() {
    ap_CS_fsm_pp0_stage11 = ap_CS_fsm.read()[12];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage12() {
    ap_CS_fsm_pp0_stage12 = ap_CS_fsm.read()[13];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage2() {
    ap_CS_fsm_pp0_stage2 = ap_CS_fsm.read()[3];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage3() {
    ap_CS_fsm_pp0_stage3 = ap_CS_fsm.read()[4];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage4() {
    ap_CS_fsm_pp0_stage4 = ap_CS_fsm.read()[5];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage5() {
    ap_CS_fsm_pp0_stage5 = ap_CS_fsm.read()[6];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage6() {
    ap_CS_fsm_pp0_stage6 = ap_CS_fsm.read()[7];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage7() {
    ap_CS_fsm_pp0_stage7 = ap_CS_fsm.read()[8];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage8() {
    ap_CS_fsm_pp0_stage8 = ap_CS_fsm.read()[9];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp0_stage9() {
    ap_CS_fsm_pp0_stage9 = ap_CS_fsm.read()[10];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage0() {
    ap_CS_fsm_pp1_stage0 = ap_CS_fsm.read()[15];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage1() {
    ap_CS_fsm_pp1_stage1 = ap_CS_fsm.read()[16];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage2() {
    ap_CS_fsm_pp1_stage2 = ap_CS_fsm.read()[17];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage3() {
    ap_CS_fsm_pp1_stage3 = ap_CS_fsm.read()[18];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage4() {
    ap_CS_fsm_pp1_stage4 = ap_CS_fsm.read()[19];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage5() {
    ap_CS_fsm_pp1_stage5 = ap_CS_fsm.read()[20];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage6() {
    ap_CS_fsm_pp1_stage6 = ap_CS_fsm.read()[21];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage7() {
    ap_CS_fsm_pp1_stage7 = ap_CS_fsm.read()[22];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage8() {
    ap_CS_fsm_pp1_stage8 = ap_CS_fsm.read()[23];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp1_stage9() {
    ap_CS_fsm_pp1_stage9 = ap_CS_fsm.read()[24];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage0() {
    ap_CS_fsm_pp2_stage0 = ap_CS_fsm.read()[26];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage1() {
    ap_CS_fsm_pp2_stage1 = ap_CS_fsm.read()[27];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage2() {
    ap_CS_fsm_pp2_stage2 = ap_CS_fsm.read()[28];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage3() {
    ap_CS_fsm_pp2_stage3 = ap_CS_fsm.read()[29];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage4() {
    ap_CS_fsm_pp2_stage4 = ap_CS_fsm.read()[30];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage5() {
    ap_CS_fsm_pp2_stage5 = ap_CS_fsm.read()[31];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage6() {
    ap_CS_fsm_pp2_stage6 = ap_CS_fsm.read()[32];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage7() {
    ap_CS_fsm_pp2_stage7 = ap_CS_fsm.read()[33];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage8() {
    ap_CS_fsm_pp2_stage8 = ap_CS_fsm.read()[34];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_pp2_stage9() {
    ap_CS_fsm_pp2_stage9 = ap_CS_fsm.read()[35];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_state1() {
    ap_CS_fsm_state1 = ap_CS_fsm.read()[0];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_state25() {
    ap_CS_fsm_state25 = ap_CS_fsm.read()[14];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_state47() {
    ap_CS_fsm_state47 = ap_CS_fsm.read()[25];
}

void kernel_3mm_nonP::thread_ap_CS_fsm_state84() {
    ap_CS_fsm_state84 = ap_CS_fsm.read()[36];
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage0_subdone() {
    ap_block_pp0_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage1() {
    ap_block_pp0_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage10() {
    ap_block_pp0_stage10 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage10_11001() {
    ap_block_pp0_stage10_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage10_subdone() {
    ap_block_pp0_stage10_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage11() {
    ap_block_pp0_stage11 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage11_11001() {
    ap_block_pp0_stage11_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage11_subdone() {
    ap_block_pp0_stage11_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage12() {
    ap_block_pp0_stage12 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage12_11001() {
    ap_block_pp0_stage12_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage12_subdone() {
    ap_block_pp0_stage12_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage1_11001() {
    ap_block_pp0_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage1_subdone() {
    ap_block_pp0_stage1_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage2() {
    ap_block_pp0_stage2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage2_11001() {
    ap_block_pp0_stage2_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage2_subdone() {
    ap_block_pp0_stage2_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage3() {
    ap_block_pp0_stage3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage3_11001() {
    ap_block_pp0_stage3_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage3_subdone() {
    ap_block_pp0_stage3_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage4() {
    ap_block_pp0_stage4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage4_11001() {
    ap_block_pp0_stage4_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage4_subdone() {
    ap_block_pp0_stage4_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage5() {
    ap_block_pp0_stage5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage5_11001() {
    ap_block_pp0_stage5_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage5_subdone() {
    ap_block_pp0_stage5_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage6() {
    ap_block_pp0_stage6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage6_11001() {
    ap_block_pp0_stage6_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage6_subdone() {
    ap_block_pp0_stage6_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage7() {
    ap_block_pp0_stage7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage7_11001() {
    ap_block_pp0_stage7_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage7_subdone() {
    ap_block_pp0_stage7_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage8() {
    ap_block_pp0_stage8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage8_11001() {
    ap_block_pp0_stage8_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage8_subdone() {
    ap_block_pp0_stage8_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage9() {
    ap_block_pp0_stage9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage9_11001() {
    ap_block_pp0_stage9_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp0_stage9_subdone() {
    ap_block_pp0_stage9_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage0() {
    ap_block_pp1_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage0_11001() {
    ap_block_pp1_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage0_subdone() {
    ap_block_pp1_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage1() {
    ap_block_pp1_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage1_11001() {
    ap_block_pp1_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage1_subdone() {
    ap_block_pp1_stage1_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage2() {
    ap_block_pp1_stage2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage2_11001() {
    ap_block_pp1_stage2_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage2_subdone() {
    ap_block_pp1_stage2_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage3() {
    ap_block_pp1_stage3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage3_11001() {
    ap_block_pp1_stage3_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage3_subdone() {
    ap_block_pp1_stage3_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage4() {
    ap_block_pp1_stage4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage4_11001() {
    ap_block_pp1_stage4_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage4_subdone() {
    ap_block_pp1_stage4_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage5() {
    ap_block_pp1_stage5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage5_11001() {
    ap_block_pp1_stage5_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage5_subdone() {
    ap_block_pp1_stage5_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage6() {
    ap_block_pp1_stage6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage6_11001() {
    ap_block_pp1_stage6_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage6_subdone() {
    ap_block_pp1_stage6_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage7() {
    ap_block_pp1_stage7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage7_11001() {
    ap_block_pp1_stage7_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage7_subdone() {
    ap_block_pp1_stage7_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage8() {
    ap_block_pp1_stage8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage8_11001() {
    ap_block_pp1_stage8_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage8_subdone() {
    ap_block_pp1_stage8_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage9() {
    ap_block_pp1_stage9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage9_11001() {
    ap_block_pp1_stage9_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp1_stage9_subdone() {
    ap_block_pp1_stage9_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage0() {
    ap_block_pp2_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage0_11001() {
    ap_block_pp2_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage0_subdone() {
    ap_block_pp2_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage1() {
    ap_block_pp2_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage1_11001() {
    ap_block_pp2_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage1_subdone() {
    ap_block_pp2_stage1_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage2() {
    ap_block_pp2_stage2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage2_11001() {
    ap_block_pp2_stage2_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage2_subdone() {
    ap_block_pp2_stage2_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage3() {
    ap_block_pp2_stage3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage3_11001() {
    ap_block_pp2_stage3_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage3_subdone() {
    ap_block_pp2_stage3_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage4() {
    ap_block_pp2_stage4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage4_11001() {
    ap_block_pp2_stage4_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage4_subdone() {
    ap_block_pp2_stage4_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage5() {
    ap_block_pp2_stage5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage5_11001() {
    ap_block_pp2_stage5_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage5_subdone() {
    ap_block_pp2_stage5_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage6() {
    ap_block_pp2_stage6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage6_11001() {
    ap_block_pp2_stage6_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage6_subdone() {
    ap_block_pp2_stage6_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage7() {
    ap_block_pp2_stage7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage7_11001() {
    ap_block_pp2_stage7_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage7_subdone() {
    ap_block_pp2_stage7_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage8() {
    ap_block_pp2_stage8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage8_11001() {
    ap_block_pp2_stage8_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage8_subdone() {
    ap_block_pp2_stage8_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage9() {
    ap_block_pp2_stage9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage9_11001() {
    ap_block_pp2_stage9_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_pp2_stage9_subdone() {
    ap_block_pp2_stage9_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state10_pp0_stage8_iter0() {
    ap_block_state10_pp0_stage8_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state11_pp0_stage9_iter0() {
    ap_block_state11_pp0_stage9_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state12_pp0_stage10_iter0() {
    ap_block_state12_pp0_stage10_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state13_pp0_stage11_iter0() {
    ap_block_state13_pp0_stage11_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state14_pp0_stage12_iter0() {
    ap_block_state14_pp0_stage12_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state15_pp0_stage0_iter1() {
    ap_block_state15_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state16_pp0_stage1_iter1() {
    ap_block_state16_pp0_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state17_pp0_stage2_iter1() {
    ap_block_state17_pp0_stage2_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state18_pp0_stage3_iter1() {
    ap_block_state18_pp0_stage3_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state19_pp0_stage4_iter1() {
    ap_block_state19_pp0_stage4_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state20_pp0_stage5_iter1() {
    ap_block_state20_pp0_stage5_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state21_pp0_stage6_iter1() {
    ap_block_state21_pp0_stage6_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state22_pp0_stage7_iter1() {
    ap_block_state22_pp0_stage7_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state23_pp0_stage8_iter1() {
    ap_block_state23_pp0_stage8_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state24_pp0_stage9_iter1() {
    ap_block_state24_pp0_stage9_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state26_pp1_stage0_iter0() {
    ap_block_state26_pp1_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state27_pp1_stage1_iter0() {
    ap_block_state27_pp1_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state28_pp1_stage2_iter0() {
    ap_block_state28_pp1_stage2_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state29_pp1_stage3_iter0() {
    ap_block_state29_pp1_stage3_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state2_pp0_stage0_iter0() {
    ap_block_state2_pp0_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state30_pp1_stage4_iter0() {
    ap_block_state30_pp1_stage4_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state31_pp1_stage5_iter0() {
    ap_block_state31_pp1_stage5_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state32_pp1_stage6_iter0() {
    ap_block_state32_pp1_stage6_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state33_pp1_stage7_iter0() {
    ap_block_state33_pp1_stage7_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state34_pp1_stage8_iter0() {
    ap_block_state34_pp1_stage8_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state35_pp1_stage9_iter0() {
    ap_block_state35_pp1_stage9_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state36_pp1_stage0_iter1() {
    ap_block_state36_pp1_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state37_pp1_stage1_iter1() {
    ap_block_state37_pp1_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state38_pp1_stage2_iter1() {
    ap_block_state38_pp1_stage2_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state39_pp1_stage3_iter1() {
    ap_block_state39_pp1_stage3_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state3_pp0_stage1_iter0() {
    ap_block_state3_pp0_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state40_pp1_stage4_iter1() {
    ap_block_state40_pp1_stage4_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state41_pp1_stage5_iter1() {
    ap_block_state41_pp1_stage5_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state42_pp1_stage6_iter1() {
    ap_block_state42_pp1_stage6_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state43_pp1_stage7_iter1() {
    ap_block_state43_pp1_stage7_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state44_pp1_stage8_iter1() {
    ap_block_state44_pp1_stage8_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state45_pp1_stage9_iter1() {
    ap_block_state45_pp1_stage9_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state46_pp1_stage0_iter2() {
    ap_block_state46_pp1_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state48_pp2_stage0_iter0() {
    ap_block_state48_pp2_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state49_pp2_stage1_iter0() {
    ap_block_state49_pp2_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state4_pp0_stage2_iter0() {
    ap_block_state4_pp0_stage2_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state50_pp2_stage2_iter0() {
    ap_block_state50_pp2_stage2_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state51_pp2_stage3_iter0() {
    ap_block_state51_pp2_stage3_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state52_pp2_stage4_iter0() {
    ap_block_state52_pp2_stage4_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state53_pp2_stage5_iter0() {
    ap_block_state53_pp2_stage5_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state54_pp2_stage6_iter0() {
    ap_block_state54_pp2_stage6_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state55_pp2_stage7_iter0() {
    ap_block_state55_pp2_stage7_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state56_pp2_stage8_iter0() {
    ap_block_state56_pp2_stage8_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state57_pp2_stage9_iter0() {
    ap_block_state57_pp2_stage9_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state58_pp2_stage0_iter1() {
    ap_block_state58_pp2_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state59_pp2_stage1_iter1() {
    ap_block_state59_pp2_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state5_pp0_stage3_iter0() {
    ap_block_state5_pp0_stage3_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state60_pp2_stage2_iter1() {
    ap_block_state60_pp2_stage2_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state61_pp2_stage3_iter1() {
    ap_block_state61_pp2_stage3_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state62_pp2_stage4_iter1() {
    ap_block_state62_pp2_stage4_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state63_pp2_stage5_iter1() {
    ap_block_state63_pp2_stage5_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state64_pp2_stage6_iter1() {
    ap_block_state64_pp2_stage6_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state65_pp2_stage7_iter1() {
    ap_block_state65_pp2_stage7_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state66_pp2_stage8_iter1() {
    ap_block_state66_pp2_stage8_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state67_pp2_stage9_iter1() {
    ap_block_state67_pp2_stage9_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state68_pp2_stage0_iter2() {
    ap_block_state68_pp2_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state69_pp2_stage1_iter2() {
    ap_block_state69_pp2_stage1_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state6_pp0_stage4_iter0() {
    ap_block_state6_pp0_stage4_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state70_pp2_stage2_iter2() {
    ap_block_state70_pp2_stage2_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state71_pp2_stage3_iter2() {
    ap_block_state71_pp2_stage3_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state72_pp2_stage4_iter2() {
    ap_block_state72_pp2_stage4_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state73_pp2_stage5_iter2() {
    ap_block_state73_pp2_stage5_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state74_pp2_stage6_iter2() {
    ap_block_state74_pp2_stage6_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state75_pp2_stage7_iter2() {
    ap_block_state75_pp2_stage7_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state76_pp2_stage8_iter2() {
    ap_block_state76_pp2_stage8_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state77_pp2_stage9_iter2() {
    ap_block_state77_pp2_stage9_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state78_pp2_stage0_iter3() {
    ap_block_state78_pp2_stage0_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state79_pp2_stage1_iter3() {
    ap_block_state79_pp2_stage1_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state7_pp0_stage5_iter0() {
    ap_block_state7_pp0_stage5_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state80_pp2_stage2_iter3() {
    ap_block_state80_pp2_stage2_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state81_pp2_stage3_iter3() {
    ap_block_state81_pp2_stage3_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state82_pp2_stage4_iter3() {
    ap_block_state82_pp2_stage4_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state83_pp2_stage5_iter3() {
    ap_block_state83_pp2_stage5_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state8_pp0_stage6_iter0() {
    ap_block_state8_pp0_stage6_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_block_state9_pp0_stage7_iter0() {
    ap_block_state9_pp0_stage7_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void kernel_3mm_nonP::thread_ap_condition_4933() {
    ap_condition_4933 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0));
}

void kernel_3mm_nonP::thread_ap_condition_4959() {
    ap_condition_4959 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0));
}

void kernel_3mm_nonP::thread_ap_condition_4988() {
    ap_condition_4988 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0));
}

void kernel_3mm_nonP::thread_ap_condition_5000() {
    ap_condition_5000 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0));
}

void kernel_3mm_nonP::thread_ap_condition_5012() {
    ap_condition_5012 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0));
}

void kernel_3mm_nonP::thread_ap_condition_5024() {
    ap_condition_5024 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0));
}

void kernel_3mm_nonP::thread_ap_condition_5116() {
    ap_condition_5116 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0));
}

void kernel_3mm_nonP::thread_ap_condition_5122() {
    ap_condition_5122 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0));
}

void kernel_3mm_nonP::thread_ap_condition_5128() {
    ap_condition_5128 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0));
}

void kernel_3mm_nonP::thread_ap_condition_pp0_exit_iter0_state2() {
    if (esl_seteq<1,1,1>(icmp_ln59_fu_6017_p2.read(), ap_const_lv1_1)) {
        ap_condition_pp0_exit_iter0_state2 = ap_const_logic_1;
    } else {
        ap_condition_pp0_exit_iter0_state2 = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_ap_condition_pp1_exit_iter0_state26() {
    if (esl_seteq<1,1,1>(icmp_ln320_fu_6416_p2.read(), ap_const_lv1_1)) {
        ap_condition_pp1_exit_iter0_state26 = ap_const_logic_1;
    } else {
        ap_condition_pp1_exit_iter0_state26 = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_ap_condition_pp2_exit_iter0_state57() {
    if (esl_seteq<1,1,1>(icmp_ln591_reg_9201.read(), ap_const_lv1_1)) {
        ap_condition_pp2_exit_iter0_state57 = ap_const_logic_1;
    } else {
        ap_condition_pp2_exit_iter0_state57 = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_ap_done() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state84.read())) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void kernel_3mm_nonP::thread_ap_enable_pp1() {
    ap_enable_pp1 = (ap_idle_pp1.read() ^ ap_const_logic_1);
}

void kernel_3mm_nonP::thread_ap_enable_pp2() {
    ap_enable_pp2 = (ap_idle_pp2.read() ^ ap_const_logic_1);
}

void kernel_3mm_nonP::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_ap_idle_pp1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter2.read()))) {
        ap_idle_pp1 = ap_const_logic_1;
    } else {
        ap_idle_pp1 = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_ap_idle_pp2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp2_iter3.read()))) {
        ap_idle_pp2 = ap_const_logic_1;
    } else {
        ap_idle_pp2 = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_indvar_flatten183_phi_fu_4416_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten183_phi_fu_4416_p4 = add_ln591_4_reg_9779.read();
    } else {
        ap_phi_mux_indvar_flatten183_phi_fu_4416_p4 = indvar_flatten183_reg_4412.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_indvar_flatten37_phi_fu_4306_p4() {
    if ((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten37_phi_fu_4306_p4 = add_ln59_reg_8119.read();
    } else {
        ap_phi_mux_indvar_flatten37_phi_fu_4306_p4 = indvar_flatten37_reg_4302.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_indvar_flatten64_phi_fu_4383_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten64_phi_fu_4383_p4 = select_ln321_reg_8867.read();
    } else {
        ap_phi_mux_indvar_flatten64_phi_fu_4383_p4 = indvar_flatten64_reg_4379.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_indvar_flatten78_phi_fu_4361_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten78_phi_fu_4361_p4 = add_ln320_reg_8704.read();
    } else {
        ap_phi_mux_indvar_flatten78_phi_fu_4361_p4 = indvar_flatten78_reg_4357.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_indvar_flatten85_phi_fu_4439_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten85_phi_fu_4439_p4 = select_ln592_8_reg_9253.read();
    } else {
        ap_phi_mux_indvar_flatten85_phi_fu_4439_p4 = indvar_flatten85_reg_4435.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_indvar_flatten_phi_fu_4328_p4() {
    if ((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_indvar_flatten_phi_fu_4328_p4 = select_ln60_reg_8322.read();
    } else {
        ap_phi_mux_indvar_flatten_phi_fu_4328_p4 = indvar_flatten_reg_4324.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_v10_0_phi_fu_4350_p4() {
    if ((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v10_0_phi_fu_4350_p4 = v10_reg_8317.read();
    } else {
        ap_phi_mux_v10_0_phi_fu_4350_p4 = v10_0_reg_4346.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_v169_0_phi_fu_4372_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v169_0_phi_fu_4372_p4 = select_ln329_2_reg_8718.read();
    } else {
        ap_phi_mux_v169_0_phi_fu_4372_p4 = v169_0_reg_4368.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_v170_0_phi_fu_4394_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v170_0_phi_fu_4394_p4 = select_ln324_1_reg_8723.read();
    } else {
        ap_phi_mux_v170_0_phi_fu_4394_p4 = v170_0_reg_4390.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_v171_0_phi_fu_4405_p4() {
    if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v171_0_phi_fu_4405_p4 = v171_reg_8862.read();
    } else {
        ap_phi_mux_v171_0_phi_fu_4405_p4 = v171_0_reg_4401.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_v316_0_phi_fu_4428_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v316_0_phi_fu_4428_p4 = select_ln591_10_reg_9245.read();
    } else {
        ap_phi_mux_v316_0_phi_fu_4428_p4 = v316_0_reg_4424.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_v317_0_phi_fu_4450_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v317_0_phi_fu_4450_p4 = select_ln592_2_reg_9305.read();
    } else {
        ap_phi_mux_v317_0_phi_fu_4450_p4 = v317_0_reg_4446.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_v318_0_phi_fu_4462_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        ap_phi_mux_v318_0_phi_fu_4462_p4 = v318_reg_9954.read();
    } else {
        ap_phi_mux_v318_0_phi_fu_4462_p4 = v318_0_reg_4458.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_v8_0_phi_fu_4317_p4() {
    if ((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v8_0_phi_fu_4317_p4 = select_ln59_2_reg_8132.read();
    } else {
        ap_phi_mux_v8_0_phi_fu_4317_p4 = v8_0_reg_4313.read();
    }
}

void kernel_3mm_nonP::thread_ap_phi_mux_v9_0_phi_fu_4339_p4() {
    if ((esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_v9_0_phi_fu_4339_p4 = select_ln63_1_reg_8137.read();
    } else {
        ap_phi_mux_v9_0_phi_fu_4339_p4 = v9_0_reg_4335.read();
    }
}

void kernel_3mm_nonP::thread_ap_ready() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state84.read())) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_ap_rst_n_inv() {
    ap_rst_n_inv =  (sc_logic) (~ap_rst_n.read());
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4874_ap_start() {
    grp_aesl_mux_load_5_5_x_1_fu_4874_ap_start = grp_aesl_mux_load_5_5_x_1_fu_4874_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4874_empty() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty = trunc_ln76_1_reg_8350.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty = trunc_ln66_2_reg_8309.read();
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty = "XXXX";
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Dout_A = v4_4_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Dout_A = v4_0_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Dout_A = v4_4_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Dout_A = v4_0_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Dout_A = v4_4_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Dout_A = v4_0_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Dout_A = v4_4_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Dout_A = v4_0_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Dout_A = v4_4_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Dout_A = v4_0_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Dout_A = v4_4_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Dout_A = v4_0_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Dout_A = v4_4_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Dout_A = v4_0_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Dout_A = v4_4_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Dout_A = v4_0_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Dout_A = v4_4_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Dout_A = v4_0_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Dout_A = v4_4_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Dout_A = v4_0_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4874_empty_23() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty_23 = trunc_ln66_1_reg_8524.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty_23 = trunc_ln66_1_fu_6317_p1.read();
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4874_empty_23 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4891_ap_start() {
    grp_aesl_mux_load_5_5_x_1_fu_4891_ap_start = grp_aesl_mux_load_5_5_x_1_fu_4891_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4891_empty() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty = trunc_ln76_1_reg_8350.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty = trunc_ln66_2_reg_8309.read();
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty = "XXXX";
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Dout_A = v4_5_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Dout_A = v4_1_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Dout_A = v4_5_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Dout_A = v4_1_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Dout_A = v4_5_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Dout_A = v4_1_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Dout_A = v4_5_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Dout_A = v4_1_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Dout_A = v4_5_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Dout_A = v4_1_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Dout_A = v4_5_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Dout_A = v4_1_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Dout_A = v4_5_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Dout_A = v4_1_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Dout_A = v4_5_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Dout_A = v4_1_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Dout_A = v4_5_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Dout_A = v4_1_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Dout_A = v4_5_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Dout_A = v4_1_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4891_empty_23() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty_23 = trunc_ln66_1_reg_8524.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty_23 = trunc_ln66_1_fu_6317_p1.read();
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4891_empty_23 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4908_ap_start() {
    grp_aesl_mux_load_5_5_x_1_fu_4908_ap_start = grp_aesl_mux_load_5_5_x_1_fu_4908_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4908_empty() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty = trunc_ln76_1_reg_8350.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty = trunc_ln66_2_reg_8309.read();
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty = "XXXX";
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Dout_A = v4_6_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Dout_A = v4_2_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Dout_A = v4_6_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Dout_A = v4_2_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Dout_A = v4_6_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Dout_A = v4_2_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Dout_A = v4_6_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Dout_A = v4_2_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Dout_A = v4_6_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Dout_A = v4_2_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Dout_A = v4_6_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Dout_A = v4_2_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Dout_A = v4_6_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Dout_A = v4_2_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Dout_A = v4_6_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Dout_A = v4_2_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Dout_A = v4_6_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Dout_A = v4_2_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Dout_A = v4_6_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Dout_A = v4_2_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4908_empty_23() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty_23 = trunc_ln66_1_reg_8524.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty_23 = trunc_ln66_1_fu_6317_p1.read();
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4908_empty_23 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4925_ap_start() {
    grp_aesl_mux_load_5_5_x_1_fu_4925_ap_start = grp_aesl_mux_load_5_5_x_1_fu_4925_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4925_empty() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty = trunc_ln76_1_reg_8350.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty = trunc_ln66_2_reg_8309.read();
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty = "XXXX";
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Dout_A = v4_7_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Dout_A = v4_3_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Dout_A = v4_7_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Dout_A = v4_3_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty_18_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Dout_A = v4_7_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Dout_A = v4_3_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Dout_A = v4_7_1_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Dout_A = v4_3_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty_19_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Dout_A = v4_7_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Dout_A = v4_3_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Dout_A = v4_7_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Dout_A = v4_3_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty_20_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Dout_A = v4_7_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Dout_A = v4_3_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Dout_A = v4_7_3_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Dout_A = v4_3_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty_21_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Dout_A() {
    if (esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0)) {
        if (esl_seteq<1,1,1>(ap_condition_4933.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Dout_A = v4_7_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5128.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Dout_A = v4_3_0_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5122.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Dout_A = v4_7_4_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5116.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Dout_A = v4_3_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty_22_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_1_fu_4925_empty_23() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty_23 = trunc_ln66_1_reg_8524.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(icmp_ln59_reg_8115.read(), ap_const_lv1_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty_23 = trunc_ln66_1_fu_6317_p1.read();
    } else {
        grp_aesl_mux_load_5_5_x_1_fu_4925_empty_23 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4714_ap_start() {
    grp_aesl_mux_load_5_5_x_s_fu_4714_ap_start = grp_aesl_mux_load_5_5_x_s_fu_4714_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4714_empty() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty = trunc_ln337_1_reg_9048.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty = trunc_ln327_2_reg_9034.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty = mul_ln327_fu_6642_p2.read().range(14, 10);
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty =  (sc_lv<5>) ("XXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Dout_A = v5_5_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Dout_A = v5_0_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Dout_A = v5_5_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Dout_A = v5_0_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Dout_A = v5_5_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Dout_A = v5_0_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Dout_A = v5_5_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Dout_A = v5_0_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Dout_A = v5_5_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Dout_A = v5_0_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Dout_A = v5_5_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Dout_A = v5_0_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Dout_A = v5_5_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Dout_A = v5_0_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Dout_A = v5_5_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Dout_A = v5_0_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Dout_A = v5_5_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Dout_A = v5_0_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Dout_A = v5_5_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Dout_A = v5_0_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4714_empty_30() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_30 = trunc_ln327_1_reg_9025.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_30 = trunc_ln327_1_fu_6658_p1.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_30 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4714_empty_31() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_31 = select_ln324_1_reg_8723_pp1_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_31 = select_ln324_1_reg_8723.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4714_empty_31 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4731_ap_start() {
    grp_aesl_mux_load_5_5_x_s_fu_4731_ap_start = grp_aesl_mux_load_5_5_x_s_fu_4731_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4731_empty() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty = trunc_ln337_1_reg_9048.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty = trunc_ln327_2_reg_9034.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty = mul_ln327_fu_6642_p2.read().range(14, 10);
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty =  (sc_lv<5>) ("XXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Dout_A = v5_6_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Dout_A = v5_1_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Dout_A = v5_6_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Dout_A = v5_1_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Dout_A = v5_6_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Dout_A = v5_1_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Dout_A = v5_6_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Dout_A = v5_1_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Dout_A = v5_6_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Dout_A = v5_1_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Dout_A = v5_6_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Dout_A = v5_1_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Dout_A = v5_6_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Dout_A = v5_1_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Dout_A = v5_6_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Dout_A = v5_1_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Dout_A = v5_6_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Dout_A = v5_1_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Dout_A = v5_6_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Dout_A = v5_1_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4731_empty_30() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_30 = trunc_ln327_1_reg_9025.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_30 = trunc_ln327_1_fu_6658_p1.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_30 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4731_empty_31() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_31 = select_ln324_1_reg_8723_pp1_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_31 = select_ln324_1_reg_8723.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4731_empty_31 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4748_ap_start() {
    grp_aesl_mux_load_5_5_x_s_fu_4748_ap_start = grp_aesl_mux_load_5_5_x_s_fu_4748_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4748_empty() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty = trunc_ln337_1_reg_9048.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty = trunc_ln327_2_reg_9034.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty = mul_ln327_fu_6642_p2.read().range(14, 10);
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty =  (sc_lv<5>) ("XXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Dout_A = v5_7_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Dout_A = v5_2_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Dout_A = v5_7_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Dout_A = v5_2_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Dout_A = v5_7_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Dout_A = v5_2_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Dout_A = v5_7_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Dout_A = v5_2_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Dout_A = v5_7_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Dout_A = v5_2_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Dout_A = v5_7_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Dout_A = v5_2_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Dout_A = v5_7_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Dout_A = v5_2_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Dout_A = v5_7_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Dout_A = v5_2_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Dout_A = v5_7_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Dout_A = v5_2_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Dout_A = v5_7_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Dout_A = v5_2_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4748_empty_30() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_30 = trunc_ln327_1_reg_9025.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_30 = trunc_ln327_1_fu_6658_p1.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_30 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4748_empty_31() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_31 = select_ln324_1_reg_8723_pp1_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_31 = select_ln324_1_reg_8723.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4748_empty_31 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4765_ap_start() {
    grp_aesl_mux_load_5_5_x_s_fu_4765_ap_start = grp_aesl_mux_load_5_5_x_s_fu_4765_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4765_empty() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty = trunc_ln337_1_reg_9048.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty = trunc_ln327_2_reg_9034.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty = mul_ln327_fu_6642_p2.read().range(14, 10);
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty =  (sc_lv<5>) ("XXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Dout_A = v5_8_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Dout_A = v5_3_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Dout_A = v5_8_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Dout_A = v5_3_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Dout_A = v5_8_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Dout_A = v5_3_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Dout_A = v5_8_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Dout_A = v5_3_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Dout_A = v5_8_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Dout_A = v5_3_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Dout_A = v5_8_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Dout_A = v5_3_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Dout_A = v5_8_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Dout_A = v5_3_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Dout_A = v5_8_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Dout_A = v5_3_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Dout_A = v5_8_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Dout_A = v5_3_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Dout_A = v5_8_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Dout_A = v5_3_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4765_empty_30() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_30 = trunc_ln327_1_reg_9025.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_30 = trunc_ln327_1_fu_6658_p1.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_30 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4765_empty_31() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_31 = select_ln324_1_reg_8723_pp1_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_31 = select_ln324_1_reg_8723.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4765_empty_31 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4782_ap_start() {
    grp_aesl_mux_load_5_5_x_s_fu_4782_ap_start = grp_aesl_mux_load_5_5_x_s_fu_4782_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4782_empty() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty = trunc_ln337_1_reg_9048.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty = trunc_ln327_2_reg_9034.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty = mul_ln327_fu_6642_p2.read().range(14, 10);
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty =  (sc_lv<5>) ("XXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Dout_A = v5_9_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Dout_A = v5_4_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Dout_A = v5_9_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Dout_A = v5_4_0_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_25_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Dout_A = v5_9_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Dout_A = v5_4_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Dout_A = v5_9_1_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Dout_A = v5_4_1_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_26_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Dout_A = v5_9_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Dout_A = v5_4_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Dout_A = v5_9_2_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Dout_A = v5_4_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_27_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Dout_A = v5_9_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Dout_A = v5_4_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Dout_A = v5_9_3_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Dout_A = v5_4_3_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_28_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Dout_A = v5_9_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Dout_A = v5_4_0_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Dout_A = v5_9_4_Dout_A.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Dout_A = v5_4_4_Dout_A.read();
        } else {
            grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_29_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4782_empty_30() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_30 = trunc_ln327_1_reg_9025.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_30 = trunc_ln327_1_fu_6658_p1.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_30 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_5_5_x_s_fu_4782_empty_31() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700_pp1_iter1_reg.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_31 = select_ln324_1_reg_8723_pp1_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_8700.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_31 = select_ln324_1_reg_8723.read();
    } else {
        grp_aesl_mux_load_5_5_x_s_fu_4782_empty_31 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_ap_start() {
    grp_aesl_mux_load_8_5_x_s_fu_4469_ap_start = grp_aesl_mux_load_8_5_x_s_fu_4469_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_6_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_6_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_5_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_5_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_4_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_4_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_3_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_3_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_2_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A = v4_2_0_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_10_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_7_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_7_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_6_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_6_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_5_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_5_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_4_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_4_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_3_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A = v4_3_0_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_11_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_0_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_0_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_7_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_7_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_6_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_6_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_5_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_5_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_4_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A = v4_4_0_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_12_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_1_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_1_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_0_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_0_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_7_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_7_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_6_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_6_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_5_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A = v4_5_0_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_13_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_2_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_2_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_1_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_1_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_0_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_0_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_7_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_7_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_6_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A = v4_6_0_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_14_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_3_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_3_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_2_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_2_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_1_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_1_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_0_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_0_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_7_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A = v4_7_0_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_15_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_16() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_16 = select_ln592_1_reg_9298.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_16 = select_ln592_1_fu_7247_p3.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_16 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_17() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_17 = select_ln592_7_reg_9340.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_17 = select_ln592_6_reg_9333.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_17 = select_ln592_5_reg_9326.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_17 = select_ln592_4_reg_9319.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_17 = select_ln592_3_reg_9312.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_17 = select_ln592_3_fu_7299_p3.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_17 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_4_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_4_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_3_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_3_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_2_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_2_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_1_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_1_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_0_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A = v4_0_0_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_8_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_5_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_5_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_4_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_4_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_3_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_3_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_2_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_2_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_1_3_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A = v4_1_0_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4469_empty_9_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_ap_start() {
    grp_aesl_mux_load_8_5_x_s_fu_4492_ap_start = grp_aesl_mux_load_8_5_x_s_fu_4492_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_6_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_6_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_5_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_5_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_4_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_4_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_3_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_3_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_2_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A = v4_2_1_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_10_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_7_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_7_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_6_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_6_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_5_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_5_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_4_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_4_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_3_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A = v4_3_1_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_11_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_0_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_0_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_7_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_7_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_6_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_6_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_5_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_5_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_4_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A = v4_4_1_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_12_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_1_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_1_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_0_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_0_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_7_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_7_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_6_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_6_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_5_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A = v4_5_1_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_13_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_2_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_2_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_1_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_1_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_0_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_0_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_7_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_7_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_6_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A = v4_6_1_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_14_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_3_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_3_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_2_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_2_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_1_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_1_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_0_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_0_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_7_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A = v4_7_1_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_15_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_16() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_16 = select_ln592_1_reg_9298.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_16 = select_ln592_1_fu_7247_p3.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_16 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_17() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_17 = select_ln592_7_reg_9340.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_17 = select_ln592_6_reg_9333.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_17 = select_ln592_5_reg_9326.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_17 = select_ln592_4_reg_9319.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_17 = select_ln592_3_reg_9312.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_17 = select_ln592_3_fu_7299_p3.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_17 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_4_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_4_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_3_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_3_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_2_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_2_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_1_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_1_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_0_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A = v4_0_1_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_8_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201_pp2_iter1_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_5_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_5_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_4_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_4_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_3_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_3_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_2_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_2_1_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_1_4_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A = v4_1_1_Dout_A.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4492_empty_9_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_ap_start() {
    grp_aesl_mux_load_8_5_x_s_fu_4515_ap_start = grp_aesl_mux_load_8_5_x_s_fu_4515_ap_start_reg.read();
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read())) {
        if (esl_seteq<1,1,1>(ap_condition_4959.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Dout_A = v4_6_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5024.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Dout_A = v4_5_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5012.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Dout_A = v4_4_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5000.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Dout_A = v4_3_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_4988.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Dout_A = v4_2_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_10_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read())) {
        if (esl_seteq<1,1,1>(ap_condition_4959.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Dout_A = v4_7_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5024.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Dout_A = v4_6_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5012.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Dout_A = v4_5_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5000.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Dout_A = v4_4_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_4988.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Dout_A = v4_3_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_11_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read())) {
        if (esl_seteq<1,1,1>(ap_condition_4959.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Dout_A = v4_0_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5024.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Dout_A = v4_7_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5012.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Dout_A = v4_6_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5000.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Dout_A = v4_5_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_4988.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Dout_A = v4_4_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_12_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read())) {
        if (esl_seteq<1,1,1>(ap_condition_4959.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Dout_A = v4_1_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5024.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Dout_A = v4_0_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5012.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Dout_A = v4_7_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5000.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Dout_A = v4_6_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_4988.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Dout_A = v4_5_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_13_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read())) {
        if (esl_seteq<1,1,1>(ap_condition_4959.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Dout_A = v4_2_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5024.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Dout_A = v4_1_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5012.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Dout_A = v4_0_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5000.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Dout_A = v4_7_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_4988.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Dout_A = v4_6_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_14_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read())) {
        if (esl_seteq<1,1,1>(ap_condition_4959.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Dout_A = v4_3_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5024.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Dout_A = v4_2_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5012.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Dout_A = v4_1_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5000.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Dout_A = v4_0_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_4988.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Dout_A = v4_7_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_15_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_16() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_16 = select_ln592_1_reg_9298.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_16 = select_ln592_1_fu_7247_p3.read();
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_16 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_17() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read()))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_17 = select_ln592_7_reg_9340.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_17 = select_ln592_6_reg_9333.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_17 = select_ln592_5_reg_9326.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_17 = select_ln592_4_reg_9319.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_17 = select_ln592_3_fu_7299_p3.read();
        } else {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_17 =  (sc_lv<3>) ("XXX");
        }
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_17 =  (sc_lv<3>) ("XXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read())) {
        if (esl_seteq<1,1,1>(ap_condition_4959.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Dout_A = v4_4_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5024.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Dout_A = v4_3_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5012.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Dout_A = v4_2_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5000.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Dout_A = v4_1_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_4988.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Dout_A = v4_0_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_8_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Dout_A() {
    if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_9201.read())) {
        if (esl_seteq<1,1,1>(ap_condition_4959.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Dout_A = v4_5_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5024.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Dout_A = v4_4_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5012.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Dout_A = v4_3_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_5000.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Dout_A = v4_2_2_Dout_A.read();
        } else if (esl_seteq<1,1,1>(ap_condition_4988.read(), ap_const_boolean_1)) {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Dout_A = v4_1_2_Dout_A.read();
        } else {
            grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_aesl_mux_load_8_5_x_s_fu_4515_empty_9_Dout_A =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5002_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5002_p0 = grp_fu_5341_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)))) {
        grp_fu_5002_p0 = grp_fu_5002_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5002_p0 = grp_fu_5305_p3.read();
    } else {
        grp_fu_5002_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5002_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5002_p1 = reg_5517.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5002_p1 = reg_5510.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5002_p1 = reg_5625.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5002_p1 = reg_5618.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5002_p1 = reg_5492.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5002_p1 = reg_5485.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5002_p1 = reg_5392.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        grp_fu_5002_p1 = reg_5386.read();
    } else {
        grp_fu_5002_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5006_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p0 = reg_5954.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p0 = reg_5727.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p0 = reg_5698.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p0 = reg_5677.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5006_p0 = v381_1_reg_10192.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5006_p0 = v323_1_reg_10127.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5006_p0 = reg_5691.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p0 = grp_fu_5341_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p0 = grp_fu_5350_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p0 = grp_fu_5006_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5006_p0 = reg_5684.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p0 = grp_fu_5305_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p0 = grp_fu_5314_p3.read();
    } else {
        grp_fu_5006_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5006_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = v643_reg_10895.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = v611_reg_10850.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = v583_reg_10810.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = v551_reg_10765.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = v523_reg_10725.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = v491_reg_10635.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = v463_reg_10550.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = v431_reg_10428.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5410.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5386.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5611.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5531.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5552.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5453.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5446.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = v152_reg_8577.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5638.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5645.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5545.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5503.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5510.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5439.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p1 = reg_5404.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0))) {
        grp_fu_5006_p1 = reg_5432.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        grp_fu_5006_p1 = reg_5398.read();
    } else {
        grp_fu_5006_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5010_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p0 = reg_5748.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p0 = reg_5734.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p0 = reg_5704.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p0 = reg_5684.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5010_p0 = v385_1_reg_10197.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5010_p0 = v328_1_reg_10132.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5010_p0 = reg_5716.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p0 = grp_fu_5350_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p0 = grp_fu_5359_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p0 = grp_fu_5010_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5010_p0 = reg_5691.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p0 = grp_fu_5314_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p0 = grp_fu_5323_p3.read();
    } else {
        grp_fu_5010_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5010_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = v645_reg_10900.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = v614_reg_10855.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = v585_reg_10815.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = v554_reg_10770.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = v525_reg_10730.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = v494_reg_10640.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5432.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5392.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5625.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5545.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5590.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5466.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p1 = reg_5460.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = v157_reg_8587.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5652.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5659.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5559.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5517.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5524.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5453.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p1 = reg_5416.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0))) {
        grp_fu_5010_p1 = reg_5446.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)))) {
        grp_fu_5010_p1 = reg_5410.read();
    } else {
        grp_fu_5010_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5014_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = reg_5753.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = reg_5741.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = reg_5710.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = reg_5691.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5014_p0 = v390_1_reg_10202.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5014_p0 = v333_1_reg_10137.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = grp_fu_5359_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = grp_fu_5368_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = grp_fu_5014_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = grp_fu_5006_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = grp_fu_5323_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p0 = grp_fu_5332_p3.read();
    } else {
        grp_fu_5014_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5014_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = v648_reg_10905.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = v617_reg_10860.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = v588_reg_10820.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = v557_reg_10775.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5510.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5485.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5439.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5398.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5638.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5559.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5604.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5478.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5472.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = v162_reg_8597.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5665.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = v150_reg_8572.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5597.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5531.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5538.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p1 = reg_5466.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p1 = reg_5426.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0))) {
        grp_fu_5014_p1 = reg_5460.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5014_p1 = reg_5421.read();
    } else {
        grp_fu_5014_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5018_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p0 = reg_5812.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p0 = reg_5770.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p0 = reg_5758.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5018_p0 = v394_1_reg_10207.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5018_p0 = v338_1_reg_10142.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p0 = grp_fu_5368_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p0 = grp_fu_5377_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p0 = grp_fu_5018_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p0 = reg_5716.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p0 = grp_fu_5010_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p0 = grp_fu_5332_p3.read();
    } else {
        grp_fu_5018_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5018_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = v650_reg_10910.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = v620_reg_10865.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5590.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5538.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5517.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5446.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5426.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5404.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5652.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5597.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5618.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p1 = reg_5492.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5439.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5485.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5432.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = v167_reg_8607.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = v165_reg_8602.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = v155_reg_8582.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5611.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5604.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5552.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5018_p1 = reg_5478.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_5018_p1 = reg_5472.read();
    } else {
        grp_fu_5018_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5023_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5023_p0 = reg_5959.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5023_p0 = reg_5892.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5023_p0 = reg_5777.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5023_p0 = reg_5764.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5023_p0 = v398_1_reg_10212.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5023_p0 = v343_1_reg_10147.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5023_p0 = grp_fu_5377_p3.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5023_p0 = grp_fu_5023_p2.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5023_p0 = grp_fu_5014_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5023_p0 = grp_fu_5006_p2.read();
    } else {
        grp_fu_5023_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5023_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5645.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5618.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5597.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5545.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5524.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5478.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5453.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = v396_reg_10388.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = v341_reg_10288.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5665.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5503.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = v160_reg_8592.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5023_p1 = reg_5632.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5023_p1 = reg_5590.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5023_p1 = reg_5498.read();
    } else {
        grp_fu_5023_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5111_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5111_p0 = reg_5964.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5111_p0 = reg_5899.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5111_p0 = reg_5857.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5111_p0 = reg_5817.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5111_p0 = v402_1_reg_10217.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5111_p0 = v348_1_reg_10152.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5111_p0 = grp_fu_5018_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5111_p0 = grp_fu_5006_p2.read();
    } else {
        grp_fu_5111_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5111_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = reg_5652.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = reg_5625.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = reg_5604.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = reg_5552.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = reg_5531.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = reg_5503.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = v474_reg_10600.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = v446_reg_10510.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = v400_reg_10393.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = v346_reg_10293.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = reg_5645.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5111_p1 = reg_5524.read();
    } else {
        grp_fu_5111_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5121_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5121_p0 = reg_5969.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5121_p0 = reg_5906.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5121_p0 = reg_5862.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5121_p0 = reg_5822.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5121_p0 = v406_1_reg_10222.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5121_p0 = v352_1_reg_10157.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5121_p0 = grp_fu_5023_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5121_p0 = grp_fu_5010_p2.read();
    } else {
        grp_fu_5121_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5121_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = reg_5632.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = reg_5611.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = reg_5559.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = v536_reg_10735.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = v508_reg_10690.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = v476_reg_10605.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = v448_reg_10515.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = v404_reg_10398.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = v350_reg_10298.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5121_p1 = reg_5659.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5121_p1 = reg_5538.read();
    } else {
        grp_fu_5121_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5213_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5213_p0 = reg_5974.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5213_p0 = reg_5913.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5213_p0 = reg_5867.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5213_p0 = reg_5827.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5213_p0 = v411_1_reg_10227.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5213_p0 = v356_1_reg_10162.read();
    } else {
        grp_fu_5213_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5213_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = reg_5665.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = reg_5638.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = v599_reg_10825.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = v570_reg_10780.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = v539_reg_10740.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = v510_reg_10695.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = v479_reg_10610.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = v450_reg_10520.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = v409_reg_10403.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5213_p1 = v354_reg_10303.read();
    } else {
        grp_fu_5213_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5217_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5217_p0 = reg_5979.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5217_p0 = reg_5920.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5217_p0 = reg_5872.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5217_p0 = reg_5832.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5217_p0 = v415_1_reg_10232.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5217_p0 = v360_1_reg_10167.read();
    } else {
        grp_fu_5217_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5217_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v661_reg_10915.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v632_reg_10870.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v601_reg_10830.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v572_reg_10785.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v541_reg_10745.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v512_reg_10700.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v481_reg_10615.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v452_reg_10525.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v413_reg_10408.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5217_p1 = v358_reg_10308.read();
    } else {
        grp_fu_5217_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5221_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5221_p0 = reg_5984.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5221_p0 = reg_5927.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5221_p0 = reg_5877.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5221_p0 = reg_5837.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5221_p0 = v419_1_reg_10237.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5221_p0 = v364_1_reg_10172.read();
    } else {
        grp_fu_5221_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5221_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v663_reg_10920.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v634_reg_10875.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v603_reg_10835.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v574_reg_10790.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v543_reg_10750.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v514_reg_10705.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v483_reg_10620.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v454_reg_10530.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v417_reg_10413.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5221_p1 = v362_reg_10313.read();
    } else {
        grp_fu_5221_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5225_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5225_p0 = reg_5989.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5225_p0 = reg_5934.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5225_p0 = reg_5882.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5225_p0 = reg_5842.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5225_p0 = v423_1_reg_10242.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5225_p0 = v369_1_reg_10177.read();
    } else {
        grp_fu_5225_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5225_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v665_reg_10925.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v637_reg_10880.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v605_reg_10840.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v577_reg_10795.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v545_reg_10755.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v517_reg_10710.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v485_reg_10625.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v457_reg_10535.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v421_reg_10418.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5225_p1 = v367_reg_10318.read();
    } else {
        grp_fu_5225_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5229_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0)))) {
        grp_fu_5229_p0 = reg_5994.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5229_p0 = reg_5941.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0)))) {
        grp_fu_5229_p0 = reg_5887.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5229_p0 = reg_5847.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5229_p0 = v427_1_reg_10247.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5229_p0 = v373_1_reg_10182.read();
    } else {
        grp_fu_5229_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5229_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v667_reg_10930.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v639_reg_10885.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v607_reg_10845.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v579_reg_10800.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v547_reg_10760.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v519_reg_10715.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v487_reg_10630.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v459_reg_10540.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v425_reg_10423.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5229_p1 = v371_reg_10323.read();
    } else {
        grp_fu_5229_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5233_p0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0)))) {
        grp_fu_5233_p0 = reg_5948.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0)))) {
        grp_fu_5233_p0 = reg_5852.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5233_p0 = v377_1_reg_10187.read();
    } else {
        grp_fu_5233_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5233_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5233_p1 = v641_reg_10890.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5233_p1 = v581_reg_10805.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5233_p1 = v521_reg_10720.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5233_p1 = v461_reg_10545.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5233_p1 = v375_reg_10328.read();
    } else {
        grp_fu_5233_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5237_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v647_reg_9793_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v609_reg_9628_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v587_reg_9784.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v549_reg_9619_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v527_reg_9765.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v489_reg_9530_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v456_reg_9711.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v429_reg_9521_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v366_reg_9702.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v319_reg_9412.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v306_reg_9004.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v296_reg_8992.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v286_reg_8980.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v276_reg_8968.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v264_reg_8944.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v246_reg_8932.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v228_reg_8920.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v210_reg_8908.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v192_reg_8896.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v2_0_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v159_reg_8508.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v149_reg_8496.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v139_reg_8484.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v127_reg_8460.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v117_reg_8448.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v107_reg_8436.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v97_reg_8424.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v85_reg_8400.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v67_reg_8388.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v49_reg_8376.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v31_reg_8364.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5237_p0 = v0_0_0_Dout_A.read();
    } else {
        grp_fu_5237_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5237_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v616_reg_10663.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v622_reg_10681.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v553_reg_10564.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v559_reg_10582.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v490_reg_9927.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v496_reg_10433.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v442_reg_9909.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v433_reg_9882.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v335_reg_9846.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v320_reg_9819.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_5237_p1 = v265_reg_8950.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5237_p1 = v173_reg_8878.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v3_0_0_Dout_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5237_p1 = v128_reg_8466.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_5237_p1 = v86_reg_8406.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5237_p1 = v12_reg_8333.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5237_p1 = v1_0_0_Dout_A.read();
    } else {
        grp_fu_5237_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5243_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v647_reg_9793_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v625_reg_9693_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v587_reg_9784.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v549_reg_9619_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v527_reg_9765.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v489_reg_9530_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v467_reg_9756.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v429_reg_9521_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v366_reg_9702.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v319_reg_9412.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v306_reg_9004.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v296_reg_8992.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v286_reg_8980.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v276_reg_8968.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v264_reg_8944.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v246_reg_8932.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v228_reg_8920.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v210_reg_8908.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v192_reg_8896.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v2_0_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v159_reg_8508.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v149_reg_8496.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v139_reg_8484.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v127_reg_8460.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v117_reg_8448.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v107_reg_8436.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v97_reg_8424.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v85_reg_8400.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v67_reg_8388.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v49_reg_8376.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v31_reg_8364.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5243_p0 = v0_0_0_Dout_A.read();
    } else {
        grp_fu_5243_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5243_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v619_reg_10672.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v610_reg_10645.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v556_reg_10573.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v562_reg_10591.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v493_reg_9936.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v499_reg_10442.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v430_reg_9873.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v436_reg_9891.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v340_reg_9855.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v325_reg_9828.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_5243_p1 = v268_reg_8956.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5243_p1 = v178_reg_8884.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v3_0_1_Dout_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5243_p1 = v131_reg_8472.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_5243_p1 = v89_reg_8412.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5243_p1 = v17_reg_8339.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5243_p1 = v1_0_1_Dout_A.read();
    } else {
        grp_fu_5243_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5249_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v647_reg_9793_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v625_reg_9693_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v587_reg_9784.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v565_reg_9684_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v527_reg_9765.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v489_reg_9530_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v467_reg_9756.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v429_reg_9521_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v387_reg_9747.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v319_reg_9412.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v311_reg_9010.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v301_reg_8998.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v291_reg_8986.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v281_reg_8974.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v271_reg_8962.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v255_reg_8938.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v237_reg_8926.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v219_reg_8914.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v201_reg_8902.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v2_1_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v164_reg_8514.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v154_reg_8502.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v144_reg_8490.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v134_reg_8478.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v122_reg_8454.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v112_reg_8442.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v102_reg_8430.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v92_reg_8418.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v76_reg_8394.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v58_reg_8382.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v40_reg_8370.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5249_p0 = v0_1_0_Dout_A.read();
    } else {
        grp_fu_5249_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5249_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v622_reg_10681.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v613_reg_10654.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v559_reg_10582.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v550_reg_10555.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v496_reg_10433.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v502_reg_10451.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v433_reg_9882.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v439_reg_9900.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v320_reg_9819.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v330_reg_9837.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_5249_p1 = v265_reg_8950.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5249_p1 = v173_reg_8878.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v3_0_0_Dout_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5249_p1 = v128_reg_8466.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_5249_p1 = v86_reg_8406.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5249_p1 = v12_reg_8333.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5249_p1 = v1_0_0_Dout_A.read();
    } else {
        grp_fu_5249_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5255_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v658_reg_10118.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v625_reg_9693_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v587_reg_9784.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v565_reg_9684_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v527_reg_9765.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v505_reg_9675_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v467_reg_9756.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v429_reg_9521_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v387_reg_9747.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v319_reg_9412.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v311_reg_9010.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v301_reg_8998.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v291_reg_8986.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v281_reg_8974.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v271_reg_8962.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v255_reg_8938.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v237_reg_8926.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v219_reg_8914.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v201_reg_8902.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v2_1_0_Dout_A.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v164_reg_8514.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v154_reg_8502.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v144_reg_8490.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v134_reg_8478.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v122_reg_8454.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v112_reg_8442.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v102_reg_8430.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v92_reg_8418.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v76_reg_8394.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v58_reg_8382.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v40_reg_8370.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5255_p0 = v0_1_0_Dout_A.read();
    } else {
        grp_fu_5255_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5255_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v610_reg_10645.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v616_reg_10663.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v562_reg_10591.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v553_reg_10564.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v499_reg_10442.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v490_reg_9927.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v436_reg_9891.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v442_reg_9909.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v325_reg_9828.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v335_reg_9846.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage8.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage9.read(), ap_const_boolean_0)))) {
        grp_fu_5255_p1 = v268_reg_8956.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp1_stage5.read(), ap_const_boolean_0)))) {
        grp_fu_5255_p1 = v178_reg_8884.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v3_0_1_Dout_A.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0)))) {
        grp_fu_5255_p1 = v131_reg_8472.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_fu_5255_p1 = v89_reg_8412.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)))) {
        grp_fu_5255_p1 = v17_reg_8339.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5255_p1 = v1_0_1_Dout_A.read();
    } else {
        grp_fu_5255_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5269_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v658_reg_10118.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v625_reg_9693_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v598_reg_10109.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v565_reg_9684_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v527_reg_9765.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v505_reg_9675_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v467_reg_9756.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v445_reg_9646.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v387_reg_9747.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5269_p0 = v319_reg_9412.read();
    } else {
        grp_fu_5269_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5269_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v613_reg_10654.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v619_reg_10672.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v550_reg_10555.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v556_reg_10573.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v502_reg_10451.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v493_reg_9936.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v439_reg_9900.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v430_reg_9873.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v330_reg_9837.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5269_p1 = v340_reg_9855.read();
    } else {
        grp_fu_5269_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5273_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v658_reg_10118.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v625_reg_9693_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v598_reg_10109.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v565_reg_9684_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v538_reg_9945.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v505_reg_9675_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v467_reg_9756.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v445_reg_9646.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v387_reg_9747.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5273_p0 = v345_reg_9637.read();
    } else {
        grp_fu_5273_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5273_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v616_reg_10663.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v622_reg_10681.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v553_reg_10564.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v559_reg_10582.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v490_reg_9927.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v496_reg_10433.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v442_reg_9909.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v433_reg_9882.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v335_reg_9846.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5273_p1 = v320_reg_9819.read();
    } else {
        grp_fu_5273_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5277_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v658_reg_10118.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v636_reg_9738_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v598_reg_10109.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v565_reg_9684_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v538_reg_9945.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v505_reg_9675_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v478_reg_9918.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v445_reg_9646.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v387_reg_9747.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5277_p0 = v345_reg_9637.read();
    } else {
        grp_fu_5277_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5277_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v619_reg_10672.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v610_reg_10645.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v556_reg_10573.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v562_reg_10591.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v493_reg_9936.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v499_reg_10442.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v430_reg_9873.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v436_reg_9891.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v340_reg_9855.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5277_p1 = v325_reg_9828.read();
    } else {
        grp_fu_5277_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5281_p0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v658_reg_10118.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v636_reg_9738_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v598_reg_10109.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v576_reg_9729.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v538_reg_9945.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v505_reg_9675_pp2_iter1_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v478_reg_9918.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v445_reg_9646.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v408_reg_9864.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5281_p0 = v345_reg_9637.read();
    } else {
        grp_fu_5281_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5281_p1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v622_reg_10681.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v613_reg_10654.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v559_reg_10582.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v550_reg_10555.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v496_reg_10433.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v502_reg_10451.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v433_reg_9882.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v439_reg_9900.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v320_reg_9819.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        grp_fu_5281_p1 = v330_reg_9837.read();
    } else {
        grp_fu_5281_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5285_p0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5285_p0 = v636_reg_9738_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5285_p0 = v598_reg_10109.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5285_p0 = v576_reg_9729.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5285_p0 = v538_reg_9945.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5285_p0 = v516_reg_9720.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5285_p0 = v478_reg_9918.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5285_p0 = v445_reg_9646.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5285_p0 = v408_reg_9864.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5285_p0 = v345_reg_9637.read();
        } else {
            grp_fu_5285_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5285_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5285_p1() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5285_p1 = v616_reg_10663.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5285_p1 = v562_reg_10591.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5285_p1 = v553_reg_10564.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5285_p1 = v499_reg_10442.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5285_p1 = v490_reg_9927.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5285_p1 = v436_reg_9891.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5285_p1 = v442_reg_9909.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5285_p1 = v325_reg_9828.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5285_p1 = v335_reg_9846.read();
        } else {
            grp_fu_5285_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5285_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5289_p0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5289_p0 = v636_reg_9738_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5289_p0 = v609_reg_9628_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5289_p0 = v576_reg_9729.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5289_p0 = v538_reg_9945.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5289_p0 = v516_reg_9720.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5289_p0 = v478_reg_9918.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5289_p0 = v456_reg_9711.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5289_p0 = v408_reg_9864.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5289_p0 = v345_reg_9637.read();
        } else {
            grp_fu_5289_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5289_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5289_p1() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5289_p1 = v619_reg_10672.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5289_p1 = v610_reg_10645.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5289_p1 = v556_reg_10573.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5289_p1 = v502_reg_10451.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5289_p1 = v493_reg_9936.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5289_p1 = v439_reg_9900.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5289_p1 = v430_reg_9873.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5289_p1 = v330_reg_9837.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5289_p1 = v340_reg_9855.read();
        } else {
            grp_fu_5289_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5289_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5293_p0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5293_p0 = v636_reg_9738_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5293_p0 = v609_reg_9628_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5293_p0 = v576_reg_9729.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5293_p0 = v549_reg_9619_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5293_p0 = v516_reg_9720.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5293_p0 = v478_reg_9918.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5293_p0 = v456_reg_9711.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5293_p0 = v408_reg_9864.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5293_p0 = v366_reg_9702.read();
        } else {
            grp_fu_5293_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5293_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5293_p1() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5293_p1 = v622_reg_10681.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5293_p1 = v613_reg_10654.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5293_p1 = v559_reg_10582.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5293_p1 = v550_reg_10555.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5293_p1 = v496_reg_10433.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5293_p1 = v442_reg_9909.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5293_p1 = v433_reg_9882.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5293_p1 = v335_reg_9846.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5293_p1 = v320_reg_9819.read();
        } else {
            grp_fu_5293_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5293_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5297_p0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5297_p0 = v647_reg_9793.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5297_p0 = v609_reg_9628_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5297_p0 = v576_reg_9729.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5297_p0 = v549_reg_9619_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5297_p0 = v516_reg_9720.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5297_p0 = v489_reg_9530_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5297_p0 = v456_reg_9711.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5297_p0 = v408_reg_9864.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5297_p0 = v366_reg_9702.read();
        } else {
            grp_fu_5297_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5297_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5297_p1() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5297_p1 = v610_reg_10645.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5297_p1 = v616_reg_10663.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5297_p1 = v562_reg_10591.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5297_p1 = v553_reg_10564.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5297_p1 = v499_reg_10442.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5297_p1 = v490_reg_9927.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5297_p1 = v436_reg_9891.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5297_p1 = v340_reg_9855.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5297_p1 = v325_reg_9828.read();
        } else {
            grp_fu_5297_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5297_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5301_p0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5301_p0 = v647_reg_9793.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5301_p0 = v609_reg_9628_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5301_p0 = v587_reg_9784.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5301_p0 = v549_reg_9619_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5301_p0 = v516_reg_9720.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5301_p0 = v489_reg_9530_pp2_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5301_p0 = v456_reg_9711.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5301_p0 = v429_reg_9521.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5301_p0 = v366_reg_9702.read();
        } else {
            grp_fu_5301_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5301_p0 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5301_p1() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
             esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
            grp_fu_5301_p1 = v613_reg_10654.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
            grp_fu_5301_p1 = v619_reg_10672.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
            grp_fu_5301_p1 = v550_reg_10555.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
            grp_fu_5301_p1 = v556_reg_10573.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
            grp_fu_5301_p1 = v502_reg_10451.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
            grp_fu_5301_p1 = v493_reg_9936.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
            grp_fu_5301_p1 = v439_reg_9900.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
            grp_fu_5301_p1 = v430_reg_9873.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
            grp_fu_5301_p1 = v330_reg_9837.read();
        } else {
            grp_fu_5301_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fu_5301_p1 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void kernel_3mm_nonP::thread_grp_fu_5305_p3() {
    grp_fu_5305_p3 = (!select_ln59_1_reg_8124.read()[0].is_01())? sc_lv<32>(): ((select_ln59_1_reg_8124.read()[0].to_bool())? ap_const_lv32_0: grp_aesl_mux_load_5_5_x_1_fu_4874_ap_return.read());
}

void kernel_3mm_nonP::thread_grp_fu_5314_p3() {
    grp_fu_5314_p3 = (!select_ln59_1_reg_8124.read()[0].is_01())? sc_lv<32>(): ((select_ln59_1_reg_8124.read()[0].to_bool())? ap_const_lv32_0: grp_aesl_mux_load_5_5_x_1_fu_4891_ap_return.read());
}

void kernel_3mm_nonP::thread_grp_fu_5323_p3() {
    grp_fu_5323_p3 = (!select_ln59_1_reg_8124.read()[0].is_01())? sc_lv<32>(): ((select_ln59_1_reg_8124.read()[0].to_bool())? ap_const_lv32_0: grp_aesl_mux_load_5_5_x_1_fu_4908_ap_return.read());
}

void kernel_3mm_nonP::thread_grp_fu_5332_p3() {
    grp_fu_5332_p3 = (!select_ln59_1_reg_8124.read()[0].is_01())? sc_lv<32>(): ((select_ln59_1_reg_8124.read()[0].to_bool())? ap_const_lv32_0: grp_aesl_mux_load_5_5_x_1_fu_4925_ap_return.read());
}

void kernel_3mm_nonP::thread_grp_fu_5341_p3() {
    grp_fu_5341_p3 = (!select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: grp_aesl_mux_load_5_5_x_s_fu_4714_ap_return.read());
}

void kernel_3mm_nonP::thread_grp_fu_5350_p3() {
    grp_fu_5350_p3 = (!select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: grp_aesl_mux_load_5_5_x_s_fu_4731_ap_return.read());
}

void kernel_3mm_nonP::thread_grp_fu_5359_p3() {
    grp_fu_5359_p3 = (!select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: grp_aesl_mux_load_5_5_x_s_fu_4748_ap_return.read());
}

void kernel_3mm_nonP::thread_grp_fu_5368_p3() {
    grp_fu_5368_p3 = (!select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: grp_aesl_mux_load_5_5_x_s_fu_4765_ap_return.read());
}

void kernel_3mm_nonP::thread_grp_fu_5377_p3() {
    grp_fu_5377_p3 = (!select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln329_1_reg_8709_pp1_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: grp_aesl_mux_load_5_5_x_s_fu_4782_ap_return.read());
}

void kernel_3mm_nonP::thread_grp_fu_6222_p1() {
    grp_fu_6222_p1 =  (sc_lv<4>) (ap_const_lv6_5);
}

void kernel_3mm_nonP::thread_grp_fu_6609_p0() {
    grp_fu_6609_p0 = esl_concat<6,1>(select_ln324_fu_6514_p3.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_grp_fu_6609_p1() {
    grp_fu_6609_p1 =  (sc_lv<4>) (ap_const_lv7_5);
}

void kernel_3mm_nonP::thread_grp_fu_6842_p1() {
    grp_fu_6842_p1 =  (sc_lv<5>) (ap_const_lv6_A);
}

void kernel_3mm_nonP::thread_grp_fu_7068_p1() {
    grp_fu_7068_p1 =  (sc_lv<5>) (ap_const_lv6_A);
}

void kernel_3mm_nonP::thread_grp_fu_8097_p0() {
    grp_fu_8097_p0 =  (sc_lv<6>) (ap_const_lv10_19);
}

void kernel_3mm_nonP::thread_grp_fu_8097_p1() {
    grp_fu_8097_p1 =  (sc_lv<5>) (grp_fu_8097_p10.read());
}

void kernel_3mm_nonP::thread_grp_fu_8097_p10() {
    grp_fu_8097_p10 = esl_zext<10,5>(select_ln59_2_fu_6075_p3.read());
}

void kernel_3mm_nonP::thread_grp_fu_8097_p2() {
    grp_fu_8097_p2 =  (sc_lv<5>) (grp_fu_8097_p20.read());
}

void kernel_3mm_nonP::thread_grp_fu_8097_p20() {
    grp_fu_8097_p20 = esl_zext<10,5>(select_ln63_fu_6121_p3.read());
}

void kernel_3mm_nonP::thread_grp_fu_8106_p0() {
    grp_fu_8106_p0 =  (sc_lv<7>) (ap_const_lv12_23);
}

void kernel_3mm_nonP::thread_grp_fu_8106_p1() {
    grp_fu_8106_p1 =  (sc_lv<6>) (grp_fu_8106_p10.read());
}

void kernel_3mm_nonP::thread_grp_fu_8106_p10() {
    grp_fu_8106_p10 = esl_zext<12,6>(select_ln329_2_fu_6468_p3.read());
}

void kernel_3mm_nonP::thread_grp_fu_8106_p2() {
    grp_fu_8106_p2 =  (sc_lv<6>) (grp_fu_8106_p20.read());
}

void kernel_3mm_nonP::thread_grp_fu_8106_p20() {
    grp_fu_8106_p20 = esl_zext<12,6>(select_ln324_fu_6514_p3.read());
}

void kernel_3mm_nonP::thread_icmp_ln320_fu_6416_p2() {
    icmp_ln320_fu_6416_p2 = (!ap_phi_mux_indvar_flatten78_phi_fu_4361_p4.read().is_01() || !ap_const_lv13_1B58.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten78_phi_fu_4361_p4.read() == ap_const_lv13_1B58);
}

void kernel_3mm_nonP::thread_icmp_ln321_fu_6434_p2() {
    icmp_ln321_fu_6434_p2 = (!ap_phi_mux_indvar_flatten64_phi_fu_4383_p4.read().is_01() || !ap_const_lv9_AF.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten64_phi_fu_4383_p4.read() == ap_const_lv9_AF);
}

void kernel_3mm_nonP::thread_icmp_ln322_fu_6490_p2() {
    icmp_ln322_fu_6490_p2 = (!ap_phi_mux_v171_0_phi_fu_4405_p4.read().is_01() || !ap_const_lv6_23.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v171_0_phi_fu_4405_p4.read() == ap_const_lv6_23);
}

void kernel_3mm_nonP::thread_icmp_ln329_1_fu_6454_p2() {
    icmp_ln329_1_fu_6454_p2 = (!ap_phi_mux_v169_0_phi_fu_4372_p4.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v169_0_phi_fu_4372_p4.read() == ap_const_lv6_0);
}

void kernel_3mm_nonP::thread_icmp_ln329_fu_6448_p2() {
    icmp_ln329_fu_6448_p2 = (!v169_fu_6428_p2.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(v169_fu_6428_p2.read() == ap_const_lv6_0);
}

void kernel_3mm_nonP::thread_icmp_ln591_fu_6856_p2() {
    icmp_ln591_fu_6856_p2 = (!ap_phi_mux_indvar_flatten183_phi_fu_4416_p4.read().is_01() || !ap_const_lv11_460.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten183_phi_fu_4416_p4.read() == ap_const_lv11_460);
}

void kernel_3mm_nonP::thread_icmp_ln592_fu_6868_p2() {
    icmp_ln592_fu_6868_p2 = (!ap_phi_mux_indvar_flatten85_phi_fu_4439_p4.read().is_01() || !ap_const_lv8_70.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten85_phi_fu_4439_p4.read() == ap_const_lv8_70);
}

void kernel_3mm_nonP::thread_icmp_ln593_fu_7173_p2() {
    icmp_ln593_fu_7173_p2 = (!ap_phi_mux_v318_0_phi_fu_4462_p4.read().is_01() || !ap_const_lv4_E.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v318_0_phi_fu_4462_p4.read() == ap_const_lv4_E);
}

void kernel_3mm_nonP::thread_icmp_ln596_1_fu_7539_p2() {
    icmp_ln596_1_fu_7539_p2 = (!trunc_ln596_1_fu_7535_p1.read().is_01() || !ap_const_lv4_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln596_1_fu_7535_p1.read() == ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_icmp_ln596_fu_7523_p2() {
    icmp_ln596_fu_7523_p2 = (!trunc_ln596_fu_7519_p1.read().is_01() || !ap_const_lv4_0.is_01())? sc_lv<1>(): sc_lv<1>(trunc_ln596_fu_7519_p1.read() == ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_icmp_ln59_fu_6017_p2() {
    icmp_ln59_fu_6017_p2 = (!ap_phi_mux_indvar_flatten37_phi_fu_4306_p4.read().is_01() || !ap_const_lv12_9C4.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten37_phi_fu_4306_p4.read() == ap_const_lv12_9C4);
}

void kernel_3mm_nonP::thread_icmp_ln600_1_fu_7057_p2() {
    icmp_ln600_1_fu_7057_p2 = (!add_ln595_3_reg_9225.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(add_ln595_3_reg_9225.read() == ap_const_lv6_0);
}

void kernel_3mm_nonP::thread_icmp_ln600_fu_6836_p2() {
    icmp_ln600_fu_6836_p2 = (!add_ln595_fu_6830_p2.read().is_01() || !ap_const_lv6_0.is_01())? sc_lv<1>(): sc_lv<1>(add_ln595_fu_6830_p2.read() == ap_const_lv6_0);
}

void kernel_3mm_nonP::thread_icmp_ln60_fu_6035_p2() {
    icmp_ln60_fu_6035_p2 = (!ap_phi_mux_indvar_flatten_phi_fu_4328_p4.read().is_01() || !ap_const_lv8_7D.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_indvar_flatten_phi_fu_4328_p4.read() == ap_const_lv8_7D);
}

void kernel_3mm_nonP::thread_icmp_ln61_fu_6097_p2() {
    icmp_ln61_fu_6097_p2 = (!ap_phi_mux_v10_0_phi_fu_4350_p4.read().is_01() || !ap_const_lv5_19.is_01())? sc_lv<1>(): sc_lv<1>(ap_phi_mux_v10_0_phi_fu_4350_p4.read() == ap_const_lv5_19);
}

void kernel_3mm_nonP::thread_icmp_ln68_1_fu_6061_p2() {
    icmp_ln68_1_fu_6061_p2 = (!shl_ln63_mid1_fu_6053_p3.read().is_01() || !zext_ln59_1_fu_6049_p1.read().is_01())? sc_lv<1>(): sc_lv<1>(shl_ln63_mid1_fu_6053_p3.read() == zext_ln59_1_fu_6049_p1.read());
}

void kernel_3mm_nonP::thread_icmp_ln68_fu_6011_p2() {
    icmp_ln68_fu_6011_p2 = (!shl_ln_fu_6003_p3.read().is_01() || !zext_ln59_fu_5999_p1.read().is_01())? sc_lv<1>(): sc_lv<1>(shl_ln_fu_6003_p3.read() == zext_ln59_fu_5999_p1.read());
}

void kernel_3mm_nonP::thread_mul_ln327_fu_6642_p1() {
    mul_ln327_fu_6642_p1 =  (sc_lv<7>) (mul_ln327_fu_6642_p10.read());
}

void kernel_3mm_nonP::thread_mul_ln327_fu_6642_p10() {
    mul_ln327_fu_6642_p10 = esl_zext<16,7>(shl_ln2_reg_8835.read());
}

void kernel_3mm_nonP::thread_mul_ln327_fu_6642_p2() {
    mul_ln327_fu_6642_p2 = (!ap_const_lv16_CD.is_01() || !mul_ln327_fu_6642_p1.read().is_01())? sc_lv<16>(): sc_biguint<16>(ap_const_lv16_CD) * sc_biguint<7>(mul_ln327_fu_6642_p1.read());
}

void kernel_3mm_nonP::thread_mul_ln337_fu_6691_p1() {
    mul_ln337_fu_6691_p1 =  (sc_lv<7>) (mul_ln337_fu_6691_p10.read());
}

void kernel_3mm_nonP::thread_mul_ln337_fu_6691_p10() {
    mul_ln337_fu_6691_p10 = esl_zext<16,7>(or_ln335_fu_6682_p2.read());
}

void kernel_3mm_nonP::thread_mul_ln337_fu_6691_p2() {
    mul_ln337_fu_6691_p2 = (!ap_const_lv16_CD.is_01() || !mul_ln337_fu_6691_p1.read().is_01())? sc_lv<16>(): sc_biguint<16>(ap_const_lv16_CD) * sc_biguint<7>(mul_ln337_fu_6691_p1.read());
}

void kernel_3mm_nonP::thread_mul_ln591_1_fu_7110_p1() {
    mul_ln591_1_fu_7110_p1 =  (sc_lv<6>) (mul_ln591_1_fu_7110_p10.read());
}

void kernel_3mm_nonP::thread_mul_ln591_1_fu_7110_p10() {
    mul_ln591_1_fu_7110_p10 = esl_zext<14,6>(add_ln591_fu_7101_p2.read());
}

void kernel_3mm_nonP::thread_mul_ln591_1_fu_7110_p2() {
    mul_ln591_1_fu_7110_p2 = (!ap_const_lv14_67.is_01() || !mul_ln591_1_fu_7110_p1.read().is_01())? sc_lv<14>(): sc_biguint<14>(ap_const_lv14_67) * sc_biguint<6>(mul_ln591_1_fu_7110_p1.read());
}

void kernel_3mm_nonP::thread_mul_ln591_2_fu_7443_p1() {
    mul_ln591_2_fu_7443_p1 =  (sc_lv<6>) (mul_ln591_2_fu_7443_p10.read());
}

void kernel_3mm_nonP::thread_mul_ln591_2_fu_7443_p10() {
    mul_ln591_2_fu_7443_p10 = esl_zext<14,6>(add_ln591_1_fu_7434_p2.read());
}

void kernel_3mm_nonP::thread_mul_ln591_2_fu_7443_p2() {
    mul_ln591_2_fu_7443_p2 = (!ap_const_lv14_67.is_01() || !mul_ln591_2_fu_7443_p1.read().is_01())? sc_lv<14>(): sc_biguint<14>(ap_const_lv14_67) * sc_biguint<6>(mul_ln591_2_fu_7443_p1.read());
}

void kernel_3mm_nonP::thread_mul_ln591_3_fu_7870_p1() {
    mul_ln591_3_fu_7870_p1 =  (sc_lv<6>) (mul_ln591_3_fu_7870_p10.read());
}

void kernel_3mm_nonP::thread_mul_ln591_3_fu_7870_p10() {
    mul_ln591_3_fu_7870_p10 = esl_zext<14,6>(add_ln591_2_fu_7861_p2.read());
}

void kernel_3mm_nonP::thread_mul_ln591_3_fu_7870_p2() {
    mul_ln591_3_fu_7870_p2 = (!ap_const_lv14_67.is_01() || !mul_ln591_3_fu_7870_p1.read().is_01())? sc_lv<14>(): sc_biguint<14>(ap_const_lv14_67) * sc_biguint<6>(mul_ln591_3_fu_7870_p1.read());
}

void kernel_3mm_nonP::thread_mul_ln591_4_fu_7923_p1() {
    mul_ln591_4_fu_7923_p1 =  (sc_lv<6>) (mul_ln591_4_fu_7923_p10.read());
}

void kernel_3mm_nonP::thread_mul_ln591_4_fu_7923_p10() {
    mul_ln591_4_fu_7923_p10 = esl_zext<14,6>(add_ln591_3_fu_7914_p2.read());
}

void kernel_3mm_nonP::thread_mul_ln591_4_fu_7923_p2() {
    mul_ln591_4_fu_7923_p2 = (!ap_const_lv14_67.is_01() || !mul_ln591_4_fu_7923_p1.read().is_01())? sc_lv<14>(): sc_biguint<14>(ap_const_lv14_67) * sc_biguint<6>(mul_ln591_4_fu_7923_p1.read());
}

void kernel_3mm_nonP::thread_mul_ln591_fu_6912_p1() {
    mul_ln591_fu_6912_p1 =  (sc_lv<6>) (mul_ln591_fu_6912_p10.read());
}

void kernel_3mm_nonP::thread_mul_ln591_fu_6912_p10() {
    mul_ln591_fu_6912_p10 = esl_zext<14,6>(select_ln591_2_fu_6900_p3.read());
}

void kernel_3mm_nonP::thread_mul_ln591_fu_6912_p2() {
    mul_ln591_fu_6912_p2 = (!ap_const_lv14_67.is_01() || !mul_ln591_fu_6912_p1.read().is_01())? sc_lv<14>(): sc_biguint<14>(ap_const_lv14_67) * sc_biguint<6>(mul_ln591_fu_6912_p1.read());
}

void kernel_3mm_nonP::thread_mul_ln66_fu_6232_p1() {
    mul_ln66_fu_6232_p1 =  (sc_lv<6>) (mul_ln66_fu_6232_p10.read());
}

void kernel_3mm_nonP::thread_mul_ln66_fu_6232_p10() {
    mul_ln66_fu_6232_p10 = esl_zext<14,6>(shl_ln1_fu_6201_p3.read());
}

void kernel_3mm_nonP::thread_mul_ln66_fu_6232_p2() {
    mul_ln66_fu_6232_p2 = (!ap_const_lv14_67.is_01() || !mul_ln66_fu_6232_p1.read().is_01())? sc_lv<14>(): sc_biguint<14>(ap_const_lv14_67) * sc_biguint<6>(mul_ln66_fu_6232_p1.read());
}

void kernel_3mm_nonP::thread_mul_ln76_fu_6287_p1() {
    mul_ln76_fu_6287_p1 =  (sc_lv<6>) (mul_ln76_fu_6287_p10.read());
}

void kernel_3mm_nonP::thread_mul_ln76_fu_6287_p10() {
    mul_ln76_fu_6287_p10 = esl_zext<14,6>(or_ln74_fu_6278_p2.read());
}

void kernel_3mm_nonP::thread_mul_ln76_fu_6287_p2() {
    mul_ln76_fu_6287_p2 = (!ap_const_lv14_67.is_01() || !mul_ln76_fu_6287_p1.read().is_01())? sc_lv<14>(): sc_biguint<14>(ap_const_lv14_67) * sc_biguint<6>(mul_ln76_fu_6287_p1.read());
}

void kernel_3mm_nonP::thread_or_ln324_fu_6508_p2() {
    or_ln324_fu_6508_p2 = (and_ln329_fu_6496_p2.read() | icmp_ln321_fu_6434_p2.read());
}

void kernel_3mm_nonP::thread_or_ln335_fu_6682_p2() {
    or_ln335_fu_6682_p2 = (shl_ln2_reg_8835_pp1_iter1_reg.read() | ap_const_lv7_1);
}

void kernel_3mm_nonP::thread_or_ln592_fu_7190_p2() {
    or_ln592_fu_7190_p2 = (and_ln591_fu_7179_p2.read() | icmp_ln592_reg_9205.read());
}

void kernel_3mm_nonP::thread_or_ln63_fu_6115_p2() {
    or_ln63_fu_6115_p2 = (and_ln59_fu_6103_p2.read() | icmp_ln60_fu_6035_p2.read());
}

void kernel_3mm_nonP::thread_or_ln74_fu_6278_p2() {
    or_ln74_fu_6278_p2 = (shl_ln1_reg_8268.read() | ap_const_lv6_1);
}

void kernel_3mm_nonP::thread_p_shl8_cast_fu_7628_p3() {
    p_shl8_cast_fu_7628_p3 = esl_concat<4,4>(select_ln592_2_reg_9305.read(), ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_select_ln321_fu_6627_p3() {
    select_ln321_fu_6627_p3 = (!icmp_ln321_fu_6434_p2.read()[0].is_01())? sc_lv<9>(): ((icmp_ln321_fu_6434_p2.read()[0].to_bool())? ap_const_lv9_1: add_ln321_1_fu_6621_p2.read());
}

void kernel_3mm_nonP::thread_select_ln324_1_fu_6522_p3() {
    select_ln324_1_fu_6522_p3 = (!and_ln329_fu_6496_p2.read()[0].is_01())? sc_lv<3>(): ((and_ln329_fu_6496_p2.read()[0].to_bool())? v170_fu_6502_p2.read(): select_ln329_fu_6440_p3.read());
}

void kernel_3mm_nonP::thread_select_ln324_fu_6514_p3() {
    select_ln324_fu_6514_p3 = (!or_ln324_fu_6508_p2.read()[0].is_01())? sc_lv<6>(): ((or_ln324_fu_6508_p2.read()[0].to_bool())? ap_const_lv6_0: ap_phi_mux_v171_0_phi_fu_4405_p4.read());
}

void kernel_3mm_nonP::thread_select_ln329_1_fu_6460_p3() {
    select_ln329_1_fu_6460_p3 = (!icmp_ln321_fu_6434_p2.read()[0].is_01())? sc_lv<1>(): ((icmp_ln321_fu_6434_p2.read()[0].to_bool())? icmp_ln329_fu_6448_p2.read(): icmp_ln329_1_fu_6454_p2.read());
}

void kernel_3mm_nonP::thread_select_ln329_2_fu_6468_p3() {
    select_ln329_2_fu_6468_p3 = (!icmp_ln321_fu_6434_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln321_fu_6434_p2.read()[0].to_bool())? v169_fu_6428_p2.read(): ap_phi_mux_v169_0_phi_fu_4372_p4.read());
}

void kernel_3mm_nonP::thread_select_ln329_fu_6440_p3() {
    select_ln329_fu_6440_p3 = (!icmp_ln321_fu_6434_p2.read()[0].is_01())? sc_lv<3>(): ((icmp_ln321_fu_6434_p2.read()[0].to_bool())? ap_const_lv3_0: ap_phi_mux_v170_0_phi_fu_4394_p4.read());
}

void kernel_3mm_nonP::thread_select_ln591_10_fu_6928_p3() {
    select_ln591_10_fu_6928_p3 = (!icmp_ln592_fu_6868_p2.read()[0].is_01())? sc_lv<4>(): ((icmp_ln592_fu_6868_p2.read()[0].to_bool())? v316_fu_6862_p2.read(): ap_phi_mux_v316_0_phi_fu_4428_p4.read());
}

void kernel_3mm_nonP::thread_select_ln591_1_fu_7062_p3() {
    select_ln591_1_fu_7062_p3 = (!icmp_ln592_reg_9205.read()[0].is_01())? sc_lv<1>(): ((icmp_ln592_reg_9205.read()[0].to_bool())? icmp_ln600_1_fu_7057_p2.read(): icmp_ln600_reg_9185.read());
}

void kernel_3mm_nonP::thread_select_ln591_2_fu_6900_p3() {
    select_ln591_2_fu_6900_p3 = (!icmp_ln592_fu_6868_p2.read()[0].is_01())? sc_lv<6>(): ((icmp_ln592_fu_6868_p2.read()[0].to_bool())? add_ln595_3_fu_6894_p2.read(): add_ln595_fu_6830_p2.read());
}

void kernel_3mm_nonP::thread_select_ln591_3_fu_7545_p3() {
    select_ln591_3_fu_7545_p3 = (!icmp_ln592_reg_9205.read()[0].is_01())? sc_lv<1>(): ((icmp_ln592_reg_9205.read()[0].to_bool())? icmp_ln596_1_fu_7539_p2.read(): icmp_ln596_reg_9774.read());
}

void kernel_3mm_nonP::thread_select_ln591_4_fu_7126_p3() {
    select_ln591_4_fu_7126_p3 = (!icmp_ln592_reg_9205.read()[0].is_01())? sc_lv<3>(): ((icmp_ln592_reg_9205.read()[0].to_bool())? ap_const_lv3_0: add_ln595_2_fu_6978_p2.read());
}

void kernel_3mm_nonP::thread_select_ln591_5_fu_7133_p3() {
    select_ln591_5_fu_7133_p3 = (!icmp_ln592_reg_9205.read()[0].is_01())? sc_lv<3>(): ((icmp_ln592_reg_9205.read()[0].to_bool())? ap_const_lv3_0: trunc_ln595_2_fu_7007_p4.read());
}

void kernel_3mm_nonP::thread_select_ln591_6_fu_7140_p3() {
    select_ln591_6_fu_7140_p3 = (!icmp_ln592_reg_9205.read()[0].is_01())? sc_lv<3>(): ((icmp_ln592_reg_9205.read()[0].to_bool())? ap_const_lv3_0: trunc_ln4_fu_7017_p4.read());
}

void kernel_3mm_nonP::thread_select_ln591_7_fu_7147_p3() {
    select_ln591_7_fu_7147_p3 = (!icmp_ln592_reg_9205.read()[0].is_01())? sc_lv<3>(): ((icmp_ln592_reg_9205.read()[0].to_bool())? ap_const_lv3_0: trunc_ln5_fu_7027_p4.read());
}

void kernel_3mm_nonP::thread_select_ln591_8_fu_7154_p3() {
    select_ln591_8_fu_7154_p3 = (!icmp_ln592_reg_9205.read()[0].is_01())? sc_lv<3>(): ((icmp_ln592_reg_9205.read()[0].to_bool())? ap_const_lv3_0: trunc_ln6_fu_7037_p4.read());
}

void kernel_3mm_nonP::thread_select_ln591_9_fu_7161_p3() {
    select_ln591_9_fu_7161_p3 = (!icmp_ln592_reg_9205.read()[0].is_01())? sc_lv<3>(): ((icmp_ln592_reg_9205.read()[0].to_bool())? ap_const_lv3_0: trunc_ln7_fu_7047_p4.read());
}

void kernel_3mm_nonP::thread_select_ln591_fu_6874_p3() {
    select_ln591_fu_6874_p3 = (!icmp_ln592_fu_6868_p2.read()[0].is_01())? sc_lv<4>(): ((icmp_ln592_fu_6868_p2.read()[0].to_bool())? ap_const_lv4_0: ap_phi_mux_v317_0_phi_fu_4450_p4.read());
}

void kernel_3mm_nonP::thread_select_ln592_1_fu_7247_p3() {
    select_ln592_1_fu_7247_p3 = (!and_ln591_fu_7179_p2.read()[0].is_01())? sc_lv<3>(): ((and_ln591_fu_7179_p2.read()[0].to_bool())? add_ln595_5_fu_7241_p2.read(): select_ln591_4_fu_7126_p3.read());
}

void kernel_3mm_nonP::thread_select_ln592_2_fu_7282_p3() {
    select_ln592_2_fu_7282_p3 = (!and_ln591_fu_7179_p2.read()[0].is_01())? sc_lv<4>(): ((and_ln591_fu_7179_p2.read()[0].to_bool())? v317_fu_7185_p2.read(): select_ln591_reg_9219.read());
}

void kernel_3mm_nonP::thread_select_ln592_3_fu_7299_p3() {
    select_ln592_3_fu_7299_p3 = (!and_ln591_fu_7179_p2.read()[0].is_01())? sc_lv<3>(): ((and_ln591_fu_7179_p2.read()[0].to_bool())? trunc_ln595_2_mid1_fu_7289_p4.read(): select_ln591_5_fu_7133_p3.read());
}

void kernel_3mm_nonP::thread_select_ln592_4_fu_7320_p3() {
    select_ln592_4_fu_7320_p3 = (!and_ln591_fu_7179_p2.read()[0].is_01())? sc_lv<3>(): ((and_ln591_fu_7179_p2.read()[0].to_bool())? trunc_ln646_mid1_fu_7310_p4.read(): select_ln591_6_fu_7140_p3.read());
}

void kernel_3mm_nonP::thread_select_ln592_5_fu_7338_p3() {
    select_ln592_5_fu_7338_p3 = (!and_ln591_fu_7179_p2.read()[0].is_01())? sc_lv<3>(): ((and_ln591_fu_7179_p2.read()[0].to_bool())? trunc_ln692_mid1_fu_7328_p4.read(): select_ln591_7_fu_7147_p3.read());
}

void kernel_3mm_nonP::thread_select_ln592_6_fu_7356_p3() {
    select_ln592_6_fu_7356_p3 = (!and_ln591_fu_7179_p2.read()[0].is_01())? sc_lv<3>(): ((and_ln591_fu_7179_p2.read()[0].to_bool())? trunc_ln738_mid1_fu_7346_p4.read(): select_ln591_8_fu_7154_p3.read());
}

void kernel_3mm_nonP::thread_select_ln592_7_fu_7374_p3() {
    select_ln592_7_fu_7374_p3 = (!and_ln591_fu_7179_p2.read()[0].is_01())? sc_lv<3>(): ((and_ln591_fu_7179_p2.read()[0].to_bool())? trunc_ln784_mid1_fu_7364_p4.read(): select_ln591_9_fu_7161_p3.read());
}

void kernel_3mm_nonP::thread_select_ln592_8_fu_6942_p3() {
    select_ln592_8_fu_6942_p3 = (!icmp_ln592_fu_6868_p2.read()[0].is_01())? sc_lv<8>(): ((icmp_ln592_fu_6868_p2.read()[0].to_bool())? ap_const_lv8_1: add_ln592_1_fu_6936_p2.read());
}

void kernel_3mm_nonP::thread_select_ln592_fu_7195_p3() {
    select_ln592_fu_7195_p3 = (!or_ln592_fu_7190_p2.read()[0].is_01())? sc_lv<4>(): ((or_ln592_fu_7190_p2.read()[0].to_bool())? ap_const_lv4_0: ap_phi_mux_v318_0_phi_fu_4462_p4.read());
}

void kernel_3mm_nonP::thread_select_ln59_1_fu_6067_p3() {
    select_ln59_1_fu_6067_p3 = (!icmp_ln60_fu_6035_p2.read()[0].is_01())? sc_lv<1>(): ((icmp_ln60_fu_6035_p2.read()[0].to_bool())? icmp_ln68_1_fu_6061_p2.read(): icmp_ln68_fu_6011_p2.read());
}

void kernel_3mm_nonP::thread_select_ln59_2_fu_6075_p3() {
    select_ln59_2_fu_6075_p3 = (!icmp_ln60_fu_6035_p2.read()[0].is_01())? sc_lv<5>(): ((icmp_ln60_fu_6035_p2.read()[0].to_bool())? v8_fu_6029_p2.read(): ap_phi_mux_v8_0_phi_fu_4317_p4.read());
}

void kernel_3mm_nonP::thread_select_ln59_fu_6041_p3() {
    select_ln59_fu_6041_p3 = (!icmp_ln60_fu_6035_p2.read()[0].is_01())? sc_lv<3>(): ((icmp_ln60_fu_6035_p2.read()[0].to_bool())? ap_const_lv3_0: ap_phi_mux_v9_0_phi_fu_4339_p4.read());
}

void kernel_3mm_nonP::thread_select_ln60_fu_6270_p3() {
    select_ln60_fu_6270_p3 = (!icmp_ln60_fu_6035_p2.read()[0].is_01())? sc_lv<8>(): ((icmp_ln60_fu_6035_p2.read()[0].to_bool())? ap_const_lv8_1: add_ln60_1_fu_6264_p2.read());
}

void kernel_3mm_nonP::thread_select_ln63_1_fu_6129_p3() {
    select_ln63_1_fu_6129_p3 = (!and_ln59_fu_6103_p2.read()[0].is_01())? sc_lv<3>(): ((and_ln59_fu_6103_p2.read()[0].to_bool())? v9_fu_6109_p2.read(): select_ln59_fu_6041_p3.read());
}

void kernel_3mm_nonP::thread_select_ln63_fu_6121_p3() {
    select_ln63_fu_6121_p3 = (!or_ln63_fu_6115_p2.read()[0].is_01())? sc_lv<5>(): ((or_ln63_fu_6115_p2.read()[0].to_bool())? ap_const_lv5_0: ap_phi_mux_v10_0_phi_fu_4350_p4.read());
}

void kernel_3mm_nonP::thread_sext_ln1011_1_fu_8014_p1() {
    sext_ln1011_1_fu_8014_p1 = esl_sext<64,8>(add_ln1011_reg_10358.read());
}

void kernel_3mm_nonP::thread_sext_ln1011_fu_7955_p1() {
    sext_ln1011_fu_7955_p1 = esl_sext<7,5>(tmp_33_fu_7947_p3.read());
}

void kernel_3mm_nonP::thread_sext_ln325_fu_6602_p1() {
    sext_ln325_fu_6602_p1 = esl_sext<64,12>(grp_fu_8106_p3.read());
}

void kernel_3mm_nonP::thread_sext_ln327_fu_6745_p1() {
    sext_ln327_fu_6745_p1 = esl_sext<7,6>(tmp_12_reg_9020.read());
}

void kernel_3mm_nonP::thread_sext_ln337_fu_6777_p1() {
    sext_ln337_fu_6777_p1 = esl_sext<7,6>(tmp_13_reg_9043.read());
}

void kernel_3mm_nonP::thread_sext_ln596_1_fu_7392_p1() {
    sext_ln596_1_fu_7392_p1 = esl_sext<64,8>(add_ln596_fu_7386_p2.read());
}

void kernel_3mm_nonP::thread_sext_ln596_fu_7087_p1() {
    sext_ln596_fu_7087_p1 = esl_sext<7,5>(tmp_17_fu_7080_p3.read());
}

void kernel_3mm_nonP::thread_sext_ln64_fu_6213_p1() {
    sext_ln64_fu_6213_p1 = esl_sext<64,10>(grp_fu_8097_p3.read());
}

void kernel_3mm_nonP::thread_sext_ln66_fu_6353_p1() {
    sext_ln66_fu_6353_p1 = esl_sext<6,5>(tmp_6_reg_8304_pp0_iter1_reg.read());
}

void kernel_3mm_nonP::thread_sext_ln76_fu_6380_p1() {
    sext_ln76_fu_6380_p1 = esl_sext<6,5>(tmp_7_reg_8345_pp0_iter1_reg.read());
}

void kernel_3mm_nonP::thread_sext_ln831_1_fu_7464_p1() {
    sext_ln831_1_fu_7464_p1 = esl_sext<64,8>(add_ln831_fu_7459_p2.read());
}

void kernel_3mm_nonP::thread_sext_ln831_fu_7420_p1() {
    sext_ln831_fu_7420_p1 = esl_sext<7,5>(tmp_21_fu_7413_p3.read());
}

void kernel_3mm_nonP::thread_sext_ln891_1_fu_7511_p1() {
    sext_ln891_1_fu_7511_p1 = esl_sext<64,8>(add_ln891_fu_7506_p2.read());
}

void kernel_3mm_nonP::thread_sext_ln891_fu_7492_p1() {
    sext_ln891_fu_7492_p1 = esl_sext<7,5>(tmp_25_fu_7485_p3.read());
}

void kernel_3mm_nonP::thread_sext_ln951_1_fu_7974_p1() {
    sext_ln951_1_fu_7974_p1 = esl_sext<64,8>(add_ln951_fu_7969_p2.read());
}

void kernel_3mm_nonP::thread_sext_ln951_fu_7900_p1() {
    sext_ln951_fu_7900_p1 = esl_sext<7,5>(tmp_29_fu_7893_p3.read());
}

void kernel_3mm_nonP::thread_shl_ln1_fu_6201_p3() {
    shl_ln1_fu_6201_p3 = esl_concat<5,1>(select_ln63_fu_6121_p3.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_shl_ln2_fu_6590_p3() {
    shl_ln2_fu_6590_p3 = esl_concat<6,1>(select_ln324_fu_6514_p3.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_shl_ln3_fu_6822_p3() {
    shl_ln3_fu_6822_p3 = esl_concat<4,2>(ap_phi_mux_v316_0_phi_fu_4428_p4.read(), ap_const_lv2_0);
}

void kernel_3mm_nonP::thread_shl_ln595_1_fu_6954_p3() {
    shl_ln595_1_fu_6954_p3 = esl_concat<3,2>(trunc_ln595_reg_9190.read(), ap_const_lv2_0);
}

void kernel_3mm_nonP::thread_shl_ln595_1_mid1_fu_7211_p3() {
    shl_ln595_1_mid1_fu_7211_p3 = esl_concat<3,2>(trunc_ln595_4_fu_7207_p1.read(), ap_const_lv2_0);
}

void kernel_3mm_nonP::thread_shl_ln595_mid1_fu_6886_p3() {
    shl_ln595_mid1_fu_6886_p3 = esl_concat<4,2>(v316_fu_6862_p2.read(), ap_const_lv2_0);
}

void kernel_3mm_nonP::thread_shl_ln63_mid1_fu_6053_p3() {
    shl_ln63_mid1_fu_6053_p3 = esl_concat<5,2>(v8_fu_6029_p2.read(), ap_const_lv2_0);
}

void kernel_3mm_nonP::thread_shl_ln_fu_6003_p3() {
    shl_ln_fu_6003_p3 = esl_concat<5,2>(ap_phi_mux_v8_0_phi_fu_4317_p4.read(), ap_const_lv2_0);
}

void kernel_3mm_nonP::thread_sub_ln1011_fu_7963_p2() {
    sub_ln1011_fu_7963_p2 = (!tmp_32_fu_7939_p3.read().is_01() || !zext_ln1011_fu_7959_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_32_fu_7939_p3.read()) - sc_biguint<8>(zext_ln1011_fu_7959_p1.read()));
}

void kernel_3mm_nonP::thread_sub_ln327_fu_6739_p2() {
    sub_ln327_fu_6739_p2 = (!zext_ln327_fu_6724_p1.read().is_01() || !zext_ln327_1_fu_6735_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(zext_ln327_fu_6724_p1.read()) - sc_biguint<8>(zext_ln327_1_fu_6735_p1.read()));
}

void kernel_3mm_nonP::thread_sub_ln596_fu_7095_p2() {
    sub_ln596_fu_7095_p2 = (!tmp_16_fu_7073_p3.read().is_01() || !zext_ln596_fu_7091_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_16_fu_7073_p3.read()) - sc_biguint<8>(zext_ln596_fu_7091_p1.read()));
}

void kernel_3mm_nonP::thread_sub_ln598_fu_7646_p2() {
    sub_ln598_fu_7646_p2 = (!p_shl8_cast_fu_7628_p3.read().is_01() || !zext_ln598_fu_7642_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(p_shl8_cast_fu_7628_p3.read()) - sc_biguint<8>(zext_ln598_fu_7642_p1.read()));
}

void kernel_3mm_nonP::thread_sub_ln831_fu_7428_p2() {
    sub_ln831_fu_7428_p2 = (!tmp_20_fu_7406_p3.read().is_01() || !zext_ln831_fu_7424_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_20_fu_7406_p3.read()) - sc_biguint<8>(zext_ln831_fu_7424_p1.read()));
}

void kernel_3mm_nonP::thread_sub_ln891_fu_7500_p2() {
    sub_ln891_fu_7500_p2 = (!tmp_24_fu_7478_p3.read().is_01() || !zext_ln891_fu_7496_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_24_fu_7478_p3.read()) - sc_biguint<8>(zext_ln891_fu_7496_p1.read()));
}

void kernel_3mm_nonP::thread_sub_ln951_fu_7908_p2() {
    sub_ln951_fu_7908_p2 = (!tmp_28_fu_7886_p3.read().is_01() || !zext_ln951_fu_7904_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_28_fu_7886_p3.read()) - sc_biguint<8>(zext_ln951_fu_7904_p1.read()));
}

void kernel_3mm_nonP::thread_tmp_10_fu_6717_p3() {
    tmp_10_fu_6717_p3 = esl_concat<3,4>(select_ln324_1_reg_8723_pp1_iter1_reg.read(), ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_tmp_11_fu_6728_p3() {
    tmp_11_fu_6728_p3 = esl_concat<3,1>(select_ln324_1_reg_8723_pp1_iter1_reg.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_tmp_16_fu_7073_p3() {
    tmp_16_fu_7073_p3 = esl_concat<4,4>(tmp_14_reg_9239.read(), ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_tmp_17_fu_7080_p3() {
    tmp_17_fu_7080_p3 = esl_concat<4,1>(tmp_14_reg_9239.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_tmp_20_fu_7406_p3() {
    tmp_20_fu_7406_p3 = esl_concat<4,4>(tmp_18_reg_9287.read(), ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_tmp_21_fu_7413_p3() {
    tmp_21_fu_7413_p3 = esl_concat<4,1>(tmp_18_reg_9287.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_tmp_24_fu_7478_p3() {
    tmp_24_fu_7478_p3 = esl_concat<4,4>(tmp_22_reg_9406.read(), ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_tmp_25_fu_7485_p3() {
    tmp_25_fu_7485_p3 = esl_concat<4,1>(tmp_22_reg_9406.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_tmp_28_fu_7886_p3() {
    tmp_28_fu_7886_p3 = esl_concat<4,4>(tmp_26_reg_10252.read(), ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_tmp_29_fu_7893_p3() {
    tmp_29_fu_7893_p3 = esl_concat<4,1>(tmp_26_reg_10252.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_tmp_2_fu_6137_p3() {
    tmp_2_fu_6137_p3 = esl_concat<3,4>(select_ln63_1_fu_6129_p3.read(), ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_tmp_30_fu_7929_p4() {
    tmp_30_fu_7929_p4 = mul_ln591_4_fu_7923_p2.read().range(13, 10);
}

void kernel_3mm_nonP::thread_tmp_32_fu_7939_p3() {
    tmp_32_fu_7939_p3 = esl_concat<4,4>(tmp_30_fu_7929_p4.read(), ap_const_lv4_0);
}

void kernel_3mm_nonP::thread_tmp_33_fu_7947_p3() {
    tmp_33_fu_7947_p3 = esl_concat<4,1>(tmp_30_fu_7929_p4.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_tmp_34_fu_7635_p3() {
    tmp_34_fu_7635_p3 = esl_concat<4,1>(select_ln592_2_reg_9305.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_tmp_3_fu_6149_p3() {
    tmp_3_fu_6149_p3 = esl_concat<3,2>(select_ln63_1_fu_6129_p3.read(), ap_const_lv2_0);
}

void kernel_3mm_nonP::thread_tmp_4_fu_6325_p3() {
    tmp_4_fu_6325_p3 = esl_concat<3,3>(select_ln63_1_reg_8137_pp0_iter1_reg.read(), ap_const_lv3_0);
}

void kernel_3mm_nonP::thread_tmp_5_fu_6336_p3() {
    tmp_5_fu_6336_p3 = esl_concat<3,1>(select_ln63_1_reg_8137_pp0_iter1_reg.read(), ap_const_lv1_0);
}

void kernel_3mm_nonP::thread_tmp_8_fu_6530_p3() {
    tmp_8_fu_6530_p3 = esl_concat<3,5>(select_ln324_1_fu_6522_p3.read(), ap_const_lv5_0);
}

void kernel_3mm_nonP::thread_tmp_9_fu_6542_p3() {
    tmp_9_fu_6542_p3 = esl_concat<3,3>(select_ln324_1_fu_6522_p3.read(), ap_const_lv3_0);
}

void kernel_3mm_nonP::thread_trunc_ln327_1_fu_6658_p1() {
    trunc_ln327_1_fu_6658_p1 = grp_fu_6609_p2.read().range(3-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln327_fu_6635_p1() {
    trunc_ln327_fu_6635_p1 = grp_fu_6609_p2.read().range(4-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln4_fu_7017_p4() {
    trunc_ln4_fu_7017_p4 = add_ln646_fu_6983_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_trunc_ln595_1_fu_6965_p3() {
    trunc_ln595_1_fu_6965_p3 = esl_concat<1,2>(trunc_ln595_3_reg_9196.read(), ap_const_lv2_0);
}

void kernel_3mm_nonP::thread_trunc_ln595_1_mid1_fu_7227_p3() {
    trunc_ln595_1_mid1_fu_7227_p3 = esl_concat<1,2>(trunc_ln595_5_fu_7223_p1.read(), ap_const_lv2_0);
}

void kernel_3mm_nonP::thread_trunc_ln595_2_fu_7007_p4() {
    trunc_ln595_2_fu_7007_p4 = add_ln595_1_fu_6972_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_trunc_ln595_2_mid1_fu_7289_p4() {
    trunc_ln595_2_mid1_fu_7289_p4 = add_ln595_4_fu_7235_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_trunc_ln595_3_fu_6852_p1() {
    trunc_ln595_3_fu_6852_p1 = ap_phi_mux_v317_0_phi_fu_4450_p4.read().range(1-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln595_4_fu_7207_p1() {
    trunc_ln595_4_fu_7207_p1 = v317_fu_7185_p2.read().range(3-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln595_5_fu_7223_p1() {
    trunc_ln595_5_fu_7223_p1 = v317_fu_7185_p2.read().range(1-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln595_fu_6848_p1() {
    trunc_ln595_fu_6848_p1 = ap_phi_mux_v317_0_phi_fu_4450_p4.read().range(3-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln596_1_fu_7535_p1() {
    trunc_ln596_1_fu_7535_p1 = grp_fu_7068_p2.read().range(4-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln596_fu_7519_p1() {
    trunc_ln596_fu_7519_p1 = grp_fu_6842_p2.read().range(4-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln5_fu_7027_p4() {
    trunc_ln5_fu_7027_p4 = add_ln692_fu_6989_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_trunc_ln646_mid1_fu_7310_p4() {
    trunc_ln646_mid1_fu_7310_p4 = add_ln646_1_fu_7258_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_trunc_ln66_1_fu_6317_p1() {
    trunc_ln66_1_fu_6317_p1 = grp_fu_6222_p2.read().range(3-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln66_fu_6313_p1() {
    trunc_ln66_fu_6313_p1 = grp_fu_6222_p2.read().range(4-1, 0);
}

void kernel_3mm_nonP::thread_trunc_ln692_mid1_fu_7328_p4() {
    trunc_ln692_mid1_fu_7328_p4 = add_ln692_1_fu_7264_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_trunc_ln6_fu_7037_p4() {
    trunc_ln6_fu_7037_p4 = add_ln738_fu_6995_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_trunc_ln738_mid1_fu_7346_p4() {
    trunc_ln738_mid1_fu_7346_p4 = add_ln738_1_fu_7270_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_trunc_ln784_mid1_fu_7364_p4() {
    trunc_ln784_mid1_fu_7364_p4 = add_ln784_1_fu_7276_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_trunc_ln7_fu_7047_p4() {
    trunc_ln7_fu_7047_p4 = add_ln784_fu_7001_p2.read().range(5, 3);
}

void kernel_3mm_nonP::thread_v0_0_0_Addr_A() {
    v0_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_0_0_Addr_A_orig() {
    v0_0_0_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_0_0_Clk_A() {
    v0_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_0_0_Din_A() {
    v0_0_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_0_0_EN_A = ap_const_logic_1;
    } else {
        v0_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_0_0_Rst_A() {
    v0_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_0_0_WEN_A() {
    v0_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_0_1_Addr_A() {
    v0_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_0_1_Addr_A_orig() {
    v0_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_0_1_Clk_A() {
    v0_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_0_1_Din_A() {
    v0_0_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_0_1_EN_A = ap_const_logic_1;
    } else {
        v0_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_0_1_Rst_A() {
    v0_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_0_1_WEN_A() {
    v0_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_0_2_Addr_A() {
    v0_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_0_2_Addr_A_orig() {
    v0_0_2_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_0_2_Clk_A() {
    v0_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_0_2_Din_A() {
    v0_0_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_0_2_EN_A = ap_const_logic_1;
    } else {
        v0_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_0_2_Rst_A() {
    v0_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_0_2_WEN_A() {
    v0_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_1_0_Addr_A() {
    v0_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_1_0_Addr_A_orig() {
    v0_1_0_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_1_0_Clk_A() {
    v0_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_1_0_Din_A() {
    v0_1_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_1_0_EN_A = ap_const_logic_1;
    } else {
        v0_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_1_0_Rst_A() {
    v0_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_1_0_WEN_A() {
    v0_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_1_1_Addr_A() {
    v0_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_1_1_Addr_A_orig() {
    v0_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_1_1_Clk_A() {
    v0_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_1_1_Din_A() {
    v0_1_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_1_1_EN_A = ap_const_logic_1;
    } else {
        v0_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_1_1_Rst_A() {
    v0_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_1_1_WEN_A() {
    v0_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_1_2_Addr_A() {
    v0_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_1_2_Addr_A_orig() {
    v0_1_2_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_1_2_Clk_A() {
    v0_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_1_2_Din_A() {
    v0_1_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_1_2_EN_A = ap_const_logic_1;
    } else {
        v0_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_1_2_Rst_A() {
    v0_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_1_2_WEN_A() {
    v0_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_2_0_Addr_A() {
    v0_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_2_0_Addr_A_orig() {
    v0_2_0_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_2_0_Clk_A() {
    v0_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_2_0_Din_A() {
    v0_2_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_2_0_EN_A = ap_const_logic_1;
    } else {
        v0_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_2_0_Rst_A() {
    v0_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_2_0_WEN_A() {
    v0_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_2_1_Addr_A() {
    v0_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_2_1_Addr_A_orig() {
    v0_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_2_1_Clk_A() {
    v0_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_2_1_Din_A() {
    v0_2_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_2_1_EN_A = ap_const_logic_1;
    } else {
        v0_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_2_1_Rst_A() {
    v0_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_2_1_WEN_A() {
    v0_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_2_2_Addr_A() {
    v0_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_2_2_Addr_A_orig() {
    v0_2_2_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_2_2_Clk_A() {
    v0_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_2_2_Din_A() {
    v0_2_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_2_2_EN_A = ap_const_logic_1;
    } else {
        v0_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_2_2_Rst_A() {
    v0_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_2_2_WEN_A() {
    v0_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_3_0_Addr_A() {
    v0_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_3_0_Addr_A_orig() {
    v0_3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_3_0_Clk_A() {
    v0_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_3_0_Din_A() {
    v0_3_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_3_0_EN_A = ap_const_logic_1;
    } else {
        v0_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_3_0_Rst_A() {
    v0_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_3_0_WEN_A() {
    v0_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_3_1_Addr_A() {
    v0_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_3_1_Addr_A_orig() {
    v0_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_3_1_Clk_A() {
    v0_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_3_1_Din_A() {
    v0_3_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_3_1_EN_A = ap_const_logic_1;
    } else {
        v0_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_3_1_Rst_A() {
    v0_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_3_1_WEN_A() {
    v0_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_3_2_Addr_A() {
    v0_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_3_2_Addr_A_orig() {
    v0_3_2_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_3_2_Clk_A() {
    v0_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_3_2_Din_A() {
    v0_3_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_3_2_EN_A = ap_const_logic_1;
    } else {
        v0_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_3_2_Rst_A() {
    v0_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_3_2_WEN_A() {
    v0_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_4_0_Addr_A() {
    v0_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_4_0_Addr_A_orig() {
    v0_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_4_0_Clk_A() {
    v0_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_4_0_Din_A() {
    v0_4_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_4_0_EN_A = ap_const_logic_1;
    } else {
        v0_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_4_0_Rst_A() {
    v0_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_4_0_WEN_A() {
    v0_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_4_1_Addr_A() {
    v0_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_4_1_Addr_A_orig() {
    v0_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_4_1_Clk_A() {
    v0_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_4_1_Din_A() {
    v0_4_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_4_1_EN_A = ap_const_logic_1;
    } else {
        v0_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_4_1_Rst_A() {
    v0_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_4_1_WEN_A() {
    v0_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_4_2_Addr_A() {
    v0_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_4_2_Addr_A_orig() {
    v0_4_2_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_4_2_Clk_A() {
    v0_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_4_2_Din_A() {
    v0_4_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_4_2_EN_A = ap_const_logic_1;
    } else {
        v0_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_4_2_Rst_A() {
    v0_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_4_2_WEN_A() {
    v0_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_5_0_Addr_A() {
    v0_5_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_5_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_5_0_Addr_A_orig() {
    v0_5_0_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_5_0_Clk_A() {
    v0_5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_5_0_Din_A() {
    v0_5_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_5_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_5_0_EN_A = ap_const_logic_1;
    } else {
        v0_5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_5_0_Rst_A() {
    v0_5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_5_0_WEN_A() {
    v0_5_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_5_1_Addr_A() {
    v0_5_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_5_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_5_1_Addr_A_orig() {
    v0_5_1_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_5_1_Clk_A() {
    v0_5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_5_1_Din_A() {
    v0_5_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_5_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_5_1_EN_A = ap_const_logic_1;
    } else {
        v0_5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_5_1_Rst_A() {
    v0_5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_5_1_WEN_A() {
    v0_5_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_5_2_Addr_A() {
    v0_5_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_5_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_5_2_Addr_A_orig() {
    v0_5_2_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_5_2_Clk_A() {
    v0_5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_5_2_Din_A() {
    v0_5_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_5_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_5_2_EN_A = ap_const_logic_1;
    } else {
        v0_5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_5_2_Rst_A() {
    v0_5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_5_2_WEN_A() {
    v0_5_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_6_0_Addr_A() {
    v0_6_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_6_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_6_0_Addr_A_orig() {
    v0_6_0_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_6_0_Clk_A() {
    v0_6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_6_0_Din_A() {
    v0_6_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_6_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_6_0_EN_A = ap_const_logic_1;
    } else {
        v0_6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_6_0_Rst_A() {
    v0_6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_6_0_WEN_A() {
    v0_6_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_6_1_Addr_A() {
    v0_6_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_6_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_6_1_Addr_A_orig() {
    v0_6_1_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_6_1_Clk_A() {
    v0_6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_6_1_Din_A() {
    v0_6_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_6_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_6_1_EN_A = ap_const_logic_1;
    } else {
        v0_6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_6_1_Rst_A() {
    v0_6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_6_1_WEN_A() {
    v0_6_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_6_2_Addr_A() {
    v0_6_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_6_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_6_2_Addr_A_orig() {
    v0_6_2_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_6_2_Clk_A() {
    v0_6_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_6_2_Din_A() {
    v0_6_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_6_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_6_2_EN_A = ap_const_logic_1;
    } else {
        v0_6_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_6_2_Rst_A() {
    v0_6_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_6_2_WEN_A() {
    v0_6_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_7_0_Addr_A() {
    v0_7_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_7_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_7_0_Addr_A_orig() {
    v0_7_0_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_7_0_Clk_A() {
    v0_7_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_7_0_Din_A() {
    v0_7_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_7_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_7_0_EN_A = ap_const_logic_1;
    } else {
        v0_7_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_7_0_Rst_A() {
    v0_7_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_7_0_WEN_A() {
    v0_7_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_7_1_Addr_A() {
    v0_7_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_7_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_7_1_Addr_A_orig() {
    v0_7_1_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_7_1_Clk_A() {
    v0_7_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_7_1_Din_A() {
    v0_7_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_7_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_7_1_EN_A = ap_const_logic_1;
    } else {
        v0_7_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_7_1_Rst_A() {
    v0_7_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_7_1_WEN_A() {
    v0_7_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v0_7_2_Addr_A() {
    v0_7_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v0_7_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v0_7_2_Addr_A_orig() {
    v0_7_2_Addr_A_orig =  (sc_lv<32>) (zext_ln63_2_fu_6173_p1.read());
}

void kernel_3mm_nonP::thread_v0_7_2_Clk_A() {
    v0_7_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v0_7_2_Din_A() {
    v0_7_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v0_7_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v0_7_2_EN_A = ap_const_logic_1;
    } else {
        v0_7_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v0_7_2_Rst_A() {
    v0_7_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v0_7_2_WEN_A() {
    v0_7_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v10_fu_6258_p2() {
    v10_fu_6258_p2 = (!select_ln63_fu_6121_p3.read().is_01() || !ap_const_lv5_1.is_01())? sc_lv<5>(): (sc_biguint<5>(select_ln63_fu_6121_p3.read()) + sc_biguint<5>(ap_const_lv5_1));
}

void kernel_3mm_nonP::thread_v169_fu_6428_p2() {
    v169_fu_6428_p2 = (!ap_const_lv6_1.is_01() || !ap_phi_mux_v169_0_phi_fu_4372_p4.read().is_01())? sc_lv<6>(): (sc_biguint<6>(ap_const_lv6_1) + sc_biguint<6>(ap_phi_mux_v169_0_phi_fu_4372_p4.read()));
}

void kernel_3mm_nonP::thread_v170_fu_6502_p2() {
    v170_fu_6502_p2 = (!ap_const_lv3_1.is_01() || !select_ln329_fu_6440_p3.read().is_01())? sc_lv<3>(): (sc_biguint<3>(ap_const_lv3_1) + sc_biguint<3>(select_ln329_fu_6440_p3.read()));
}

void kernel_3mm_nonP::thread_v171_fu_6615_p2() {
    v171_fu_6615_p2 = (!select_ln324_fu_6514_p3.read().is_01() || !ap_const_lv6_1.is_01())? sc_lv<6>(): (sc_biguint<6>(select_ln324_fu_6514_p3.read()) + sc_biguint<6>(ap_const_lv6_1));
}

void kernel_3mm_nonP::thread_v1_0_0_Addr_A() {
    v1_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v1_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v1_0_0_Addr_A_orig() {
    v1_0_0_Addr_A_orig =  (sc_lv<32>) (sext_ln64_fu_6213_p1.read());
}

void kernel_3mm_nonP::thread_v1_0_0_Clk_A() {
    v1_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v1_0_0_Din_A() {
    v1_0_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v1_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v1_0_0_EN_A = ap_const_logic_1;
    } else {
        v1_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v1_0_0_Rst_A() {
    v1_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v1_0_0_WEN_A() {
    v1_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v1_0_1_Addr_A() {
    v1_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v1_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v1_0_1_Addr_A_orig() {
    v1_0_1_Addr_A_orig =  (sc_lv<32>) (sext_ln64_fu_6213_p1.read());
}

void kernel_3mm_nonP::thread_v1_0_1_Clk_A() {
    v1_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v1_0_1_Din_A() {
    v1_0_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v1_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v1_0_1_EN_A = ap_const_logic_1;
    } else {
        v1_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v1_0_1_Rst_A() {
    v1_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v1_0_1_WEN_A() {
    v1_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v1_1_0_Addr_A() {
    v1_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v1_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v1_1_0_Addr_A_orig() {
    v1_1_0_Addr_A_orig =  (sc_lv<32>) (sext_ln64_fu_6213_p1.read());
}

void kernel_3mm_nonP::thread_v1_1_0_Clk_A() {
    v1_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v1_1_0_Din_A() {
    v1_1_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v1_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v1_1_0_EN_A = ap_const_logic_1;
    } else {
        v1_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v1_1_0_Rst_A() {
    v1_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v1_1_0_WEN_A() {
    v1_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v1_1_1_Addr_A() {
    v1_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v1_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v1_1_1_Addr_A_orig() {
    v1_1_1_Addr_A_orig =  (sc_lv<32>) (sext_ln64_fu_6213_p1.read());
}

void kernel_3mm_nonP::thread_v1_1_1_Clk_A() {
    v1_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v1_1_1_Din_A() {
    v1_1_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v1_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v1_1_1_EN_A = ap_const_logic_1;
    } else {
        v1_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v1_1_1_Rst_A() {
    v1_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v1_1_1_WEN_A() {
    v1_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v1_2_0_Addr_A() {
    v1_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v1_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v1_2_0_Addr_A_orig() {
    v1_2_0_Addr_A_orig =  (sc_lv<32>) (sext_ln64_fu_6213_p1.read());
}

void kernel_3mm_nonP::thread_v1_2_0_Clk_A() {
    v1_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v1_2_0_Din_A() {
    v1_2_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v1_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v1_2_0_EN_A = ap_const_logic_1;
    } else {
        v1_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v1_2_0_Rst_A() {
    v1_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v1_2_0_WEN_A() {
    v1_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v1_2_1_Addr_A() {
    v1_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v1_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v1_2_1_Addr_A_orig() {
    v1_2_1_Addr_A_orig =  (sc_lv<32>) (sext_ln64_fu_6213_p1.read());
}

void kernel_3mm_nonP::thread_v1_2_1_Clk_A() {
    v1_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v1_2_1_Din_A() {
    v1_2_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v1_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v1_2_1_EN_A = ap_const_logic_1;
    } else {
        v1_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v1_2_1_Rst_A() {
    v1_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v1_2_1_WEN_A() {
    v1_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_0_0_Addr_A() {
    v2_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_0_0_Addr_A_orig() {
    v2_0_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_0_0_Clk_A() {
    v2_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_0_0_Din_A() {
    v2_0_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_0_0_EN_A = ap_const_logic_1;
    } else {
        v2_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_0_0_Rst_A() {
    v2_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_0_0_WEN_A() {
    v2_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_0_1_Addr_A() {
    v2_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_0_1_Addr_A_orig() {
    v2_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_0_1_Clk_A() {
    v2_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_0_1_Din_A() {
    v2_0_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_0_1_EN_A = ap_const_logic_1;
    } else {
        v2_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_0_1_Rst_A() {
    v2_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_0_1_WEN_A() {
    v2_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_1_0_Addr_A() {
    v2_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_1_0_Addr_A_orig() {
    v2_1_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_1_0_Clk_A() {
    v2_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_1_0_Din_A() {
    v2_1_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_1_0_EN_A = ap_const_logic_1;
    } else {
        v2_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_1_0_Rst_A() {
    v2_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_1_0_WEN_A() {
    v2_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_1_1_Addr_A() {
    v2_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_1_1_Addr_A_orig() {
    v2_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_1_1_Clk_A() {
    v2_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_1_1_Din_A() {
    v2_1_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_1_1_EN_A = ap_const_logic_1;
    } else {
        v2_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_1_1_Rst_A() {
    v2_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_1_1_WEN_A() {
    v2_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_2_0_Addr_A() {
    v2_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_2_0_Addr_A_orig() {
    v2_2_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_2_0_Clk_A() {
    v2_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_2_0_Din_A() {
    v2_2_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_2_0_EN_A = ap_const_logic_1;
    } else {
        v2_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_2_0_Rst_A() {
    v2_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_2_0_WEN_A() {
    v2_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_2_1_Addr_A() {
    v2_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_2_1_Addr_A_orig() {
    v2_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_2_1_Clk_A() {
    v2_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_2_1_Din_A() {
    v2_2_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_2_1_EN_A = ap_const_logic_1;
    } else {
        v2_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_2_1_Rst_A() {
    v2_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_2_1_WEN_A() {
    v2_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_3_0_Addr_A() {
    v2_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_3_0_Addr_A_orig() {
    v2_3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_3_0_Clk_A() {
    v2_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_3_0_Din_A() {
    v2_3_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_3_0_EN_A = ap_const_logic_1;
    } else {
        v2_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_3_0_Rst_A() {
    v2_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_3_0_WEN_A() {
    v2_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_3_1_Addr_A() {
    v2_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_3_1_Addr_A_orig() {
    v2_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_3_1_Clk_A() {
    v2_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_3_1_Din_A() {
    v2_3_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_3_1_EN_A = ap_const_logic_1;
    } else {
        v2_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_3_1_Rst_A() {
    v2_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_3_1_WEN_A() {
    v2_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_4_0_Addr_A() {
    v2_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_4_0_Addr_A_orig() {
    v2_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_4_0_Clk_A() {
    v2_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_4_0_Din_A() {
    v2_4_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_4_0_EN_A = ap_const_logic_1;
    } else {
        v2_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_4_0_Rst_A() {
    v2_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_4_0_WEN_A() {
    v2_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_4_1_Addr_A() {
    v2_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_4_1_Addr_A_orig() {
    v2_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_4_1_Clk_A() {
    v2_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_4_1_Din_A() {
    v2_4_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_4_1_EN_A = ap_const_logic_1;
    } else {
        v2_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_4_1_Rst_A() {
    v2_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_4_1_WEN_A() {
    v2_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_5_0_Addr_A() {
    v2_5_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_5_0_Addr_A_orig() {
    v2_5_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_5_0_Clk_A() {
    v2_5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_5_0_Din_A() {
    v2_5_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_5_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_5_0_EN_A = ap_const_logic_1;
    } else {
        v2_5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_5_0_Rst_A() {
    v2_5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_5_0_WEN_A() {
    v2_5_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_5_1_Addr_A() {
    v2_5_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_5_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_5_1_Addr_A_orig() {
    v2_5_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_5_1_Clk_A() {
    v2_5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_5_1_Din_A() {
    v2_5_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_5_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_5_1_EN_A = ap_const_logic_1;
    } else {
        v2_5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_5_1_Rst_A() {
    v2_5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_5_1_WEN_A() {
    v2_5_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_6_0_Addr_A() {
    v2_6_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_6_0_Addr_A_orig() {
    v2_6_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_6_0_Clk_A() {
    v2_6_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_6_0_Din_A() {
    v2_6_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_6_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_6_0_EN_A = ap_const_logic_1;
    } else {
        v2_6_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_6_0_Rst_A() {
    v2_6_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_6_0_WEN_A() {
    v2_6_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_6_1_Addr_A() {
    v2_6_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_6_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_6_1_Addr_A_orig() {
    v2_6_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_6_1_Clk_A() {
    v2_6_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_6_1_Din_A() {
    v2_6_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_6_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_6_1_EN_A = ap_const_logic_1;
    } else {
        v2_6_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_6_1_Rst_A() {
    v2_6_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_6_1_WEN_A() {
    v2_6_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_7_0_Addr_A() {
    v2_7_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_7_0_Addr_A_orig() {
    v2_7_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_7_0_Clk_A() {
    v2_7_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_7_0_Din_A() {
    v2_7_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_7_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_7_0_EN_A = ap_const_logic_1;
    } else {
        v2_7_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_7_0_Rst_A() {
    v2_7_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_7_0_WEN_A() {
    v2_7_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_7_1_Addr_A() {
    v2_7_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_7_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_7_1_Addr_A_orig() {
    v2_7_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_7_1_Clk_A() {
    v2_7_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_7_1_Din_A() {
    v2_7_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_7_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_7_1_EN_A = ap_const_logic_1;
    } else {
        v2_7_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_7_1_Rst_A() {
    v2_7_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_7_1_WEN_A() {
    v2_7_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_8_0_Addr_A() {
    v2_8_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_8_0_Addr_A_orig() {
    v2_8_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_8_0_Clk_A() {
    v2_8_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_8_0_Din_A() {
    v2_8_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_8_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_8_0_EN_A = ap_const_logic_1;
    } else {
        v2_8_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_8_0_Rst_A() {
    v2_8_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_8_0_WEN_A() {
    v2_8_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_8_1_Addr_A() {
    v2_8_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_8_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_8_1_Addr_A_orig() {
    v2_8_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_8_1_Clk_A() {
    v2_8_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_8_1_Din_A() {
    v2_8_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_8_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_8_1_EN_A = ap_const_logic_1;
    } else {
        v2_8_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_8_1_Rst_A() {
    v2_8_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_8_1_WEN_A() {
    v2_8_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_9_0_Addr_A() {
    v2_9_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_9_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_9_0_Addr_A_orig() {
    v2_9_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_9_0_Clk_A() {
    v2_9_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_9_0_Din_A() {
    v2_9_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_9_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_9_0_EN_A = ap_const_logic_1;
    } else {
        v2_9_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_9_0_Rst_A() {
    v2_9_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_9_0_WEN_A() {
    v2_9_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v2_9_1_Addr_A() {
    v2_9_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_9_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP::thread_v2_9_1_Addr_A_orig() {
    v2_9_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_2_fu_6566_p1.read());
}

void kernel_3mm_nonP::thread_v2_9_1_Clk_A() {
    v2_9_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP::thread_v2_9_1_Din_A() {
    v2_9_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP::thread_v2_9_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        v2_9_1_EN_A = ap_const_logic_1;
    } else {
        v2_9_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP::thread_v2_9_1_Rst_A() {
    v2_9_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP::thread_v2_9_1_WEN_A() {
    v2_9_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP::thread_v316_fu_6862_p2() {
    v316_fu_6862_p2 = (!ap_const_lv4_1.is_01() || !ap_phi_mux_v316_0_phi_fu_4428_p4.read().is_01())? sc_lv<4>(): (sc_biguint<4>(ap_const_lv4_1) + sc_biguint<4>(ap_phi_mux_v316_0_phi_fu_4428_p4.read()));
}

void kernel_3mm_nonP::thread_v317_fu_7185_p2() {
    v317_fu_7185_p2 = (!ap_const_lv4_1.is_01() || !select_ln591_reg_9219.read().is_01())? sc_lv<4>(): (sc_biguint<4>(ap_const_lv4_1) + sc_biguint<4>(select_ln591_reg_9219.read()));
}

void kernel_3mm_nonP::thread_v318_fu_7623_p2() {
    v318_fu_7623_p2 = (!ap_const_lv4_1.is_01() || !select_ln592_reg_9293.read().is_01())? sc_lv<4>(): (sc_biguint<4>(ap_const_lv4_1) + sc_biguint<4>(select_ln592_reg_9293.read()));
}

void kernel_3mm_nonP::thread_v320_fu_7551_p3() {
    v320_fu_7551_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_0_0_load_reg_9471.read(): v5_5_0_load_reg_9476.read());
}

void kernel_3mm_nonP::thread_v323_1_fu_7686_p3() {
    v323_1_fu_7686_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_0_0_Dout_A.read());
}

void kernel_3mm_nonP::thread_v325_fu_7557_p3() {
    v325_fu_7557_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_0_1_load_reg_9481.read(): v5_5_1_load_reg_9486.read());
}

void kernel_3mm_nonP::thread_v328_1_fu_7693_p3() {
    v328_1_fu_7693_p3 = (!select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].is_01())? sc_lv<32>(): ((select_ln591_1_reg_9258_pp2_iter1_reg.read()[0].to_bool())? ap_const_lv32_0: v6_0_1_Dout_A.read());
}

void kernel_3mm_nonP::thread_v330_fu_7563_p3() {
    v330_fu_7563_p3 = (!select_ln591_3_fu_7545_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_7545_p3.read()[0].to_bool())? v5_0_2_load_reg_9491.read(): v5_5_2_load_reg_9496.read());
}

}


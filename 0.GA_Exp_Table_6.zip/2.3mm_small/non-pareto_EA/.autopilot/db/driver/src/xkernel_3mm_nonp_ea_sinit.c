// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xkernel_3mm_nonp_ea.h"

extern XKernel_3mm_nonp_ea_Config XKernel_3mm_nonp_ea_ConfigTable[];

XKernel_3mm_nonp_ea_Config *XKernel_3mm_nonp_ea_LookupConfig(u16 DeviceId) {
	XKernel_3mm_nonp_ea_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XKERNEL_3MM_NONP_EA_NUM_INSTANCES; Index++) {
		if (XKernel_3mm_nonp_ea_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XKernel_3mm_nonp_ea_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XKernel_3mm_nonp_ea_Initialize(XKernel_3mm_nonp_ea *InstancePtr, u16 DeviceId) {
	XKernel_3mm_nonp_ea_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XKernel_3mm_nonp_ea_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XKernel_3mm_nonp_ea_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif


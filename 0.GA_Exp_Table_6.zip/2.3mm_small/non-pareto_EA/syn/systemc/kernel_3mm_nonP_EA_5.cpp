#include "kernel_3mm_nonP_EA.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void kernel_3mm_nonP_EA::thread_v2_8_1_Clk_A() {
    v2_8_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v2_8_1_Din_A() {
    v2_8_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v2_8_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_8_1_EN_A = ap_const_logic_1;
    } else {
        v2_8_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v2_8_1_Rst_A() {
    v2_8_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v2_8_1_WEN_A() {
    v2_8_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v2_9_0_Addr_A() {
    v2_9_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_9_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v2_9_0_Addr_A_orig() {
    v2_9_0_Addr_A_orig =  (sc_lv<32>) (zext_ln324_3_fu_4407_p1.read());
}

void kernel_3mm_nonP_EA::thread_v2_9_0_Clk_A() {
    v2_9_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v2_9_0_Din_A() {
    v2_9_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v2_9_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_9_0_EN_A = ap_const_logic_1;
    } else {
        v2_9_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v2_9_0_Rst_A() {
    v2_9_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v2_9_0_WEN_A() {
    v2_9_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v2_9_1_Addr_A() {
    v2_9_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v2_9_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v2_9_1_Addr_A_orig() {
    v2_9_1_Addr_A_orig =  (sc_lv<32>) (zext_ln324_3_fu_4407_p1.read());
}

void kernel_3mm_nonP_EA::thread_v2_9_1_Clk_A() {
    v2_9_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v2_9_1_Din_A() {
    v2_9_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v2_9_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v2_9_1_EN_A = ap_const_logic_1;
    } else {
        v2_9_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v2_9_1_Rst_A() {
    v2_9_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v2_9_1_WEN_A() {
    v2_9_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v316_fu_4725_p2() {
    v316_fu_4725_p2 = (!ap_const_lv4_1.is_01() || !ap_phi_mux_v316_0_phi_fu_2803_p4.read().is_01())? sc_lv<4>(): (sc_biguint<4>(ap_const_lv4_1) + sc_biguint<4>(ap_phi_mux_v316_0_phi_fu_2803_p4.read()));
}

void kernel_3mm_nonP_EA::thread_v317_fu_4831_p2() {
    v317_fu_4831_p2 = (!ap_const_lv4_1.is_01() || !select_ln591_fu_4737_p3.read().is_01())? sc_lv<4>(): (sc_biguint<4>(ap_const_lv4_1) + sc_biguint<4>(select_ln591_fu_4737_p3.read()));
}

void kernel_3mm_nonP_EA::thread_v318_fu_5311_p2() {
    v318_fu_5311_p2 = (!ap_const_lv4_1.is_01() || !select_ln592_reg_7827.read().is_01())? sc_lv<4>(): (sc_biguint<4>(ap_const_lv4_1) + sc_biguint<4>(select_ln592_reg_7827.read()));
}

void kernel_3mm_nonP_EA::thread_v320_fu_5877_p3() {
    v320_fu_5877_p3 = (!select_ln591_3_fu_5826_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_5826_p3.read()[0].to_bool())? reg_3578.read(): reg_3586.read());
}

void kernel_3mm_nonP_EA::thread_v323_1_fu_5136_p3() {
    v323_1_fu_5136_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_0_0_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v325_fu_5885_p3() {
    v325_fu_5885_p3 = (!select_ln591_3_fu_5826_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_5826_p3.read()[0].to_bool())? v5_0_load_1_reg_8383.read(): v5_5_load_1_reg_8388.read());
}

void kernel_3mm_nonP_EA::thread_v328_1_fu_5143_p3() {
    v328_1_fu_5143_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_0_1_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v330_fu_5901_p3() {
    v330_fu_5901_p3 = (!select_ln591_3_fu_5826_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_5826_p3.read()[0].to_bool())? v5_0_load_2_reg_8457.read(): v5_5_load_2_reg_8462.read());
}

void kernel_3mm_nonP_EA::thread_v333_1_fu_5150_p3() {
    v333_1_fu_5150_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_0_2_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v335_fu_5907_p3() {
    v335_fu_5907_p3 = (!select_ln591_3_fu_5826_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_5826_p3.read()[0].to_bool())? v5_0_load_3_reg_8531.read(): v5_5_load_3_reg_8536.read());
}

void kernel_3mm_nonP_EA::thread_v338_1_fu_5157_p3() {
    v338_1_fu_5157_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_0_3_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v340_fu_5913_p3() {
    v340_fu_5913_p3 = (!select_ln591_3_fu_5826_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_5826_p3.read()[0].to_bool())? v5_0_load_4_reg_8602.read(): v5_5_load_4_reg_8607.read());
}

void kernel_3mm_nonP_EA::thread_v343_1_fu_5164_p3() {
    v343_1_fu_5164_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_0_4_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v348_1_fu_5171_p3() {
    v348_1_fu_5171_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_1_0_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v34_1_fu_4215_p3() {
    v34_1_fu_4215_p3 = (!select_ln59_1_reg_6262.read()[0].is_01())? sc_lv<32>(): ((select_ln59_1_reg_6262.read()[0].to_bool())? ap_const_lv32_0: v33_reg_6757.read());
}

void kernel_3mm_nonP_EA::thread_v352_1_fu_5178_p3() {
    v352_1_fu_5178_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_1_1_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v356_1_fu_5185_p3() {
    v356_1_fu_5185_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_1_2_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v360_1_fu_5192_p3() {
    v360_1_fu_5192_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_1_3_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v364_1_fu_5199_p3() {
    v364_1_fu_5199_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_1_4_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v369_1_fu_5206_p3() {
    v369_1_fu_5206_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_2_0_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v373_1_fu_5213_p3() {
    v373_1_fu_5213_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_2_1_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v377_1_fu_5220_p3() {
    v377_1_fu_5220_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_2_2_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v381_1_fu_5227_p3() {
    v381_1_fu_5227_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_2_3_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v385_1_fu_5234_p3() {
    v385_1_fu_5234_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_2_4_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v390_1_fu_5241_p3() {
    v390_1_fu_5241_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_3_0_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v394_1_fu_5248_p3() {
    v394_1_fu_5248_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_3_1_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v398_1_fu_5255_p3() {
    v398_1_fu_5255_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_3_2_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v3_0_0_Addr_A() {
    v3_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v3_0_0_Addr_A_orig() {
    v3_0_0_Addr_A_orig =  (sc_lv<32>) (sext_ln325_fu_4434_p1.read());
}

void kernel_3mm_nonP_EA::thread_v3_0_0_Clk_A() {
    v3_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v3_0_0_Din_A() {
    v3_0_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v3_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v3_0_0_EN_A = ap_const_logic_1;
    } else {
        v3_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v3_0_0_Rst_A() {
    v3_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v3_0_0_WEN_A() {
    v3_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v3_0_1_Addr_A() {
    v3_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v3_0_1_Addr_A_orig() {
    v3_0_1_Addr_A_orig =  (sc_lv<32>) (sext_ln325_fu_4434_p1.read());
}

void kernel_3mm_nonP_EA::thread_v3_0_1_Clk_A() {
    v3_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v3_0_1_Din_A() {
    v3_0_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v3_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v3_0_1_EN_A = ap_const_logic_1;
    } else {
        v3_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v3_0_1_Rst_A() {
    v3_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v3_0_1_WEN_A() {
    v3_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v3_1_0_Addr_A() {
    v3_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v3_1_0_Addr_A_orig() {
    v3_1_0_Addr_A_orig =  (sc_lv<32>) (sext_ln325_fu_4434_p1.read());
}

void kernel_3mm_nonP_EA::thread_v3_1_0_Clk_A() {
    v3_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v3_1_0_Din_A() {
    v3_1_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v3_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v3_1_0_EN_A = ap_const_logic_1;
    } else {
        v3_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v3_1_0_Rst_A() {
    v3_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v3_1_0_WEN_A() {
    v3_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v3_1_1_Addr_A() {
    v3_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v3_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v3_1_1_Addr_A_orig() {
    v3_1_1_Addr_A_orig =  (sc_lv<32>) (sext_ln325_fu_4434_p1.read());
}

void kernel_3mm_nonP_EA::thread_v3_1_1_Clk_A() {
    v3_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v3_1_1_Din_A() {
    v3_1_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v3_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        v3_1_1_EN_A = ap_const_logic_1;
    } else {
        v3_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v3_1_1_Rst_A() {
    v3_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v3_1_1_WEN_A() {
    v3_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v402_1_fu_5262_p3() {
    v402_1_fu_5262_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_3_3_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v406_1_fu_5269_p3() {
    v406_1_fu_5269_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_3_4_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v411_1_fu_5276_p3() {
    v411_1_fu_5276_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_4_0_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v415_1_fu_5283_p3() {
    v415_1_fu_5283_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_4_1_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v419_1_fu_5290_p3() {
    v419_1_fu_5290_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_4_2_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v423_1_fu_5297_p3() {
    v423_1_fu_5297_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_4_3_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v427_1_fu_5304_p3() {
    v427_1_fu_5304_p3 = (!select_ln591_2_reg_7874.read()[0].is_01())? sc_lv<32>(): ((select_ln591_2_reg_7874.read()[0].to_bool())? ap_const_lv32_0: v6_4_4_Dout_A.read());
}

void kernel_3mm_nonP_EA::thread_v430_fu_5919_p3() {
    v430_fu_5919_p3 = (!select_ln591_3_fu_5826_p3.read()[0].is_01())? sc_lv<32>(): ((select_ln591_3_fu_5826_p3.read()[0].to_bool())? reg_3582.read(): reg_3590.read());
}

void kernel_3mm_nonP_EA::thread_v43_1_fu_4226_p3() {
    v43_1_fu_4226_p3 = (!select_ln59_1_reg_6262.read()[0].is_01())? sc_lv<32>(): ((select_ln59_1_reg_6262.read()[0].to_bool())? ap_const_lv32_0: v42_reg_6762.read());
}

void kernel_3mm_nonP_EA::thread_v4_0_Addr_A() {
    v4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v4_0_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln1079_fu_6178_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1047_fu_6137_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1010_fu_6099_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1063_fu_6039_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln999_fu_6044_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln1031_fu_5971_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln977_fu_5981_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln988_fu_5860_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln950_fu_5850_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln966_fu_5790_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln939_fu_5800_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln928_fu_5724_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln917_fu_5714_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln906_fu_5681_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln879_fu_5691_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln868_fu_5612_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln784_fu_5632_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln857_fu_5562_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln738_fu_5582_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln846_fu_5512_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln692_fu_5532_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln890_fu_5396_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln646_fu_5416_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln830_fu_5072_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln595_fu_4955_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln190_fu_4242_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln181_fu_4232_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln152_fu_4221_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln143_fu_4179_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln114_fu_4169_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln105_fu_4159_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln76_fu_4140_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        v4_0_Addr_A_orig =  (sc_lv<32>) (sext_ln66_fu_4099_p1.read());
    } else {
        v4_0_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v4_0_Addr_B() {
    v4_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v4_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        v4_0_Addr_B_orig =  (sc_lv<32>) (v4_0_addr_7_reg_6878_pp0_iter3_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        v4_0_Addr_B_orig =  (sc_lv<32>) (v4_0_addr_3_reg_6851_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        v4_0_Addr_B_orig =  (sc_lv<32>) (v4_0_addr_6_reg_6819_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v4_0_Addr_B_orig =  (sc_lv<32>) (v4_0_addr_2_reg_6767_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        v4_0_Addr_B_orig =  (sc_lv<32>) (v4_0_addr_5_reg_6745_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        v4_0_Addr_B_orig =  (sc_lv<32>) (v4_0_addr_1_reg_6723_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        v4_0_Addr_B_orig =  (sc_lv<32>) (v4_0_addr_4_reg_6532_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        v4_0_Addr_B_orig =  (sc_lv<32>) (v4_0_addr_reg_6459_pp0_iter2_reg.read());
    } else {
        v4_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v4_0_Clk_A() {
    v4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v4_0_Clk_B() {
    v4_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v4_0_Din_A() {
    v4_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v4_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        v4_0_Din_B = reg_3314.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        v4_0_Din_B = reg_3244.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v4_0_Din_B = reg_3237.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)))) {
        v4_0_Din_B = reg_3560.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        v4_0_Din_B = reg_3514.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        v4_0_Din_B = reg_3482.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        v4_0_Din_B = reg_3476.read();
    } else {
        v4_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v4_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)))) {
        v4_0_EN_A = ap_const_logic_1;
    } else {
        v4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v4_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)))) {
        v4_0_EN_B = ap_const_logic_1;
    } else {
        v4_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v4_0_Rst_A() {
    v4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v4_0_Rst_B() {
    v4_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v4_0_WEN_A() {
    v4_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v4_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter3_reg.read())))) {
        v4_0_WEN_B = ap_const_lv4_F;
    } else {
        v4_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v4_1_Addr_A() {
    v4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v4_1_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln1079_fu_6178_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1047_fu_6137_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1010_fu_6099_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1063_fu_6039_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln999_fu_6044_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln1031_fu_5971_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln977_fu_5981_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln988_fu_5860_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln950_fu_5850_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln966_fu_5790_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln939_fu_5800_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln928_fu_5724_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln917_fu_5714_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln906_fu_5681_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln879_fu_5691_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln868_fu_5612_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln784_fu_5632_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln857_fu_5562_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln738_fu_5582_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln846_fu_5512_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln692_fu_5532_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln890_fu_5396_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln646_fu_5416_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln830_fu_5072_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln595_fu_4955_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln190_fu_4242_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln181_fu_4232_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln152_fu_4221_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln143_fu_4179_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln114_fu_4169_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln105_fu_4159_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln76_fu_4140_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        v4_1_Addr_A_orig =  (sc_lv<32>) (sext_ln66_fu_4099_p1.read());
    } else {
        v4_1_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v4_1_Addr_B() {
    v4_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v4_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v4_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        v4_1_Addr_B_orig =  (sc_lv<32>) (v4_1_addr_7_reg_6884_pp0_iter3_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        v4_1_Addr_B_orig =  (sc_lv<32>) (v4_1_addr_3_reg_6857_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        v4_1_Addr_B_orig =  (sc_lv<32>) (v4_1_addr_6_reg_6825_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v4_1_Addr_B_orig =  (sc_lv<32>) (v4_1_addr_2_reg_6778_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        v4_1_Addr_B_orig =  (sc_lv<32>) (v4_1_addr_5_reg_6751_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        v4_1_Addr_B_orig =  (sc_lv<32>) (v4_1_addr_1_reg_6729_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        v4_1_Addr_B_orig =  (sc_lv<32>) (v4_1_addr_4_reg_6538_pp0_iter2_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        v4_1_Addr_B_orig =  (sc_lv<32>) (v4_1_addr_reg_6465_pp0_iter2_reg.read());
    } else {
        v4_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v4_1_Clk_A() {
    v4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v4_1_Clk_B() {
    v4_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v4_1_Din_A() {
    v4_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v4_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        v4_1_Din_B = reg_3543.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        v4_1_Din_B = reg_3258.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v4_1_Din_B = reg_3251.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)))) {
        v4_1_Din_B = reg_3572.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        v4_1_Din_B = reg_3566.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        v4_1_Din_B = reg_3495.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        v4_1_Din_B = reg_3488.read();
    } else {
        v4_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v4_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, select_ln592_1_reg_7835.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(select_ln592_1_reg_7835.read(), ap_const_lv1_1)))) {
        v4_1_EN_A = ap_const_logic_1;
    } else {
        v4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v4_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)))) {
        v4_1_EN_B = ap_const_logic_1;
    } else {
        v4_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v4_1_Rst_A() {
    v4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v4_1_Rst_B() {
    v4_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v4_1_WEN_A() {
    v4_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v4_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter2_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter3_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln59_reg_6253_pp0_iter3_reg.read())))) {
        v4_1_WEN_B = ap_const_lv4_F;
    } else {
        v4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_0_Addr_A() {
    v5_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_0_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v5_0_Addr_A_orig =  (sc_lv<32>) (sext_ln636_fu_5652_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v5_0_Addr_A_orig =  (sc_lv<32>) (sext_ln626_fu_5602_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v5_0_Addr_A_orig =  (sc_lv<32>) (sext_ln616_fu_5552_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v5_0_Addr_A_orig =  (sc_lv<32>) (sext_ln606_fu_5502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v5_0_Addr_A_orig =  (sc_lv<32>) (sext_ln596_fu_5130_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_0_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_0_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_0_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_0_Addr_B() {
    v5_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_0_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_0_Addr_B_orig =  (sc_lv<32>) (v5_0_addr_1_reg_7351_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_0_Addr_B_orig =  (sc_lv<32>) (v5_0_addr_reg_7286_pp1_iter6_reg.read());
    } else {
        v5_0_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_0_Clk_A() {
    v5_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_0_Clk_B() {
    v5_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_0_Din_A() {
    v5_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_0_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_0_Din_B = reg_3307.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_0_Din_B = reg_3300.read();
    } else {
        v5_0_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_0_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_0_EN_A = ap_const_logic_1;
    } else {
        v5_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_0_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_0_EN_B = ap_const_logic_1;
    } else {
        v5_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_0_Rst_A() {
    v5_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_0_Rst_B() {
    v5_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_0_WEN_A() {
    v5_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_0_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_0_WEN_B = ap_const_lv4_F;
    } else {
        v5_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_1_Addr_A() {
    v5_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_1_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v5_1_Addr_A_orig =  (sc_lv<32>) (sext_ln843_fu_6074_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_1_Addr_A_orig =  (sc_lv<32>) (sext_ln840_fu_6020_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0))) {
        v5_1_Addr_A_orig =  (sc_lv<32>) (sext_ln837_fu_5895_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        v5_1_Addr_A_orig =  (sc_lv<32>) (sext_ln834_fu_5810_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        v5_1_Addr_A_orig =  (sc_lv<32>) (sext_ln831_fu_5735_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_1_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_1_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_1_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_1_Addr_B() {
    v5_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_1_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_1_Addr_B_orig =  (sc_lv<32>) (v5_1_addr_1_reg_7357_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_1_Addr_B_orig =  (sc_lv<32>) (v5_1_addr_reg_7292_pp1_iter6_reg.read());
    } else {
        v5_1_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_1_Clk_A() {
    v5_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_1_Clk_B() {
    v5_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_1_Din_A() {
    v5_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_1_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_1_Din_B = reg_3322.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_1_Din_B = reg_3314.read();
    } else {
        v5_1_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_1_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_1_EN_A = ap_const_logic_1;
    } else {
        v5_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_1_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_1_EN_B = ap_const_logic_1;
    } else {
        v5_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_1_Rst_A() {
    v5_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_1_Rst_B() {
    v5_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_1_WEN_A() {
    v5_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_1_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_1_WEN_B = ap_const_lv4_F;
    } else {
        v5_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_2_Addr_A() {
    v5_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_2_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v5_2_Addr_A_orig =  (sc_lv<32>) (sext_ln903_fu_6172_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0))) {
        v5_2_Addr_A_orig =  (sc_lv<32>) (sext_ln900_fu_6118_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v5_2_Addr_A_orig =  (sc_lv<32>) (sext_ln897_fu_6064_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_2_Addr_A_orig =  (sc_lv<32>) (sext_ln894_fu_6010_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0))) {
        v5_2_Addr_A_orig =  (sc_lv<32>) (sext_ln891_fu_5871_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_2_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_2_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_2_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_2_Addr_B() {
    v5_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_2_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_2_Addr_B_orig =  (sc_lv<32>) (v5_2_addr_1_reg_7363_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_2_Addr_B_orig =  (sc_lv<32>) (v5_2_addr_reg_7298_pp1_iter6_reg.read());
    } else {
        v5_2_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_2_Clk_A() {
    v5_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_2_Clk_B() {
    v5_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_2_Din_A() {
    v5_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_2_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_2_Din_B = reg_3495.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_2_Din_B = reg_3488.read();
    } else {
        v5_2_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_2_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_2_EN_A = ap_const_logic_1;
    } else {
        v5_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_2_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_2_EN_B = ap_const_logic_1;
    } else {
        v5_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_2_Rst_A() {
    v5_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_2_Rst_B() {
    v5_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_2_WEN_A() {
    v5_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_2_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_2_WEN_B = ap_const_lv4_F;
    } else {
        v5_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_3_Addr_A() {
    v5_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_3_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v5_3_Addr_A_orig =  (sc_lv<32>) (sext_ln963_fu_6220_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v5_3_Addr_A_orig =  (sc_lv<32>) (sext_ln960_fu_6197_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v5_3_Addr_A_orig =  (sc_lv<32>) (sext_ln957_fu_6157_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0))) {
        v5_3_Addr_A_orig =  (sc_lv<32>) (sext_ln954_fu_6108_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v5_3_Addr_A_orig =  (sc_lv<32>) (sext_ln951_fu_6054_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_3_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_3_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_3_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_3_Addr_B() {
    v5_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_3_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_3_Addr_B_orig =  (sc_lv<32>) (v5_3_addr_1_reg_7369_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_3_Addr_B_orig =  (sc_lv<32>) (v5_3_addr_reg_7304_pp1_iter6_reg.read());
    } else {
        v5_3_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_3_Clk_A() {
    v5_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_3_Clk_B() {
    v5_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_3_Din_A() {
    v5_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_3_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_3_Din_B = reg_3651.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_3_Din_B = reg_3645.read();
    } else {
        v5_3_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_3_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_3_EN_A = ap_const_logic_1;
    } else {
        v5_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_3_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_3_EN_B = ap_const_logic_1;
    } else {
        v5_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_3_Rst_A() {
    v5_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_3_Rst_B() {
    v5_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_3_WEN_A() {
    v5_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_3_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_3_WEN_B = ap_const_lv4_F;
    } else {
        v5_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_4_Addr_A() {
    v5_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_4_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v5_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1027_fu_6230_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v5_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1023_fu_6225_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v5_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1019_fu_6215_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v5_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_6187_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v5_4_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_fu_6147_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_4_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_4_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_4_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_4_Addr_B() {
    v5_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_4_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_4_Addr_B_orig =  (sc_lv<32>) (v5_4_addr_1_reg_7375_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_4_Addr_B_orig =  (sc_lv<32>) (v5_4_addr_reg_7310_pp1_iter6_reg.read());
    } else {
        v5_4_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_4_Clk_A() {
    v5_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_4_Clk_B() {
    v5_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_4_Din_A() {
    v5_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_4_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_4_Din_B = v290_reg_7706.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_4_Din_B = reg_3657.read();
    } else {
        v5_4_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_4_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_4_EN_A = ap_const_logic_1;
    } else {
        v5_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_4_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_4_EN_B = ap_const_logic_1;
    } else {
        v5_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_4_Rst_A() {
    v5_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_4_Rst_B() {
    v5_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_4_WEN_A() {
    v5_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_4_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_4_WEN_B = ap_const_lv4_F;
    } else {
        v5_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_5_Addr_A() {
    v5_5_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_5_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v5_5_Addr_A_orig =  (sc_lv<32>) (sext_ln636_fu_5652_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v5_5_Addr_A_orig =  (sc_lv<32>) (sext_ln626_fu_5602_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v5_5_Addr_A_orig =  (sc_lv<32>) (sext_ln616_fu_5552_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v5_5_Addr_A_orig =  (sc_lv<32>) (sext_ln606_fu_5502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v5_5_Addr_A_orig =  (sc_lv<32>) (sext_ln596_fu_5130_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_5_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_5_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_5_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_5_Addr_B() {
    v5_5_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_5_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_5_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_5_Addr_B_orig =  (sc_lv<32>) (v5_5_addr_1_reg_7381_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_5_Addr_B_orig =  (sc_lv<32>) (v5_5_addr_reg_7316_pp1_iter6_reg.read());
    } else {
        v5_5_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_5_Clk_A() {
    v5_5_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_5_Clk_B() {
    v5_5_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_5_Din_A() {
    v5_5_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_5_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_5_Din_B = v295_reg_7716.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_5_Din_B = v293_reg_7711.read();
    } else {
        v5_5_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_5_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_5_EN_A = ap_const_logic_1;
    } else {
        v5_5_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_5_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_5_EN_B = ap_const_logic_1;
    } else {
        v5_5_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_5_Rst_A() {
    v5_5_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_5_Rst_B() {
    v5_5_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_5_WEN_A() {
    v5_5_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_5_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_5_WEN_B = ap_const_lv4_F;
    } else {
        v5_5_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_6_Addr_A() {
    v5_6_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_6_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v5_6_Addr_A_orig =  (sc_lv<32>) (sext_ln843_fu_6074_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_6_Addr_A_orig =  (sc_lv<32>) (sext_ln840_fu_6020_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0))) {
        v5_6_Addr_A_orig =  (sc_lv<32>) (sext_ln837_fu_5895_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage9.read(), ap_const_boolean_0))) {
        v5_6_Addr_A_orig =  (sc_lv<32>) (sext_ln834_fu_5810_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage8.read(), ap_const_boolean_0))) {
        v5_6_Addr_A_orig =  (sc_lv<32>) (sext_ln831_fu_5735_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_6_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_6_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_6_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_6_Addr_B() {
    v5_6_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_6_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_6_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_6_Addr_B_orig =  (sc_lv<32>) (v5_6_addr_1_reg_7387_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_6_Addr_B_orig =  (sc_lv<32>) (v5_6_addr_reg_7322_pp1_iter6_reg.read());
    } else {
        v5_6_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_6_Clk_A() {
    v5_6_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_6_Clk_B() {
    v5_6_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_6_Din_A() {
    v5_6_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_6_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_6_Din_B = v300_reg_7726.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_6_Din_B = v298_reg_7721.read();
    } else {
        v5_6_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_6_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage8_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_6_EN_A = ap_const_logic_1;
    } else {
        v5_6_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_6_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_6_EN_B = ap_const_logic_1;
    } else {
        v5_6_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_6_Rst_A() {
    v5_6_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_6_Rst_B() {
    v5_6_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_6_WEN_A() {
    v5_6_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_6_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_6_WEN_B = ap_const_lv4_F;
    } else {
        v5_6_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_7_Addr_A() {
    v5_7_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_7_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v5_7_Addr_A_orig =  (sc_lv<32>) (sext_ln903_fu_6172_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0))) {
        v5_7_Addr_A_orig =  (sc_lv<32>) (sext_ln900_fu_6118_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v5_7_Addr_A_orig =  (sc_lv<32>) (sext_ln897_fu_6064_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage11.read(), ap_const_boolean_0))) {
        v5_7_Addr_A_orig =  (sc_lv<32>) (sext_ln894_fu_6010_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage10.read(), ap_const_boolean_0))) {
        v5_7_Addr_A_orig =  (sc_lv<32>) (sext_ln891_fu_5871_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_7_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_7_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_7_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_7_Addr_B() {
    v5_7_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_7_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_7_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_7_Addr_B_orig =  (sc_lv<32>) (v5_7_addr_1_reg_7393_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_7_Addr_B_orig =  (sc_lv<32>) (v5_7_addr_reg_7328_pp1_iter6_reg.read());
    } else {
        v5_7_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_7_Clk_A() {
    v5_7_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_7_Clk_B() {
    v5_7_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_7_Din_A() {
    v5_7_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_7_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_7_Din_B = v305_reg_7736.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_7_Din_B = v303_reg_7731.read();
    } else {
        v5_7_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_7_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage11_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_7_EN_A = ap_const_logic_1;
    } else {
        v5_7_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_7_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_7_EN_B = ap_const_logic_1;
    } else {
        v5_7_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_7_Rst_A() {
    v5_7_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_7_Rst_B() {
    v5_7_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_7_WEN_A() {
    v5_7_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_7_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_7_WEN_B = ap_const_lv4_F;
    } else {
        v5_7_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_8_Addr_A() {
    v5_8_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_8_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v5_8_Addr_A_orig =  (sc_lv<32>) (sext_ln963_fu_6220_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v5_8_Addr_A_orig =  (sc_lv<32>) (sext_ln960_fu_6197_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v5_8_Addr_A_orig =  (sc_lv<32>) (sext_ln957_fu_6157_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage13.read(), ap_const_boolean_0))) {
        v5_8_Addr_A_orig =  (sc_lv<32>) (sext_ln954_fu_6108_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage12.read(), ap_const_boolean_0))) {
        v5_8_Addr_A_orig =  (sc_lv<32>) (sext_ln951_fu_6054_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_8_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_8_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_8_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_8_Addr_B() {
    v5_8_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_8_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_8_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_8_Addr_B_orig =  (sc_lv<32>) (v5_8_addr_1_reg_7399_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_8_Addr_B_orig =  (sc_lv<32>) (v5_8_addr_reg_7334_pp1_iter6_reg.read());
    } else {
        v5_8_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_8_Clk_A() {
    v5_8_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_8_Clk_B() {
    v5_8_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_8_Din_A() {
    v5_8_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_8_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_8_Din_B = v310_reg_7746.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_8_Din_B = v308_reg_7741.read();
    } else {
        v5_8_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_8_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_8_EN_A = ap_const_logic_1;
    } else {
        v5_8_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_8_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_8_EN_B = ap_const_logic_1;
    } else {
        v5_8_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_8_Rst_A() {
    v5_8_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_8_Rst_B() {
    v5_8_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_8_WEN_A() {
    v5_8_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_8_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_8_WEN_B = ap_const_lv4_F;
    } else {
        v5_8_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_9_Addr_A() {
    v5_9_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_9_Addr_A_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v5_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1027_fu_6230_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v5_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1023_fu_6225_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v5_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1019_fu_6215_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v5_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1015_fu_6187_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage14.read(), ap_const_boolean_0))) {
        v5_9_Addr_A_orig =  (sc_lv<32>) (sext_ln1011_fu_6147_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v5_9_Addr_A_orig =  (sc_lv<32>) (sext_ln337_fu_4502_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_9_Addr_A_orig =  (sc_lv<32>) (sext_ln327_fu_4472_p1.read());
    } else {
        v5_9_Addr_A_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_9_Addr_B() {
    v5_9_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v5_9_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v5_9_Addr_B_orig() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_9_Addr_B_orig =  (sc_lv<32>) (v5_9_addr_1_reg_7405_pp1_iter7_reg.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_9_Addr_B_orig =  (sc_lv<32>) (v5_9_addr_reg_7340_pp1_iter6_reg.read());
    } else {
        v5_9_Addr_B_orig = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_9_Clk_A() {
    v5_9_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_9_Clk_B() {
    v5_9_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v5_9_Din_A() {
    v5_9_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v5_9_Din_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()))) {
        v5_9_Din_B = v315_reg_7756.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v5_9_Din_B = v313_reg_7751.read();
    } else {
        v5_9_Din_B = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void kernel_3mm_nonP_EA::thread_v5_9_EN_A() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read())))) {
        v5_9_EN_A = ap_const_logic_1;
    } else {
        v5_9_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_9_EN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_9_EN_B = ap_const_logic_1;
    } else {
        v5_9_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v5_9_Rst_A() {
    v5_9_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_9_Rst_B() {
    v5_9_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v5_9_WEN_A() {
    v5_9_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v5_9_WEN_B() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter7.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln320_reg_6925_pp1_iter7_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read())))) {
        v5_9_WEN_B = ap_const_lv4_F;
    } else {
        v5_9_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Addr_A() {
    v6_0_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Addr_A_orig() {
    v6_0_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Addr_B() {
    v6_0_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Addr_B_orig() {
    v6_0_0_Addr_B_orig =  (sc_lv<32>) (v6_0_0_addr_reg_7921_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Clk_A() {
    v6_0_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Clk_B() {
    v6_0_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Din_A() {
    v6_0_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Din_B() {
    v6_0_0_Din_B = v612_reg_9642.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_0_EN_A = ap_const_logic_1;
    } else {
        v6_0_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_0_0_EN_B = ap_const_logic_1;
    } else {
        v6_0_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Rst_A() {
    v6_0_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_0_Rst_B() {
    v6_0_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_0_WEN_A() {
    v6_0_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_0_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Addr_A() {
    v6_0_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Addr_A_orig() {
    v6_0_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Addr_B() {
    v6_0_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Addr_B_orig() {
    v6_0_1_Addr_B_orig =  (sc_lv<32>) (v6_0_1_addr_reg_7927_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Clk_A() {
    v6_0_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Clk_B() {
    v6_0_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Din_A() {
    v6_0_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Din_B() {
    v6_0_1_Din_B = v615_reg_9647.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_1_EN_A = ap_const_logic_1;
    } else {
        v6_0_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_0_1_EN_B = ap_const_logic_1;
    } else {
        v6_0_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Rst_A() {
    v6_0_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_1_Rst_B() {
    v6_0_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_1_WEN_A() {
    v6_0_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_0_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Addr_A() {
    v6_0_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Addr_A_orig() {
    v6_0_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Addr_B() {
    v6_0_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Addr_B_orig() {
    v6_0_2_Addr_B_orig =  (sc_lv<32>) (v6_0_2_addr_reg_7933_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Clk_A() {
    v6_0_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Clk_B() {
    v6_0_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Din_A() {
    v6_0_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Din_B() {
    v6_0_2_Din_B = reg_3411.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_2_EN_A = ap_const_logic_1;
    } else {
        v6_0_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_0_2_EN_B = ap_const_logic_1;
    } else {
        v6_0_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Rst_A() {
    v6_0_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_2_Rst_B() {
    v6_0_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_2_WEN_A() {
    v6_0_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_0_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Addr_A() {
    v6_0_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Addr_A_orig() {
    v6_0_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Addr_B() {
    v6_0_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Addr_B_orig() {
    v6_0_3_Addr_B_orig =  (sc_lv<32>) (v6_0_3_addr_reg_7939_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Clk_A() {
    v6_0_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Clk_B() {
    v6_0_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Din_A() {
    v6_0_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Din_B() {
    v6_0_3_Din_B = reg_3420.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_3_EN_A = ap_const_logic_1;
    } else {
        v6_0_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_0_3_EN_B = ap_const_logic_1;
    } else {
        v6_0_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Rst_A() {
    v6_0_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_3_Rst_B() {
    v6_0_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_3_WEN_A() {
    v6_0_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_0_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Addr_A() {
    v6_0_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Addr_A_orig() {
    v6_0_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Addr_B() {
    v6_0_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_0_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Addr_B_orig() {
    v6_0_4_Addr_B_orig =  (sc_lv<32>) (v6_0_4_addr_reg_7945_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Clk_A() {
    v6_0_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Clk_B() {
    v6_0_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Din_A() {
    v6_0_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Din_B() {
    v6_0_4_Din_B = reg_3514.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_0_4_EN_A = ap_const_logic_1;
    } else {
        v6_0_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_0_4_EN_B = ap_const_logic_1;
    } else {
        v6_0_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Rst_A() {
    v6_0_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_4_Rst_B() {
    v6_0_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_0_4_WEN_A() {
    v6_0_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_0_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_0_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_0_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Addr_A() {
    v6_1_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Addr_A_orig() {
    v6_1_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Addr_B() {
    v6_1_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Addr_B_orig() {
    v6_1_0_Addr_B_orig =  (sc_lv<32>) (v6_1_0_addr_reg_7951_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Clk_A() {
    v6_1_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Clk_B() {
    v6_1_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Din_A() {
    v6_1_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Din_B() {
    v6_1_0_Din_B = reg_3523.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_0_EN_A = ap_const_logic_1;
    } else {
        v6_1_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_1_0_EN_B = ap_const_logic_1;
    } else {
        v6_1_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Rst_A() {
    v6_1_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_0_Rst_B() {
    v6_1_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_0_WEN_A() {
    v6_1_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_1_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Addr_A() {
    v6_1_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Addr_A_orig() {
    v6_1_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Addr_B() {
    v6_1_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Addr_B_orig() {
    v6_1_1_Addr_B_orig =  (sc_lv<32>) (v6_1_1_addr_reg_7957_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Clk_A() {
    v6_1_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Clk_B() {
    v6_1_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Din_A() {
    v6_1_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Din_B() {
    v6_1_1_Din_B = reg_3543.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_1_EN_A = ap_const_logic_1;
    } else {
        v6_1_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_1_1_EN_B = ap_const_logic_1;
    } else {
        v6_1_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Rst_A() {
    v6_1_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_1_Rst_B() {
    v6_1_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_1_WEN_A() {
    v6_1_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_1_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Addr_A() {
    v6_1_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Addr_A_orig() {
    v6_1_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Addr_B() {
    v6_1_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Addr_B_orig() {
    v6_1_2_Addr_B_orig =  (sc_lv<32>) (v6_1_2_addr_reg_7963_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Clk_A() {
    v6_1_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Clk_B() {
    v6_1_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Din_A() {
    v6_1_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Din_B() {
    v6_1_2_Din_B = reg_3552.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_2_EN_A = ap_const_logic_1;
    } else {
        v6_1_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_1_2_EN_B = ap_const_logic_1;
    } else {
        v6_1_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Rst_A() {
    v6_1_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_2_Rst_B() {
    v6_1_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_2_WEN_A() {
    v6_1_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_1_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Addr_A() {
    v6_1_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Addr_A_orig() {
    v6_1_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Addr_B() {
    v6_1_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Addr_B_orig() {
    v6_1_3_Addr_B_orig =  (sc_lv<32>) (v6_1_3_addr_reg_7969_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Clk_A() {
    v6_1_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Clk_B() {
    v6_1_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Din_A() {
    v6_1_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Din_B() {
    v6_1_3_Din_B = reg_3704.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_3_EN_A = ap_const_logic_1;
    } else {
        v6_1_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_1_3_EN_B = ap_const_logic_1;
    } else {
        v6_1_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Rst_A() {
    v6_1_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_3_Rst_B() {
    v6_1_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_3_WEN_A() {
    v6_1_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_1_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Addr_A() {
    v6_1_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Addr_A_orig() {
    v6_1_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Addr_B() {
    v6_1_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_1_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Addr_B_orig() {
    v6_1_4_Addr_B_orig =  (sc_lv<32>) (v6_1_4_addr_reg_7975_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Clk_A() {
    v6_1_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Clk_B() {
    v6_1_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Din_A() {
    v6_1_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Din_B() {
    v6_1_4_Din_B = reg_3711.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_1_4_EN_A = ap_const_logic_1;
    } else {
        v6_1_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_1_4_EN_B = ap_const_logic_1;
    } else {
        v6_1_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Rst_A() {
    v6_1_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_4_Rst_B() {
    v6_1_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_1_4_WEN_A() {
    v6_1_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_1_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_1_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_1_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Addr_A() {
    v6_2_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Addr_A_orig() {
    v6_2_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Addr_B() {
    v6_2_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Addr_B_orig() {
    v6_2_0_Addr_B_orig =  (sc_lv<32>) (v6_2_0_addr_reg_7981_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Clk_A() {
    v6_2_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Clk_B() {
    v6_2_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Din_A() {
    v6_2_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Din_B() {
    v6_2_0_Din_B = reg_3720.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_0_EN_A = ap_const_logic_1;
    } else {
        v6_2_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_2_0_EN_B = ap_const_logic_1;
    } else {
        v6_2_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Rst_A() {
    v6_2_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_0_Rst_B() {
    v6_2_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_0_WEN_A() {
    v6_2_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_2_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Addr_A() {
    v6_2_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Addr_A_orig() {
    v6_2_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Addr_B() {
    v6_2_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Addr_B_orig() {
    v6_2_1_Addr_B_orig =  (sc_lv<32>) (v6_2_1_addr_reg_7987_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Clk_A() {
    v6_2_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Clk_B() {
    v6_2_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Din_A() {
    v6_2_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Din_B() {
    v6_2_1_Din_B = reg_3711.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_1_EN_A = ap_const_logic_1;
    } else {
        v6_2_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0))) {
        v6_2_1_EN_B = ap_const_logic_1;
    } else {
        v6_2_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Rst_A() {
    v6_2_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_1_Rst_B() {
    v6_2_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_1_WEN_A() {
    v6_2_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0))) {
        v6_2_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Addr_A() {
    v6_2_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Addr_A_orig() {
    v6_2_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Addr_B() {
    v6_2_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Addr_B_orig() {
    v6_2_2_Addr_B_orig =  (sc_lv<32>) (v6_2_2_addr_reg_7993_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Clk_A() {
    v6_2_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Clk_B() {
    v6_2_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Din_A() {
    v6_2_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Din_B() {
    v6_2_2_Din_B = reg_3720.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_2_EN_A = ap_const_logic_1;
    } else {
        v6_2_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0))) {
        v6_2_2_EN_B = ap_const_logic_1;
    } else {
        v6_2_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Rst_A() {
    v6_2_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_2_Rst_B() {
    v6_2_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_2_WEN_A() {
    v6_2_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage9.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage9_11001.read(), ap_const_boolean_0))) {
        v6_2_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Addr_A() {
    v6_2_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Addr_A_orig() {
    v6_2_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Addr_B() {
    v6_2_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Addr_B_orig() {
    v6_2_3_Addr_B_orig =  (sc_lv<32>) (v6_2_3_addr_reg_7999_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Clk_A() {
    v6_2_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Clk_B() {
    v6_2_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Din_A() {
    v6_2_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Din_B() {
    v6_2_3_Din_B = reg_3411.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_3_EN_A = ap_const_logic_1;
    } else {
        v6_2_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_2_3_EN_B = ap_const_logic_1;
    } else {
        v6_2_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Rst_A() {
    v6_2_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_3_Rst_B() {
    v6_2_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_3_WEN_A() {
    v6_2_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_2_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Addr_A() {
    v6_2_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Addr_A_orig() {
    v6_2_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Addr_B() {
    v6_2_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_2_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Addr_B_orig() {
    v6_2_4_Addr_B_orig =  (sc_lv<32>) (v6_2_4_addr_reg_8005_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Clk_A() {
    v6_2_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Clk_B() {
    v6_2_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Din_A() {
    v6_2_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Din_B() {
    v6_2_4_Din_B = reg_3420.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_2_4_EN_A = ap_const_logic_1;
    } else {
        v6_2_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_2_4_EN_B = ap_const_logic_1;
    } else {
        v6_2_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Rst_A() {
    v6_2_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_4_Rst_B() {
    v6_2_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_2_4_WEN_A() {
    v6_2_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_2_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_2_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_2_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Addr_A() {
    v6_3_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Addr_A_orig() {
    v6_3_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Addr_B() {
    v6_3_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Addr_B_orig() {
    v6_3_0_Addr_B_orig =  (sc_lv<32>) (v6_3_0_addr_reg_8011_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Clk_A() {
    v6_3_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Clk_B() {
    v6_3_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Din_A() {
    v6_3_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Din_B() {
    v6_3_0_Din_B = reg_3514.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_0_EN_A = ap_const_logic_1;
    } else {
        v6_3_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_3_0_EN_B = ap_const_logic_1;
    } else {
        v6_3_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Rst_A() {
    v6_3_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_0_Rst_B() {
    v6_3_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_0_WEN_A() {
    v6_3_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_3_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Addr_A() {
    v6_3_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Addr_A_orig() {
    v6_3_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Addr_B() {
    v6_3_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Addr_B_orig() {
    v6_3_1_Addr_B_orig =  (sc_lv<32>) (v6_3_1_addr_reg_8017_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Clk_A() {
    v6_3_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Clk_B() {
    v6_3_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Din_A() {
    v6_3_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Din_B() {
    v6_3_1_Din_B = reg_3523.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_1_EN_A = ap_const_logic_1;
    } else {
        v6_3_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_3_1_EN_B = ap_const_logic_1;
    } else {
        v6_3_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Rst_A() {
    v6_3_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_1_Rst_B() {
    v6_3_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_1_WEN_A() {
    v6_3_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_3_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Addr_A() {
    v6_3_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Addr_A_orig() {
    v6_3_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Addr_B() {
    v6_3_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Addr_B_orig() {
    v6_3_2_Addr_B_orig =  (sc_lv<32>) (v6_3_2_addr_reg_8023_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Clk_A() {
    v6_3_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Clk_B() {
    v6_3_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Din_A() {
    v6_3_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Din_B() {
    v6_3_2_Din_B = reg_3543.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_2_EN_A = ap_const_logic_1;
    } else {
        v6_3_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_3_2_EN_B = ap_const_logic_1;
    } else {
        v6_3_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Rst_A() {
    v6_3_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_2_Rst_B() {
    v6_3_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_2_WEN_A() {
    v6_3_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_3_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Addr_A() {
    v6_3_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Addr_A_orig() {
    v6_3_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Addr_B() {
    v6_3_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Addr_B_orig() {
    v6_3_3_Addr_B_orig =  (sc_lv<32>) (v6_3_3_addr_reg_8029_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Clk_A() {
    v6_3_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Clk_B() {
    v6_3_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Din_A() {
    v6_3_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Din_B() {
    v6_3_3_Din_B = reg_3552.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_3_EN_A = ap_const_logic_1;
    } else {
        v6_3_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_3_3_EN_B = ap_const_logic_1;
    } else {
        v6_3_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Rst_A() {
    v6_3_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_3_Rst_B() {
    v6_3_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_3_WEN_A() {
    v6_3_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_3_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Addr_A() {
    v6_3_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Addr_A_orig() {
    v6_3_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Addr_B() {
    v6_3_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_3_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Addr_B_orig() {
    v6_3_4_Addr_B_orig =  (sc_lv<32>) (v6_3_4_addr_reg_8035_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Clk_A() {
    v6_3_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Clk_B() {
    v6_3_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Din_A() {
    v6_3_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Din_B() {
    v6_3_4_Din_B = reg_3704.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_3_4_EN_A = ap_const_logic_1;
    } else {
        v6_3_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_3_4_EN_B = ap_const_logic_1;
    } else {
        v6_3_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Rst_A() {
    v6_3_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_4_Rst_B() {
    v6_3_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_3_4_WEN_A() {
    v6_3_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_3_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_3_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_3_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Addr_A() {
    v6_4_0_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_0_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Addr_A_orig() {
    v6_4_0_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Addr_B() {
    v6_4_0_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_0_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Addr_B_orig() {
    v6_4_0_Addr_B_orig =  (sc_lv<32>) (v6_4_0_addr_reg_8041_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Clk_A() {
    v6_4_0_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Clk_B() {
    v6_4_0_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Din_A() {
    v6_4_0_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Din_B() {
    v6_4_0_Din_B = reg_3711.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_0_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_0_EN_A = ap_const_logic_1;
    } else {
        v6_4_0_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_0_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_4_0_EN_B = ap_const_logic_1;
    } else {
        v6_4_0_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Rst_A() {
    v6_4_0_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_0_Rst_B() {
    v6_4_0_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_0_WEN_A() {
    v6_4_0_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_0_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_4_0_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_0_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Addr_A() {
    v6_4_1_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_1_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Addr_A_orig() {
    v6_4_1_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Addr_B() {
    v6_4_1_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_1_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Addr_B_orig() {
    v6_4_1_Addr_B_orig =  (sc_lv<32>) (v6_4_1_addr_reg_8047_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Clk_A() {
    v6_4_1_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Clk_B() {
    v6_4_1_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Din_A() {
    v6_4_1_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Din_B() {
    v6_4_1_Din_B = reg_3720.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_1_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_1_EN_A = ap_const_logic_1;
    } else {
        v6_4_1_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_1_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_4_1_EN_B = ap_const_logic_1;
    } else {
        v6_4_1_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Rst_A() {
    v6_4_1_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_1_Rst_B() {
    v6_4_1_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_1_WEN_A() {
    v6_4_1_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_1_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage10.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage10_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_4_1_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_1_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Addr_A() {
    v6_4_2_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_2_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Addr_A_orig() {
    v6_4_2_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Addr_B() {
    v6_4_2_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_2_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Addr_B_orig() {
    v6_4_2_Addr_B_orig =  (sc_lv<32>) (v6_4_2_addr_reg_8053_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Clk_A() {
    v6_4_2_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Clk_B() {
    v6_4_2_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Din_A() {
    v6_4_2_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Din_B() {
    v6_4_2_Din_B = reg_3711.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_2_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_2_EN_A = ap_const_logic_1;
    } else {
        v6_4_2_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_2_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_4_2_EN_B = ap_const_logic_1;
    } else {
        v6_4_2_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Rst_A() {
    v6_4_2_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_2_Rst_B() {
    v6_4_2_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_2_WEN_A() {
    v6_4_2_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_2_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_4_2_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_2_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Addr_A() {
    v6_4_3_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_3_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Addr_A_orig() {
    v6_4_3_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Addr_B() {
    v6_4_3_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_3_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Addr_B_orig() {
    v6_4_3_Addr_B_orig =  (sc_lv<32>) (v6_4_3_addr_reg_8059_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Clk_A() {
    v6_4_3_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Clk_B() {
    v6_4_3_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Din_A() {
    v6_4_3_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Din_B() {
    v6_4_3_Din_B = reg_3720.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_3_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_3_EN_A = ap_const_logic_1;
    } else {
        v6_4_3_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_3_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_4_3_EN_B = ap_const_logic_1;
    } else {
        v6_4_3_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Rst_A() {
    v6_4_3_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_3_Rst_B() {
    v6_4_3_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_3_WEN_A() {
    v6_4_3_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_3_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage13.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage13_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_4_3_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_3_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Addr_A() {
    v6_4_4_Addr_A = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_4_Addr_A_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Addr_A_orig() {
    v6_4_4_Addr_A_orig =  (sc_lv<32>) (zext_ln598_2_fu_4994_p1.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Addr_B() {
    v6_4_4_Addr_B = (!ap_const_lv32_2.is_01())? sc_lv<32>(): v6_4_4_Addr_B_orig.read() << (unsigned short)ap_const_lv32_2.to_uint();
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Addr_B_orig() {
    v6_4_4_Addr_B_orig =  (sc_lv<32>) (v6_4_4_addr_reg_8065_pp2_iter2_reg.read());
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Clk_A() {
    v6_4_4_Clk_A = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Clk_B() {
    v6_4_4_Clk_B = ap_clk.read()? SC_LOGIC_1 : SC_LOGIC_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Din_A() {
    v6_4_4_Din_A = ap_const_lv32_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Din_B() {
    v6_4_4_Din_B = reg_3411.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_4_EN_A() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0))) {
        v6_4_4_EN_A = ap_const_logic_1;
    } else {
        v6_4_4_EN_A = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_4_EN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()))) {
        v6_4_4_EN_B = ap_const_logic_1;
    } else {
        v6_4_4_EN_B = ap_const_logic_0;
    }
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Rst_A() {
    v6_4_4_Rst_A = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_4_Rst_B() {
    v6_4_4_Rst_B = ap_rst_n_inv.read();
}

void kernel_3mm_nonP_EA::thread_v6_4_4_WEN_A() {
    v6_4_4_WEN_A = ap_const_lv4_0;
}

void kernel_3mm_nonP_EA::thread_v6_4_4_WEN_B() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage14.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage14_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln591_reg_7779_pp2_iter2_reg.read()))) {
        v6_4_4_WEN_B = ap_const_lv4_F;
    } else {
        v6_4_4_WEN_B = ap_const_lv4_0;
    }
}

void kernel_3mm_nonP_EA::thread_v8_fu_3792_p2() {
    v8_fu_3792_p2 = (!ap_phi_mux_v8_0_phi_fu_2692_p4.read().is_01() || !ap_const_lv5_1.is_01())? sc_lv<5>(): (sc_biguint<5>(ap_phi_mux_v8_0_phi_fu_2692_p4.read()) + sc_biguint<5>(ap_const_lv5_1));
}

void kernel_3mm_nonP_EA::thread_v9_fu_3896_p2() {
    v9_fu_3896_p2 = (!select_ln59_fu_3804_p3.read().is_01() || !ap_const_lv3_1.is_01())? sc_lv<3>(): (sc_biguint<3>(select_ln59_fu_3804_p3.read()) + sc_biguint<3>(ap_const_lv3_1));
}

void kernel_3mm_nonP_EA::thread_xor_ln329_fu_4307_p2() {
    xor_ln329_fu_4307_p2 = (icmp_ln321_fu_4265_p2.read() ^ ap_const_lv1_1);
}

void kernel_3mm_nonP_EA::thread_xor_ln591_fu_4791_p2() {
    xor_ln591_fu_4791_p2 = (icmp_ln592_fu_4731_p2.read() ^ ap_const_lv1_1);
}

void kernel_3mm_nonP_EA::thread_xor_ln59_fu_3878_p2() {
    xor_ln59_fu_3878_p2 = (icmp_ln60_fu_3798_p2.read() ^ ap_const_lv1_1);
}

void kernel_3mm_nonP_EA::thread_zext_ln1079_fu_6178_p1() {
    zext_ln1079_fu_6178_p1 = esl_zext<64,11>(add_ln1079_reg_8954.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln143_fu_4179_p1() {
    zext_ln143_fu_4179_p1 = esl_zext<64,11>(add_ln143_fu_4175_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln152_fu_4221_p1() {
    zext_ln152_fu_4221_p1 = esl_zext<64,11>(add_ln152_reg_6789.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln181_fu_4232_p1() {
    zext_ln181_fu_4232_p1 = esl_zext<64,11>(add_ln181_reg_6773.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln190_fu_4242_p1() {
    zext_ln190_fu_4242_p1 = esl_zext<64,11>(add_ln190_reg_6794.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln324_1_fu_4380_p1() {
    zext_ln324_1_fu_4380_p1 = esl_zext<9,8>(tmp_5_fu_4373_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln324_2_fu_4391_p1() {
    zext_ln324_2_fu_4391_p1 = esl_zext<9,6>(tmp_6_fu_4384_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln324_3_fu_4407_p1() {
    zext_ln324_3_fu_4407_p1 = esl_zext<64,9>(add_ln324_1_fu_4401_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln325_fu_4367_p1() {
    zext_ln325_fu_4367_p1 = esl_zext<9,6>(select_ln329_2_reg_6958.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln327_fu_4462_p1() {
    zext_ln327_fu_4462_p1 = esl_zext<10,7>(shl_ln3_fu_4455_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln337_fu_4492_p1() {
    zext_ln337_fu_4492_p1 = esl_zext<10,7>(or_ln335_fu_4486_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln591_1_fu_4745_p1() {
    zext_ln591_1_fu_4745_p1 = esl_zext<6,4>(v316_fu_4725_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln591_2_fu_5043_p1() {
    zext_ln591_2_fu_5043_p1 = esl_zext<11,6>(add_ln591_fu_5038_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln591_3_fu_5366_p1() {
    zext_ln591_3_fu_5366_p1 = esl_zext<11,6>(add_ln591_1_fu_5361_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln591_4_fu_5762_p1() {
    zext_ln591_4_fu_5762_p1 = esl_zext<11,6>(add_ln591_2_fu_5757_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln591_fu_4649_p1() {
    zext_ln591_fu_4649_p1 = esl_zext<6,4>(ap_phi_mux_v316_0_phi_fu_2803_p4.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln592_1_fu_4851_p1() {
    zext_ln592_1_fu_4851_p1 = esl_zext<6,4>(v317_fu_4831_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln592_fu_4679_p1() {
    zext_ln592_fu_4679_p1 = esl_zext<6,4>(ap_phi_mux_v317_0_phi_fu_2825_p4.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln593_fu_5100_p1() {
    zext_ln593_fu_5100_p1 = esl_zext<7,4>(select_ln592_reg_7827.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln595_1_fu_4867_p1() {
    zext_ln595_1_fu_4867_p1 = esl_zext<6,5>(shl_ln595_1_mid1_fu_4859_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln595_fu_4695_p1() {
    zext_ln595_fu_4695_p1 = esl_zext<6,5>(shl_ln595_1_fu_4687_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln596_1_fu_5110_p1() {
    zext_ln596_1_fu_5110_p1 = esl_zext<7,6>(shl_ln5_fu_5103_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln596_3_fu_5120_p1() {
    zext_ln596_3_fu_5120_p1 = esl_zext<10,7>(add_ln596_fu_5114_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln596_fu_5938_p1() {
    zext_ln596_fu_5938_p1 = esl_zext<11,6>(add_ln591_3_fu_5933_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln598_1_fu_4985_p1() {
    zext_ln598_1_fu_4985_p1 = esl_zext<8,4>(select_ln592_reg_7827.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln598_2_fu_4994_p1() {
    zext_ln598_2_fu_4994_p1 = esl_zext<64,8>(add_ln598_fu_4988_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln598_fu_4975_p1() {
    zext_ln598_fu_4975_p1 = esl_zext<8,5>(tmp_12_fu_4968_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln59_1_fu_3812_p1() {
    zext_ln59_1_fu_3812_p1 = esl_zext<7,5>(v8_fu_3792_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln59_fu_3736_p1() {
    zext_ln59_fu_3736_p1 = esl_zext<7,5>(ap_phi_mux_v8_0_phi_fu_2692_p4.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln600_fu_4921_p1() {
    zext_ln600_fu_4921_p1 = esl_zext<11,6>(select_ln591_1_reg_7800.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln606_fu_5493_p1() {
    zext_ln606_fu_5493_p1 = esl_zext<10,7>(add_ln606_fu_5488_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln616_fu_5543_p1() {
    zext_ln616_fu_5543_p1 = esl_zext<10,7>(add_ln616_fu_5538_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln626_fu_5593_p1() {
    zext_ln626_fu_5593_p1 = esl_zext<10,7>(add_ln626_fu_5588_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln636_fu_5643_p1() {
    zext_ln636_fu_5643_p1 = esl_zext<10,7>(add_ln636_fu_5638_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln63_1_fu_4030_p1() {
    zext_ln63_1_fu_4030_p1 = esl_zext<8,5>(tmp_4_fu_4023_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln63_2_fu_4046_p1() {
    zext_ln63_2_fu_4046_p1 = esl_zext<64,8>(add_ln63_1_fu_4040_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln63_fu_4019_p1() {
    zext_ln63_fu_4019_p1 = esl_zext<8,7>(tmp_3_fu_4012_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln64_fu_4006_p1() {
    zext_ln64_fu_4006_p1 = esl_zext<8,5>(select_ln59_2_reg_6274.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln66_fu_4090_p1() {
    zext_ln66_fu_4090_p1 = esl_zext<11,6>(shl_ln2_fu_4083_p3.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln76_fu_4131_p1() {
    zext_ln76_fu_4131_p1 = esl_zext<11,6>(or_ln74_fu_4126_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln784_fu_5632_p1() {
    zext_ln784_fu_5632_p1 = esl_zext<64,11>(add_ln784_2_fu_5627_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln879_fu_5691_p1() {
    zext_ln879_fu_5691_p1 = esl_zext<64,11>(add_ln879_fu_5687_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln939_fu_5800_p1() {
    zext_ln939_fu_5800_p1 = esl_zext<64,11>(add_ln939_fu_5796_p2.read());
}

void kernel_3mm_nonP_EA::thread_zext_ln999_fu_6044_p1() {
    zext_ln999_fu_6044_p1 = esl_zext<64,11>(add_ln999_reg_8949.read());
}

}


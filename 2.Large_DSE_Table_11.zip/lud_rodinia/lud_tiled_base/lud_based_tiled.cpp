#define GRID_ROWS 256
#define GRID_COLS 256
#define matrix_dim GRID_ROWS

// Elment with the block 16, diagonal
#define AA(i, j) result[(offset + i) * matrix_dim + j + offset]
// Elment with global index
#define BB(i, j) result[i * matrix_dim + j]

void diagonal_load(float result[GRID_ROWS * GRID_COLS], float buffer[16 * 16], int offset) {
    int i, j;
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            buffer[i * 16 + j] = AA(i, j);
        }
    }
}

void diagonal_store(float result[GRID_ROWS * GRID_COLS], float buffer[16 * 16], int offset) {
    int i, j;
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            AA(i, j) = buffer[i * 16 + j];
        }
    }
}
void lud_diagonal(float result[GRID_ROWS * GRID_COLS],
                  int offset, float buffer[16 * 16]) {
    int i, j, k;

    // float buffer[16 * 16];

    diagonal_load(result, buffer, offset);

    for (i = 0; i < 16; i++) {
    top:
        for (j = i; j < 16; j++) {
            for (k = 0; k < i; k++) {
                buffer[i * 16 + j] = buffer[i * 16 + j] -
                                        buffer[i * 16 + k] * buffer[k * 16 + j];
            }
        }

        float temp = 1.f / buffer[i * 16 + i];

    left:
        for (j = i + 1; j < 16; j++) {
            for (k = 0; k < i; k++) {
                buffer[j * 16 + i] = buffer[j * 16 + i] - buffer[j * 16 + k] * buffer[k * 16 + i];
            }
            buffer[j * 16 + i] = buffer[j * 16 + i] * temp;
        }
    }

    diagonal_store(result, buffer, offset);
}

void perimeter_load(float result[GRID_ROWS * GRID_COLS], float top[16 * 16], float left[16 * 16], int offset, int chunk_idx) {
    int i, j;

    int i_top = offset;
    int j_top = offset + 16 * (chunk_idx + 1);

    int i_left = offset + 16 * (chunk_idx + 1);
    int j_left = offset;

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            top[i * 16 + j] = BB((i_top + i), (j_top + j));
        }
    }

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            left[i * 16 + j] = BB((i_left + i), (j_left + j));
        }
    }
}

void perimeter_store(float result[GRID_ROWS * GRID_COLS], float top[16 * 16], float left[16 * 16], int offset, int chunk_idx) {
    int i, j;

    int i_top = offset;
    int j_top = offset + 16 * (chunk_idx + 1);

    int i_left = offset + 16 * (chunk_idx + 1);
    int j_left = offset;

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            BB((i_top + i), (j_top + j)) = top[i * 16 + j];
        }
    }

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            BB((i_left + i), (j_left + j)) = left[i * 16 + j];
        }
    }
}
// 99327
void lud_perimeter(float result[GRID_ROWS * GRID_COLS],
                   int offset, float diagonal_buffer[16 * 16],
                   float top_buffer[16 * 16],
                   float left_buffer[16 * 16]) {

    // float diagonal_buffer[16 * 16];
    // float top_buffer[16 * 16];
    // float left_buffer[16 * 16];

    int i, j, k;

diagonal:
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            diagonal_buffer[i * 16 + j] = AA(i, j);
        }
    }

    int chunk_idx, chunk_num;

    chunk_num = ((matrix_dim - offset) / 16) - 1;

    for (chunk_idx = 0; chunk_idx < chunk_num; chunk_idx++) {
        perimeter_load(result, top_buffer, left_buffer, offset, chunk_idx);

        float sum;
        // processing top perimeter
        for (j = 0; j < 16; j++) {
            for (i = 0; i < 16; i++) {
                sum = 0.0f;
                for (k = 0; k < i; k++) {
                    sum += diagonal_buffer[16 * i + k] * top_buffer[k * 16 + j];
                }

                top_buffer[i * 16 + j] = top_buffer[i * 16 + j] - sum;
            }
        }

        // processing left perimeter
        for (i = 0; i < 16; i++) {
            for (j = 0; j < 16; j++) {
                sum = 0.0f;
                for (k = 0; k < j; k++) {
                    sum += left_buffer[i * 16 + k] * diagonal_buffer[16 * k + j];
                }

                left_buffer[i * 16 + j] = (left_buffer[i * 16 + j] - sum) / diagonal_buffer[j * 16 + j];
            }
        }

        perimeter_store(result, top_buffer, left_buffer, offset, chunk_idx);
    }
}

void internal_load(float result[GRID_ROWS * GRID_COLS], float top[16 * 16], float left[16 * 16], float inner[16 * 16], int offset, int chunk_idx, int chunk_num) {
    int i, j;
    int i_global, j_global;

    i_global = offset + 16 * (1 + chunk_idx / chunk_num);
    j_global = offset + 16 * (1 + chunk_idx % chunk_num);

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            top[i * 16 + j] = result[matrix_dim * (i + offset) + j + j_global];
        }
    }
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            left[i * 16 + j] = result[matrix_dim * (i + i_global) + offset + j];
        }
    }

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            inner[i * 16 + j] = result[matrix_dim * (i + i_global) + j + j_global];
        }
    }
}

void internal_store(float result[GRID_ROWS * GRID_COLS], float inner[16 * 16], int offset, int chunk_idx, int chunk_num) {
    int i, j;
    int i_global, j_global;

    i_global = offset + 16 * (1 + chunk_idx / chunk_num);
    j_global = offset + 16 * (1 + chunk_idx % chunk_num);

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            result[matrix_dim * (i + i_global) + j + j_global] = inner[i * 16 + j];
        }
    }
}

void lud_internal(float result[GRID_ROWS * GRID_COLS],
                  int offset, float top_buffer[16 * 16], float left_buffer[16 * 16], float inner_buffer[16 * 16]) {
    int chunk_idx, chunk_num;

    chunk_num = ((matrix_dim - offset) / 16) - 1;

    // float top_buffer[16 * 16];
    // float left_buffer[16 * 16];
    // float inner_buffer[16 * 16];

    int i, j, k, i_global, j_global;

    for (chunk_idx = 0; chunk_idx < chunk_num * chunk_num; chunk_idx++) {
        internal_load(result, top_buffer, left_buffer, inner_buffer, offset, chunk_idx, chunk_num);

        for (i = 0; i < 16; i++) {
            for (j = 0; j < 16; j++) {
                float sum = 0.0f;
                // #pragma HLS unsafemath
                for (k = 0; k < 16; k++) {
                    sum += left_buffer[16 * i + k] * top_buffer[16 * k + j];
                }
                inner_buffer[i * 16 + j] -= sum;
            }
        }

        internal_store(result, inner_buffer, offset, chunk_idx, chunk_num);
    }
}

void workload_based_tiled(float result[GRID_ROWS * GRID_COLS]) {
#pragma HLS INTERFACE m_axi port = result offset = slave bundle = gmem
#pragma HLS INTERFACE s_axilite port = result bundle = control
#pragma HLS INTERFACE s_axilite port = return bundle = control

    float buffer[16 * 16];

    float diagonal_buffer[16 * 16];
    float top_buffer[16 * 16];
    float left_buffer[16 * 16];

    // float top_buffer[16 * 16];
    // float left_buffer[16 * 16];
    float inner_buffer[16 * 16];


    for (int i = 0; i < matrix_dim - 16; i += 16) {
        lud_diagonal(result, i, buffer);
        lud_perimeter(result, i, diagonal_buffer, top_buffer, left_buffer);
        lud_internal(result, i, top_buffer, left_buffer, inner_buffer);
    }

    int i = matrix_dim - 16;
    lud_diagonal(result, i, buffer);
    return;
}

// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xworkload_based_tiled.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XWorkload_based_tiled_CfgInitialize(XWorkload_based_tiled *InstancePtr, XWorkload_based_tiled_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XWorkload_based_tiled_Start(XWorkload_based_tiled *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWorkload_based_tiled_ReadReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_AP_CTRL) & 0x80;
    XWorkload_based_tiled_WriteReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XWorkload_based_tiled_IsDone(XWorkload_based_tiled *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWorkload_based_tiled_ReadReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XWorkload_based_tiled_IsIdle(XWorkload_based_tiled *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWorkload_based_tiled_ReadReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XWorkload_based_tiled_IsReady(XWorkload_based_tiled *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWorkload_based_tiled_ReadReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XWorkload_based_tiled_EnableAutoRestart(XWorkload_based_tiled *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWorkload_based_tiled_WriteReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XWorkload_based_tiled_DisableAutoRestart(XWorkload_based_tiled *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWorkload_based_tiled_WriteReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_AP_CTRL, 0);
}

void XWorkload_based_tiled_Set_result(XWorkload_based_tiled *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWorkload_based_tiled_WriteReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_RESULT_DATA, Data);
}

u32 XWorkload_based_tiled_Get_result(XWorkload_based_tiled *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWorkload_based_tiled_ReadReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_RESULT_DATA);
    return Data;
}

void XWorkload_based_tiled_InterruptGlobalEnable(XWorkload_based_tiled *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWorkload_based_tiled_WriteReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_GIE, 1);
}

void XWorkload_based_tiled_InterruptGlobalDisable(XWorkload_based_tiled *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWorkload_based_tiled_WriteReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_GIE, 0);
}

void XWorkload_based_tiled_InterruptEnable(XWorkload_based_tiled *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XWorkload_based_tiled_ReadReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_IER);
    XWorkload_based_tiled_WriteReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_IER, Register | Mask);
}

void XWorkload_based_tiled_InterruptDisable(XWorkload_based_tiled *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XWorkload_based_tiled_ReadReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_IER);
    XWorkload_based_tiled_WriteReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_IER, Register & (~Mask));
}

void XWorkload_based_tiled_InterruptClear(XWorkload_based_tiled *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWorkload_based_tiled_WriteReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_ISR, Mask);
}

u32 XWorkload_based_tiled_InterruptGetEnabled(XWorkload_based_tiled *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XWorkload_based_tiled_ReadReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_IER);
}

u32 XWorkload_based_tiled_InterruptGetStatus(XWorkload_based_tiled *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XWorkload_based_tiled_ReadReg(InstancePtr->Control_BaseAddress, XWORKLOAD_BASED_TILED_CONTROL_ADDR_ISR);
}


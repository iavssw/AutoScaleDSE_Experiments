# 1 "lud/lud_based_tiled.cpp"
# 1 "lud/lud_based_tiled.cpp" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 152 "<built-in>" 3
# 1 "<command line>" 1







# 1 "C:/Xilinx/Vivado/2019.2/common/technology/autopilot\\etc/autopilot_ssdm_op.h" 1
# 157 "C:/Xilinx/Vivado/2019.2/common/technology/autopilot\\etc/autopilot_ssdm_op.h"
extern "C" {






    void _ssdm_op_IfRead(...) __attribute__ ((nothrow));
    void _ssdm_op_IfWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanWrite(...) __attribute__ ((nothrow));


    void _ssdm_StreamRead(...) __attribute__ ((nothrow));
    void _ssdm_StreamWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanWrite(...) __attribute__ ((nothrow));
    unsigned _ssdm_StreamSize(...) __attribute__ ((nothrow));




    void _ssdm_op_MemShiftRead(...) __attribute__ ((nothrow));

    void _ssdm_op_Wait(...) __attribute__ ((nothrow));
    void _ssdm_op_Poll(...) __attribute__ ((nothrow));

    void _ssdm_op_Return(...) __attribute__ ((nothrow));


    void _ssdm_op_SpecSynModule(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecTopModule(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDecl(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDef(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecPort(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecConnection(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecChannel(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecSensitive(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecModuleInst(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecPortMap(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecReset(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecPlatform(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecClockDomain(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecPowerDomain(...) __attribute__ ((nothrow));

    int _ssdm_op_SpecRegionBegin(...) __attribute__ ((nothrow));
    int _ssdm_op_SpecRegionEnd(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopName(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopTripCount(...) __attribute__ ((nothrow));

    int _ssdm_op_SpecStateBegin(...) __attribute__ ((nothrow));
    int _ssdm_op_SpecStateEnd(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecInterface(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecPipeline(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecDataflowPipeline(...) __attribute__ ((nothrow));


    void _ssdm_op_SpecLatency(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecParallel(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecProtocol(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecOccurrence(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecResource(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecResourceLimit(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecCHCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecFUCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecIFCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecIPCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecKeepValue(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecMemCore(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecExt(...) __attribute__ ((nothrow));




    void _ssdm_SpecArrayDimSize(...) __attribute__ ((nothrow));

    void _ssdm_RegionBegin(...) __attribute__ ((nothrow));
    void _ssdm_RegionEnd(...) __attribute__ ((nothrow));

    void _ssdm_Unroll(...) __attribute__ ((nothrow));
    void _ssdm_UnrollRegion(...) __attribute__ ((nothrow));

    void _ssdm_InlineAll(...) __attribute__ ((nothrow));
    void _ssdm_InlineLoop(...) __attribute__ ((nothrow));
    void _ssdm_Inline(...) __attribute__ ((nothrow));
    void _ssdm_InlineSelf(...) __attribute__ ((nothrow));
    void _ssdm_InlineRegion(...) __attribute__ ((nothrow));

    void _ssdm_SpecArrayMap(...) __attribute__ ((nothrow));
    void _ssdm_SpecArrayPartition(...) __attribute__ ((nothrow));
    void _ssdm_SpecArrayReshape(...) __attribute__ ((nothrow));

    void _ssdm_SpecStream(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecStable(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecStableContent(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecPipoDepth(...) __attribute__ ((nothrow));

    void _ssdm_SpecExpr(...) __attribute__ ((nothrow));
    void _ssdm_SpecExprBalance(...) __attribute__ ((nothrow));

    void _ssdm_SpecDependence(...) __attribute__ ((nothrow));

    void _ssdm_SpecLoopMerge(...) __attribute__ ((nothrow));
    void _ssdm_SpecLoopFlatten(...) __attribute__ ((nothrow));
    void _ssdm_SpecLoopRewind(...) __attribute__ ((nothrow));

    void _ssdm_SpecFuncInstantiation(...) __attribute__ ((nothrow));
    void _ssdm_SpecFuncBuffer(...) __attribute__ ((nothrow));
    void _ssdm_SpecFuncExtract(...) __attribute__ ((nothrow));
    void _ssdm_SpecConstant(...) __attribute__ ((nothrow));

    void _ssdm_DataPack(...) __attribute__ ((nothrow));
    void _ssdm_SpecDataPack(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecBitsMap(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecLicense(...) __attribute__ ((nothrow));

    void __xilinx_ip_top(...) __attribute__ ((nothrow));


}
# 9 "<command line>" 2
# 1 "<built-in>" 2
# 1 "lud/lud_based_tiled.cpp" 2
# 10 "lud/lud_based_tiled.cpp"
void diagonal_load(float result[256 * 256], float buffer[16 * 16], int offset) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(buffer, 256);
    int i, j;
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            buffer[i * 16 + j] = result[(offset + i) * 256 + j + offset];
        }
    }
}

void diagonal_store(float result[256 * 256], float buffer[16 * 16], int offset) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(buffer, 256);
    int i, j;
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            result[(offset + i) * 256 + j + offset] = buffer[i * 16 + j];
        }
    }
}
void lud_diagonal(float result[256 * 256],
                  int offset, float buffer[16 * 16]) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(buffer, 256);
    int i, j, k;



    diagonal_load(result, buffer, offset);

    for (i = 0; i < 16; i++) {
    top:
        for (j = i; j < 16; j++) {
            for (k = 0; k < i; k++) {
                buffer[i * 16 + j] = buffer[i * 16 + j] -
                                        buffer[i * 16 + k] * buffer[k * 16 + j];
            }
        }

        float temp = 1.f / buffer[i * 16 + i];

    left:
        for (j = i + 1; j < 16; j++) {
            for (k = 0; k < i; k++) {
                buffer[j * 16 + i] = buffer[j * 16 + i] - buffer[j * 16 + k] * buffer[k * 16 + i];
            }
            buffer[j * 16 + i] = buffer[j * 16 + i] * temp;
        }
    }

    diagonal_store(result, buffer, offset);
}

void perimeter_load(float result[256 * 256], float top[16 * 16], float left[16 * 16], int offset, int chunk_idx) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(top, 256);_ssdm_SpecArrayDimSize(left, 256);
    int i, j;

    int i_top = offset;
    int j_top = offset + 16 * (chunk_idx + 1);

    int i_left = offset + 16 * (chunk_idx + 1);
    int j_left = offset;

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            top[i * 16 + j] = result[(i_top + i) * 256 + (j_top + j)];
        }
    }

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            left[i * 16 + j] = result[(i_left + i) * 256 + (j_left + j)];
        }
    }
}

void perimeter_store(float result[256 * 256], float top[16 * 16], float left[16 * 16], int offset, int chunk_idx) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(top, 256);_ssdm_SpecArrayDimSize(left, 256);
    int i, j;

    int i_top = offset;
    int j_top = offset + 16 * (chunk_idx + 1);

    int i_left = offset + 16 * (chunk_idx + 1);
    int j_left = offset;

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            result[(i_top + i) * 256 + (j_top + j)] = top[i * 16 + j];
        }
    }

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            result[(i_left + i) * 256 + (j_left + j)] = left[i * 16 + j];
        }
    }
}

void lud_perimeter(float result[256 * 256],
                   int offset, float diagonal_buffer[16 * 16],
                   float top_buffer[16 * 16],
                   float left_buffer[16 * 16]) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(diagonal_buffer, 256);_ssdm_SpecArrayDimSize(top_buffer, 256);_ssdm_SpecArrayDimSize(left_buffer, 256);





    int i, j, k;

diagonal:
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            diagonal_buffer[i * 16 + j] = result[(offset + i) * 256 + j + offset];
        }
    }

    int chunk_idx, chunk_num;

    chunk_num = ((256 - offset) / 16) - 1;

    for (chunk_idx = 0; chunk_idx < chunk_num; chunk_idx++) {
        perimeter_load(result, top_buffer, left_buffer, offset, chunk_idx);

        float sum;

        for (j = 0; j < 16; j++) {
            for (i = 0; i < 16; i++) {
                sum = 0.0f;
                for (k = 0; k < i; k++) {
                    sum += diagonal_buffer[16 * i + k] * top_buffer[k * 16 + j];
                }

                top_buffer[i * 16 + j] = top_buffer[i * 16 + j] - sum;
            }
        }


        for (i = 0; i < 16; i++) {
            for (j = 0; j < 16; j++) {
                sum = 0.0f;
                for (k = 0; k < j; k++) {
                    sum += left_buffer[i * 16 + k] * diagonal_buffer[16 * k + j];
                }

                left_buffer[i * 16 + j] = (left_buffer[i * 16 + j] - sum) / diagonal_buffer[j * 16 + j];
            }
        }

        perimeter_store(result, top_buffer, left_buffer, offset, chunk_idx);
    }
}

void internal_load(float result[256 * 256], float top[16 * 16], float left[16 * 16], float inner[16 * 16], int offset, int chunk_idx, int chunk_num) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(top, 256);_ssdm_SpecArrayDimSize(left, 256);_ssdm_SpecArrayDimSize(inner, 256);
    int i, j;
    int i_global, j_global;

    i_global = offset + 16 * (1 + chunk_idx / chunk_num);
    j_global = offset + 16 * (1 + chunk_idx % chunk_num);

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            top[i * 16 + j] = result[256 * (i + offset) + j + j_global];
        }
    }
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            left[i * 16 + j] = result[256 * (i + i_global) + offset + j];
        }
    }

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            inner[i * 16 + j] = result[256 * (i + i_global) + j + j_global];
        }
    }
}

void internal_store(float result[256 * 256], float inner[16 * 16], int offset, int chunk_idx, int chunk_num) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(inner, 256);
    int i, j;
    int i_global, j_global;

    i_global = offset + 16 * (1 + chunk_idx / chunk_num);
    j_global = offset + 16 * (1 + chunk_idx % chunk_num);

    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            result[256 * (i + i_global) + j + j_global] = inner[i * 16 + j];
        }
    }
}

void lud_internal(float result[256 * 256],
                  int offset, float top_buffer[16 * 16], float left_buffer[16 * 16], float inner_buffer[16 * 16]) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(top_buffer, 256);_ssdm_SpecArrayDimSize(left_buffer, 256);_ssdm_SpecArrayDimSize(inner_buffer, 256);
    int chunk_idx, chunk_num;

    chunk_num = ((256 - offset) / 16) - 1;





    int i, j, k, i_global, j_global;

    for (chunk_idx = 0; chunk_idx < chunk_num * chunk_num; chunk_idx++) {
        internal_load(result, top_buffer, left_buffer, inner_buffer, offset, chunk_idx, chunk_num);

        for (i = 0; i < 16; i++) {
            for (j = 0; j < 16; j++) {
                float sum = 0.0f;

                for (k = 0; k < 16; k++) {
                    sum += left_buffer[16 * i + k] * top_buffer[16 * k + j];
                }
                inner_buffer[i * 16 + j] -= sum;
            }
        }

        internal_store(result, inner_buffer, offset, chunk_idx, chunk_num);
    }
}

void workload_based_tiled(float result[256 * 256]) {_ssdm_SpecArrayDimSize(result, 65536);
_ssdm_op_SpecInterface(result, "m_axi", 0, 0, "", 0, 0, "gmem", "slave", "", 16, 16, 16, 16, "", "");
_ssdm_op_SpecInterface(result, "s_axilite", 0, 0, "", 0, 0, "control", "", "", 0, 0, 0, 0, "", "");
_ssdm_op_SpecInterface(0, "s_axilite", 0, 0, "", 0, 0, "control", "", "", 0, 0, 0, 0, "", "");

 float buffer[16 * 16];

    float diagonal_buffer[16 * 16];
    float top_buffer[16 * 16];
    float left_buffer[16 * 16];



    float inner_buffer[16 * 16];


    for (int i = 0; i < 256 - 16; i += 16) {
        lud_diagonal(result, i, buffer);
        lud_perimeter(result, i, diagonal_buffer, top_buffer, left_buffer);
        lud_internal(result, i, top_buffer, left_buffer, inner_buffer);
    }

    int i = 256 - 16;
    lud_diagonal(result, i, buffer);
    return;
}

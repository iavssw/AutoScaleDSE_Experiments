# 1 "lud/lud_adse.cpp"
# 1 "lud/lud_adse.cpp" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 152 "<built-in>" 3
# 1 "<command line>" 1







# 1 "C:/Xilinx/Vivado/2019.2/common/technology/autopilot\\etc/autopilot_ssdm_op.h" 1
# 157 "C:/Xilinx/Vivado/2019.2/common/technology/autopilot\\etc/autopilot_ssdm_op.h"
extern "C" {






    void _ssdm_op_IfRead(...) __attribute__ ((nothrow));
    void _ssdm_op_IfWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanWrite(...) __attribute__ ((nothrow));


    void _ssdm_StreamRead(...) __attribute__ ((nothrow));
    void _ssdm_StreamWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbWrite(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanRead(...) __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanWrite(...) __attribute__ ((nothrow));
    unsigned _ssdm_StreamSize(...) __attribute__ ((nothrow));




    void _ssdm_op_MemShiftRead(...) __attribute__ ((nothrow));

    void _ssdm_op_Wait(...) __attribute__ ((nothrow));
    void _ssdm_op_Poll(...) __attribute__ ((nothrow));

    void _ssdm_op_Return(...) __attribute__ ((nothrow));


    void _ssdm_op_SpecSynModule(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecTopModule(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDecl(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDef(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecPort(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecConnection(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecChannel(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecSensitive(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecModuleInst(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecPortMap(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecReset(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecPlatform(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecClockDomain(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecPowerDomain(...) __attribute__ ((nothrow));

    int _ssdm_op_SpecRegionBegin(...) __attribute__ ((nothrow));
    int _ssdm_op_SpecRegionEnd(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopName(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopTripCount(...) __attribute__ ((nothrow));

    int _ssdm_op_SpecStateBegin(...) __attribute__ ((nothrow));
    int _ssdm_op_SpecStateEnd(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecInterface(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecPipeline(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecDataflowPipeline(...) __attribute__ ((nothrow));


    void _ssdm_op_SpecLatency(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecParallel(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecProtocol(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecOccurrence(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecResource(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecResourceLimit(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecCHCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecFUCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecIFCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecIPCore(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecKeepValue(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecMemCore(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecExt(...) __attribute__ ((nothrow));




    void _ssdm_SpecArrayDimSize(...) __attribute__ ((nothrow));

    void _ssdm_RegionBegin(...) __attribute__ ((nothrow));
    void _ssdm_RegionEnd(...) __attribute__ ((nothrow));

    void _ssdm_Unroll(...) __attribute__ ((nothrow));
    void _ssdm_UnrollRegion(...) __attribute__ ((nothrow));

    void _ssdm_InlineAll(...) __attribute__ ((nothrow));
    void _ssdm_InlineLoop(...) __attribute__ ((nothrow));
    void _ssdm_Inline(...) __attribute__ ((nothrow));
    void _ssdm_InlineSelf(...) __attribute__ ((nothrow));
    void _ssdm_InlineRegion(...) __attribute__ ((nothrow));

    void _ssdm_SpecArrayMap(...) __attribute__ ((nothrow));
    void _ssdm_SpecArrayPartition(...) __attribute__ ((nothrow));
    void _ssdm_SpecArrayReshape(...) __attribute__ ((nothrow));

    void _ssdm_SpecStream(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecStable(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecStableContent(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecPipoDepth(...) __attribute__ ((nothrow));

    void _ssdm_SpecExpr(...) __attribute__ ((nothrow));
    void _ssdm_SpecExprBalance(...) __attribute__ ((nothrow));

    void _ssdm_SpecDependence(...) __attribute__ ((nothrow));

    void _ssdm_SpecLoopMerge(...) __attribute__ ((nothrow));
    void _ssdm_SpecLoopFlatten(...) __attribute__ ((nothrow));
    void _ssdm_SpecLoopRewind(...) __attribute__ ((nothrow));

    void _ssdm_SpecFuncInstantiation(...) __attribute__ ((nothrow));
    void _ssdm_SpecFuncBuffer(...) __attribute__ ((nothrow));
    void _ssdm_SpecFuncExtract(...) __attribute__ ((nothrow));
    void _ssdm_SpecConstant(...) __attribute__ ((nothrow));

    void _ssdm_DataPack(...) __attribute__ ((nothrow));
    void _ssdm_SpecDataPack(...) __attribute__ ((nothrow));

    void _ssdm_op_SpecBitsMap(...) __attribute__ ((nothrow));
    void _ssdm_op_SpecLicense(...) __attribute__ ((nothrow));

    void __xilinx_ip_top(...) __attribute__ ((nothrow));


}
# 9 "<command line>" 2
# 1 "<built-in>" 2
# 1 "lud/lud_adse.cpp" 2
# 10 "lud/lud_adse.cpp"
void diagonal_load(
  float v0[65536],
  float v1[256],
  int v2
) {_ssdm_SpecArrayDimSize(v0, 65536);_ssdm_SpecArrayDimSize(v1, 256);
  int v3 = v2;
  for (int v4 = 0; v4 < 8; v4 += 1) {
#pragma HLS pipeline
 for (int v5 = 0; v5 < 2; v5 += 1) {
      for (int v6 = 0; v6 < 2; v6 += 1) {
        for (int v7 = 0; v7 < 8; v7 += 1) {
          float v8 = v0[((((v7 + (v5 * 8)) + (v6 * 256)) + (v4 * 512)) + (v3 * 257))];
          v1[(((v7 + (v5 * 8)) + (v6 * 16)) + (v4 * 32))] = v8;
        }
      }
    }
  }
}

void diagonal_store(
  float v0[65536],
  float v1[256],
  int v2
) {_ssdm_SpecArrayDimSize(v0, 65536);_ssdm_SpecArrayDimSize(v1, 256);
  int v3 = v2;
  for (int v4 = 0; v4 < 8; v4 += 1) {
#pragma HLS pipeline
 for (int v5 = 0; v5 < 8; v5 += 1) {
      for (int v6 = 0; v6 < 2; v6 += 1) {
        for (int v7 = 0; v7 < 2; v7 += 1) {
          float v8 = v1[(((v7 + (v5 * 2)) + (v6 * 16)) + (v4 * 32))];
          v0[((((v7 + (v5 * 2)) + (v6 * 256)) + (v4 * 512)) + (v3 * 257))] = v8;
        }
      }
    }
  }
}
void lud_diagonal(float result[256 * 256],
                  int offset, float buffer[16 * 16]) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(buffer, 256);
    int i, j, k;



    diagonal_load(result, buffer, offset);

    Loop4: for (i = 0; i < 16; i++) {
    top:
        Loop5: for (j = i; j < 16; j++) {
            Loop6: for (k = 0; k < i; k++) {
                buffer[i * 16 + j] = buffer[i * 16 + j] -
                                        buffer[i * 16 + k] * buffer[k * 16 + j];
            }
        }

        float temp = 1.f / buffer[i * 16 + i];

    left:
        Loop7: for (j = i + 1; j < 16; j++) {
            Loop8: for (k = 0; k < i; k++) {
                buffer[j * 16 + i] = buffer[j * 16 + i] - buffer[j * 16 + k] * buffer[k * 16 + i];
            }
            buffer[j * 16 + i] = buffer[j * 16 + i] * temp;
        }
    }

    diagonal_store(result, buffer, offset);
}

void perimeter_load(
  float v0[65536],
  float v1[256],
  float v2[256],
  int v3,
  int v4
) {_ssdm_SpecArrayDimSize(v0, 65536);_ssdm_SpecArrayDimSize(v1, 256);_ssdm_SpecArrayDimSize(v2, 256);
  int v5 = v3;
  int v6 = v4;
  int v7 = v6 + 1;
  int v8 = v7 * 16;
  int v9 = v5 + v8;
  for (int v10 = 0; v10 < 4; v10 += 1) {
#pragma HLS pipeline
 for (int v11 = 0; v11 < 4; v11 += 1) {
    for (int v12 = 0; v12 < 16; v12 += 1) {
   float v13 = v0[((((v12 + (v11 * 256)) + (v10 * 1024)) + v9) + (v5 * 256))];
   v1[((v12 + (v11 * 16)) + (v10 * 64))] = v13;
    }
    }
  }
  for (int v14 = 0; v14 < 2; v14 += 1) {
#pragma HLS pipeline
 for (int v15 = 0; v15 < 4; v15 += 1) {
      for (int v16 = 0; v16 < 8; v16 += 1) {
        for (int v17 = 0; v17 < 4; v17 += 1) {
          float v18 = v0[(((((v17 + (v15 * 4)) + (v16 * 256)) + (v14 * 2048)) + v5) + (v9 * 256))];
          v2[(((v17 + (v15 * 4)) + (v16 * 16)) + (v14 * 128))] = v18;
        }
      }
    }
  }
}

void perimeter_store(
  float v0[65536],
  float v1[256],
  float v2[256],
  int v3,
  int v4
) {_ssdm_SpecArrayDimSize(v0, 65536);_ssdm_SpecArrayDimSize(v1, 256);_ssdm_SpecArrayDimSize(v2, 256);
  int v5 = v3;
  int v6 = v4;
  int v7 = v6 + 1;
  int v8 = v7 * 16;
  int v9 = v5 + v8;
  for (int v10 = 0; v10 < 2; v10 += 1) {
    for (int v11 = 0; v11 < 16; v11 += 1) {
#pragma HLS pipeline
 for (int v12 = 0; v12 < 8; v12 += 1) {
        float v13 = v1[((v11 + (v12 * 16)) + (v10 * 128))];
        v0[((((v11 + (v12 * 256)) + (v10 * 2048)) + v9) + (v5 * 256))] = v13;
      }
    }
  }
  for (int v14 = 0; v14 < 16; v14 += 1) {
#pragma HLS pipeline
 for (int v15 = 0; v15 < 4; v15 += 1) {
    for (int v16 = 0; v16 < 4; v16 += 1) {
   float v17 = v2[(((v14 * 16) + v16) + (v15 * 4))];
   v0[(((((v14 * 256) + v16) + (v15 * 4)) + v5) + (v9 * 256))] = v17;
    }
    }
  }
}

void lud_perimeter(float result[256 * 256],
                   int offset, float diagonal_buffer[16 * 16],
                   float top_buffer[16 * 16],
                   float left_buffer[16 * 16]) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(diagonal_buffer, 256);_ssdm_SpecArrayDimSize(top_buffer, 256);_ssdm_SpecArrayDimSize(left_buffer, 256);





    int i, j, k;

diagonal:
    Loop17: for (i = 0; i < 16; i++) {
        Loop18: for (j = 0; j < 16; j++) {
#pragma HLS pipeline
 diagonal_buffer[i * 16 + j] = result[(offset + i) * 256 + j + offset];
        }
    }

    int chunk_idx, chunk_num;

    chunk_num = ((256 - offset) / 16) - 1;

    Loop19: for (chunk_idx = 0; chunk_idx < chunk_num; chunk_idx++) {
        perimeter_load(result, top_buffer, left_buffer, offset, chunk_idx);

        float sum;

        Loop20: for (j = 0; j < 16; j++) {
            Loop21: for (i = 0; i < 16; i++) {
                sum = 0.0f;
                Loop22: for (k = 0; k < i; k++) {
                    sum += diagonal_buffer[16 * i + k] * top_buffer[k * 16 + j];
                }

                top_buffer[i * 16 + j] = top_buffer[i * 16 + j] - sum;
            }
        }


        Loop23: for (i = 0; i < 16; i++) {
            Loop24: for (j = 0; j < 16; j++) {
                sum = 0.0f;
                Loop25: for (k = 0; k < j; k++) {
                    sum += left_buffer[i * 16 + k] * diagonal_buffer[16 * k + j];
                }

                left_buffer[i * 16 + j] = (left_buffer[i * 16 + j] - sum) / diagonal_buffer[j * 16 + j];
            }
        }

        perimeter_store(result, top_buffer, left_buffer, offset, chunk_idx);
    }
}

void internal_load(
  float v0[65536],
  float v1[256],
  float v2[256],
  float v3[256],
  int v4,
  int v5,
  int v6
) {_ssdm_SpecArrayDimSize(v0, 65536);_ssdm_SpecArrayDimSize(v1, 256);_ssdm_SpecArrayDimSize(v2, 256);_ssdm_SpecArrayDimSize(v3, 256);
  int v7 = v4;
  int v8 = v5;
  int v9 = v6;
  int v10 = v8 / v9;
  int v11 = v10 + 1;
  int v12 = v11 * 16;
  int v13 = v7 + v12;
  int v14 = v8 % v9;
  int v15 = v14 + 1;
  int v16 = v15 * 16;
  int v17 = v7 + v16;
  for (int v18 = 0; v18 < 8; v18 += 1) {
#pragma HLS pipeline
 for (int v19 = 0; v19 < 2; v19 += 1) {
      for (int v20 = 0; v20 < 2; v20 += 1) {
        for (int v21 = 0; v21 < 8; v21 += 1) {
          float v22 = v0[(((((v21 + (v19 * 8)) + (v20 * 256)) + (v18 * 512)) + v17) + (v7 * 256))];
          v1[(((v21 + (v19 * 8)) + (v20 * 16)) + (v18 * 32))] = v22;
        }
      }
    }
  }
  for (int v23 = 0; v23 < 4; v23 += 1) {
#pragma HLS pipeline
 for (int v24 = 0; v24 < 4; v24 += 1) {
      for (int v25 = 0; v25 < 4; v25 += 1) {
        for (int v26 = 0; v26 < 4; v26 += 1) {
          float v27 = v0[(((((v26 + (v24 * 4)) + (v25 * 256)) + (v23 * 1024)) + v7) + (v13 * 256))];
          v2[(((v26 + (v24 * 4)) + (v25 * 16)) + (v23 * 64))] = v27;
        }
      }
    }
  }
  for (int v28 = 0; v28 < 4; v28 += 1) {
#pragma HLS pipeline
 for (int v29 = 0; v29 < 4; v29 += 1) {
    for (int v30 = 0; v30 < 16; v30 += 1) {
   float v31 = v0[((((v30 + (v29 * 256)) + (v28 * 1024)) + v17) + (v13 * 256))];
   v3[((v30 + (v29 * 16)) + (v28 * 64))] = v31;
    }
    }
  }
}

void internal_store(
  float v0[65536],
  float v1[256],
  int v2,
  int v3,
  int v4
) {_ssdm_SpecArrayDimSize(v0, 65536);_ssdm_SpecArrayDimSize(v1, 256);
  int v5 = v3;
  int v6 = v4;
  int v7 = v2;
  int v8 = v5 / v6;
  int v9 = v8 + 1;
  int v10 = v9 * 16;
  int v11 = v7 + v10;
  int v12 = v5 % v6;
  int v13 = v12 + 1;
  int v14 = v13 * 16;
  int v15 = v7 + v14;
  for (int v16 = 0; v16 < 2; v16 += 1) {
    for (int v17 = 0; v17 < 16; v17 += 1) {
#pragma HLS pipeline
 for (int v18 = 0; v18 < 8; v18 += 1) {
        float v19 = v1[((v17 + (v18 * 16)) + (v16 * 128))];
        v0[((((v17 + (v18 * 256)) + (v16 * 2048)) + v15) + (v11 * 256))] = v19;
      }
    }
  }
}

void lud_internal(float result[256 * 256],
                  int offset, float top_buffer[16 * 16], float left_buffer[16 * 16], float inner_buffer[16 * 16]) {_ssdm_SpecArrayDimSize(result, 65536);_ssdm_SpecArrayDimSize(top_buffer, 256);_ssdm_SpecArrayDimSize(left_buffer, 256);_ssdm_SpecArrayDimSize(inner_buffer, 256);
    int chunk_idx, chunk_num;

    chunk_num = ((256 - offset) / 16) - 1;





    int i, j, k, i_global, j_global;

    Loop34: for (chunk_idx = 0; chunk_idx < chunk_num * chunk_num; chunk_idx++) {
        internal_load(result, top_buffer, left_buffer, inner_buffer, offset, chunk_idx, chunk_num);

        Loop35: for (i = 0; i < 16; i++) {
            Loop36: for (j = 0; j < 16; j++) {
                float sum = 0.0f;

                Loop37: for (k = 0; k < 16; k++) {
#pragma HLS pipeline
 sum += left_buffer[16 * i + k] * top_buffer[16 * k + j];
                }
                inner_buffer[i * 16 + j] -= sum;
            }
        }

        internal_store(result, inner_buffer, offset, chunk_idx, chunk_num);
    }
}

void workload_asdse(float result[256 * 256]) {_ssdm_SpecArrayDimSize(result, 65536);

#pragma HLS array_partition variable=&result cyclic factor=64 dim=1


 float buffer[16 * 16];

    float diagonal_buffer[16 * 16];
    float top_buffer[16 * 16];
    float left_buffer[16 * 16];



    float inner_buffer[16 * 16];

#pragma HLS array_partition variable=&buffer cyclic factor=16 dim=1
#pragma HLS array_partition variable=&diagonal_buffer cyclic factor=16 dim=1
#pragma HLS array_partition variable=&top_buffer cyclic factor=16 dim=1
#pragma HLS array_partition variable=&left_buffer cyclic factor=16 dim=1
#pragma HLS array_partition variable=&inner_buffer cyclic factor=16 dim=1

 Loop38: for (int i = 0; i < 256 - 16; i += 16) {
        lud_diagonal(result, i, buffer);
        lud_perimeter(result, i, diagonal_buffer, top_buffer, left_buffer);
        lud_internal(result, i, top_buffer, left_buffer, inner_buffer);
    }

    int i = 256 - 16;
    lud_diagonal(result, i, buffer);
    return;
}

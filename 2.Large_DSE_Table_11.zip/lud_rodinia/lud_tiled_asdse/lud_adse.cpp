#define GRID_ROWS 256
#define GRID_COLS 256
#define matrix_dim GRID_ROWS

// Elment with the block 16, diagonal
#define AA(i, j) result[(offset + i) * matrix_dim + j + offset]
// Elment with global index
#define BB(i, j) result[i * matrix_dim + j]

void diagonal_load(
  float v0[65536],
  float v1[256],
  int v2
) {	// L2
  int v3 = v2;	// L3
  for (int v4 = 0; v4 < 8; v4 += 1) {	// L4
#pragma HLS pipeline
    for (int v5 = 0; v5 < 2; v5 += 1) {	// L4
      for (int v6 = 0; v6 < 2; v6 += 1) {	// L4
        for (int v7 = 0; v7 < 8; v7 += 1) {	// L4
          float v8 = v0[((((v7 + (v5 * 8)) + (v6 * 256)) + (v4 * 512)) + (v3 * 257))];	// L6
          v1[(((v7 + (v5 * 8)) + (v6 * 16)) + (v4 * 32))] = v8;	// L7
        }
      }
    }
  }
}

void diagonal_store(
  float v0[65536],
  float v1[256],
  int v2
) {	// L2
  int v3 = v2;	// L3
  for (int v4 = 0; v4 < 8; v4 += 1) {	// L4
#pragma HLS pipeline
    for (int v5 = 0; v5 < 8; v5 += 1) {	// L4
      for (int v6 = 0; v6 < 2; v6 += 1) {	// L4
        for (int v7 = 0; v7 < 2; v7 += 1) {	// L4
          float v8 = v1[(((v7 + (v5 * 2)) + (v6 * 16)) + (v4 * 32))];	// L6
          v0[((((v7 + (v5 * 2)) + (v6 * 256)) + (v4 * 512)) + (v3 * 257))] = v8;	// L7
        }
      }
    }
  }
}
void lud_diagonal(float result[GRID_ROWS * GRID_COLS],
                  int offset, float buffer[16 * 16]) {
    int i, j, k;

    // float buffer[16 * 16];

    diagonal_load(result, buffer, offset);

    Loop4: for (i = 0; i < 16; i++) {
    top:
        Loop5: for (j = i; j < 16; j++) {
            Loop6: for (k = 0; k < i; k++) {
                buffer[i * 16 + j] = buffer[i * 16 + j] -
                                        buffer[i * 16 + k] * buffer[k * 16 + j];
            }
        }

        float temp = 1.f / buffer[i * 16 + i];

    left:
        Loop7: for (j = i + 1; j < 16; j++) {
            Loop8: for (k = 0; k < i; k++) {
                buffer[j * 16 + i] = buffer[j * 16 + i] - buffer[j * 16 + k] * buffer[k * 16 + i];
            }
            buffer[j * 16 + i] = buffer[j * 16 + i] * temp;
        }
    }

    diagonal_store(result, buffer, offset);
}

void perimeter_load(
  float v0[65536],
  float v1[256],
  float v2[256],
  int v3,
  int v4
) {	// L2
  int v5 = v3;	// L5
  int v6 = v4;	// L6
  int v7 = v6 + 1;	// L7
  int v8 = v7 * 16;	// L8
  int v9 = v5 + v8;	// L9
  for (int v10 = 0; v10 < 4; v10 += 1) {	// L10
#pragma HLS pipeline
	  for (int v11 = 0; v11 < 4; v11 += 1) {	// L10
		  for (int v12 = 0; v12 < 16; v12 += 1) {	// L10
			float v13 = v0[((((v12 + (v11 * 256)) + (v10 * 1024)) + v9) + (v5 * 256))];	// L12
			v1[((v12 + (v11 * 16)) + (v10 * 64))] = v13;	// L13
		  }
    }
  }
  for (int v14 = 0; v14 < 2; v14 += 1) {	// L16
#pragma HLS pipeline
    for (int v15 = 0; v15 < 4; v15 += 1) {	// L16
      for (int v16 = 0; v16 < 8; v16 += 1) {	// L16
        for (int v17 = 0; v17 < 4; v17 += 1) {	// L16
          float v18 = v0[(((((v17 + (v15 * 4)) + (v16 * 256)) + (v14 * 2048)) + v5) + (v9 * 256))];	// L18
          v2[(((v17 + (v15 * 4)) + (v16 * 16)) + (v14 * 128))] = v18;	// L19
        }
      }
    }
  }
}

void perimeter_store(
  float v0[65536],
  float v1[256],
  float v2[256],
  int v3,
  int v4
) {	// L2
  int v5 = v3;	// L5
  int v6 = v4;	// L6
  int v7 = v6 + 1;	// L7
  int v8 = v7 * 16;	// L8
  int v9 = v5 + v8;	// L9
  for (int v10 = 0; v10 < 2; v10 += 1) {	// L10
    for (int v11 = 0; v11 < 16; v11 += 1) {	// L10
#pragma HLS pipeline
      for (int v12 = 0; v12 < 8; v12 += 1) {	// L10
        float v13 = v1[((v11 + (v12 * 16)) + (v10 * 128))];	// L12
        v0[((((v11 + (v12 * 256)) + (v10 * 2048)) + v9) + (v5 * 256))] = v13;	// L13
      }
    }
  }
  for (int v14 = 0; v14 < 16; v14 += 1) {	// L16
#pragma HLS pipeline
	  for (int v15 = 0; v15 < 4; v15 += 1) {	// L16
		  for (int v16 = 0; v16 < 4; v16 += 1) {	// L16
			float v17 = v2[(((v14 * 16) + v16) + (v15 * 4))];	// L18
			v0[(((((v14 * 256) + v16) + (v15 * 4)) + v5) + (v9 * 256))] = v17;	// L19
		  }
    }
  }
}
// 99327
void lud_perimeter(float result[GRID_ROWS * GRID_COLS],
                   int offset, float diagonal_buffer[16 * 16],
                   float top_buffer[16 * 16],
                   float left_buffer[16 * 16]) {

    // float diagonal_buffer[16 * 16];
    // float top_buffer[16 * 16];
    // float left_buffer[16 * 16];

    int i, j, k;

diagonal:
    Loop17: for (i = 0; i < 16; i++) {
        Loop18: for (j = 0; j < 16; j++) {
#pragma HLS pipeline
            diagonal_buffer[i * 16 + j] = AA(i, j);
        }
    }

    int chunk_idx, chunk_num;

    chunk_num = ((matrix_dim - offset) / 16) - 1;

    Loop19: for (chunk_idx = 0; chunk_idx < chunk_num; chunk_idx++) {
        perimeter_load(result, top_buffer, left_buffer, offset, chunk_idx);

        float sum;
        // processing top perimeter
        Loop20: for (j = 0; j < 16; j++) {
            Loop21: for (i = 0; i < 16; i++) {
                sum = 0.0f;
                Loop22: for (k = 0; k < i; k++) {
                    sum += diagonal_buffer[16 * i + k] * top_buffer[k * 16 + j];
                }

                top_buffer[i * 16 + j] = top_buffer[i * 16 + j] - sum;
            }
        }

        // processing left perimeter
        Loop23: for (i = 0; i < 16; i++) {
            Loop24: for (j = 0; j < 16; j++) {
                sum = 0.0f;
                Loop25: for (k = 0; k < j; k++) {
                    sum += left_buffer[i * 16 + k] * diagonal_buffer[16 * k + j];
                }

                left_buffer[i * 16 + j] = (left_buffer[i * 16 + j] - sum) / diagonal_buffer[j * 16 + j];
            }
        }

        perimeter_store(result, top_buffer, left_buffer, offset, chunk_idx);
    }
}

void internal_load(
  float v0[65536],
  float v1[256],
  float v2[256],
  float v3[256],
  int v4,
  int v5,
  int v6
) {	// L2
  int v7 = v4;	// L5
  int v8 = v5;	// L6
  int v9 = v6;	// L7
  int v10 = v8 / v9;	// L8
  int v11 = v10 + 1;	// L9
  int v12 = v11 * 16;	// L10
  int v13 = v7 + v12;	// L11
  int v14 = v8 % v9;	// L12
  int v15 = v14 + 1;	// L13
  int v16 = v15 * 16;	// L14
  int v17 = v7 + v16;	// L15
  for (int v18 = 0; v18 < 8; v18 += 1) {	// L16
#pragma HLS pipeline
	  for (int v19 = 0; v19 < 2; v19 += 1) {	// L16
      for (int v20 = 0; v20 < 2; v20 += 1) {	// L16
        for (int v21 = 0; v21 < 8; v21 += 1) {	// L16
          float v22 = v0[(((((v21 + (v19 * 8)) + (v20 * 256)) + (v18 * 512)) + v17) + (v7 * 256))];	// L18
          v1[(((v21 + (v19 * 8)) + (v20 * 16)) + (v18 * 32))] = v22;	// L19
        }
      }
    }
  }
  for (int v23 = 0; v23 < 4; v23 += 1) {	// L22
#pragma HLS pipeline
	  for (int v24 = 0; v24 < 4; v24 += 1) {	// L22
      for (int v25 = 0; v25 < 4; v25 += 1) {	// L22
        for (int v26 = 0; v26 < 4; v26 += 1) {	// L22
          float v27 = v0[(((((v26 + (v24 * 4)) + (v25 * 256)) + (v23 * 1024)) + v7) + (v13 * 256))];	// L24
          v2[(((v26 + (v24 * 4)) + (v25 * 16)) + (v23 * 64))] = v27;	// L25
        }
      }
    }
  }
  for (int v28 = 0; v28 < 4; v28 += 1) {	// L28
#pragma HLS pipeline
	  for (int v29 = 0; v29 < 4; v29 += 1) {	// L28
		  for (int v30 = 0; v30 < 16; v30 += 1) {	// L28
			float v31 = v0[((((v30 + (v29 * 256)) + (v28 * 1024)) + v17) + (v13 * 256))];	// L30
			v3[((v30 + (v29 * 16)) + (v28 * 64))] = v31;	// L31
		  }
    }
  }
}

void internal_store(
  float v0[65536],
  float v1[256],
  int v2,
  int v3,
  int v4
) {	// L2
  int v5 = v3;	// L5
  int v6 = v4;	// L6
  int v7 = v2;	// L7
  int v8 = v5 / v6;	// L8
  int v9 = v8 + 1;	// L9
  int v10 = v9 * 16;	// L10
  int v11 = v7 + v10;	// L11
  int v12 = v5 % v6;	// L12
  int v13 = v12 + 1;	// L13
  int v14 = v13 * 16;	// L14
  int v15 = v7 + v14;	// L15
  for (int v16 = 0; v16 < 2; v16 += 1) {	// L16
    for (int v17 = 0; v17 < 16; v17 += 1) {	// L16
#pragma HLS pipeline
      for (int v18 = 0; v18 < 8; v18 += 1) {	// L16
        float v19 = v1[((v17 + (v18 * 16)) + (v16 * 128))];	// L18
        v0[((((v17 + (v18 * 256)) + (v16 * 2048)) + v15) + (v11 * 256))] = v19;	// L19
      }
    }
  }
}

void lud_internal(float result[GRID_ROWS * GRID_COLS],
                  int offset, float top_buffer[16 * 16], float left_buffer[16 * 16], float inner_buffer[16 * 16]) {
    int chunk_idx, chunk_num;

    chunk_num = ((matrix_dim - offset) / 16) - 1;

    // float top_buffer[16 * 16];
    // float left_buffer[16 * 16];
    // float inner_buffer[16 * 16];

    int i, j, k, i_global, j_global;

    Loop34: for (chunk_idx = 0; chunk_idx < chunk_num * chunk_num; chunk_idx++) {
        internal_load(result, top_buffer, left_buffer, inner_buffer, offset, chunk_idx, chunk_num);

        Loop35: for (i = 0; i < 16; i++) {
            Loop36: for (j = 0; j < 16; j++) {
                float sum = 0.0f;
                // #pragma HLS unsafemath
                Loop37: for (k = 0; k < 16; k++) {
#pragma HLS pipeline
                    sum += left_buffer[16 * i + k] * top_buffer[16 * k + j];
                }
                inner_buffer[i * 16 + j] -= sum;
            }
        }

        internal_store(result, inner_buffer, offset, chunk_idx, chunk_num);
    }
}

void workload_asdse(float result[GRID_ROWS * GRID_COLS]) {

#pragma HLS array_partition variable=result cyclic factor=16 dim=1


    float buffer[16 * 16];

    float diagonal_buffer[16 * 16];
    float top_buffer[16 * 16];
    float left_buffer[16 * 16];

    // float top_buffer[16 * 16];
    // float left_buffer[16 * 16];
    float inner_buffer[16 * 16];

#pragma HLS array_partition variable=buffer cyclic factor=16 dim=1
#pragma HLS array_partition variable=diagonal_buffer cyclic factor=16 dim=1
#pragma HLS array_partition variable=top_buffer cyclic factor=16 dim=1
#pragma HLS array_partition variable=left_buffer cyclic factor=16 dim=1
#pragma HLS array_partition variable=inner_buffer cyclic factor=16 dim=1

    Loop38: for (int i = 0; i < matrix_dim - 16; i += 16) {
        lud_diagonal(result, i, buffer);
        lud_perimeter(result, i, diagonal_buffer, top_buffer, left_buffer);
        lud_internal(result, i, top_buffer, left_buffer, inner_buffer);
    }

    int i = matrix_dim - 16;
    lud_diagonal(result, i, buffer);
    return;
}

#include "math.h"

void soft_max(
  double v0[3],
  double v1[3]
) {	// L2
  for (int v2 = 0; v2 < 3; v2 += 1) {	// L4
#pragma HLS pipeline
    double v3 = v1[v2];	// L5
    double v4 = -(v3);	// L6
    double v5 = exp(v4);	// L7
    double v6 = double v7 + v5;	// L8
  }
  for (int v8 = 0; v8 < 3; v8 += 1) {	// L11
#pragma HLS pipeline  
    double v9 = v1[v8];	// L12
    double v10 = -(v9);	// L13
    double v11 = exp(v10);	// L14
    double v12 = v11 / double v13;	// L15
    v0[v8] = v12;	// L16
  }
}

void RELU(double activations[64], double dactivations[64], int size) {
    int i;
    Loop2: for( i = 0; i < size; i++) {
        dactivations[i] = activations[i]*(1.0-activations[i]);
        activations[i] = 1.0/(1.0+exp(-activations[i]));
    }
}

void add_bias_to_activations(double biases[64], 
                               double activations[64],
                               int size) {
    int i;
    Loop3: for( i = 0; i < size; i++){
        activations[i] = activations[i] + biases[i];
    }
}

void matrix_vector_product_with_bias_input_layer(
  double v0[64],
  double v1[832],
  double v2[64],
  double v3[13]
) {	// L2
  for (int v5 = 0; v5 < 8; v5 += 1) {	// L7
    for (int v6 = 0; v6 < 13; v6 += 1) {	// L7
#pragma HLS pipeline
      for (int v7 = 0; v7 < 8; v7 += 1) {	// L7
        v2[(v7 + (v5 * 8))] = 0.000000;	// L6
        double v8 = v1[((v6 + (v7 * 13)) + (v5 * 104))];	// L8
        double v9 = v3[v6];	// L9
        double v10 = v8 * v9;	// L10
        double v11 = v2[(v7 + (v5 * 8))];	// L11
        double v12 = v11 + v10;	// L12
        v2[(v7 + (v5 * 8))] = v12;	// L13
      }
    }
  }
  add_bias_to_activations(v0, v2, 64);
}

void matrix_vector_product_with_bias_second_layer(
  double v0[64],
  double v1[4096],
  double v2[64],
  double v3[64]
) {	// L2
  for (int v5 = 0; v5 < 8; v5 += 1) {	// L7
    for (int v6 = 0; v6 < 64; v6 += 1) {	// L7
#pragma HLS pipeline
      for (int v7 = 0; v7 < 8; v7 += 1) {	// L7
        v2[v6] = 0.000000;	// L6
        double v8 = v1[(((v6 * 64) + v7) + (v5 * 8))];	// L8
        double v9 = v3[(v7 + (v5 * 8))];	// L9
        double v10 = v8 * v9;	// L10
        double v11 = v2[v6];	// L11
        double v12 = v11 + v10;	// L12
        v2[v6] = v12;	// L13
      }
    }
  }
  add_bias_to_activations(v0, v2, 64);
}

void matrix_vector_product_with_bias_output_layer(
  double v0[3],
  double v1[192],
  double v2[3],
  double v3[64]
) {	// L2
  for (int v5 = 0; v5 < 2; v5 += 1) {	// L7
    for (int v6 = 0; v6 < 32; v6 += 1) {	// L7
#pragma HLS pipeline
      for (int v7 = 0; v7 < 3; v7 += 1) {	// L7
        v2[v7] = 0.000000;	// L6
        double v8 = v1[(((v7 * 64) + v6) + (v5 * 32))];	// L8
        double v9 = v3[(v6 + (v5 * 32))];	// L9
        double v10 = v8 * v9;	// L10
        double v11 = v2[v7];	// L11
        double v12 = v11 + v10;	// L12
        v2[v7] = v12;	// L13
      }
    }
  }
  add_bias_to_activations(v0, v2, 3);
}

void take_difference(
  double v0[3],
  double v1[3],
  double v2[3],
  double v3[3]
) {	// L2
  for (int v4 = 0; v4 < 3; v4 += 1) {	// L4
    double v5 = v0[v4];	// L5
    double v6 = v1[v4];	// L6
    double v7 = v5 - v6;	// L7
    double v8 = v7 * -1.000000;	// L8
    double v9 = v3[v4];	// L9
    double v10 = v8 * v9;	// L10
    v2[v4] = v10;	// L11
  }
}

void get_delta_matrix_weights3(
  double v0[192],
  double v1[3],
  double v2[64]
) {	// L2
  for (int v3 = 0; v3 < 4; v3 += 1) {	// L3
    for (int v4 = 0; v4 < 16; v4 += 1) {	// L3
#pragma HLS pipeline
      for (int v5 = 0; v5 < 3; v5 += 1) {	// L3
        double v6 = v2[(v4 + (v3 * 16))];	// L5
        double v7 = v1[v5];	// L6
        double v8 = v6 * v7;	// L7
        v0[((v5 + (v4 * 3)) + (v3 * 48))] = v8;	// L8
      }
    }
  }
}

void get_oracle_activations2(
  double v0[192],
  double v1[3],
  double v2[64],
  double v3[64]
) {	// L2
  for (int v4 = 0; v4 < 2; v4 += 1) {	// L6
    for (int v5 = 0; v5 < 3; v5 += 1) {	// L6
#pragma HLS pipeline
      for (int v6 = 0; v6 < 32; v6 += 1) {	// L6
        v2[(v6 + (v4 * 32))] = 0.000000;	// L5
        double v7 = v1[v5];	// L7
        double v8 = v0[((v5 + (v6 * 3)) + (v4 * 96))];	// L8
        double v9 = v7 * v8;	// L9
        double v10 = v2[(v6 + (v4 * 32))];	// L10
        double v11 = v10 + v9;	// L11
        v2[(v6 + (v4 * 32))] = v11;	// L12
        double v12 = v2[(v6 + (v4 * 32))];	// L14
        double v13 = v3[(v6 + (v4 * 32))];	// L15
        double v14 = v12 * v13;	// L16
        v2[(v6 + (v4 * 32))] = v14;	// L17
      }
    }
  }
}

void get_delta_matrix_weights2(
  double v0[4096],
  double v1[64],
  double v2[64]
) {	// L2
  for (int v3 = 0; v3 < 32; v3 += 1) {	// L3
    for (int v4 = 0; v4 < 2; v4 += 1) {	// L3
#pragma HLS pipeline
      for (int v5 = 0; v5 < 64; v5 += 1) {	// L3
        double v6 = v2[(v4 + (v3 * 2))];	// L5
        double v7 = v1[v5];	// L6
        double v8 = v6 * v7;	// L7
        v0[((v5 + (v4 * 64)) + (v3 * 128))] = v8;	// L8
      }
    }
  }
}

void get_oracle_activations1(
  double v0[4096],
  double v1[64],
  double v2[64],
  double v3[64]
) {	// L2
  for (int v4 = 0; v4 < 32; v4 += 1) {	// L6
    for (int v5 = 0; v5 < 64; v5 += 1) {	// L6
#pragma HLS pipeline
      for (int v6 = 0; v6 < 2; v6 += 1) {	// L6
        v2[(v6 + (v4 * 2))] = 0.000000;	// L5
        double v7 = v1[v5];	// L7
        double v8 = v0[((v5 + (v6 * 64)) + (v4 * 128))];	// L8
        double v9 = v7 * v8;	// L9
        double v10 = v2[(v6 + (v4 * 2))];	// L10
        double v11 = v10 + v9;	// L11
        v2[(v6 + (v4 * 2))] = v11;	// L12
        double v12 = v2[(v6 + (v4 * 2))];	// L14
        double v13 = v3[(v6 + (v4 * 2))];	// L15
        double v14 = v12 * v13;	// L16
        v2[(v6 + (v4 * 2))] = v14;	// L17
      }
    }
  }
}

void get_delta_matrix_weights1(
  double v0[832],
  double v1[64],
  double v2[13]
) {	// L2
  for (int v3 = 0; v3 < 13; v3 += 1) {	// L3
    for (int v4 = 0; v4 < 64; v4 += 1) {	// L3
#pragma HLS pipeline
      double v5 = v2[v3];	// L5
      double v6 = v1[v4];	// L6
      double v7 = v5 * v6;	// L7
      v0[(v4 + (v3 * 64))] = v7;	// L8
    }
  }
}

void update_weights(
  double v0[832],
  double v1[4096],
  double v2[192],
  double v3[832],
  double v4[4096],
  double v5[192],
  double v6[64],
  double v7[64],
  double v8[3],
  double v9[64],
  double v10[64],
  double v11[3]
) {	// L2
  for (int v12 = 0; v12 < 13; v12 += 1) {	// L5
    for (int v13 = 0; v13 < 64; v13 += 1) {	// L5
#pragma HLS pipeline
      double v14 = v3[(v13 + (v12 * 64))];	// L7
      double v15 = v14 * 0.010000;	// L8
      double v16 = v0[(v13 + (v12 * 64))];	// L9
      double v17 = v16 - v15;	// L10
      v0[(v13 + (v12 * 64))] = v17;	// L11
    }
  }
  for (int v18 = 0; v18 < 8; v18 += 1) {	// L14
    for (int v19 = 0; v19 < 8; v19 += 1) {	// L14
#pragma HLS pipeline
      double v20 = v9[(v19 + (v18 * 8))];	// L15
      double v21 = v20 * 0.010000;	// L16
      double v22 = v6[(v19 + (v18 * 8))];	// L17
      double v23 = v22 - v21;	// L18
      v6[(v19 + (v18 * 8))] = v23;	// L19
    }
  }
  for (int v24 = 0; v24 < 13; v24 += 1) {	// L21
    for (int v25 = 0; v25 < 64; v25 += 1) {	// L21
#pragma HLS pipeline
      double v26 = v0[(v25 + (v24 * 64))];	// L23
      double v27 = v26 / 0.000000;	// L24
      v0[(v25 + (v24 * 64))] = v27;	// L25
    }
  }
  for (int v28 = 0; v28 < 2; v28 += 1) {	// L28
    for (int v29 = 0; v29 < 32; v29 += 1) {	// L28
#pragma HLS pipeline
      double v30 = v6[(v29 + (v28 * 32))];	// L29
      double v31 = v30 / 0.000000;	// L30
      v6[(v29 + (v28 * 32))] = v31;	// L31
    }
  }
  for (int v32 = 0; v32 < 64; v32 += 1) {	// L33
    for (int v33 = 0; v33 < 64; v33 += 1) {	// L33
#pragma HLS pipeline
      double v34 = v4[(v33 + (v32 * 64))];	// L35
      double v35 = v34 * 0.010000;	// L36
      double v36 = v1[(v33 + (v32 * 64))];	// L37
      double v37 = v36 - v35;	// L38
      v1[(v33 + (v32 * 64))] = v37;	// L39
    }
  }
  for (int v38 = 0; v38 < 8; v38 += 1) {	// L42
    for (int v39 = 0; v39 < 8; v39 += 1) {	// L42
#pragma HLS pipeline
      double v40 = v10[(v39 + (v38 * 8))];	// L43
      double v41 = v40 * 0.010000;	// L44
      double v42 = v7[(v39 + (v38 * 8))];	// L45
      double v43 = v42 - v41;	// L46
      v7[(v39 + (v38 * 8))] = v43;	// L47
    }
  }
  for (int v44 = 0; v44 < 32; v44 += 1) {	// L49
    for (int v45 = 0; v45 < 2; v45 += 1) {	// L49
#pragma HLS pipeline
      for (int v46 = 0; v46 < 64; v46 += 1) {	// L49
        double v47 = v1[((v46 + (v45 * 64)) + (v44 * 128))];	// L51
        double v48 = v47 / 0.000000;	// L52
        v1[((v46 + (v45 * 64)) + (v44 * 128))] = v48;	// L53
      }
    }
  }
  for (int v49 = 0; v49 < 2; v49 += 1) {	// L56
    for (int v50 = 0; v50 < 32; v50 += 1) {	// L56
#pragma HLS pipeline
      double v51 = v7[(v50 + (v49 * 32))];	// L57
      double v52 = v51 / 0.000000;	// L58
      v7[(v50 + (v49 * 32))] = v52;	// L59
    }
  }
  for (int v53 = 0; v53 < 16; v53 += 1) {	// L61
#pragma HLS pipeline    
    for (int v54 = 0; v54 < 4; v54 += 1) {	// L61
      for (int v55 = 0; v55 < 3; v55 += 1) {	// L61
        double v56 = v5[((v55 + (v54 * 3)) + (v53 * 12))];	// L63
        double v57 = v56 * 0.010000;	// L64
        double v58 = v2[((v55 + (v54 * 3)) + (v53 * 12))];	// L65
        double v59 = v58 - v57;	// L66
        v2[((v55 + (v54 * 3)) + (v53 * 12))] = v59;	// L67
      }
    }
  }
  for (int v60 = 0; v60 < 3; v60 += 1) {	// L70
#pragma HLS pipeline  
    double v61 = v11[v60];	// L71
    double v62 = v61 * 0.010000;	// L72
    double v63 = v8[v60];	// L73
    double v64 = v63 - v62;	// L74
    v8[v60] = v64;	// L75
  }
  for (int v65 = 0; v65 < 2; v65 += 1) {	// L77
#pragma HLS pipeline
    for (int v66 = 0; v66 < 32; v66 += 1) {	// L77
      for (int v67 = 0; v67 < 3; v67 += 1) {	// L77
        double v68 = v2[((v67 + (v66 * 3)) + (v65 * 96))];	// L79
        double v69 = v68 / 0.000000;	// L80
        v2[((v67 + (v66 * 3)) + (v65 * 96))] = v69;	// L81
      }
    }
  }
  for (int v70 = 0; v70 < 3; v70 += 1) {	// L84
#pragma HLS pipeline  
    double v71 = v8[v70];	// L85
    double v72 = v71 / 0.000000;	// L86
    v8[v70] = v72;	// L87
  }
}

void backprop(double weights1[13*64], 
                double weights2[64*64],
                double weights3[64*3],
                double biases1[64], 
                double biases2[64],
                double biases3[3],
                double training_data[163*13],
                double training_targets[163*3]) {
    int i,j;
    //Forward and training structures
    double activations1[64];
    double activations2[64];
    double activations3[3];
    double dactivations1[64];
    double dactivations2[64];
    double dactivations3[3];
    double net_outputs[3];
    //Training structure
    double output_difference[3];
    double delta_weights1[13*64]; 
    double delta_weights2[64*64];
    double delta_weights3[64*3];
    double oracle_activations1[64];
    double oracle_activations2[64];

    Loop39: for(i=0; i<163; i++){
        Loop40: for(j=0;j<64;j++){
            activations1[j] = (double)0.0;
            activations2[j] = (double)0.0;
            if(j<3){
                activations3[j] = (double)0.0;
            }
        }
        matrix_vector_product_with_bias_input_layer(biases1, weights1, activations1, &training_data[i*13]);
        RELU(activations1, dactivations1, 64);
        matrix_vector_product_with_bias_second_layer(biases2, weights2, activations2, activations1);
        RELU(activations2, dactivations2, 64);
        matrix_vector_product_with_bias_output_layer(biases3, weights3, activations3, activations2);
        RELU(activations3, dactivations3, 3);
        soft_max(net_outputs, activations3);
        take_difference(net_outputs, &training_targets[i*3], output_difference, dactivations3);
        get_delta_matrix_weights3(delta_weights3, output_difference, activations2);
        get_oracle_activations2(weights3, output_difference, oracle_activations2, dactivations2);
        get_delta_matrix_weights2(delta_weights2, oracle_activations2, activations1);
        get_oracle_activations1(weights2, oracle_activations2, oracle_activations1, dactivations1);
        get_delta_matrix_weights1(delta_weights1, oracle_activations1, &training_data[i*13]);
        update_weights(weights1, weights2, weights3, delta_weights1, delta_weights2, delta_weights3, 
                       biases1, biases2, biases3, oracle_activations1, oracle_activations2, output_difference);
    }
}
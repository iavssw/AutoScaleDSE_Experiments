#include "math.h"

void soft_max(double net_outputs[3], double activations[3]) {
    int i;
    double sum;
    sum = (double) 0.0;

    Loop0: for(i=0; i < 3; i++) {
#pragma HLS pipeline
        sum += exp(-activations[i]);
    }
    Loop1: for(i=0; i < 3; i++) {
#pragma HLS pipeline
        net_outputs[i] = exp(-activations[i])/sum;
    }
}

void RELU(double activations[64], double dactivations[64], int size) {
    int i;
    Loop2: for( i = 0; i < size; i++) {
        dactivations[i] = activations[i]*(1.0-activations[i]);
        activations[i] = 1.0/(1.0+exp(-activations[i]));
    }
}

void add_bias_to_activations(double biases[64], 
                               double activations[64],
                               int size) {
    int i;
    Loop3: for( i = 0; i < size; i++){
        activations[i] = activations[i] + biases[i];
    }
}

void matrix_vector_product_with_bias_input_layer(
  double v0[64],
  double v1[832],
  double v2[64],
  double v3[13]
) {	// L2





  for (int v4 = 0; v4 < 8; v4 += 1) {	// L6
    for (int v5 = 0; v5 < 13; v5 += 1) {	// L6
#pragma HLS pipeline    
      for (int v6 = 0; v6 < 8; v6 += 1) {	// L6
        int v7 = (v6 + (v4 * 8));	// L6
        v2[v7] = 0.000000;	// L5
        double v8 = v1[(v5 + (v7 * 13))];	// L7
        double v9 = v3[v5];	// L8
        double v10 = v8 * v9;	// L9
        double v11 = v2[v7];	// L10
        double v12 = v11 + v10;	// L11
        v2[v7] = v12;	// L12
      }
    }
  }

  add_bias_to_activations(v0, v2, 64);
}

void matrix_vector_product_with_bias_second_layer(
  double v0[64],
  double v1[4096],
  double v2[64],
  double v3[64]
) {	// L2





  for (int v4 = 0; v4 < 8; v4 += 1) {	// L6
    for (int v5 = 0; v5 < 64; v5 += 1) {	// L6
#pragma HLS pipeline    
      for (int v6 = 0; v6 < 8; v6 += 1) {	// L6
        int v7 = (v6 + (v4 * 8));	// L6
        v2[v5] = 0.000000;	// L5
        double v8 = v1[(v7 + (v5 * 64))];	// L7
        double v9 = v3[v7];	// L8
        double v10 = v8 * v9;	// L9
        double v11 = v2[v5];	// L10
        double v12 = v11 + v10;	// L11
        v2[v5] = v12;	// L12
      }
    }
  }

  add_bias_to_activations(v0, v2, 64);
}

void matrix_vector_product_with_bias_output_layer(
  double v0[3],
  double v1[192],
  double v2[3],
  double v3[64]
) {	// L2





  for (int v4 = 0; v4 < 8; v4 += 1) {	// L6
    for (int v5 = 0; v5 < 8; v5 += 1) {	// L6
#pragma HLS pipeline    
      int v6 = (v5 + (v4 * 8));	// L6
      for (int v7 = 0; v7 < 3; v7 += 1) {	// L6
        v2[v7] = 0.000000;	// L5
        double v8 = v1[(v6 + (v7 * 64))];	// L7
        double v9 = v3[v6];	// L8
        double v10 = v8 * v9;	// L9
        double v11 = v2[v7];	// L10
        double v12 = v11 + v10;	// L11
        v2[v7] = v12;	// L12
      }
    }
  }

  add_bias_to_activations(v0, v2, 3);
}

void take_difference(
  double v0[3],
  double v1[3],
  double v2[3],
  double v3[3]
) {	// L2





  for (int v4 = 0; v4 < 3; v4 += 1) {	// L4
    double v5 = v0[v4];	// L5
    double v6 = v1[v4];	// L6
    double v7 = v5 - v6;	// L7
    double v8 = v7 * -1.000000;	// L8
    double v9 = v3[v4];	// L9
    double v10 = v8 * v9;	// L10
    v2[v4] = v10;	// L11
  }
}

void get_delta_matrix_weights3(
  double v0[192],
  double v1[3],
  double v2[64]
) {	// L2




  for (int v3 = 0; v3 < 8; v3 += 1) {	// L3
    for (int v4 = 0; v4 < 8; v4 += 1) {	// L3
#pragma HLS pipeline    
      int v5 = (v4 + (v3 * 8));	// L3
      for (int v6 = 0; v6 < 3; v6 += 1) {	// L3
        double v7 = v2[v5];	// L5
        double v8 = v1[v6];	// L6
        double v9 = v7 * v8;	// L7
        v0[(v6 + (v5 * 3))] = v9;	// L8
      }
    }
  }
}

void get_oracle_activations2(
  double v0[192],
  double v1[3],
  double v2[64],
  double v3[64]
) {	// L2





  for (int v4 = 0; v4 < 8; v4 += 1) {	// L6
    for (int v5 = 0; v5 < 3; v5 += 1) {	// L6
#pragma HLS pipeline    
      for (int v6 = 0; v6 < 8; v6 += 1) {	// L6
        int v7 = (v6 + (v4 * 8));	// L6
        v2[v7] = 0.000000;	// L5
        double v8 = v1[v5];	// L7
        double v9 = v0[(v5 + (v7 * 3))];	// L8
        double v10 = v8 * v9;	// L9
        double v11 = v2[v7];	// L10
        double v12 = v11 + v10;	// L11
        v2[v7] = v12;	// L12
        double v13 = v2[v7];	// L14
        double v14 = v3[v7];	// L15
        double v15 = v13 * v14;	// L16
        v2[v7] = v15;	// L17
      }
    }
  }
}

void get_delta_matrix_weights2(
  double v0[4096],
  double v1[64],
  double v2[64]
) {	// L2




  for (int v3 = 0; v3 < 64; v3 += 1) {	// L3
    for (int v4 = 0; v4 < 4; v4 += 1) {	// L3
#pragma HLS pipeline    
      for (int v5 = 0; v5 < 16; v5 += 1) {	// L3
        int v6 = (v5 + (v4 * 16));	// L3
        double v7 = v2[v3];	// L5
        double v8 = v1[v6];	// L6
        double v9 = v7 * v8;	// L7
        v0[(v6 + (v3 * 64))] = v9;	// L8
      }
    }
  }
}

void get_oracle_activations1(
  double v0[4096],
  double v1[64],
  double v2[64],
  double v3[64]
) {	// L2





  for (int v4 = 0; v4 < 4; v4 += 1) {	// L6
    for (int v5 = 0; v5 < 64; v5 += 1) {	// L6
#pragma HLS pipeline    
      for (int v6 = 0; v6 < 16; v6 += 1) {	// L6
        int v7 = (v6 + (v4 * 16));	// L6
        v2[v5] = 0.000000;	// L5
        double v8 = v1[v7];	// L7
        double v9 = v0[(v7 + (v5 * 64))];	// L8
        double v10 = v8 * v9;	// L9
        double v11 = v2[v5];	// L10
        double v12 = v11 + v10;	// L11
        v2[v5] = v12;	// L12
        double v13 = v2[v5];	// L14
        double v14 = v3[v5];	// L15
        double v15 = v13 * v14;	// L16
        v2[v5] = v15;	// L17
      }
    }
  }
}

void get_delta_matrix_weights1(
  double v0[832],
  double v1[64],
  double v2[13]
) {	// L2




  for (int v3 = 0; v3 < 13; v3 += 1) {	// L3
    for (int v4 = 0; v4 < 4; v4 += 1) {	// L3
#pragma HLS pipeline    
      for (int v5 = 0; v5 < 16; v5 += 1) {	// L3
        int v6 = (v5 + (v4 * 16));	// L3
        double v7 = v2[v3];	// L5
        double v8 = v1[v6];	// L6
        double v9 = v7 * v8;	// L7
        v0[(v6 + (v3 * 64))] = v9;	// L8
      }
    }
  }
}

void update_weights(
  double v0[832],
  double v1[4096],
  double v2[192],
  double v3[832],
  double v4[4096],
  double v5[192],
  double v6[64],
  double v7[64],
  double v8[3],
  double v9[64],
  double v10[64],
  double v11[3]
) {     // L2

  double v12[1];        // L5
  v12[0] = 0.000000;    // L6
  double v13[1];        // L7
  v13[0] = 0.000000;    // L8
  double v14[1];        // L11
  double v15[1];        // L13
  for (int v16 = 0; v16 < 13; v16 += 1) {       // L9
    for (int v17 = 0; v17 < 4; v17 += 1) {      // L9
#pragma HLS pipeline    
      for (int v18 = 0; v18 < 16; v18 += 1) {   // L9
        double v19 = v12[0];    // L10
        v14[0] = v19;   // L12
        v15[0] = v19;   // L14
        double v20 = v14[0];    // L16
        double v21 = v3[(((v16 * 64) + v18) + (v17 * 16))];     // L17
        double v22 = v21 * 0.010000;    // L18
        double v23 = v0[(((v16 * 64) + v18) + (v17 * 16))];     // L19
        double v24 = v23 - v22; // L20
        v0[(((v16 * 64) + v18) + (v17 * 16))] = v24;    // L21
        double v25 = v24 * v24; // L22
        double v26 = v20 + v25; // L23
        v14[0] = v26;   // L24
        v15[0] = v26;   // L25
        double v27 = v15[0];    // L27
        v12[0] = v27;   // L28
        v13[0] = v27;   // L29
      }
    }
  }
  double v28 = v13[0];  // L31
  double v29[1];        // L32
  v29[0] = 0.000000;    // L33
  double v30[1];        // L34
  v30[0] = 0.000000;    // L35
  for (int v31 = 0; v31 < 8; v31 += 1) {        // L36
#pragma HLS pipeline  
    for (int v32 = 0; v32 < 8; v32 += 1) {      // L36
      double v33 = v29[0];      // L37
      double v34 = v9[(v32 + (v31 * 8))];       // L38
      double v35 = v34 * 0.010000;      // L39
      double v36 = v6[(v32 + (v31 * 8))];       // L40
      double v37 = v36 - v35;   // L41
      v6[(v32 + (v31 * 8))] = v37;      // L42
      double v38 = v37 * v37;   // L43
      double v39 = v33 + v38;   // L44
      v29[0] = v39;     // L45
      v30[0] = v39;     // L46
    }
  }
  double v40 = v30[0];  // L48
  double v41 = sqrt(v28);       // L49
  double v42 = sqrt(v40);       // L50
  for (int v43 = 0; v43 < 13; v43 += 1) {       // L51
    for (int v44 = 0; v44 < 4; v44 += 1) {      // L51
#pragma HLS pipeline    
      for (int v45 = 0; v45 < 16; v45 += 1) {   // L51
        double v46 = v0[(((v43 * 64) + v45) + (v44 * 16))];     // L53
        double v47 = v46 / v41; // L54
        v0[(((v43 * 64) + v45) + (v44 * 16))] = v47;    // L55
      }
    }
  }
  for (int v48 = 0; v48 < 8; v48 += 1) {        // L58
#pragma HLS pipeline  
    for (int v49 = 0; v49 < 8; v49 += 1) {      // L58
      double v50 = v6[(v49 + (v48 * 8))];       // L59
      double v51 = v50 / v42;   // L60
      v6[(v49 + (v48 * 8))] = v51;      // L61
    }
  }
  double v52[1];        // L63
  v52[0] = 0.000000;    // L64
  double v53[1];        // L65
  v53[0] = 0.000000;    // L66
  double v54[1];        // L69
  double v55[1];        // L71
  for (int v56 = 0; v56 < 8; v56 += 1) {        // L67
    for (int v57 = 0; v57 < 4; v57 += 1) {      // L67
#pragma HLS pipeline    
      for (int v58 = 0; v58 < 8; v58 += 1) {    // L67
        for (int v59 = 0; v59 < 16; v59 += 1) { // L67
          double v60 = v52[0];  // L68
          v54[0] = v60; // L70
          v55[0] = v60; // L72
          double v61 = v54[0];  // L74
          double v62 = v4[(((v59 + (v57 * 16)) + (v58 * 64)) + (v56 * 512))];   // L75
          double v63 = v62 * 0.010000;  // L76
          double v64 = v1[(((v59 + (v57 * 16)) + (v58 * 64)) + (v56 * 512))];   // L77
          double v65 = v64 - v63;       // L78
          v1[(((v59 + (v57 * 16)) + (v58 * 64)) + (v56 * 512))] = v65;  // L79
          double v66 = v65 * v65;       // L80
          double v67 = v61 + v66;       // L81
          v54[0] = v67; // L82
          v55[0] = v67; // L83
          double v68 = v55[0];  // L85
          v52[0] = v68; // L86
          v53[0] = v68; // L87
        }
      }
    }
  }
  double v69 = v53[0];  // L89
  double v70[1];        // L90
  v70[0] = 0.000000;    // L91
  double v71[1];        // L92
  v71[0] = 0.000000;    // L93
  for (int v72 = 0; v72 < 8; v72 += 1) {        // L94
#pragma HLS pipeline  
    for (int v73 = 0; v73 < 8; v73 += 1) {      // L94
      double v74 = v70[0];      // L95
      double v75 = v10[(v73 + (v72 * 8))];      // L96
      double v76 = v75 * 0.010000;      // L97
      double v77 = v7[(v73 + (v72 * 8))];       // L98
      double v78 = v77 - v76;   // L99
      v7[(v73 + (v72 * 8))] = v78;      // L100
      double v79 = v78 * v78;   // L101
      double v80 = v74 + v79;   // L102
      v70[0] = v80;     // L103
      v71[0] = v80;     // L104
    }
  }
  double v81 = v71[0];  // L106
  double v82 = sqrt(v69);       // L107
  double v83 = sqrt(v81);       // L108
  for (int v84 = 0; v84 < 64; v84 += 1) {       // L109
    for (int v85 = 0; v85 < 4; v85 += 1) {      // L109
#pragma HLS pipeline    
      for (int v86 = 0; v86 < 16; v86 += 1) {   // L109
        double v87 = v1[(((v84 * 64) + v86) + (v85 * 16))];     // L111
        double v88 = v87 / v82; // L112
        v1[(((v84 * 64) + v86) + (v85 * 16))] = v88;    // L113
      }
    }
  }
  for (int v89 = 0; v89 < 8; v89 += 1) {        // L116
#pragma HLS pipeline  
    for (int v90 = 0; v90 < 8; v90 += 1) {      // L116
      double v91 = v7[(v90 + (v89 * 8))];       // L117
      double v92 = v91 / v83;   // L118
      v7[(v90 + (v89 * 8))] = v92;      // L119
    }
  }
  double v93[1];        // L121
  v93[0] = 0.000000;    // L122
  double v94[1];        // L123
  v94[0] = 0.000000;    // L124
  double v95[1];        // L127
  double v96[1];        // L129
  for (int v97 = 0; v97 < 16; v97 += 1) {       // L125
    for (int v98 = 0; v98 < 4; v98 += 1) {      // L125
#pragma HLS pipeline    
      for (int v99 = 0; v99 < 3; v99 += 1) {    // L125
        double v100 = v93[0];   // L126
        v95[0] = v100;  // L128
        v96[0] = v100;  // L130
        double v101 = v95[0];   // L132
        double v102 = v5[((v99 + (v98 * 3)) + (v97 * 12))];     // L133
        double v103 = v102 * 0.010000;  // L134
        double v104 = v2[((v99 + (v98 * 3)) + (v97 * 12))];     // L135
        double v105 = v104 - v103;      // L136
        v2[((v99 + (v98 * 3)) + (v97 * 12))] = v105;    // L137
        double v106 = v105 * v105;      // L138
        double v107 = v101 + v106;      // L139
        v95[0] = v107;  // L140
        v96[0] = v107;  // L141
        double v108 = v96[0];   // L143
        v93[0] = v108;  // L144
        v94[0] = v108;  // L145
      }
    }
  }
  double v109 = v94[0]; // L147
  double v110[1];       // L148
  v110[0] = 0.000000;   // L149
  double v111[1];       // L150
  v111[0] = 0.000000;   // L151
  for (int v112 = 0; v112 < 3; v112 += 1) {     // L152
#pragma HLS pipeline  
    double v113 = v110[0];      // L153
    double v114 = v11[v112];    // L154
    double v115 = v114 * 0.010000;      // L155
    double v116 = v8[v112];     // L156
    double v117 = v116 - v115;  // L157
    v8[v112] = v117;    // L158
    double v118 = v117 * v117;  // L159
    double v119 = v113 + v118;  // L160
    v110[0] = v119;     // L161
    v111[0] = v119;     // L162
  }
  double v120 = v111[0];        // L164
  double v121 = sqrt(v109);     // L165
  double v122 = sqrt(v120);     // L166
  for (int v123 = 0; v123 < 8; v123 += 1) {     // L167
    for (int v124 = 0; v124 < 8; v124 += 1) {   // L167
#pragma HLS pipeline    
      for (int v125 = 0; v125 < 3; v125 += 1) { // L167
        double v126 = v2[((v125 + (v124 * 3)) + (v123 * 24))];  // L169
        double v127 = v126 / v121;      // L170
        v2[((v125 + (v124 * 3)) + (v123 * 24))] = v127; // L171
      }
    }
  }
  for (int v128 = 0; v128 < 3; v128 += 1) {     // L174
#pragma HLS pipeline  
    double v129 = v8[v128];     // L175
    double v130 = v129 / v122;  // L176
    v8[v128] = v130;    // L177
  }
}

void backprop(double weights1[13*64], 
                double weights2[64*64],
                double weights3[64*3],
                double biases1[64], 
                double biases2[64],
                double biases3[3],
                double training_data[163*13],
                double training_targets[163*3]) {
    int i,j;
    //Forward and training structures
    double activations1[64];
#pragma HLS ARRAY_PARTITION variable=activations1 cyclic factor=8 dim=1
    double activations2[64];
#pragma HLS ARRAY_PARTITION variable=activations2 cyclic factor=8 dim=1
    double activations3[3];
#pragma HLS ARRAY_PARTITION variable=activations3 cyclic factor=3 dim=1
    double dactivations1[64];
#pragma HLS ARRAY_PARTITION variable=dactivations1 cyclic factor=8 dim=1
    double dactivations2[64];
#pragma HLS ARRAY_PARTITION variable=dactivations2 cyclic factor=8 dim=1
    double dactivations3[3];
#pragma HLS ARRAY_PARTITION variable=dactivations3 cyclic factor=3 dim=1
    double net_outputs[3];
#pragma HLS ARRAY_PARTITION variable=net_outputs cyclic factor=3 dim=1
    //Training structure
    double output_difference[3];
#pragma HLS ARRAY_PARTITION variable=output_difference cyclic factor=3 dim=1
    double delta_weights1[13*64]; 
#pragma HLS ARRAY_PARTITION variable=delta_weights1 cyclic factor=32 dim=1
    double delta_weights2[64*64];
#pragma HLS ARRAY_PARTITION variable=delta_weights2 cyclic factor=32 dim=1
    double delta_weights3[64*3];
#pragma HLS ARRAY_PARTITION variable=delta_weights3 cyclic factor=32 dim=1
    double oracle_activations1[64];
#pragma HLS ARRAY_PARTITION variable=oracle_activations1 cyclic factor=32 dim=1
    double oracle_activations2[64];
#pragma HLS ARRAY_PARTITION variable=oracle_activations2 cyclic factor=32 dim=1

    Loop39: for(i=0; i<163; i++){
        Loop40: for(j=0;j<64;j++){
            activations1[j] = (double)0.0;
            activations2[j] = (double)0.0;
            if(j<3){
                activations3[j] = (double)0.0;
            }
        }
        matrix_vector_product_with_bias_input_layer(biases1, weights1, activations1, &training_data[i*13]);
        RELU(activations1, dactivations1, 64);
        matrix_vector_product_with_bias_second_layer(biases2, weights2, activations2, activations1);
        RELU(activations2, dactivations2, 64);
        matrix_vector_product_with_bias_output_layer(biases3, weights3, activations3, activations2);
        RELU(activations3, dactivations3, 3);
        soft_max(net_outputs, activations3);
        take_difference(net_outputs, &training_targets[i*3], output_difference, dactivations3);
        get_delta_matrix_weights3(delta_weights3, output_difference, activations2);
        get_oracle_activations2(weights3, output_difference, oracle_activations2, dactivations2);
        get_delta_matrix_weights2(delta_weights2, oracle_activations2, activations1);
        get_oracle_activations1(weights2, oracle_activations2, oracle_activations1, dactivations1);
        get_delta_matrix_weights1(delta_weights1, oracle_activations1, &training_data[i*13]);
        update_weights(weights1, weights2, weights3, delta_weights1, delta_weights2, delta_weights3, 
                       biases1, biases2, biases3, oracle_activations1, oracle_activations2, output_difference);
    }
}

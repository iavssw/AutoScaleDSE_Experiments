# 1 "backprop/v5.c"
# 1 "backprop/v5.c" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 147 "<built-in>" 3
# 1 "<command line>" 1






# 1 "C:/Xilinx/Vivado/2019.2/common/technology/autopilot\\etc/autopilot_ssdm_op.h" 1
# 305 "C:/Xilinx/Vivado/2019.2/common/technology/autopilot\\etc/autopilot_ssdm_op.h"
    void _ssdm_op_IfRead() __attribute__ ((nothrow));
    void _ssdm_op_IfWrite() __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbRead() __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfNbWrite() __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanRead() __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_op_IfCanWrite() __attribute__ ((nothrow));


    void _ssdm_StreamRead() __attribute__ ((nothrow));
    void _ssdm_StreamWrite() __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbRead() __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamNbWrite() __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanRead() __attribute__ ((nothrow));
    unsigned int __attribute__ ((bitwidth(1))) _ssdm_StreamCanWrite() __attribute__ ((nothrow));




    void _ssdm_op_MemShiftRead() __attribute__ ((nothrow));

    void _ssdm_op_Wait() __attribute__ ((nothrow));
    void _ssdm_op_Poll() __attribute__ ((nothrow));

    void _ssdm_op_Return() __attribute__ ((nothrow));


    void _ssdm_op_SpecSynModule() __attribute__ ((nothrow));
    void _ssdm_op_SpecTopModule() __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDecl() __attribute__ ((nothrow));
    void _ssdm_op_SpecProcessDef() __attribute__ ((nothrow));
    void _ssdm_op_SpecPort() __attribute__ ((nothrow));
    void _ssdm_op_SpecConnection() __attribute__ ((nothrow));
    void _ssdm_op_SpecChannel() __attribute__ ((nothrow));
    void _ssdm_op_SpecSensitive() __attribute__ ((nothrow));
    void _ssdm_op_SpecModuleInst() __attribute__ ((nothrow));
    void _ssdm_op_SpecPortMap() __attribute__ ((nothrow));

    void _ssdm_op_SpecReset() __attribute__ ((nothrow));

    void _ssdm_op_SpecPlatform() __attribute__ ((nothrow));
    void _ssdm_op_SpecClockDomain() __attribute__ ((nothrow));
    void _ssdm_op_SpecPowerDomain() __attribute__ ((nothrow));

    int _ssdm_op_SpecRegionBegin() __attribute__ ((nothrow));
    int _ssdm_op_SpecRegionEnd() __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopName() __attribute__ ((nothrow));

    void _ssdm_op_SpecLoopTripCount() __attribute__ ((nothrow));

    int _ssdm_op_SpecStateBegin() __attribute__ ((nothrow));
    int _ssdm_op_SpecStateEnd() __attribute__ ((nothrow));

    void _ssdm_op_SpecInterface() __attribute__ ((nothrow));

    void _ssdm_op_SpecPipeline() __attribute__ ((nothrow));
    void _ssdm_op_SpecDataflowPipeline() __attribute__ ((nothrow));


    void _ssdm_op_SpecLatency() __attribute__ ((nothrow));
    void _ssdm_op_SpecParallel() __attribute__ ((nothrow));
    void _ssdm_op_SpecProtocol() __attribute__ ((nothrow));
    void _ssdm_op_SpecOccurrence() __attribute__ ((nothrow));

    void _ssdm_op_SpecResource() __attribute__ ((nothrow));
    void _ssdm_op_SpecResourceLimit() __attribute__ ((nothrow));
    void _ssdm_op_SpecCHCore() __attribute__ ((nothrow));
    void _ssdm_op_SpecFUCore() __attribute__ ((nothrow));
    void _ssdm_op_SpecIFCore() __attribute__ ((nothrow));
    void _ssdm_op_SpecIPCore() __attribute__ ((nothrow));
    void _ssdm_op_SpecKeepValue() __attribute__ ((nothrow));
    void _ssdm_op_SpecMemCore() __attribute__ ((nothrow));

    void _ssdm_op_SpecExt() __attribute__ ((nothrow));




    void _ssdm_SpecArrayDimSize() __attribute__ ((nothrow));

    void _ssdm_RegionBegin() __attribute__ ((nothrow));
    void _ssdm_RegionEnd() __attribute__ ((nothrow));

    void _ssdm_Unroll() __attribute__ ((nothrow));
    void _ssdm_UnrollRegion() __attribute__ ((nothrow));

    void _ssdm_InlineAll() __attribute__ ((nothrow));
    void _ssdm_InlineLoop() __attribute__ ((nothrow));
    void _ssdm_Inline() __attribute__ ((nothrow));
    void _ssdm_InlineSelf() __attribute__ ((nothrow));
    void _ssdm_InlineRegion() __attribute__ ((nothrow));

    void _ssdm_SpecArrayMap() __attribute__ ((nothrow));
    void _ssdm_SpecArrayPartition() __attribute__ ((nothrow));
    void _ssdm_SpecArrayReshape() __attribute__ ((nothrow));

    void _ssdm_SpecStream() __attribute__ ((nothrow));

    void _ssdm_op_SpecStable() __attribute__ ((nothrow));
    void _ssdm_op_SpecStableContent() __attribute__ ((nothrow));

    void _ssdm_op_SpecPipoDepth() __attribute__ ((nothrow));

    void _ssdm_SpecExpr() __attribute__ ((nothrow));
    void _ssdm_SpecExprBalance() __attribute__ ((nothrow));

    void _ssdm_SpecDependence() __attribute__ ((nothrow));

    void _ssdm_SpecLoopMerge() __attribute__ ((nothrow));
    void _ssdm_SpecLoopFlatten() __attribute__ ((nothrow));
    void _ssdm_SpecLoopRewind() __attribute__ ((nothrow));

    void _ssdm_SpecFuncInstantiation() __attribute__ ((nothrow));
    void _ssdm_SpecFuncBuffer() __attribute__ ((nothrow));
    void _ssdm_SpecFuncExtract() __attribute__ ((nothrow));
    void _ssdm_SpecConstant() __attribute__ ((nothrow));

    void _ssdm_DataPack() __attribute__ ((nothrow));
    void _ssdm_SpecDataPack() __attribute__ ((nothrow));

    void _ssdm_op_SpecBitsMap() __attribute__ ((nothrow));
    void _ssdm_op_SpecLicense() __attribute__ ((nothrow));
# 8 "<command line>" 2
# 1 "<built-in>" 2
# 1 "backprop/v5.c" 2
# 1 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 1 3
# 10 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
# 10 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3


# 1 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 1 3
# 10 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
# 1 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include/_mingw_mac.h" 1 3
# 10 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 2 3
# 277 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
# 1 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\vadefs.h" 1 3
# 13 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\vadefs.h" 3
# 1 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 1 3
# 674 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
# 1 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include/sdks/_mingw_directx.h" 1 3
# 674 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 2 3

# 1 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include/sdks/_mingw_ddk.h" 1 3
# 675 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 2 3
# 13 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\vadefs.h" 2 3


#pragma pack(push,_CRT_PACKING)








 typedef __builtin_va_list __gnuc_va_list;






  typedef __gnuc_va_list va_list;
# 102 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\vadefs.h" 3
#pragma pack(pop)
# 277 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 2 3


#pragma pack(push,_CRT_PACKING)
# 370 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
__extension__ typedef unsigned long long size_t;
# 380 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
__extension__ typedef long long ssize_t;
# 392 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
__extension__ typedef long long intptr_t;
# 405 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
__extension__ typedef unsigned long long uintptr_t;
# 418 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
__extension__ typedef long long ptrdiff_t;
# 428 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
typedef unsigned short wchar_t;







typedef unsigned short wint_t;
typedef unsigned short wctype_t;
# 456 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
typedef int errno_t;




typedef long __time32_t;




__extension__ typedef long long __time64_t;







typedef __time64_t time_t;
# 607 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\_mingw.h" 3
struct threadlocaleinfostruct;
struct threadmbcinfostruct;
typedef struct threadlocaleinfostruct *pthreadlocinfo;
typedef struct threadmbcinfostruct *pthreadmbcinfo;
struct __lc_time_data;

typedef struct localeinfo_struct {
  pthreadlocinfo locinfo;
  pthreadmbcinfo mbcinfo;
} _locale_tstruct,*_locale_t;



typedef struct tagLC_ID {
  unsigned short wLanguage;
  unsigned short wCountry;
  unsigned short wCodePage;
} LC_ID,*LPLC_ID;




typedef struct threadlocaleinfostruct {
  int refcount;
  unsigned int lc_codepage;
  unsigned int lc_collate_cp;
  unsigned long lc_handle[6];
  LC_ID lc_id[6];
  struct {
    char *locale;
    wchar_t *wlocale;
    int *refcount;
    int *wrefcount;
  } lc_category[6];
  int lc_clike;
  int mb_cur_max;
  int *lconv_intl_refcount;
  int *lconv_num_refcount;
  int *lconv_mon_refcount;
  struct lconv *lconv;
  int *ctype1_refcount;
  unsigned short *ctype1;
  const unsigned short *pctype;
  const unsigned char *pclmap;
  const unsigned char *pcumap;
  struct __lc_time_data *lc_time_curr;
} threadlocinfo;







const char *__mingw_get_crt_info (void);





#pragma pack(pop)
# 12 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 2 3


struct _exception;

#pragma pack(push,_CRT_PACKING)
# 79 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
 extern double * __imp__HUGE;
# 91 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  struct _exception {
    int type;
    const char *name;
    double arg1;
    double arg2;
    double retval;
  };

  void __mingw_raise_matherr (int typ, const char *name, double a1, double a2,
         double rslt);
  void __mingw_setusermatherr (int ( *)(struct _exception *));
  __attribute__ ((__dllimport__)) void __setusermatherr(int ( *)(struct _exception *));



  double sin(double _X);
  double cos(double _X);
  double tan(double _X);
  double sinh(double _X);
  double cosh(double _X);
  double tanh(double _X);
  double asin(double _X);
  double acos(double _X);
  double atan(double _X);
  double atan2(double _Y,double _X);
  double exp(double _X);
  double log(double _X);
  double log10(double _X);
  double pow(double _X,double _Y);
  double sqrt(double _X);
  double ceil(double _X);
  double floor(double _X);
  double fabs(double _X);
# 135 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  double ldexp(double _X,int _Y);
  double frexp(double _X,int *_Y);
  double modf(double _X,double *_Y);
  double fmod(double _X,double _Y);

  void sincos (double __x, double *p_sin, double *p_cos);
  void sincosl (long double __x, long double *p_sin, long double *p_cos);
  void sincosf (float __x, float *p_sin, float *p_cos);



  int abs(int _X);
  long labs(long _X);



  double atof(const char *_String);
  double _atof_l(const char *_String,_locale_t _Locale);
# 162 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  struct _complex {
    double x;
    double y;
  };


  __attribute__ ((__dllimport__)) double _cabs(struct _complex _ComplexA);
  double _hypot(double _X,double _Y);
  __attribute__ ((__dllimport__)) double _j0(double _X);
  __attribute__ ((__dllimport__)) double _j1(double _X);
  __attribute__ ((__dllimport__)) double _jn(int _X,double _Y);
  __attribute__ ((__dllimport__)) double _y0(double _X);
  __attribute__ ((__dllimport__)) double _y1(double _X);
  __attribute__ ((__dllimport__)) double _yn(int _X,double _Y);


  __attribute__ ((__dllimport__)) int _matherr (struct _exception *);
# 189 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  __attribute__ ((__dllimport__)) double _chgsign (double _X);
  __attribute__ ((__dllimport__)) double _copysign (double _Number,double _Sign);
  __attribute__ ((__dllimport__)) double _logb (double);
  __attribute__ ((__dllimport__)) double _nextafter (double, double);
  __attribute__ ((__dllimport__)) double _scalb (double, long);
  __attribute__ ((__dllimport__)) int _finite (double);
  __attribute__ ((__dllimport__)) int _fpclass (double);
  __attribute__ ((__dllimport__)) int _isnan (double);






__attribute__ ((__dllimport__)) double j0 (double) ;
__attribute__ ((__dllimport__)) double j1 (double) ;
__attribute__ ((__dllimport__)) double jn (int, double) ;
__attribute__ ((__dllimport__)) double y0 (double) ;
__attribute__ ((__dllimport__)) double y1 (double) ;
__attribute__ ((__dllimport__)) double yn (int, double) ;

__attribute__ ((__dllimport__)) double chgsign (double);
# 219 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  __attribute__ ((__dllimport__)) int finite (double);
  __attribute__ ((__dllimport__)) int fpclass (double);
# 264 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
typedef float float_t;
typedef double double_t;
# 299 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  extern int __fpclassifyl (long double);
  extern int __fpclassifyf (float);
  extern int __fpclassify (double);
# 335 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  extern int __isnan (double);
  extern int __isnanf (float);
  extern int __isnanl (long double);
# 376 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  extern int __signbit (double);
  extern int __signbitf (float);
  extern int __signbitl (long double);
# 404 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  extern float sinf(float _X);
  extern long double sinl(long double);

  extern float cosf(float _X);
  extern long double cosl(long double);

  extern float tanf(float _X);
  extern long double tanl(long double);
  extern float asinf(float _X);
  extern long double asinl(long double);

  extern float acosf (float);
  extern long double acosl (long double);

  extern float atanf (float);
  extern long double atanl (long double);

  extern float atan2f (float, float);
  extern long double atan2l (long double, long double);


  extern float sinhf(float _X);



  extern long double sinhl(long double);

  extern float coshf(float _X);



  extern long double coshl(long double);

  extern float tanhf(float _X);



  extern long double tanhl(long double);



  extern double acosh (double);
  extern float acoshf (float);
  extern long double acoshl (long double);


  extern double asinh (double);
  extern float asinhf (float);
  extern long double asinhl (long double);


  extern double atanh (double);
  extern float atanhf (float);
  extern long double atanhl (long double);



  extern float expf(float _X);



  extern long double expl(long double);


  extern double exp2(double);
  extern float exp2f(float);
  extern long double exp2l(long double);



  extern double expm1(double);
  extern float expm1f(float);
  extern long double expm1l(long double);


  extern float frexpf(float _X,int *_Y);



  extern long double frexpl(long double,int *);




  extern int ilogb (double);
  extern int ilogbf (float);
  extern int ilogbl (long double);


  extern float ldexpf(float _X,int _Y);



  extern long double ldexpl (long double, int);


  extern float logf (float);
  extern long double logl(long double);


  extern float log10f (float);
  extern long double log10l(long double);


  extern double log1p(double);
  extern float log1pf(float);
  extern long double log1pl(long double);


  extern double log2 (double);
  extern float log2f (float);
  extern long double log2l (long double);


  extern double logb (double);
  extern float logbf (float);
  extern long double logbl (long double);
# 553 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  extern float modff (float, float*);
  extern long double modfl (long double, long double*);


  extern double scalbn (double, int);
  extern float scalbnf (float, int);
  extern long double scalbnl (long double, int);

  extern double scalbln (double, long);
  extern float scalblnf (float, long);
  extern long double scalblnl (long double, long);



  extern double cbrt (double);
  extern float cbrtf (float);
  extern long double cbrtl (long double);


  extern float fabsf (float x);
# 583 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  extern long double fabsl (long double);
# 595 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  extern double hypot (double, double) ;
  extern float hypotf (float x, float y);



  extern long double hypotl (long double, long double);


  extern float powf(float _X,float _Y);



  extern long double powl (long double, long double);


  extern float sqrtf (float);
  extern long double sqrtl(long double);


  extern double erf (double);
  extern float erff (float);
  extern long double erfl (long double);


  extern double erfc (double);
  extern float erfcf (float);
  extern long double erfcl (long double);


  extern double lgamma (double);
  extern float lgammaf (float);
  extern long double lgammal (long double);


  extern double tgamma (double);
  extern float tgammaf (float);
  extern long double tgammal (long double);


  extern float ceilf (float);
  extern long double ceill (long double);


  extern float floorf (float);
  extern long double floorl (long double);


  extern double nearbyint ( double);
  extern float nearbyintf (float);
  extern long double nearbyintl (long double);



extern double rint (double);
extern float rintf (float);
extern long double rintl (long double);


extern long lrint (double);
extern long lrintf (float);
extern long lrintl (long double);

__extension__ long long llrint (double);
__extension__ long long llrintf (float);
__extension__ long long llrintl (long double);
# 739 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  extern double round (double);
  extern float roundf (float);
  extern long double roundl (long double);


  extern long lround (double);
  extern long lroundf (float);
  extern long lroundl (long double);
  __extension__ long long llround (double);
  __extension__ long long llroundf (float);
  __extension__ long long llroundl (long double);



  extern double trunc (double);
  extern float truncf (float);
  extern long double truncl (long double);


  extern float fmodf (float, float);
  extern long double fmodl (long double, long double);


  extern double remainder (double, double);
  extern float remainderf (float, float);
  extern long double remainderl (long double, long double);


  extern double remquo(double, double, int *);
  extern float remquof(float, float, int *);
  extern long double remquol(long double, long double, int *);


  extern double copysign (double, double);
  extern float copysignf (float, float);
  extern long double copysignl (long double, long double);


  extern double nan(const char *tagp);
  extern float nanf(const char *tagp);
  extern long double nanl(const char *tagp);
# 788 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
  extern double nextafter (double, double);
  extern float nextafterf (float, float);
  extern long double nextafterl (long double, long double);


  extern double nexttoward (double, long double);
  extern float nexttowardf (float, long double);
  extern long double nexttowardl (long double, long double);



  extern double fdim (double x, double y);
  extern float fdimf (float x, float y);
  extern long double fdiml (long double x, long double y);







  extern double fmax (double, double);
  extern float fmaxf (float, float);
  extern long double fmaxl (long double, long double);


  extern double fmin (double, double);
  extern float fminf (float, float);
  extern long double fminl (long double, long double);



  extern double fma (double, double, double);
  extern float fmaf (float, float, float);
  extern long double fmal (long double, long double, long double);
# 871 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
   __attribute__ ((__dllimport__)) float _copysignf (float _Number,float _Sign);
   __attribute__ ((__dllimport__)) float _chgsignf (float _X);
   __attribute__ ((__dllimport__)) float _logbf(float _X);
   __attribute__ ((__dllimport__)) float _nextafterf(float _X,float _Y);
   __attribute__ ((__dllimport__)) int _finitef(float _X);
   __attribute__ ((__dllimport__)) int _isnanf(float _X);
   __attribute__ ((__dllimport__)) int _fpclassf(float _X);



   extern long double _chgsignl (long double);
# 898 "C:/Xilinx/Vivado/2019.2/win64/tools/clang/bin/../lib/clang/3.1/../../../x86_64-w64-mingw32/include\\math.h" 3
#pragma pack(pop)
# 2 "backprop/v5.c" 2

void soft_max(
  double v0[3],
  double v1[3]
) {_ssdm_SpecArrayDimSize(v0, 3);_ssdm_SpecArrayDimSize(v1, 3);



  double v2[1];
  v2[0] = 0.000000;
  double v3[1];
  v3[0] = 0.000000;
  for (int v4 = 0; v4 < 3; v4 += 1) {
#pragma HLS pipeline
 double v5 = v2[0];
    double v6 = v1[v4];
    double v7 = -(v6);
    double v8 = exp(v7);
    double v9 = v5 + v8;
    v2[0] = v9;
    v3[0] = v9;
  }
  double v10 = v3[0];
  for (int v11 = 0; v11 < 3; v11 += 1) {
#pragma HLS pipeline
 double v12 = v1[v11];
    double v13 = -(v12);
    double v14 = exp(v13);
    double v15 = v14 / v10;
    v0[v11] = v15;
  }
}

void RELU(double activations[64], double dactivations[64], int size) {_ssdm_SpecArrayDimSize(activations, 64);_ssdm_SpecArrayDimSize(dactivations, 64);
    int i;
    Loop2: for( i = 0; i < size; i++) {
        dactivations[i] = activations[i]*(1.0-activations[i]);
        activations[i] = 1.0/(1.0+exp(-activations[i]));
    }
}

void add_bias_to_activations(double biases[64],
                               double activations[64],
                               int size) {_ssdm_SpecArrayDimSize(biases, 64);_ssdm_SpecArrayDimSize(activations, 64);
    int i;
    Loop3: for( i = 0; i < size; i++){
        activations[i] = activations[i] + biases[i];
    }
}

void matrix_vector_product_with_bias_input_layer(
  double v0[64],
  double v1[832],
  double v2[64],
  double v3[13]
) {_ssdm_SpecArrayDimSize(v0, 64);_ssdm_SpecArrayDimSize(v1, 832);_ssdm_SpecArrayDimSize(v2, 64);_ssdm_SpecArrayDimSize(v3, 13);





  for (int v5 = 0; v5 < 8; v5 += 1) {
#pragma HLS pipeline
 for (int v6 = 0; v6 < 13; v6 += 1) {
      for (int v7 = 0; v7 < 8; v7 += 1) {
        int v8 = (v7 + (v5 * 8));
        v2[v8] = 0.000000;
        double v9 = v1[(v6 + (v8 * 13))];
        double v10 = v3[v6];
        double v11 = v9 * v10;
        double v12 = v2[v8];
        double v13 = v12 + v11;
        v2[v8] = v13;
      }
    }
  }
  add_bias_to_activations(v0, v2, 64);
}

void matrix_vector_product_with_bias_second_layer(
  double v0[64],
  double v1[4096],
  double v2[64],
  double v3[64]
) {_ssdm_SpecArrayDimSize(v0, 64);_ssdm_SpecArrayDimSize(v1, 4096);_ssdm_SpecArrayDimSize(v2, 64);_ssdm_SpecArrayDimSize(v3, 64);





  for (int v5 = 0; v5 < 8; v5 += 1) {
    for (int v6 = 0; v6 < 64; v6 += 1) {
#pragma HLS pipeline
 for (int v7 = 0; v7 < 8; v7 += 1) {
        int v8 = (v7 + (v5 * 8));
        v2[v6] = 0.000000;
        double v9 = v1[(v8 + (v6 * 64))];
        double v10 = v3[v8];
        double v11 = v9 * v10;
        double v12 = v2[v6];
        double v13 = v12 + v11;
        v2[v6] = v13;
      }
    }
  }
  add_bias_to_activations(v0, v2, 64);
}

void matrix_vector_product_with_bias_output_layer(
  double v0[3],
  double v1[192],
  double v2[3],
  double v3[64]
) {_ssdm_SpecArrayDimSize(v0, 3);_ssdm_SpecArrayDimSize(v1, 192);_ssdm_SpecArrayDimSize(v2, 3);_ssdm_SpecArrayDimSize(v3, 64);





  for (int v5 = 0; v5 < 2; v5 += 1) {
#pragma HLS pipeline
 for (int v6 = 0; v6 < 32; v6 += 1) {
      int v7 = (v6 + (v5 * 32));
      for (int v8 = 0; v8 < 3; v8 += 1) {
        v2[v8] = 0.000000;
        double v9 = v1[(v7 + (v8 * 64))];
        double v10 = v3[v7];
        double v11 = v9 * v10;
        double v12 = v2[v8];
        double v13 = v12 + v11;
        v2[v8] = v13;
      }
    }
  }
  add_bias_to_activations(v0, v2, 3);
}

void take_difference(
  double v0[3],
  double v1[3],
  double v2[3],
  double v3[3]
) {_ssdm_SpecArrayDimSize(v0, 3);_ssdm_SpecArrayDimSize(v1, 3);_ssdm_SpecArrayDimSize(v2, 3);_ssdm_SpecArrayDimSize(v3, 3);





  for (int v4 = 0; v4 < 3; v4 += 1) {
#pragma HLS pipeline
 double v5 = v0[v4];
    double v6 = v1[v4];
    double v7 = v5 - v6;
    double v8 = v7 * -1.000000;
    double v9 = v3[v4];
    double v10 = v8 * v9;
    v2[v4] = v10;
  }
}

void get_delta_matrix_weights3(
  double v0[192],
  double v1[3],
  double v2[64]
) {_ssdm_SpecArrayDimSize(v0, 192);_ssdm_SpecArrayDimSize(v1, 3);_ssdm_SpecArrayDimSize(v2, 64);




  for (int v3 = 0; v3 < 8; v3 += 1) {
#pragma HLS pipeline
 for (int v4 = 0; v4 < 8; v4 += 1) {
      int v5 = (v4 + (v3 * 8));
      for (int v6 = 0; v6 < 3; v6 += 1) {
        double v7 = v2[v5];
        double v8 = v1[v6];
        double v9 = v7 * v8;
        v0[(v6 + (v5 * 3))] = v9;
      }
    }
  }
}

void get_oracle_activations2(
  double v0[192],
  double v1[3],
  double v2[64],
  double v3[64]
) {_ssdm_SpecArrayDimSize(v0, 192);_ssdm_SpecArrayDimSize(v1, 3);_ssdm_SpecArrayDimSize(v2, 64);_ssdm_SpecArrayDimSize(v3, 64);





  for (int v4 = 0; v4 < 2; v4 += 1) {
#pragma HLS pipeline
 for (int v5 = 0; v5 < 3; v5 += 1) {
      for (int v6 = 0; v6 < 32; v6 += 1) {
        int v7 = (v6 + (v4 * 32));
        v2[v7] = 0.000000;
        double v8 = v1[v5];
        double v9 = v0[(v5 + (v7 * 3))];
        double v10 = v8 * v9;
        double v11 = v2[v7];
        double v12 = v11 + v10;
        v2[v7] = v12;
        double v13 = v2[v7];
        double v14 = v3[v7];
        double v15 = v13 * v14;
        v2[v7] = v15;
      }
    }
  }
}

void get_delta_matrix_weights2(
  double v0[4096],
  double v1[64],
  double v2[64]
) {_ssdm_SpecArrayDimSize(v0, 4096);_ssdm_SpecArrayDimSize(v1, 64);_ssdm_SpecArrayDimSize(v2, 64);




  for (int v3 = 0; v3 < 32; v3 += 1) {
#pragma HLS pipeline
 for (int v4 = 0; v4 < 2; v4 += 1) {
      int v5 = (v4 + (v3 * 2));
      for (int v6 = 0; v6 < 64; v6 += 1) {
        double v7 = v2[v5];
        double v8 = v1[v6];
        double v9 = v7 * v8;
        v0[(v6 + (v5 * 64))] = v9;
      }
    }
  }
}

void get_oracle_activations1(
  double v0[4096],
  double v1[64],
  double v2[64],
  double v3[64]
) {_ssdm_SpecArrayDimSize(v0, 4096);_ssdm_SpecArrayDimSize(v1, 64);_ssdm_SpecArrayDimSize(v2, 64);_ssdm_SpecArrayDimSize(v3, 64);





  for (int v4 = 0; v4 < 2; v4 += 1) {
    for (int v5 = 0; v5 < 64; v5 += 1) {
#pragma HLS pipeline
 for (int v6 = 0; v6 < 32; v6 += 1) {
        int v7 = (v6 + (v4 * 32));
        v2[v5] = 0.000000;
        double v8 = v1[v7];
        double v9 = v0[(v7 + (v5 * 64))];
        double v10 = v8 * v9;
        double v11 = v2[v5];
        double v12 = v11 + v10;
        v2[v5] = v12;
        double v13 = v2[v5];
        double v14 = v3[v5];
        double v15 = v13 * v14;
        v2[v5] = v15;
      }
    }
  }
}

void get_delta_matrix_weights1(
  double v0[832],
  double v1[64],
  double v2[13]
) {_ssdm_SpecArrayDimSize(v0, 832);_ssdm_SpecArrayDimSize(v1, 64);_ssdm_SpecArrayDimSize(v2, 13);




  for (int v3 = 0; v3 < 13; v3 += 1) {
#pragma HLS pipeline
 for (int v4 = 0; v4 < 64; v4 += 1) {
      double v5 = v2[v3];
      double v6 = v1[v4];
      double v7 = v5 * v6;
      v0[(v4 + (v3 * 64))] = v7;
    }
  }
}

void update_weights(
  double v0[832],
  double v1[4096],
  double v2[192],
  double v3[832],
  double v4[4096],
  double v5[192],
  double v6[64],
  double v7[64],
  double v8[3],
  double v9[64],
  double v10[64],
  double v11[3]
) {_ssdm_SpecArrayDimSize(v0, 832);_ssdm_SpecArrayDimSize(v1, 4096);_ssdm_SpecArrayDimSize(v2, 192);_ssdm_SpecArrayDimSize(v3, 832);_ssdm_SpecArrayDimSize(v4, 4096);_ssdm_SpecArrayDimSize(v5, 192);_ssdm_SpecArrayDimSize(v6, 64);_ssdm_SpecArrayDimSize(v7, 64);_ssdm_SpecArrayDimSize(v8, 3);_ssdm_SpecArrayDimSize(v9, 64);_ssdm_SpecArrayDimSize(v10, 64);_ssdm_SpecArrayDimSize(v11, 3);
# 319 "backprop/v5.c"
  double v12[1];
  v12[0] = 0.000000;
  double v13[1];
  v13[0] = 0.000000;
  double v14[1];
  double v15[1];
  for (int v16 = 0; v16 < 13; v16 += 1) {
#pragma HLS pipeline
 for (int v17 = 0; v17 < 64; v17 += 1) {
      double v18 = v12[0];
      v14[0] = v18;
      v15[0] = v18;
      double v19 = v14[0];
      double v20 = v3[(v17 + (v16 * 64))];
      double v21 = v20 * 0.010000;
      double v22 = v0[(v17 + (v16 * 64))];
      double v23 = v22 - v21;
      v0[(v17 + (v16 * 64))] = v23;
      double v24 = v23 * v23;
      double v25 = v19 + v24;
      v14[0] = v25;
      v15[0] = v25;
      double v26 = v15[0];
      v12[0] = v26;
      v13[0] = v26;
    }
  }
  double v27 = v13[0];
  double v28[1];
  v28[0] = 0.000000;
  double v29[1];
  v29[0] = 0.000000;
  for (int v30 = 0; v30 < 8; v30 += 1) {
#pragma HLS pipeline
 for (int v31 = 0; v31 < 8; v31 += 1) {
      int v32 = (v31 + (v30 * 8));
      double v33 = v28[0];
      double v34 = v9[v32];
      double v35 = v34 * 0.010000;
      double v36 = v6[v32];
      double v37 = v36 - v35;
      v6[v32] = v37;
      double v38 = v37 * v37;
      double v39 = v33 + v38;
      v28[0] = v39;
      v29[0] = v39;
    }
  }
  double v40 = v29[0];
  double v41 = sqrt(v27);
  double v42 = sqrt(v40);
  for (int v43 = 0; v43 < 13; v43 += 1) {
#pragma HLS pipeline
 for (int v44 = 0; v44 < 64; v44 += 1) {
      double v45 = v0[(v44 + (v43 * 64))];
      double v46 = v45 / v41;
      v0[(v44 + (v43 * 64))] = v46;
    }
  }
  for (int v47 = 0; v47 < 2; v47 += 1) {
#pragma HLS pipeline
 for (int v48 = 0; v48 < 32; v48 += 1) {
      int v49 = (v48 + (v47 * 32));
      double v50 = v6[v49];
      double v51 = v50 / v42;
      v6[v49] = v51;
    }
  }
  double v52[1];
  v52[0] = 0.000000;
  double v53[1];
  v53[0] = 0.000000;
  double v54[1];
  double v55[1];
  for (int v56 = 0; v56 < 64; v56 += 1) {
#pragma HLS pipeline
 for (int v57 = 0; v57 < 64; v57 += 1) {
      double v58 = v52[0];
      v54[0] = v58;
      v55[0] = v58;
      double v59 = v54[0];
      double v60 = v4[(v57 + (v56 * 64))];
      double v61 = v60 * 0.010000;
      double v62 = v1[(v57 + (v56 * 64))];
      double v63 = v62 - v61;
      v1[(v57 + (v56 * 64))] = v63;
      double v64 = v63 * v63;
      double v65 = v59 + v64;
      v54[0] = v65;
      v55[0] = v65;
      double v66 = v55[0];
      v52[0] = v66;
      v53[0] = v66;
    }
  }
  double v67 = v53[0];
  double v68[1];
  v68[0] = 0.000000;
  double v69[1];
  v69[0] = 0.000000;
  for (int v70 = 0; v70 < 8; v70 += 1) {
#pragma HLS pipeline
 for (int v71 = 0; v71 < 8; v71 += 1) {
      int v72 = (v71 + (v70 * 8));
      double v73 = v68[0];
      double v74 = v10[v72];
      double v75 = v74 * 0.010000;
      double v76 = v7[v72];
      double v77 = v76 - v75;
      v7[v72] = v77;
      double v78 = v77 * v77;
      double v79 = v73 + v78;
      v68[0] = v79;
      v69[0] = v79;
    }
  }
  double v80 = v69[0];
  double v81 = sqrt(v67);
  double v82 = sqrt(v80);
  for (int v83 = 0; v83 < 32; v83 += 1) {
#pragma HLS pipeline
 for (int v84 = 0; v84 < 2; v84 += 1) {
      int v85 = (v84 + (v83 * 2));
      for (int v86 = 0; v86 < 64; v86 += 1) {
        double v87 = v1[(v86 + (v85 * 64))];
        double v88 = v87 / v81;
        v1[(v86 + (v85 * 64))] = v88;
      }
    }
  }
  for (int v89 = 0; v89 < 2; v89 += 1) {
#pragma HLS pipeline
 for (int v90 = 0; v90 < 32; v90 += 1) {
      int v91 = (v90 + (v89 * 32));
      double v92 = v7[v91];
      double v93 = v92 / v82;
      v7[v91] = v93;
    }
  }
  double v94[1];
  v94[0] = 0.000000;
  double v95[1];
  v95[0] = 0.000000;
  double v96[1];
  double v97[1];
  for (int v98 = 0; v98 < 16; v98 += 1) {
#pragma HLS pipeline
 for (int v99 = 0; v99 < 4; v99 += 1) {
      int v100 = (v99 + (v98 * 4));
      for (int v101 = 0; v101 < 3; v101 += 1) {
        double v102 = v94[0];
        v96[0] = v102;
        v97[0] = v102;
        double v103 = v96[0];
        double v104 = v5[(v101 + (v100 * 3))];
        double v105 = v104 * 0.010000;
        double v106 = v2[(v101 + (v100 * 3))];
        double v107 = v106 - v105;
        v2[(v101 + (v100 * 3))] = v107;
        double v108 = v107 * v107;
        double v109 = v103 + v108;
        v96[0] = v109;
        v97[0] = v109;
        double v110 = v97[0];
        v94[0] = v110;
        v95[0] = v110;
      }
    }
  }
  double v111 = v95[0];
  double v112[1];
  v112[0] = 0.000000;
  double v113[1];
  v113[0] = 0.000000;
  for (int v114 = 0; v114 < 3; v114 += 1) {
#pragma HLS pipeline
 double v115 = v112[0];
    double v116 = v11[v114];
    double v117 = v116 * 0.010000;
    double v118 = v8[v114];
    double v119 = v118 - v117;
    v8[v114] = v119;
    double v120 = v119 * v119;
    double v121 = v115 + v120;
    v112[0] = v121;
    v113[0] = v121;
  }
  double v122 = v113[0];
  double v123 = sqrt(v111);
  double v124 = sqrt(v122);
  for (int v125 = 0; v125 < 2; v125 += 1) {
#pragma HLS pipeline
 for (int v126 = 0; v126 < 32; v126 += 1) {
      int v127 = (v126 + (v125 * 32));
      for (int v128 = 0; v128 < 3; v128 += 1) {
        double v129 = v2[(v128 + (v127 * 3))];
        double v130 = v129 / v123;
        v2[(v128 + (v127 * 3))] = v130;
      }
    }
  }
  for (int v131 = 0; v131 < 3; v131 += 1) {
#pragma HLS pipeline
 double v132 = v8[v131];
    double v133 = v132 / v124;
    v8[v131] = v133;
  }
}

void backprop(double weights1[13*64],
                double weights2[64*64],
                double weights3[64*3],
                double biases1[64],
                double biases2[64],
                double biases3[3],
                double training_data[163*13],
                double training_targets[163*3]) {_ssdm_SpecArrayDimSize(weights1, 832);_ssdm_SpecArrayDimSize(weights2, 4096);_ssdm_SpecArrayDimSize(weights3, 192);_ssdm_SpecArrayDimSize(biases1, 64);_ssdm_SpecArrayDimSize(biases2, 64);_ssdm_SpecArrayDimSize(biases3, 3);_ssdm_SpecArrayDimSize(training_data, 2119);_ssdm_SpecArrayDimSize(training_targets, 489);

#pragma HLS ARRAY_PARTITION variable=&weights1 cyclic factor=16 dim=1


#pragma HLS ARRAY_PARTITION variable=&weights2 cyclic factor=16 dim=1

#pragma HLS ARRAY_PARTITION variable=&weights3 cyclic factor=16 dim=1

 int i,j;

    double activations1[64];
    double activations2[64];
    double activations3[3];
    double dactivations1[64];
    double dactivations2[64];
    double dactivations3[3];
    double net_outputs[3];

    double output_difference[3];
    double delta_weights1[13*64];
    double delta_weights2[64*64];
    double delta_weights3[64*3];
    double oracle_activations1[64];
    double oracle_activations2[64];

#pragma HLS ARRAY_PARTITION variable=&activations1 cyclic factor=4 dim=1

#pragma HLS ARRAY_PARTITION variable=&activations2 cyclic factor=4 dim=1

#pragma HLS ARRAY_PARTITION variable=&delta_weights3 cyclic factor=4 dim=1


#pragma HLS ARRAY_PARTITION variable=&oracle_activations2 cyclic factor=4 dim=1
#pragma HLS ARRAY_PARTITION variable=&dactivations2 cyclic factor=4 dim=1

#pragma HLS ARRAY_PARTITION variable=&delta_weights2 cyclic factor=4 dim=1

#pragma HLS ARRAY_PARTITION variable=&oracle_activations1 cyclic factor=4 dim=1


#pragma HLS ARRAY_PARTITION variable=&delta_weights1 cyclic factor=4 dim=1

#pragma HLS ARRAY_PARTITION variable=&biases1 cyclic factor=4 dim=1
#pragma HLS ARRAY_PARTITION variable=&biases2 cyclic factor=4 dim=1

 Loop39: for(i=0; i<163; i++){
        Loop40: for(j=0;j<64;j++){
            activations1[j] = (double)0.0;
            activations2[j] = (double)0.0;
            if(j<3){
                activations3[j] = (double)0.0;
            }
        }
        matrix_vector_product_with_bias_input_layer(biases1, weights1, activations1, &training_data[i*13]);
        RELU(activations1, dactivations1, 64);
        matrix_vector_product_with_bias_second_layer(biases2, weights2, activations2, activations1);
        RELU(activations2, dactivations2, 64);
        matrix_vector_product_with_bias_output_layer(biases3, weights3, activations3, activations2);
        RELU(activations3, dactivations3, 3);
        soft_max(net_outputs, activations3);
        take_difference(net_outputs, &training_targets[i*3], output_difference, dactivations3);
        get_delta_matrix_weights3(delta_weights3, output_difference, activations2);
        get_oracle_activations2(weights3, output_difference, oracle_activations2, dactivations2);
        get_delta_matrix_weights2(delta_weights2, oracle_activations2, activations1);
        get_oracle_activations1(weights2, oracle_activations2, oracle_activations1, dactivations1);
        get_delta_matrix_weights1(delta_weights1, oracle_activations1, &training_data[i*13]);
        update_weights(weights1, weights2, weights3, delta_weights1, delta_weights2, delta_weights3,
                       biases1, biases2, biases3, oracle_activations1, oracle_activations2, output_difference);
    }
}

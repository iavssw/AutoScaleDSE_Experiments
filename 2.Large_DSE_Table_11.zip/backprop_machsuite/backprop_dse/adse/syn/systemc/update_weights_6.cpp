#include "update_weights.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void update_weights::thread_zext_ln514_68_fu_15796_p1() {
    zext_ln514_68_fu_15796_p1 = esl_zext<64,28>(sext_ln514_68_fu_15792_p1.read());
}

void update_weights::thread_zext_ln514_69_fu_15842_p1() {
    zext_ln514_69_fu_15842_p1 = esl_zext<64,28>(sext_ln514_69_fu_15838_p1.read());
}

void update_weights::thread_zext_ln514_6_fu_13656_p1() {
    zext_ln514_6_fu_13656_p1 = esl_zext<64,28>(sext_ln514_6_fu_13652_p1.read());
}

void update_weights::thread_zext_ln514_70_fu_15867_p1() {
    zext_ln514_70_fu_15867_p1 = esl_zext<64,28>(sext_ln514_70_fu_15863_p1.read());
}

void update_weights::thread_zext_ln514_71_fu_15892_p1() {
    zext_ln514_71_fu_15892_p1 = esl_zext<64,28>(sext_ln514_71_fu_15888_p1.read());
}

void update_weights::thread_zext_ln514_72_fu_13413_p1() {
    zext_ln514_72_fu_13413_p1 = esl_zext<9,8>(shl_ln11_fu_13405_p3.read());
}

void update_weights::thread_zext_ln514_73_fu_13462_p1() {
    zext_ln514_73_fu_13462_p1 = esl_zext<9,8>(shl_ln514_1_fu_13454_p3.read());
}

void update_weights::thread_zext_ln514_74_fu_13559_p1() {
    zext_ln514_74_fu_13559_p1 = esl_zext<9,8>(shl_ln514_2_fu_13551_p3.read());
}

void update_weights::thread_zext_ln514_75_fu_13632_p1() {
    zext_ln514_75_fu_13632_p1 = esl_zext<9,8>(shl_ln514_3_fu_13624_p3.read());
}

void update_weights::thread_zext_ln514_76_fu_13729_p1() {
    zext_ln514_76_fu_13729_p1 = esl_zext<9,8>(shl_ln514_4_fu_13721_p3.read());
}

void update_weights::thread_zext_ln514_77_fu_13778_p1() {
    zext_ln514_77_fu_13778_p1 = esl_zext<9,8>(shl_ln514_5_fu_13770_p3.read());
}

void update_weights::thread_zext_ln514_78_fu_13874_p1() {
    zext_ln514_78_fu_13874_p1 = esl_zext<9,8>(shl_ln514_6_fu_13866_p3.read());
}

void update_weights::thread_zext_ln514_79_fu_13946_p1() {
    zext_ln514_79_fu_13946_p1 = esl_zext<9,8>(shl_ln514_7_fu_13938_p3.read());
}

void update_weights::thread_zext_ln514_7_fu_13681_p1() {
    zext_ln514_7_fu_13681_p1 = esl_zext<64,28>(sext_ln514_7_fu_13677_p1.read());
}

void update_weights::thread_zext_ln514_80_fu_14042_p1() {
    zext_ln514_80_fu_14042_p1 = esl_zext<9,8>(shl_ln514_8_fu_14034_p3.read());
}

void update_weights::thread_zext_ln514_81_fu_14090_p1() {
    zext_ln514_81_fu_14090_p1 = esl_zext<9,8>(shl_ln514_9_fu_14082_p3.read());
}

void update_weights::thread_zext_ln514_82_fu_14186_p1() {
    zext_ln514_82_fu_14186_p1 = esl_zext<9,8>(shl_ln514_s_fu_14178_p3.read());
}

void update_weights::thread_zext_ln514_83_fu_14258_p1() {
    zext_ln514_83_fu_14258_p1 = esl_zext<9,8>(shl_ln514_10_fu_14250_p3.read());
}

void update_weights::thread_zext_ln514_84_fu_14354_p1() {
    zext_ln514_84_fu_14354_p1 = esl_zext<9,8>(shl_ln514_11_fu_14346_p3.read());
}

void update_weights::thread_zext_ln514_85_fu_14402_p1() {
    zext_ln514_85_fu_14402_p1 = esl_zext<9,8>(shl_ln514_12_fu_14394_p3.read());
}

void update_weights::thread_zext_ln514_86_fu_14498_p1() {
    zext_ln514_86_fu_14498_p1 = esl_zext<9,8>(shl_ln514_13_fu_14490_p3.read());
}

void update_weights::thread_zext_ln514_87_fu_14570_p1() {
    zext_ln514_87_fu_14570_p1 = esl_zext<9,8>(shl_ln514_14_fu_14562_p3.read());
}

void update_weights::thread_zext_ln514_88_fu_14666_p1() {
    zext_ln514_88_fu_14666_p1 = esl_zext<9,8>(shl_ln514_15_fu_14658_p3.read());
}

void update_weights::thread_zext_ln514_89_fu_14714_p1() {
    zext_ln514_89_fu_14714_p1 = esl_zext<9,8>(shl_ln514_16_fu_14706_p3.read());
}

void update_weights::thread_zext_ln514_8_fu_13706_p1() {
    zext_ln514_8_fu_13706_p1 = esl_zext<64,28>(sext_ln514_8_fu_13702_p1.read());
}

void update_weights::thread_zext_ln514_90_fu_14810_p1() {
    zext_ln514_90_fu_14810_p1 = esl_zext<9,8>(shl_ln514_17_fu_14802_p3.read());
}

void update_weights::thread_zext_ln514_91_fu_14882_p1() {
    zext_ln514_91_fu_14882_p1 = esl_zext<9,8>(shl_ln514_18_fu_14874_p3.read());
}

void update_weights::thread_zext_ln514_92_fu_14978_p1() {
    zext_ln514_92_fu_14978_p1 = esl_zext<9,8>(shl_ln514_19_fu_14970_p3.read());
}

void update_weights::thread_zext_ln514_93_fu_15026_p1() {
    zext_ln514_93_fu_15026_p1 = esl_zext<9,8>(shl_ln514_20_fu_15018_p3.read());
}

void update_weights::thread_zext_ln514_94_fu_15122_p1() {
    zext_ln514_94_fu_15122_p1 = esl_zext<9,8>(shl_ln514_21_fu_15114_p3.read());
}

void update_weights::thread_zext_ln514_95_fu_15194_p1() {
    zext_ln514_95_fu_15194_p1 = esl_zext<9,8>(shl_ln514_22_fu_15186_p3.read());
}

void update_weights::thread_zext_ln514_96_fu_15290_p1() {
    zext_ln514_96_fu_15290_p1 = esl_zext<9,8>(shl_ln514_23_fu_15282_p3.read());
}

void update_weights::thread_zext_ln514_97_fu_15338_p1() {
    zext_ln514_97_fu_15338_p1 = esl_zext<9,8>(shl_ln514_24_fu_15330_p3.read());
}

void update_weights::thread_zext_ln514_98_fu_15434_p1() {
    zext_ln514_98_fu_15434_p1 = esl_zext<9,8>(shl_ln514_25_fu_15426_p3.read());
}

void update_weights::thread_zext_ln514_99_fu_15506_p1() {
    zext_ln514_99_fu_15506_p1 = esl_zext<9,8>(shl_ln514_26_fu_15498_p3.read());
}

void update_weights::thread_zext_ln514_9_fu_13753_p1() {
    zext_ln514_9_fu_13753_p1 = esl_zext<64,28>(sext_ln514_9_fu_13749_p1.read());
}

void update_weights::thread_zext_ln514_fu_13437_p1() {
    zext_ln514_fu_13437_p1 = esl_zext<64,28>(sext_ln514_fu_13433_p1.read());
}

void update_weights::thread_zext_ln522_fu_15909_p1() {
    zext_ln522_fu_15909_p1 = esl_zext<64,2>(v131_0_reg_7149.read());
}

}


#include "update_weights.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void update_weights::thread_shl_ln441_fu_12440_p2() {
    shl_ln441_fu_12440_p2 = (!ap_const_lv6_1.is_01())? sc_lv<6>(): ap_phi_mux_v83_0_phi_fu_6906_p4.read() << (unsigned short)ap_const_lv6_1.to_uint();
}

void update_weights::thread_shl_ln443_1_fu_12555_p3() {
    shl_ln443_1_fu_12555_p3 = esl_concat<6,2>(or_ln443_3_fu_12550_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln473_1_fu_12906_p3() {
    shl_ln473_1_fu_12906_p3 = esl_concat<6,2>(or_ln467_fu_12896_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln473_2_fu_13049_p3() {
    shl_ln473_2_fu_13049_p3 = esl_concat<6,2>(or_ln467_1_fu_13039_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln473_3_fu_13144_p3() {
    shl_ln473_3_fu_13144_p3 = esl_concat<6,2>(or_ln467_2_fu_13135_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln4_fu_10555_p3() {
    shl_ln4_fu_10555_p3 = esl_concat<1,3>(trunc_ln382_fu_10551_p1.read(), ap_const_lv3_0);
}

void update_weights::thread_shl_ln514_10_fu_14250_p3() {
    shl_ln514_10_fu_14250_p3 = esl_concat<6,2>(or_ln512_10_fu_14241_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_11_fu_14346_p3() {
    shl_ln514_11_fu_14346_p3 = esl_concat<6,2>(or_ln512_11_fu_14337_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_12_fu_14394_p3() {
    shl_ln514_12_fu_14394_p3 = esl_concat<6,2>(or_ln512_12_fu_14385_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_13_fu_14490_p3() {
    shl_ln514_13_fu_14490_p3 = esl_concat<6,2>(or_ln512_13_fu_14481_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_14_fu_14562_p3() {
    shl_ln514_14_fu_14562_p3 = esl_concat<6,2>(or_ln512_14_fu_14553_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_15_fu_14658_p3() {
    shl_ln514_15_fu_14658_p3 = esl_concat<6,2>(or_ln512_15_fu_14649_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_16_fu_14706_p3() {
    shl_ln514_16_fu_14706_p3 = esl_concat<6,2>(or_ln512_16_fu_14697_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_17_fu_14802_p3() {
    shl_ln514_17_fu_14802_p3 = esl_concat<6,2>(or_ln512_17_fu_14793_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_18_fu_14874_p3() {
    shl_ln514_18_fu_14874_p3 = esl_concat<6,2>(or_ln512_18_fu_14865_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_19_fu_14970_p3() {
    shl_ln514_19_fu_14970_p3 = esl_concat<6,2>(or_ln512_19_fu_14961_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_1_fu_13454_p3() {
    shl_ln514_1_fu_13454_p3 = esl_concat<6,2>(or_ln512_fu_13444_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_20_fu_15018_p3() {
    shl_ln514_20_fu_15018_p3 = esl_concat<6,2>(or_ln512_20_fu_15009_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_21_fu_15114_p3() {
    shl_ln514_21_fu_15114_p3 = esl_concat<6,2>(or_ln512_21_fu_15105_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_22_fu_15186_p3() {
    shl_ln514_22_fu_15186_p3 = esl_concat<6,2>(or_ln512_22_fu_15177_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_23_fu_15282_p3() {
    shl_ln514_23_fu_15282_p3 = esl_concat<6,2>(or_ln512_23_fu_15273_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_24_fu_15330_p3() {
    shl_ln514_24_fu_15330_p3 = esl_concat<6,2>(or_ln512_24_fu_15321_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_25_fu_15426_p3() {
    shl_ln514_25_fu_15426_p3 = esl_concat<6,2>(or_ln512_25_fu_15417_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_26_fu_15498_p3() {
    shl_ln514_26_fu_15498_p3 = esl_concat<6,2>(or_ln512_26_fu_15489_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_27_fu_15594_p3() {
    shl_ln514_27_fu_15594_p3 = esl_concat<6,2>(or_ln512_27_fu_15585_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_28_fu_15642_p3() {
    shl_ln514_28_fu_15642_p3 = esl_concat<6,2>(or_ln512_28_fu_15633_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_29_fu_15738_p3() {
    shl_ln514_29_fu_15738_p3 = esl_concat<6,2>(or_ln512_29_fu_15729_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_2_fu_13551_p3() {
    shl_ln514_2_fu_13551_p3 = esl_concat<6,2>(or_ln512_1_fu_13541_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_30_fu_15810_p3() {
    shl_ln514_30_fu_15810_p3 = esl_concat<6,2>(or_ln512_30_fu_15801_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_3_fu_13624_p3() {
    shl_ln514_3_fu_13624_p3 = esl_concat<6,2>(or_ln512_2_fu_13614_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_4_fu_13721_p3() {
    shl_ln514_4_fu_13721_p3 = esl_concat<6,2>(or_ln512_3_fu_13711_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_5_fu_13770_p3() {
    shl_ln514_5_fu_13770_p3 = esl_concat<6,2>(or_ln512_4_fu_13760_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_6_fu_13866_p3() {
    shl_ln514_6_fu_13866_p3 = esl_concat<6,2>(or_ln512_5_fu_13857_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_7_fu_13938_p3() {
    shl_ln514_7_fu_13938_p3 = esl_concat<6,2>(or_ln512_6_fu_13929_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_8_fu_14034_p3() {
    shl_ln514_8_fu_14034_p3 = esl_concat<6,2>(or_ln512_7_fu_14025_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_9_fu_14082_p3() {
    shl_ln514_9_fu_14082_p3 = esl_concat<6,2>(or_ln512_8_fu_14073_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln514_s_fu_14178_p3() {
    shl_ln514_s_fu_14178_p3 = esl_concat<6,2>(or_ln512_9_fu_14169_p2.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln5_fu_10734_p3() {
    shl_ln5_fu_10734_p3 = esl_concat<6,6>(trunc_ln400_reg_17933.read(), ap_const_lv6_0);
}

void update_weights::thread_shl_ln6_fu_10692_p3() {
    shl_ln6_fu_10692_p3 = esl_concat<6,2>(trunc_ln400_reg_17933.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln7_fu_12799_p3() {
    shl_ln7_fu_12799_p3 = esl_concat<4,2>(trunc_ln467_fu_12795_p1.read(), ap_const_lv2_0);
}

void update_weights::thread_shl_ln8_fu_12811_p3() {
    shl_ln8_fu_12811_p3 = esl_concat<4,4>(trunc_ln467_fu_12795_p1.read(), ap_const_lv4_0);
}

void update_weights::thread_shl_ln9_fu_12446_p3() {
    shl_ln9_fu_12446_p3 = esl_concat<5,3>(trunc_ln441_fu_12436_p1.read(), ap_const_lv3_0);
}

void update_weights::thread_shl_ln_fu_8696_p3() {
    shl_ln_fu_8696_p3 = esl_concat<4,6>(v16_0_reg_6799.read(), ap_const_lv6_0);
}

void update_weights::thread_sub_ln473_1_fu_12918_p2() {
    sub_ln473_1_fu_12918_p2 = (!zext_ln473_10_fu_12914_p1.read().is_01() || !zext_ln467_1_fu_12902_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln473_10_fu_12914_p1.read()) - sc_biguint<9>(zext_ln467_1_fu_12902_p1.read()));
}

void update_weights::thread_sub_ln473_2_fu_13061_p2() {
    sub_ln473_2_fu_13061_p2 = (!zext_ln473_11_fu_13057_p1.read().is_01() || !zext_ln467_2_fu_13045_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln473_11_fu_13057_p1.read()) - sc_biguint<9>(zext_ln467_2_fu_13045_p1.read()));
}

void update_weights::thread_sub_ln473_3_fu_13156_p2() {
    sub_ln473_3_fu_13156_p2 = (!zext_ln473_12_fu_13152_p1.read().is_01() || !zext_ln467_3_fu_13140_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln473_12_fu_13152_p1.read()) - sc_biguint<9>(zext_ln467_3_fu_13140_p1.read()));
}

void update_weights::thread_sub_ln473_fu_12823_p2() {
    sub_ln473_fu_12823_p2 = (!zext_ln473_9_fu_12819_p1.read().is_01() || !zext_ln467_fu_12807_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln473_9_fu_12819_p1.read()) - sc_biguint<9>(zext_ln467_fu_12807_p1.read()));
}

void update_weights::thread_sub_ln514_10_fu_14190_p2() {
    sub_ln514_10_fu_14190_p2 = (!zext_ln514_82_fu_14186_p1.read().is_01() || !zext_ln512_10_fu_14174_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_82_fu_14186_p1.read()) - sc_biguint<9>(zext_ln512_10_fu_14174_p1.read()));
}

void update_weights::thread_sub_ln514_11_fu_14262_p2() {
    sub_ln514_11_fu_14262_p2 = (!zext_ln514_83_fu_14258_p1.read().is_01() || !zext_ln512_11_fu_14246_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_83_fu_14258_p1.read()) - sc_biguint<9>(zext_ln512_11_fu_14246_p1.read()));
}

void update_weights::thread_sub_ln514_12_fu_14358_p2() {
    sub_ln514_12_fu_14358_p2 = (!zext_ln514_84_fu_14354_p1.read().is_01() || !zext_ln512_12_fu_14342_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_84_fu_14354_p1.read()) - sc_biguint<9>(zext_ln512_12_fu_14342_p1.read()));
}

void update_weights::thread_sub_ln514_13_fu_14406_p2() {
    sub_ln514_13_fu_14406_p2 = (!zext_ln514_85_fu_14402_p1.read().is_01() || !zext_ln512_13_fu_14390_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_85_fu_14402_p1.read()) - sc_biguint<9>(zext_ln512_13_fu_14390_p1.read()));
}

void update_weights::thread_sub_ln514_14_fu_14502_p2() {
    sub_ln514_14_fu_14502_p2 = (!zext_ln514_86_fu_14498_p1.read().is_01() || !zext_ln512_14_fu_14486_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_86_fu_14498_p1.read()) - sc_biguint<9>(zext_ln512_14_fu_14486_p1.read()));
}

void update_weights::thread_sub_ln514_15_fu_14574_p2() {
    sub_ln514_15_fu_14574_p2 = (!zext_ln514_87_fu_14570_p1.read().is_01() || !zext_ln512_15_fu_14558_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_87_fu_14570_p1.read()) - sc_biguint<9>(zext_ln512_15_fu_14558_p1.read()));
}

void update_weights::thread_sub_ln514_16_fu_14670_p2() {
    sub_ln514_16_fu_14670_p2 = (!zext_ln514_88_fu_14666_p1.read().is_01() || !zext_ln512_16_fu_14654_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_88_fu_14666_p1.read()) - sc_biguint<9>(zext_ln512_16_fu_14654_p1.read()));
}

void update_weights::thread_sub_ln514_17_fu_14718_p2() {
    sub_ln514_17_fu_14718_p2 = (!zext_ln514_89_fu_14714_p1.read().is_01() || !zext_ln512_17_fu_14702_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_89_fu_14714_p1.read()) - sc_biguint<9>(zext_ln512_17_fu_14702_p1.read()));
}

void update_weights::thread_sub_ln514_18_fu_14814_p2() {
    sub_ln514_18_fu_14814_p2 = (!zext_ln514_90_fu_14810_p1.read().is_01() || !zext_ln512_18_fu_14798_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_90_fu_14810_p1.read()) - sc_biguint<9>(zext_ln512_18_fu_14798_p1.read()));
}

void update_weights::thread_sub_ln514_19_fu_14886_p2() {
    sub_ln514_19_fu_14886_p2 = (!zext_ln514_91_fu_14882_p1.read().is_01() || !zext_ln512_19_fu_14870_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_91_fu_14882_p1.read()) - sc_biguint<9>(zext_ln512_19_fu_14870_p1.read()));
}

void update_weights::thread_sub_ln514_1_fu_13466_p2() {
    sub_ln514_1_fu_13466_p2 = (!zext_ln514_73_fu_13462_p1.read().is_01() || !zext_ln512_1_fu_13450_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_73_fu_13462_p1.read()) - sc_biguint<9>(zext_ln512_1_fu_13450_p1.read()));
}

void update_weights::thread_sub_ln514_20_fu_14982_p2() {
    sub_ln514_20_fu_14982_p2 = (!zext_ln514_92_fu_14978_p1.read().is_01() || !zext_ln512_20_fu_14966_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_92_fu_14978_p1.read()) - sc_biguint<9>(zext_ln512_20_fu_14966_p1.read()));
}

void update_weights::thread_sub_ln514_21_fu_15030_p2() {
    sub_ln514_21_fu_15030_p2 = (!zext_ln514_93_fu_15026_p1.read().is_01() || !zext_ln512_21_fu_15014_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_93_fu_15026_p1.read()) - sc_biguint<9>(zext_ln512_21_fu_15014_p1.read()));
}

void update_weights::thread_sub_ln514_22_fu_15126_p2() {
    sub_ln514_22_fu_15126_p2 = (!zext_ln514_94_fu_15122_p1.read().is_01() || !zext_ln512_22_fu_15110_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_94_fu_15122_p1.read()) - sc_biguint<9>(zext_ln512_22_fu_15110_p1.read()));
}

void update_weights::thread_sub_ln514_23_fu_15198_p2() {
    sub_ln514_23_fu_15198_p2 = (!zext_ln514_95_fu_15194_p1.read().is_01() || !zext_ln512_23_fu_15182_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_95_fu_15194_p1.read()) - sc_biguint<9>(zext_ln512_23_fu_15182_p1.read()));
}

void update_weights::thread_sub_ln514_24_fu_15294_p2() {
    sub_ln514_24_fu_15294_p2 = (!zext_ln514_96_fu_15290_p1.read().is_01() || !zext_ln512_24_fu_15278_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_96_fu_15290_p1.read()) - sc_biguint<9>(zext_ln512_24_fu_15278_p1.read()));
}

void update_weights::thread_sub_ln514_25_fu_15342_p2() {
    sub_ln514_25_fu_15342_p2 = (!zext_ln514_97_fu_15338_p1.read().is_01() || !zext_ln512_25_fu_15326_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_97_fu_15338_p1.read()) - sc_biguint<9>(zext_ln512_25_fu_15326_p1.read()));
}

void update_weights::thread_sub_ln514_26_fu_15438_p2() {
    sub_ln514_26_fu_15438_p2 = (!zext_ln514_98_fu_15434_p1.read().is_01() || !zext_ln512_26_fu_15422_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_98_fu_15434_p1.read()) - sc_biguint<9>(zext_ln512_26_fu_15422_p1.read()));
}

void update_weights::thread_sub_ln514_27_fu_15510_p2() {
    sub_ln514_27_fu_15510_p2 = (!zext_ln514_99_fu_15506_p1.read().is_01() || !zext_ln512_27_fu_15494_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_99_fu_15506_p1.read()) - sc_biguint<9>(zext_ln512_27_fu_15494_p1.read()));
}

void update_weights::thread_sub_ln514_28_fu_15606_p2() {
    sub_ln514_28_fu_15606_p2 = (!zext_ln514_100_fu_15602_p1.read().is_01() || !zext_ln512_28_fu_15590_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_100_fu_15602_p1.read()) - sc_biguint<9>(zext_ln512_28_fu_15590_p1.read()));
}

void update_weights::thread_sub_ln514_29_fu_15654_p2() {
    sub_ln514_29_fu_15654_p2 = (!zext_ln514_101_fu_15650_p1.read().is_01() || !zext_ln512_29_fu_15638_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_101_fu_15650_p1.read()) - sc_biguint<9>(zext_ln512_29_fu_15638_p1.read()));
}

void update_weights::thread_sub_ln514_2_fu_13563_p2() {
    sub_ln514_2_fu_13563_p2 = (!zext_ln514_74_fu_13559_p1.read().is_01() || !zext_ln512_2_fu_13547_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_74_fu_13559_p1.read()) - sc_biguint<9>(zext_ln512_2_fu_13547_p1.read()));
}

void update_weights::thread_sub_ln514_30_fu_15750_p2() {
    sub_ln514_30_fu_15750_p2 = (!zext_ln514_102_fu_15746_p1.read().is_01() || !zext_ln512_30_fu_15734_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_102_fu_15746_p1.read()) - sc_biguint<9>(zext_ln512_30_fu_15734_p1.read()));
}

void update_weights::thread_sub_ln514_31_fu_15822_p2() {
    sub_ln514_31_fu_15822_p2 = (!zext_ln514_103_fu_15818_p1.read().is_01() || !zext_ln512_31_fu_15806_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_103_fu_15818_p1.read()) - sc_biguint<9>(zext_ln512_31_fu_15806_p1.read()));
}

void update_weights::thread_sub_ln514_3_fu_13636_p2() {
    sub_ln514_3_fu_13636_p2 = (!zext_ln514_75_fu_13632_p1.read().is_01() || !zext_ln512_3_fu_13620_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_75_fu_13632_p1.read()) - sc_biguint<9>(zext_ln512_3_fu_13620_p1.read()));
}

void update_weights::thread_sub_ln514_4_fu_13733_p2() {
    sub_ln514_4_fu_13733_p2 = (!zext_ln514_76_fu_13729_p1.read().is_01() || !zext_ln512_4_fu_13717_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_76_fu_13729_p1.read()) - sc_biguint<9>(zext_ln512_4_fu_13717_p1.read()));
}

void update_weights::thread_sub_ln514_5_fu_13782_p2() {
    sub_ln514_5_fu_13782_p2 = (!zext_ln514_77_fu_13778_p1.read().is_01() || !zext_ln512_5_fu_13766_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_77_fu_13778_p1.read()) - sc_biguint<9>(zext_ln512_5_fu_13766_p1.read()));
}

void update_weights::thread_sub_ln514_6_fu_13878_p2() {
    sub_ln514_6_fu_13878_p2 = (!zext_ln514_78_fu_13874_p1.read().is_01() || !zext_ln512_6_fu_13862_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_78_fu_13874_p1.read()) - sc_biguint<9>(zext_ln512_6_fu_13862_p1.read()));
}

void update_weights::thread_sub_ln514_7_fu_13950_p2() {
    sub_ln514_7_fu_13950_p2 = (!zext_ln514_79_fu_13946_p1.read().is_01() || !zext_ln512_7_fu_13934_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_79_fu_13946_p1.read()) - sc_biguint<9>(zext_ln512_7_fu_13934_p1.read()));
}

void update_weights::thread_sub_ln514_8_fu_14046_p2() {
    sub_ln514_8_fu_14046_p2 = (!zext_ln514_80_fu_14042_p1.read().is_01() || !zext_ln512_8_fu_14030_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_80_fu_14042_p1.read()) - sc_biguint<9>(zext_ln512_8_fu_14030_p1.read()));
}

void update_weights::thread_sub_ln514_9_fu_14094_p2() {
    sub_ln514_9_fu_14094_p2 = (!zext_ln514_81_fu_14090_p1.read().is_01() || !zext_ln512_9_fu_14078_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_81_fu_14090_p1.read()) - sc_biguint<9>(zext_ln512_9_fu_14078_p1.read()));
}

void update_weights::thread_sub_ln514_fu_13417_p2() {
    sub_ln514_fu_13417_p2 = (!zext_ln514_72_fu_13413_p1.read().is_01() || !zext_ln512_fu_13401_p1.read().is_01())? sc_lv<9>(): (sc_biguint<9>(zext_ln514_72_fu_13413_p1.read()) - sc_biguint<9>(zext_ln512_fu_13401_p1.read()));
}

void update_weights::thread_trunc_ln2_fu_13423_p4() {
    trunc_ln2_fu_13423_p4 = sub_ln514_fu_13417_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln382_fu_10551_p1() {
    trunc_ln382_fu_10551_p1 = ap_phi_mux_v47_0_phi_fu_6849_p4.read().range(1-1, 0);
}

void update_weights::thread_trunc_ln400_fu_10675_p1() {
    trunc_ln400_fu_10675_p1 = v56_0_reg_6868.read().range(6-1, 0);
}

void update_weights::thread_trunc_ln441_fu_12436_p1() {
    trunc_ln441_fu_12436_p1 = ap_phi_mux_v83_0_phi_fu_6906_p4.read().range(5-1, 0);
}

void update_weights::thread_trunc_ln453_fu_12671_p1() {
    trunc_ln453_fu_12671_p1 = ap_phi_mux_v89_0_phi_fu_6917_p4.read().range(1-1, 0);
}

void update_weights::thread_trunc_ln467_fu_12795_p1() {
    trunc_ln467_fu_12795_p1 = ap_phi_mux_v98_0_phi_fu_6940_p4.read().range(4-1, 0);
}

void update_weights::thread_trunc_ln473_1_fu_12924_p4() {
    trunc_ln473_1_fu_12924_p4 = sub_ln473_1_fu_12918_p2.read().range(8, 2);
}

void update_weights::thread_trunc_ln473_2_fu_12975_p4() {
    trunc_ln473_2_fu_12975_p4 = add_ln473_fu_12969_p2.read().range(8, 2);
}

void update_weights::thread_trunc_ln473_3_fu_13010_p4() {
    trunc_ln473_3_fu_13010_p4 = add_ln473_1_fu_13004_p2.read().range(8, 2);
}

void update_weights::thread_trunc_ln473_4_fu_13067_p4() {
    trunc_ln473_4_fu_13067_p4 = sub_ln473_2_fu_13061_p2.read().range(8, 2);
}

void update_weights::thread_trunc_ln473_5_fu_13106_p4() {
    trunc_ln473_5_fu_13106_p4 = add_ln473_2_fu_13101_p2.read().range(8, 2);
}

void update_weights::thread_trunc_ln473_6_fu_13162_p4() {
    trunc_ln473_6_fu_13162_p4 = sub_ln473_3_fu_13156_p2.read().range(8, 2);
}

void update_weights::thread_trunc_ln473_7_fu_13201_p4() {
    trunc_ln473_7_fu_13201_p4 = add_ln473_3_fu_13195_p2.read().range(8, 2);
}

void update_weights::thread_trunc_ln473_8_fu_13236_p4() {
    trunc_ln473_8_fu_13236_p4 = add_ln473_4_fu_13230_p2.read().range(8, 2);
}

void update_weights::thread_trunc_ln475_1_fu_12943_p1() {
    trunc_ln475_1_fu_12943_p1 = sub_ln473_1_fu_12918_p2.read().range(4-1, 0);
}

void update_weights::thread_trunc_ln475_2_fu_13087_p1() {
    trunc_ln475_2_fu_13087_p1 = sub_ln473_2_fu_13061_p2.read().range(4-1, 0);
}

void update_weights::thread_trunc_ln475_3_fu_13181_p1() {
    trunc_ln475_3_fu_13181_p1 = sub_ln473_3_fu_13156_p2.read().range(4-1, 0);
}

void update_weights::thread_trunc_ln475_4_fu_12854_p4() {
    trunc_ln475_4_fu_12854_p4 = sub_ln473_fu_12823_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln475_5_fu_12947_p4() {
    trunc_ln475_5_fu_12947_p4 = sub_ln473_1_fu_12918_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln475_fu_12850_p1() {
    trunc_ln475_fu_12850_p1 = sub_ln473_fu_12823_p2.read().range(4-1, 0);
}

void update_weights::thread_trunc_ln512_fu_13389_p1() {
    trunc_ln512_fu_13389_p1 = v125_0_reg_7138.read().range(1-1, 0);
}

void update_weights::thread_trunc_ln514_10_fu_13813_p4() {
    trunc_ln514_10_fu_13813_p4 = add_ln514_5_fu_13807_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_11_fu_13838_p4() {
    trunc_ln514_11_fu_13838_p4 = add_ln514_6_fu_13832_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_12_fu_13884_p4() {
    trunc_ln514_12_fu_13884_p4 = sub_ln514_6_fu_13878_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_13_fu_13910_p4() {
    trunc_ln514_13_fu_13910_p4 = add_ln514_7_fu_13904_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_14_fu_13956_p4() {
    trunc_ln514_14_fu_13956_p4 = sub_ln514_7_fu_13950_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_15_fu_13981_p4() {
    trunc_ln514_15_fu_13981_p4 = add_ln514_8_fu_13975_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_16_fu_14006_p4() {
    trunc_ln514_16_fu_14006_p4 = add_ln514_9_fu_14000_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_17_fu_14052_p4() {
    trunc_ln514_17_fu_14052_p4 = sub_ln514_8_fu_14046_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_18_fu_14100_p4() {
    trunc_ln514_18_fu_14100_p4 = sub_ln514_9_fu_14094_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_19_fu_14125_p4() {
    trunc_ln514_19_fu_14125_p4 = add_ln514_10_fu_14119_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_1_fu_13472_p4() {
    trunc_ln514_1_fu_13472_p4 = sub_ln514_1_fu_13466_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_20_fu_14150_p4() {
    trunc_ln514_20_fu_14150_p4 = add_ln514_11_fu_14144_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_21_fu_14196_p4() {
    trunc_ln514_21_fu_14196_p4 = sub_ln514_10_fu_14190_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_22_fu_14222_p4() {
    trunc_ln514_22_fu_14222_p4 = add_ln514_12_fu_14216_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_23_fu_14268_p4() {
    trunc_ln514_23_fu_14268_p4 = sub_ln514_11_fu_14262_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_24_fu_14293_p4() {
    trunc_ln514_24_fu_14293_p4 = add_ln514_13_fu_14287_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_25_fu_14318_p4() {
    trunc_ln514_25_fu_14318_p4 = add_ln514_14_fu_14312_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_26_fu_14364_p4() {
    trunc_ln514_26_fu_14364_p4 = sub_ln514_12_fu_14358_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_27_fu_14412_p4() {
    trunc_ln514_27_fu_14412_p4 = sub_ln514_13_fu_14406_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_28_fu_14437_p4() {
    trunc_ln514_28_fu_14437_p4 = add_ln514_15_fu_14431_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_29_fu_14462_p4() {
    trunc_ln514_29_fu_14462_p4 = add_ln514_16_fu_14456_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_2_fu_13497_p4() {
    trunc_ln514_2_fu_13497_p4 = add_ln514_fu_13491_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_30_fu_14508_p4() {
    trunc_ln514_30_fu_14508_p4 = sub_ln514_14_fu_14502_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_31_fu_14534_p4() {
    trunc_ln514_31_fu_14534_p4 = add_ln514_17_fu_14528_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_32_fu_14580_p4() {
    trunc_ln514_32_fu_14580_p4 = sub_ln514_15_fu_14574_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_33_fu_14605_p4() {
    trunc_ln514_33_fu_14605_p4 = add_ln514_18_fu_14599_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_34_fu_14630_p4() {
    trunc_ln514_34_fu_14630_p4 = add_ln514_19_fu_14624_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_35_fu_14676_p4() {
    trunc_ln514_35_fu_14676_p4 = sub_ln514_16_fu_14670_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_36_fu_14724_p4() {
    trunc_ln514_36_fu_14724_p4 = sub_ln514_17_fu_14718_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_37_fu_14749_p4() {
    trunc_ln514_37_fu_14749_p4 = add_ln514_20_fu_14743_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_38_fu_14774_p4() {
    trunc_ln514_38_fu_14774_p4 = add_ln514_21_fu_14768_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_39_fu_14820_p4() {
    trunc_ln514_39_fu_14820_p4 = sub_ln514_18_fu_14814_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_3_fu_13522_p4() {
    trunc_ln514_3_fu_13522_p4 = add_ln514_1_fu_13516_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_40_fu_14846_p4() {
    trunc_ln514_40_fu_14846_p4 = add_ln514_22_fu_14840_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_41_fu_14892_p4() {
    trunc_ln514_41_fu_14892_p4 = sub_ln514_19_fu_14886_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_42_fu_14917_p4() {
    trunc_ln514_42_fu_14917_p4 = add_ln514_23_fu_14911_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_43_fu_14942_p4() {
    trunc_ln514_43_fu_14942_p4 = add_ln514_24_fu_14936_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_44_fu_14988_p4() {
    trunc_ln514_44_fu_14988_p4 = sub_ln514_20_fu_14982_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_45_fu_15036_p4() {
    trunc_ln514_45_fu_15036_p4 = sub_ln514_21_fu_15030_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_46_fu_15061_p4() {
    trunc_ln514_46_fu_15061_p4 = add_ln514_25_fu_15055_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_47_fu_15086_p4() {
    trunc_ln514_47_fu_15086_p4 = add_ln514_26_fu_15080_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_48_fu_15132_p4() {
    trunc_ln514_48_fu_15132_p4 = sub_ln514_22_fu_15126_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_49_fu_15158_p4() {
    trunc_ln514_49_fu_15158_p4 = add_ln514_27_fu_15152_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_4_fu_13569_p4() {
    trunc_ln514_4_fu_13569_p4 = sub_ln514_2_fu_13563_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_50_fu_15204_p4() {
    trunc_ln514_50_fu_15204_p4 = sub_ln514_23_fu_15198_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_51_fu_15229_p4() {
    trunc_ln514_51_fu_15229_p4 = add_ln514_28_fu_15223_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_52_fu_15254_p4() {
    trunc_ln514_52_fu_15254_p4 = add_ln514_29_fu_15248_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_53_fu_15300_p4() {
    trunc_ln514_53_fu_15300_p4 = sub_ln514_24_fu_15294_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_54_fu_15348_p4() {
    trunc_ln514_54_fu_15348_p4 = sub_ln514_25_fu_15342_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_55_fu_15373_p4() {
    trunc_ln514_55_fu_15373_p4 = add_ln514_30_fu_15367_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_56_fu_15398_p4() {
    trunc_ln514_56_fu_15398_p4 = add_ln514_31_fu_15392_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_57_fu_15444_p4() {
    trunc_ln514_57_fu_15444_p4 = sub_ln514_26_fu_15438_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_58_fu_15470_p4() {
    trunc_ln514_58_fu_15470_p4 = add_ln514_32_fu_15464_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_59_fu_15516_p4() {
    trunc_ln514_59_fu_15516_p4 = sub_ln514_27_fu_15510_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_5_fu_13595_p4() {
    trunc_ln514_5_fu_13595_p4 = add_ln514_2_fu_13589_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_60_fu_15541_p4() {
    trunc_ln514_60_fu_15541_p4 = add_ln514_33_fu_15535_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_61_fu_15566_p4() {
    trunc_ln514_61_fu_15566_p4 = add_ln514_34_fu_15560_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_62_fu_15612_p4() {
    trunc_ln514_62_fu_15612_p4 = sub_ln514_28_fu_15606_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_63_fu_15660_p4() {
    trunc_ln514_63_fu_15660_p4 = sub_ln514_29_fu_15654_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_64_fu_15685_p4() {
    trunc_ln514_64_fu_15685_p4 = add_ln514_35_fu_15679_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_65_fu_15710_p4() {
    trunc_ln514_65_fu_15710_p4 = add_ln514_36_fu_15704_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_66_fu_15756_p4() {
    trunc_ln514_66_fu_15756_p4 = sub_ln514_30_fu_15750_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_67_fu_15782_p4() {
    trunc_ln514_67_fu_15782_p4 = add_ln514_37_fu_15776_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_68_fu_15828_p4() {
    trunc_ln514_68_fu_15828_p4 = sub_ln514_31_fu_15822_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_69_fu_15853_p4() {
    trunc_ln514_69_fu_15853_p4 = add_ln514_38_fu_15847_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_6_fu_13642_p4() {
    trunc_ln514_6_fu_13642_p4 = sub_ln514_3_fu_13636_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_70_fu_15878_p4() {
    trunc_ln514_70_fu_15878_p4 = add_ln514_39_fu_15872_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_7_fu_13667_p4() {
    trunc_ln514_7_fu_13667_p4 = add_ln514_3_fu_13661_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_8_fu_13692_p4() {
    trunc_ln514_8_fu_13692_p4 = add_ln514_4_fu_13686_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_9_fu_13739_p4() {
    trunc_ln514_9_fu_13739_p4 = sub_ln514_4_fu_13733_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln514_s_fu_13788_p4() {
    trunc_ln514_s_fu_13788_p4 = sub_ln514_5_fu_13782_p2.read().range(8, 4);
}

void update_weights::thread_trunc_ln_fu_12829_p4() {
    trunc_ln_fu_12829_p4 = sub_ln473_fu_12823_p2.read().range(8, 2);
}

void update_weights::thread_v0_0_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_0_address0 = v0_0_addr_7_reg_17385_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_0_address0 = v0_0_addr_5_reg_17209_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_0_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_0_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state137.read())) {
        v0_0_address0 = v0_0_addr_3_reg_16419.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read())) {
        v0_0_address0 = v0_0_addr_2_reg_16399.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state125.read())) {
        v0_0_address0 =  (sc_lv<6>) (zext_ln334_33_fu_9118_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state124.read())) {
        v0_0_address0 = v0_0_addr_reg_15976.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state123.read())) {
        v0_0_address0 =  (sc_lv<6>) (zext_ln334_17_fu_9048_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state126.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state87.read()))) {
        v0_0_address0 = v0_0_addr_1_reg_16236.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state7.read())) {
        v0_0_address0 =  (sc_lv<6>) (zext_ln334_fu_8661_p1.read());
    } else {
        v0_0_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_0_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_0_address1 = v0_0_addr_6_reg_17305_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_0_address1 = v0_0_addr_4_reg_17113_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_0_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_0_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_0_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_0_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state123.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state124.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state125.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state126.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state7.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state87.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state137.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_0_ce0 = ap_const_logic_1;
    } else {
        v0_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_0_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_0_ce1 = ap_const_logic_1;
    } else {
        v0_0_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_0_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_0_d0 = reg_8180.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_0_d0 = reg_8076.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state137.read())) {
        v0_0_d0 = reg_7731.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read())) {
        v0_0_d0 = reg_7375.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state126.read())) {
        v0_0_d0 = v23_15_reg_16275.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state124.read())) {
        v0_0_d0 = reg_7343.read();
    } else {
        v0_0_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_0_d1() {
    v0_0_d1 = reg_7972.read();
}

void update_weights::thread_v0_0_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state124.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state126.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state137.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_0_we0 = ap_const_logic_1;
    } else {
        v0_0_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_0_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_0_we1 = ap_const_logic_1;
    } else {
        v0_0_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_10_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_10_address0 = v0_10_addr_7_reg_17435_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_10_address0 = v0_10_addr_5_reg_17269_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_10_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_10_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read())) {
        v0_10_address0 = v0_10_addr_3_reg_16611.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state146.read())) {
        v0_10_address0 = v0_10_addr_2_reg_16504.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read())) {
        v0_10_address0 = v0_10_addr_1_reg_16519.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state143.read())) {
        v0_10_address0 =  (sc_lv<6>) (zext_ln334_43_fu_9705_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state137.read())) {
        v0_10_address0 =  (sc_lv<6>) (zext_ln334_11_fu_9432_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read())) {
        v0_10_address0 =  (sc_lv<6>) (zext_ln334_27_fu_9392_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state57.read()))) {
        v0_10_address0 = v0_10_addr_reg_16068.read();
    } else {
        v0_10_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_10_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_10_address1 = v0_10_addr_6_reg_17355_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_10_address1 = v0_10_addr_4_reg_17173_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_10_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_10_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_10_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_10_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state143.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state146.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state137.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state57.read()))) {
        v0_10_ce0 = ap_const_logic_1;
    } else {
        v0_10_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_10_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_10_ce1 = ap_const_logic_1;
    } else {
        v0_10_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_10_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_10_d0 = reg_8248.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_10_d0 = reg_8144.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read())) {
        v0_10_d0 = reg_7528.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state146.read())) {
        v0_10_d0 = v23_41_reg_16633.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read())) {
        v0_10_d0 = reg_7438.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read())) {
        v0_10_d0 = v23_s_reg_16137.read();
    } else {
        v0_10_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_10_d1() {
    v0_10_d1 = reg_8040.read();
}

void update_weights::thread_v0_10_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state146.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_10_we0 = ap_const_logic_1;
    } else {
        v0_10_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_10_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_10_we1 = ap_const_logic_1;
    } else {
        v0_10_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_11_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_11_address0 = v0_11_addr_7_reg_17440_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_11_address0 = v0_11_addr_5_reg_17275_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_11_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_11_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read())) {
        v0_11_address0 = v0_11_addr_3_reg_16687.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state151.read())) {
        v0_11_address0 = v0_11_addr_2_reg_16559.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read())) {
        v0_11_address0 = v0_11_addr_1_reg_16581.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state148.read())) {
        v0_11_address0 =  (sc_lv<6>) (zext_ln334_44_fu_9879_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state142.read())) {
        v0_11_address0 =  (sc_lv<6>) (zext_ln334_12_fu_9606_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read())) {
        v0_11_address0 =  (sc_lv<6>) (zext_ln334_28_fu_9566_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state57.read()))) {
        v0_11_address0 = v0_11_addr_reg_16073.read();
    } else {
        v0_11_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_11_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_11_address1 = v0_11_addr_6_reg_17360_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_11_address1 = v0_11_addr_4_reg_17179_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_11_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_11_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_11_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_11_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state148.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state151.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state142.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state57.read()))) {
        v0_11_ce0 = ap_const_logic_1;
    } else {
        v0_11_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_11_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_11_ce1 = ap_const_logic_1;
    } else {
        v0_11_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_11_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_11_d0 = reg_8254.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_11_d0 = reg_8150.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read())) {
        v0_11_d0 = reg_7556.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state151.read())) {
        v0_11_d0 = v23_42_reg_16709.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read())) {
        v0_11_d0 = reg_7438.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read())) {
        v0_11_d0 = v23_10_reg_16144.read();
    } else {
        v0_11_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_11_d1() {
    v0_11_d1 = reg_8046.read();
}

void update_weights::thread_v0_11_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state151.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_11_we0 = ap_const_logic_1;
    } else {
        v0_11_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_11_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_11_we1 = ap_const_logic_1;
    } else {
        v0_11_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_12_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_12_address0 = v0_12_addr_7_reg_17445_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_12_address0 = v0_12_addr_5_reg_17281_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_12_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_12_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state165.read())) {
        v0_12_address0 = v0_12_addr_3_reg_16763.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state156.read())) {
        v0_12_address0 = v0_12_addr_2_reg_16628.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read())) {
        v0_12_address0 = v0_12_addr_1_reg_16657.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state153.read())) {
        v0_12_address0 =  (sc_lv<6>) (zext_ln334_45_fu_10053_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state147.read())) {
        v0_12_address0 =  (sc_lv<6>) (zext_ln334_13_fu_9780_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read())) {
        v0_12_address0 =  (sc_lv<6>) (zext_ln334_29_fu_9740_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state67.read()))) {
        v0_12_address0 = v0_12_addr_reg_16078.read();
    } else {
        v0_12_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_12_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_12_address1 = v0_12_addr_6_reg_17365_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_12_address1 = v0_12_addr_4_reg_17185_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_12_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_12_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_12_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_12_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state153.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state165.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state156.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state67.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state147.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_12_ce0 = ap_const_logic_1;
    } else {
        v0_12_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_12_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_12_ce1 = ap_const_logic_1;
    } else {
        v0_12_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_12_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_12_d0 = reg_8260.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_12_d0 = reg_8156.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state165.read())) {
        v0_12_d0 = reg_7580.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state156.read())) {
        v0_12_d0 = v23_43_reg_16785.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read())) {
        v0_12_d0 = reg_7438.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read())) {
        v0_12_d0 = v23_11_reg_16166.read();
    } else {
        v0_12_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_12_d1() {
    v0_12_d1 = reg_8052.read();
}

void update_weights::thread_v0_12_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state165.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state156.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_12_we0 = ap_const_logic_1;
    } else {
        v0_12_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_12_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_12_we1 = ap_const_logic_1;
    } else {
        v0_12_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_13_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_13_address0 = v0_13_addr_7_reg_17450_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_13_address0 = v0_13_addr_5_reg_17287_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_13_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_13_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state170.read())) {
        v0_13_address0 = v0_13_addr_3_reg_16839.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state161.read())) {
        v0_13_address0 = v0_13_addr_2_reg_16704.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read())) {
        v0_13_address0 = v0_13_addr_1_reg_16733.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state158.read())) {
        v0_13_address0 =  (sc_lv<6>) (zext_ln334_46_fu_10227_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state152.read())) {
        v0_13_address0 =  (sc_lv<6>) (zext_ln334_14_fu_9954_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read())) {
        v0_13_address0 =  (sc_lv<6>) (zext_ln334_30_fu_9914_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state72.read()))) {
        v0_13_address0 = v0_13_addr_reg_16083.read();
    } else {
        v0_13_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_13_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_13_address1 = v0_13_addr_6_reg_17370_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_13_address1 = v0_13_addr_4_reg_17191_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_13_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_13_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_13_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_13_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state158.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state161.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state72.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state152.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state170.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_13_ce0 = ap_const_logic_1;
    } else {
        v0_13_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_13_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_13_ce1 = ap_const_logic_1;
    } else {
        v0_13_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_13_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_13_d0 = reg_8266.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_13_d0 = reg_8162.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state170.read())) {
        v0_13_d0 = reg_7596.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state161.read())) {
        v0_13_d0 = v23_44_reg_16861.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read())) {
        v0_13_d0 = reg_7438.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read())) {
        v0_13_d0 = v23_12_reg_16173.read();
    } else {
        v0_13_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_13_d1() {
    v0_13_d1 = reg_8058.read();
}

void update_weights::thread_v0_13_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state161.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state170.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_13_we0 = ap_const_logic_1;
    } else {
        v0_13_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_13_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_13_we1 = ap_const_logic_1;
    } else {
        v0_13_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_14_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_14_address0 = v0_14_addr_7_reg_17455_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_14_address0 = v0_14_addr_5_reg_17293_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_14_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_14_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state175.read())) {
        v0_14_address0 = v0_14_addr_3_reg_16895.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state166.read())) {
        v0_14_address0 = v0_14_addr_2_reg_16780.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state164.read())) {
        v0_14_address0 = v0_14_addr_1_reg_16809.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state163.read())) {
        v0_14_address0 =  (sc_lv<6>) (zext_ln334_47_fu_10336_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state157.read())) {
        v0_14_address0 =  (sc_lv<6>) (zext_ln334_15_fu_10128_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read())) {
        v0_14_address0 =  (sc_lv<6>) (zext_ln334_31_fu_10088_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state77.read()))) {
        v0_14_address0 = v0_14_addr_reg_16088.read();
    } else {
        v0_14_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_14_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_14_address1 = v0_14_addr_6_reg_17375_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_14_address1 = v0_14_addr_4_reg_17197_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_14_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_14_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_14_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_14_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state163.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state164.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state166.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state157.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state77.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state175.read()))) {
        v0_14_ce0 = ap_const_logic_1;
    } else {
        v0_14_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_14_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_14_ce1 = ap_const_logic_1;
    } else {
        v0_14_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_14_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_14_d0 = reg_8272.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_14_d0 = reg_8168.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state175.read())) {
        v0_14_d0 = v23_61_reg_16957.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state166.read())) {
        v0_14_d0 = v23_45_reg_16917.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state164.read())) {
        v0_14_d0 = reg_7438.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read())) {
        v0_14_d0 = v23_13_reg_16241.read();
    } else {
        v0_14_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_14_d1() {
    v0_14_d1 = reg_8064.read();
}

void update_weights::thread_v0_14_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state164.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state166.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state175.read()))) {
        v0_14_we0 = ap_const_logic_1;
    } else {
        v0_14_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_14_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_14_we1 = ap_const_logic_1;
    } else {
        v0_14_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_15_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_15_address0 = v0_15_addr_7_reg_17460_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_15_address0 = v0_15_addr_5_reg_17299_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_15_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_15_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state175.read())) {
        v0_15_address0 = v0_15_addr_3_reg_16931.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state171.read())) {
        v0_15_address0 = v0_15_addr_2_reg_16856.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state169.read())) {
        v0_15_address0 = v0_15_addr_1_reg_16885.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state168.read())) {
        v0_15_address0 =  (sc_lv<6>) (zext_ln334_48_fu_10371_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state162.read())) {
        v0_15_address0 =  (sc_lv<6>) (zext_ln334_16_fu_10302_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read())) {
        v0_15_address0 =  (sc_lv<6>) (zext_ln334_32_fu_10262_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state77.read()))) {
        v0_15_address0 = v0_15_addr_reg_16093.read();
    } else {
        v0_15_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_15_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_15_address1 = v0_15_addr_6_reg_17380_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_15_address1 = v0_15_addr_4_reg_17203_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_15_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_15_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_15_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_15_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state168.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state169.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state162.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state171.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state77.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state175.read()))) {
        v0_15_ce0 = ap_const_logic_1;
    } else {
        v0_15_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_15_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_15_ce1 = ap_const_logic_1;
    } else {
        v0_15_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_15_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_15_d0 = reg_8278.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_15_d0 = reg_8174.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state171.read())) {
        v0_15_d0 = v23_46_reg_16943.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state169.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state175.read()))) {
        v0_15_d0 = reg_7438.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read())) {
        v0_15_d0 = v23_14_reg_16248.read();
    } else {
        v0_15_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_15_d1() {
    v0_15_d1 = reg_8070.read();
}

void update_weights::thread_v0_15_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state169.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state171.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state175.read()))) {
        v0_15_we0 = ap_const_logic_1;
    } else {
        v0_15_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_15_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_15_we1 = ap_const_logic_1;
    } else {
        v0_15_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_1_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_1_address0 = v0_1_addr_7_reg_17390_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_1_address0 = v0_1_addr_5_reg_17215_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_1_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_1_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state142.read())) {
        v0_1_address0 = v0_1_addr_3_reg_16459.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read())) {
        v0_1_address0 = v0_1_addr_2_reg_16439.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state130.read())) {
        v0_1_address0 =  (sc_lv<6>) (zext_ln334_34_fu_9253_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state129.read())) {
        v0_1_address0 = v0_1_addr_reg_15986.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state128.read())) {
        v0_1_address0 =  (sc_lv<6>) (zext_ln334_18_fu_9183_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state131.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state92.read()))) {
        v0_1_address0 = v0_1_addr_1_reg_16260.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state12.read())) {
        v0_1_address0 =  (sc_lv<6>) (zext_ln334_reg_15957.read());
    } else {
        v0_1_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_1_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_1_address1 = v0_1_addr_6_reg_17310_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_1_address1 = v0_1_addr_4_reg_17119_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_1_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_1_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_1_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_1_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state128.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state129.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state130.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state131.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state12.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state92.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state142.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_1_ce0 = ap_const_logic_1;
    } else {
        v0_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_1_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_1_ce1 = ap_const_logic_1;
    } else {
        v0_1_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_1_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_1_d0 = reg_8188.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_1_d0 = reg_8084.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state142.read())) {
        v0_1_d0 = v23_48_reg_16574.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read())) {
        v0_1_d0 = reg_7767.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state131.read())) {
        v0_1_d0 = v23_16_reg_16292.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state129.read())) {
        v0_1_d0 = reg_7375.read();
    } else {
        v0_1_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_1_d1() {
    v0_1_d1 = reg_7980.read();
}

void update_weights::thread_v0_1_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state129.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state131.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state142.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_1_we0 = ap_const_logic_1;
    } else {
        v0_1_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_1_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_1_we1 = ap_const_logic_1;
    } else {
        v0_1_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_2_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_2_address0 = v0_2_addr_7_reg_17395_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_2_address0 = v0_2_addr_5_reg_17221_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_2_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_2_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state147.read())) {
        v0_2_address0 = v0_2_addr_3_reg_16514.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read())) {
        v0_2_address0 = v0_2_addr_2_reg_16484.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read())) {
        v0_2_address0 =  (sc_lv<6>) (zext_ln334_35_fu_9427_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read())) {
        v0_2_address0 = v0_2_addr_reg_15996.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state133.read())) {
        v0_2_address0 =  (sc_lv<6>) (zext_ln334_19_fu_9322_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state136.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state97.read()))) {
        v0_2_address0 = v0_2_addr_1_reg_16270.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state17.read())) {
        v0_2_address0 =  (sc_lv<6>) (zext_ln334_reg_15957.read());
    } else {
        v0_2_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_2_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_2_address1 = v0_2_addr_6_reg_17315_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_2_address1 = v0_2_addr_4_reg_17125_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_2_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_2_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_2_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_2_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state133.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state136.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state17.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state97.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state147.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_2_ce0 = ap_const_logic_1;
    } else {
        v0_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_2_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_2_ce1 = ap_const_logic_1;
    } else {
        v0_2_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_2_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_2_d0 = reg_8196.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_2_d0 = reg_8092.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state147.read())) {
        v0_2_d0 = v23_49_reg_16650.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read())) {
        v0_2_d0 = v23_33_reg_16616.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state136.read())) {
        v0_2_d0 = v23_17_reg_16309.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read())) {
        v0_2_d0 = reg_7438.read();
    } else {
        v0_2_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_2_d1() {
    v0_2_d1 = reg_7988.read();
}

void update_weights::thread_v0_2_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state136.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state147.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_2_we0 = ap_const_logic_1;
    } else {
        v0_2_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_2_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_2_we1 = ap_const_logic_1;
    } else {
        v0_2_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_3_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_3_address0 = v0_3_addr_7_reg_17400_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_3_address0 = v0_3_addr_5_reg_17227_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_3_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_3_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state152.read())) {
        v0_3_address0 = v0_3_addr_3_reg_16569.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read())) {
        v0_3_address0 = v0_3_addr_2_reg_16539.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read())) {
        v0_3_address0 =  (sc_lv<6>) (zext_ln334_36_fu_9601_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read())) {
        v0_3_address0 = v0_3_addr_reg_16006.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state138.read())) {
        v0_3_address0 =  (sc_lv<6>) (zext_ln334_20_fu_9496_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state141.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state102.read()))) {
        v0_3_address0 = v0_3_addr_1_reg_16287.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state22.read())) {
        v0_3_address0 =  (sc_lv<6>) (zext_ln334_reg_15957.read());
    } else {
        v0_3_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_3_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_3_address1 = v0_3_addr_6_reg_17320_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_3_address1 = v0_3_addr_4_reg_17131_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_3_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_3_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_3_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_3_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state138.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state141.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state22.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state102.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state152.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_3_ce0 = ap_const_logic_1;
    } else {
        v0_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_3_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_3_ce1 = ap_const_logic_1;
    } else {
        v0_3_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_3_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_3_d0 = reg_8204.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_3_d0 = reg_8100.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state152.read())) {
        v0_3_d0 = v23_50_reg_16726.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read())) {
        v0_3_d0 = v23_34_reg_16692.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state141.read())) {
        v0_3_d0 = v23_18_reg_16331.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read())) {
        v0_3_d0 = reg_7481.read();
    } else {
        v0_3_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_3_d1() {
    v0_3_d1 = reg_7996.read();
}

void update_weights::thread_v0_3_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state141.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state152.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_3_we0 = ap_const_logic_1;
    } else {
        v0_3_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_3_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_3_we1 = ap_const_logic_1;
    } else {
        v0_3_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_4_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_4_address0 = v0_4_addr_7_reg_17405_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_4_address0 = v0_4_addr_5_reg_17233_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_4_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_4_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state157.read())) {
        v0_4_address0 = v0_4_addr_3_reg_16645.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read())) {
        v0_4_address0 = v0_4_addr_2_reg_16601.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state146.read())) {
        v0_4_address0 = v0_4_addr_1_reg_16316.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read())) {
        v0_4_address0 =  (sc_lv<6>) (zext_ln334_37_fu_9775_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read())) {
        v0_4_address0 = v0_4_addr_reg_16023.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state143.read())) {
        v0_4_address0 =  (sc_lv<6>) (zext_ln334_21_fu_9670_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state107.read())) {
        v0_4_address0 =  (sc_lv<6>) (zext_ln334_5_fu_8875_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state27.read())) {
        v0_4_address0 =  (sc_lv<6>) (zext_ln334_reg_15957.read());
    } else {
        v0_4_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_4_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_4_address1 = v0_4_addr_6_reg_17325_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_4_address1 = v0_4_addr_4_reg_17137_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_4_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_4_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_4_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_4_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state143.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state146.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state27.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state107.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state157.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_4_ce0 = ap_const_logic_1;
    } else {
        v0_4_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_4_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_4_ce1 = ap_const_logic_1;
    } else {
        v0_4_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_4_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_4_d0 = reg_8212.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_4_d0 = reg_8108.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state157.read())) {
        v0_4_d0 = v23_51_reg_16802.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read())) {
        v0_4_d0 = v23_35_reg_16768.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state146.read())) {
        v0_4_d0 = v23_19_reg_16348.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read())) {
        v0_4_d0 = reg_7513.read();
    } else {
        v0_4_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_4_d1() {
    v0_4_d1 = reg_8004.read();
}

void update_weights::thread_v0_4_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state146.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state157.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_4_we0 = ap_const_logic_1;
    } else {
        v0_4_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_4_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_4_we1 = ap_const_logic_1;
    } else {
        v0_4_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_5_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_5_address0 = v0_5_addr_7_reg_17410_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_5_address0 = v0_5_addr_5_reg_17239_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_5_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_5_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state162.read())) {
        v0_5_address0 = v0_5_addr_3_reg_16721.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read())) {
        v0_5_address0 = v0_5_addr_2_reg_16677.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read())) {
        v0_5_address0 =  (sc_lv<6>) (zext_ln334_38_fu_9949_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read())) {
        v0_5_address0 = v0_5_addr_reg_16033.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state148.read())) {
        v0_5_address0 =  (sc_lv<6>) (zext_ln334_22_fu_9844_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state151.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state112.read()))) {
        v0_5_address0 = v0_5_addr_1_reg_16326.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state32.read())) {
        v0_5_address0 =  (sc_lv<6>) (zext_ln334_reg_15957.read());
    } else {
        v0_5_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_5_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_5_address1 = v0_5_addr_6_reg_17330_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_5_address1 = v0_5_addr_4_reg_17143_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_5_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_5_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_5_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_5_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state148.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state151.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state32.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state112.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state162.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_5_ce0 = ap_const_logic_1;
    } else {
        v0_5_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_5_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_5_ce1 = ap_const_logic_1;
    } else {
        v0_5_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_5_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_5_d0 = reg_8218.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_5_d0 = reg_8114.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state162.read())) {
        v0_5_d0 = v23_52_reg_16878.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read())) {
        v0_5_d0 = v23_36_reg_16844.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state151.read())) {
        v0_5_d0 = v23_20_reg_16365.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read())) {
        v0_5_d0 = reg_7528.read();
    } else {
        v0_5_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_5_d1() {
    v0_5_d1 = reg_8010.read();
}

void update_weights::thread_v0_5_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state151.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state162.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_5_we0 = ap_const_logic_1;
    } else {
        v0_5_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_5_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_5_we1 = ap_const_logic_1;
    } else {
        v0_5_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_6_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_6_address0 = v0_6_addr_7_reg_17415_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_6_address0 = v0_6_addr_5_reg_17245_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_6_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_6_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state167.read())) {
        v0_6_address0 = v0_6_addr_3_reg_16797.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state165.read())) {
        v0_6_address0 = v0_6_addr_2_reg_16753.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read())) {
        v0_6_address0 =  (sc_lv<6>) (zext_ln334_39_fu_10123_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state153.read())) {
        v0_6_address0 =  (sc_lv<6>) (zext_ln334_23_fu_10018_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state156.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state117.read()))) {
        v0_6_address0 = v0_6_addr_1_reg_16343.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state37.read()))) {
        v0_6_address0 = v0_6_addr_reg_16043.read();
    } else {
        v0_6_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_6_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_6_address1 = v0_6_addr_6_reg_17335_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_6_address1 = v0_6_addr_4_reg_17149_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_6_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_6_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_6_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_6_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state153.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state165.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state156.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state117.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state37.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state167.read()))) {
        v0_6_ce0 = ap_const_logic_1;
    } else {
        v0_6_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_6_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_6_ce1 = ap_const_logic_1;
    } else {
        v0_6_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_6_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_6_d0 = reg_8224.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_6_d0 = reg_8120.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state167.read())) {
        v0_6_d0 = v23_53_reg_16924.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state165.read())) {
        v0_6_d0 = v23_37_reg_16910.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state156.read())) {
        v0_6_d0 = v23_21_reg_16387.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read())) {
        v0_6_d0 = reg_7556.read();
    } else {
        v0_6_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_6_d1() {
    v0_6_d1 = reg_8016.read();
}

void update_weights::thread_v0_6_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state165.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state156.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state167.read()))) {
        v0_6_we0 = ap_const_logic_1;
    } else {
        v0_6_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_6_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_6_we1 = ap_const_logic_1;
    } else {
        v0_6_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_7_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_7_address0 = v0_7_addr_7_reg_17420_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_7_address0 = v0_7_addr_5_reg_17251_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_7_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_7_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state172.read())) {
        v0_7_address0 = v0_7_addr_3_reg_16873.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state170.read())) {
        v0_7_address0 = v0_7_addr_2_reg_16829.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state161.read())) {
        v0_7_address0 = v0_7_addr_1_reg_16372.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read())) {
        v0_7_address0 =  (sc_lv<6>) (zext_ln334_40_fu_10297_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state158.read())) {
        v0_7_address0 =  (sc_lv<6>) (zext_ln334_24_fu_10192_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state122.read())) {
        v0_7_address0 =  (sc_lv<6>) (zext_ln334_8_fu_8979_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state37.read()))) {
        v0_7_address0 = v0_7_addr_reg_16053.read();
    } else {
        v0_7_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_7_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_7_address1 = v0_7_addr_6_reg_17340_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_7_address1 = v0_7_addr_4_reg_17155_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_7_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_7_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_7_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_7_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state158.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state161.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state122.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state170.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state37.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state172.read()))) {
        v0_7_ce0 = ap_const_logic_1;
    } else {
        v0_7_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_7_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_7_ce1 = ap_const_logic_1;
    } else {
        v0_7_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_7_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_7_d0 = reg_8230.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_7_d0 = reg_8126.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state172.read())) {
        v0_7_d0 = v23_54_reg_16950.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state170.read())) {
        v0_7_d0 = v23_38_reg_16936.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state161.read())) {
        v0_7_d0 = reg_7580.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read())) {
        v0_7_d0 = reg_7564.read();
    } else {
        v0_7_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_7_d1() {
    v0_7_d1 = reg_8022.read();
}

void update_weights::thread_v0_7_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state161.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state170.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state172.read()))) {
        v0_7_we0 = ap_const_logic_1;
    } else {
        v0_7_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_7_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_7_we1 = ap_const_logic_1;
    } else {
        v0_7_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_8_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_8_address0 = v0_8_addr_7_reg_17425_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_8_address0 = v0_8_addr_5_reg_17257_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_8_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_8_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read())) {
        v0_8_address0 = v0_8_addr_3_reg_16494.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state136.read())) {
        v0_8_address0 = v0_8_addr_2_reg_16409.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state133.read())) {
        v0_8_address0 =  (sc_lv<6>) (zext_ln334_41_fu_9357_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state127.read()))) {
        v0_8_address0 = v0_8_addr_1_reg_16382.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state124.read())) {
        v0_8_address0 =  (sc_lv<6>) (zext_ln334_25_fu_9083_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state125.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state47.read()))) {
        v0_8_address0 = v0_8_addr_reg_16058.read();
    } else {
        v0_8_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_8_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_8_address1 = v0_8_addr_6_reg_17345_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_8_address1 = v0_8_addr_4_reg_17161_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_8_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_8_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_8_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_8_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state133.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state124.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state125.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state136.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state47.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state127.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_8_ce0 = ap_const_logic_1;
    } else {
        v0_8_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_8_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_8_ce1 = ap_const_logic_1;
    } else {
        v0_8_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_8_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_8_d0 = reg_8236.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_8_d0 = reg_8132.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read())) {
        v0_8_d0 = reg_7481.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state136.read())) {
        v0_8_d0 = reg_7417.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read())) {
        v0_8_d0 = reg_7596.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state125.read())) {
        v0_8_d0 = reg_7580.read();
    } else {
        v0_8_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_8_d1() {
    v0_8_d1 = reg_8028.read();
}

void update_weights::thread_v0_8_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state125.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state136.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_8_we0 = ap_const_logic_1;
    } else {
        v0_8_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_8_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_8_we1 = ap_const_logic_1;
    } else {
        v0_8_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_9_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_9_address0 = v0_9_addr_7_reg_17430_pp1_iter9_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_9_address0 = v0_9_addr_5_reg_17263_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_9_address0 =  (sc_lv<6>) (zext_ln373_3_fu_10519_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_9_address0 =  (sc_lv<6>) (zext_ln373_fu_10443_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read())) {
        v0_9_address0 = v0_9_addr_3_reg_16549.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state141.read())) {
        v0_9_address0 = v0_9_addr_2_reg_16449.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read())) {
        v0_9_address0 = v0_9_addr_1_reg_16464.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state138.read())) {
        v0_9_address0 =  (sc_lv<6>) (zext_ln334_42_fu_9531_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state132.read())) {
        v0_9_address0 =  (sc_lv<6>) (zext_ln334_10_fu_9258_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state129.read())) {
        v0_9_address0 =  (sc_lv<6>) (zext_ln334_26_fu_9218_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state130.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state52.read()))) {
        v0_9_address0 = v0_9_addr_reg_16063.read();
    } else {
        v0_9_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_9_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0))) {
        v0_9_address1 = v0_9_addr_6_reg_17350_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_9_address1 = v0_9_addr_4_reg_17167_pp1_iter8_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage1.read(), ap_const_boolean_0))) {
        v0_9_address1 =  (sc_lv<6>) (zext_ln373_2_fu_10494_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        v0_9_address1 =  (sc_lv<6>) (zext_ln373_1_fu_10469_p1.read());
    } else {
        v0_9_address1 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v0_9_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state138.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state129.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state130.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state141.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state52.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state132.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read())))) {
        v0_9_ce0 = ap_const_logic_1;
    } else {
        v0_9_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_9_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0)))) {
        v0_9_ce1 = ap_const_logic_1;
    } else {
        v0_9_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_9_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage3.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()))) {
        v0_9_d0 = reg_8242.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp1_stage2.read(), ap_const_boolean_0))) {
        v0_9_d0 = reg_8138.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read())) {
        v0_9_d0 = reg_7513.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state141.read())) {
        v0_9_d0 = reg_7790.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read())) {
        v0_9_d0 = reg_7438.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state130.read())) {
        v0_9_d0 = reg_7596.read();
    } else {
        v0_9_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v0_9_d1() {
    v0_9_d1 = reg_8034.read();
}

void update_weights::thread_v0_9_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state130.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state141.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter9.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter9_reg.read())))) {
        v0_9_we0 = ap_const_logic_1;
    } else {
        v0_9_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v0_9_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter8.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln370_reg_17098_pp1_iter8_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp1_stage3_11001.read(), ap_const_boolean_0)))) {
        v0_9_we1 = ap_const_logic_1;
    } else {
        v0_9_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v10_0_address0() {
    v10_0_address0 =  (sc_lv<4>) (zext_ln424_fu_12394_p1.read());
}

void update_weights::thread_v10_0_address1() {
    v10_0_address1 =  (sc_lv<4>) (zext_ln424_1_fu_12412_p1.read());
}

void update_weights::thread_v10_0_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0))) {
        v10_0_ce0 = ap_const_logic_1;
    } else {
        v10_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v10_0_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0))) {
        v10_0_ce1 = ap_const_logic_1;
    } else {
        v10_0_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v10_1_address0() {
    v10_1_address0 =  (sc_lv<4>) (zext_ln424_fu_12394_p1.read());
}

void update_weights::thread_v10_1_address1() {
    v10_1_address1 =  (sc_lv<4>) (zext_ln424_1_fu_12412_p1.read());
}

void update_weights::thread_v10_1_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0))) {
        v10_1_ce0 = ap_const_logic_1;
    } else {
        v10_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v10_1_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0))) {
        v10_1_ce1 = ap_const_logic_1;
    } else {
        v10_1_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v10_2_address0() {
    v10_2_address0 =  (sc_lv<4>) (zext_ln424_fu_12394_p1.read());
}

void update_weights::thread_v10_2_address1() {
    v10_2_address1 =  (sc_lv<4>) (zext_ln424_1_fu_12412_p1.read());
}

void update_weights::thread_v10_2_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0))) {
        v10_2_ce0 = ap_const_logic_1;
    } else {
        v10_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v10_2_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0))) {
        v10_2_ce1 = ap_const_logic_1;
    } else {
        v10_2_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v10_3_address0() {
    v10_3_address0 =  (sc_lv<4>) (zext_ln424_fu_12394_p1.read());
}

void update_weights::thread_v10_3_address1() {
    v10_3_address1 =  (sc_lv<4>) (zext_ln424_1_fu_12412_p1.read());
}

void update_weights::thread_v10_3_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0))) {
        v10_3_ce0 = ap_const_logic_1;
    } else {
        v10_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v10_3_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0))) {
        v10_3_ce1 = ap_const_logic_1;
    } else {
        v10_3_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v114_fu_13357_p2() {
    v114_fu_13357_p2 = (!ap_phi_mux_v114_0_phi_fu_7131_p4.read().is_01() || !ap_const_lv2_1.is_01())? sc_lv<2>(): (sc_biguint<2>(ap_phi_mux_v114_0_phi_fu_7131_p4.read()) + sc_biguint<2>(ap_const_lv2_1));
}

void update_weights::thread_v125_fu_13383_p2() {
    v125_fu_13383_p2 = (!v125_0_reg_7138.read().is_01() || !ap_const_lv2_1.is_01())? sc_lv<2>(): (sc_biguint<2>(v125_0_reg_7138.read()) + sc_biguint<2>(ap_const_lv2_1));
}

void update_weights::thread_v131_fu_15903_p2() {
    v131_fu_15903_p2 = (!v131_0_reg_7149.read().is_01() || !ap_const_lv2_1.is_01())? sc_lv<2>(): (sc_biguint<2>(v131_0_reg_7149.read()) + sc_biguint<2>(ap_const_lv2_1));
}

void update_weights::thread_v16_fu_8634_p2() {
    v16_fu_8634_p2 = (!v16_0_reg_6799.read().is_01() || !ap_const_lv4_1.is_01())? sc_lv<4>(): (sc_biguint<4>(v16_0_reg_6799.read()) + sc_biguint<4>(ap_const_lv4_1));
}

void update_weights::thread_v1_0_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_0_address0 = v1_0_addr_11_reg_20061_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_0_address0 = v1_0_addr_9_reg_19741_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_0_address0 = v1_0_addr_7_reg_19415_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_0_address0 = v1_0_addr_5_reg_19159_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_0_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_0_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_0_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_0_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state729.read())) {
        v1_0_address0 = v1_0_addr_3_reg_18574.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state718.read())) {
        v1_0_address0 = v1_0_addr_1_reg_18214.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state717.read())) {
        v1_0_address0 =  (sc_lv<8>) (zext_ln402_33_fu_11619_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state649.read())) {
        v1_0_address0 = v1_0_addr_2_reg_18339.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state638.read())) {
        v1_0_address0 = v1_0_addr_reg_17977.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state637.read())) {
        v1_0_address0 =  (sc_lv<8>) (zext_ln402_17_fu_11074_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state601.read())) {
        v1_0_address0 =  (sc_lv<8>) (zext_ln402_1_fu_10772_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state521.read())) {
        v1_0_address0 =  (sc_lv<8>) (zext_ln402_fu_10699_p1.read());
    } else {
        v1_0_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_0_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_0_address1 = v1_0_addr_10_reg_19981_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_0_address1 = v1_0_addr_8_reg_19661_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_0_address1 = v1_0_addr_6_reg_19335_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_0_address1 = v1_0_addr_4_reg_19063_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_0_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_0_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_0_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_0_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_0_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_0_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state637.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state717.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state638.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state718.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state521.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state601.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state649.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state729.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())))) {
        v1_0_ce0 = ap_const_logic_1;
    } else {
        v1_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_0_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_0_ce1 = ap_const_logic_1;
    } else {
        v1_0_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_0_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_0_d0 = reg_8312.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_0_d0 = reg_8284.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_0_d0 = reg_8076.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state718.read())) {
        v1_0_d0 = reg_7438.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state649.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state729.read()))) {
        v1_0_d0 = reg_7375.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state638.read())) {
        v1_0_d0 = reg_7343.read();
    } else {
        v1_0_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_0_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_0_d1 = reg_8180.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_0_d1 = reg_7972.read();
    } else {
        v1_0_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_0_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state638.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state718.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state649.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state729.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())))) {
        v1_0_we0 = ap_const_logic_1;
    } else {
        v1_0_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_0_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_0_we1 = ap_const_logic_1;
    } else {
        v1_0_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_10_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_10_address0 = v1_10_addr_11_reg_20111_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_10_address0 = v1_10_addr_9_reg_19791_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_10_address0 = v1_10_addr_7_reg_19465_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_10_address0 = v1_10_addr_5_reg_19219_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_10_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_10_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_10_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_10_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state818.read())) {
        v1_10_address0 = v1_10_addr_3_reg_18834.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state811.read())) {
        v1_10_address0 =  (sc_lv<8>) (zext_ln402_43_fu_12202_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state738.read())) {
        v1_10_address0 = v1_10_addr_2_reg_18609.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state731.read())) {
        v1_10_address0 =  (sc_lv<8>) (zext_ln402_27_fu_11692_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state658.read())) {
        v1_10_address0 = v1_10_addr_1_reg_18374.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state651.read())) {
        v1_10_address0 =  (sc_lv<8>) (zext_ln402_11_fu_11147_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state571.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state578.read()))) {
        v1_10_address0 = v1_10_addr_reg_18086.read();
    } else {
        v1_10_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_10_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_10_address1 = v1_10_addr_10_reg_20031_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_10_address1 = v1_10_addr_8_reg_19711_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_10_address1 = v1_10_addr_6_reg_19385_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_10_address1 = v1_10_addr_4_reg_19123_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_10_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_10_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_10_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_10_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_10_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_10_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state651.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state731.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state811.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state571.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state578.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state658.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state738.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state818.read()))) {
        v1_10_ce0 = ap_const_logic_1;
    } else {
        v1_10_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_10_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_10_ce1 = ap_const_logic_1;
    } else {
        v1_10_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_10_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_10_d0 = v88_1_57_reg_20391.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_10_d0 = v88_0_57_reg_20331.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_10_d0 = reg_8144.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state658.read())) {
        v1_10_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state578.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state738.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state818.read()))) {
        v1_10_d0 = reg_7438.read();
    } else {
        v1_10_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_10_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_10_d1 = reg_8248.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_10_d1 = reg_8040.read();
    } else {
        v1_10_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_10_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state578.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state658.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state738.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state818.read()))) {
        v1_10_we0 = ap_const_logic_1;
    } else {
        v1_10_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_10_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_10_we1 = ap_const_logic_1;
    } else {
        v1_10_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_11_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_11_address0 = v1_11_addr_11_reg_20116_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_11_address0 = v1_11_addr_9_reg_19796_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_11_address0 = v1_11_addr_7_reg_19470_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_11_address0 = v1_11_addr_5_reg_19225_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_11_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_11_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_11_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_11_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state823.read())) {
        v1_11_address0 = v1_11_addr_3_reg_18849.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state816.read())) {
        v1_11_address0 =  (sc_lv<8>) (zext_ln402_44_fu_12236_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state743.read())) {
        v1_11_address0 = v1_11_addr_2_reg_18624.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state736.read())) {
        v1_11_address0 =  (sc_lv<8>) (zext_ln402_28_fu_11726_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state663.read())) {
        v1_11_address0 = v1_11_addr_1_reg_18389.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state656.read())) {
        v1_11_address0 =  (sc_lv<8>) (zext_ln402_12_fu_11181_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state571.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state578.read()))) {
        v1_11_address0 = v1_11_addr_reg_18091.read();
    } else {
        v1_11_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_11_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_11_address1 = v1_11_addr_10_reg_20036_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_11_address1 = v1_11_addr_8_reg_19716_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_11_address1 = v1_11_addr_6_reg_19390_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_11_address1 = v1_11_addr_4_reg_19129_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_11_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_11_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_11_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_11_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_11_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_11_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state656.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state736.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state816.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state571.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state578.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state663.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state743.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state823.read()))) {
        v1_11_ce0 = ap_const_logic_1;
    } else {
        v1_11_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_11_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_11_ce1 = ap_const_logic_1;
    } else {
        v1_11_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_11_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_11_d0 = v88_1_58_reg_20396.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_11_d0 = v88_0_58_reg_20336.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_11_d0 = reg_8150.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state743.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state823.read()))) {
        v1_11_d0 = reg_7438.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state663.read())) {
        v1_11_d0 = reg_7481.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state578.read())) {
        v1_11_d0 = reg_7564.read();
    } else {
        v1_11_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_11_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_11_d1 = reg_8254.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_11_d1 = reg_8046.read();
    } else {
        v1_11_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_11_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state578.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state663.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state743.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state823.read()))) {
        v1_11_we0 = ap_const_logic_1;
    } else {
        v1_11_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_11_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_11_we1 = ap_const_logic_1;
    } else {
        v1_11_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_12_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_12_address0 = v1_12_addr_11_reg_20121_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_12_address0 = v1_12_addr_9_reg_19801_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_12_address0 = v1_12_addr_7_reg_19475_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_12_address0 = v1_12_addr_5_reg_19231_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_12_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_12_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_12_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_12_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state828.read())) {
        v1_12_address0 = v1_12_addr_3_reg_18864.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state821.read())) {
        v1_12_address0 =  (sc_lv<8>) (zext_ln402_45_fu_12270_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state748.read())) {
        v1_12_address0 = v1_12_addr_2_reg_18639.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state741.read())) {
        v1_12_address0 =  (sc_lv<8>) (zext_ln402_29_fu_11760_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state668.read())) {
        v1_12_address0 = v1_12_addr_1_reg_18404.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state661.read())) {
        v1_12_address0 =  (sc_lv<8>) (zext_ln402_13_fu_11215_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state581.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state588.read()))) {
        v1_12_address0 = v1_12_addr_reg_18096.read();
    } else {
        v1_12_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_12_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_12_address1 = v1_12_addr_10_reg_20041_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_12_address1 = v1_12_addr_8_reg_19721_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_12_address1 = v1_12_addr_6_reg_19395_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_12_address1 = v1_12_addr_4_reg_19135_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_12_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_12_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_12_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_12_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_12_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_12_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state581.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state661.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state741.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state821.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state588.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state668.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state748.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state828.read()))) {
        v1_12_ce0 = ap_const_logic_1;
    } else {
        v1_12_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_12_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_12_ce1 = ap_const_logic_1;
    } else {
        v1_12_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_12_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_12_d0 = v88_1_59_reg_20401.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_12_d0 = v88_0_59_reg_20341.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_12_d0 = reg_8156.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state668.read())) {
        v1_12_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state588.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state748.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state828.read()))) {
        v1_12_d0 = reg_7438.read();
    } else {
        v1_12_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_12_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_12_d1 = reg_8260.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_12_d1 = reg_8052.read();
    } else {
        v1_12_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_12_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state588.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state668.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state748.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state828.read()))) {
        v1_12_we0 = ap_const_logic_1;
    } else {
        v1_12_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_12_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_12_we1 = ap_const_logic_1;
    } else {
        v1_12_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_13_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_13_address0 = v1_13_addr_11_reg_20126_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_13_address0 = v1_13_addr_9_reg_19806_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_13_address0 = v1_13_addr_7_reg_19480_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_13_address0 = v1_13_addr_5_reg_19237_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_13_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_13_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_13_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_13_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state833.read())) {
        v1_13_address0 = v1_13_addr_3_reg_18879.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state826.read())) {
        v1_13_address0 =  (sc_lv<8>) (zext_ln402_46_fu_12304_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state753.read())) {
        v1_13_address0 = v1_13_addr_2_reg_18654.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state746.read())) {
        v1_13_address0 =  (sc_lv<8>) (zext_ln402_30_fu_11794_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state673.read())) {
        v1_13_address0 = v1_13_addr_1_reg_18419.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state666.read())) {
        v1_13_address0 =  (sc_lv<8>) (zext_ln402_14_fu_11249_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state586.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state593.read()))) {
        v1_13_address0 = v1_13_addr_reg_18101.read();
    } else {
        v1_13_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_13_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_13_address1 = v1_13_addr_10_reg_20046_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_13_address1 = v1_13_addr_8_reg_19726_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_13_address1 = v1_13_addr_6_reg_19400_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_13_address1 = v1_13_addr_4_reg_19141_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_13_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_13_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_13_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_13_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_13_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_13_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state586.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state666.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state746.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state826.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state593.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state673.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state753.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state833.read()))) {
        v1_13_ce0 = ap_const_logic_1;
    } else {
        v1_13_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_13_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_13_ce1 = ap_const_logic_1;
    } else {
        v1_13_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_13_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_13_d0 = v88_1_60_reg_20406.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_13_d0 = v88_0_60_reg_20346.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_13_d0 = reg_8162.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state673.read())) {
        v1_13_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state593.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state753.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state833.read()))) {
        v1_13_d0 = reg_7438.read();
    } else {
        v1_13_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_13_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_13_d1 = reg_8266.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_13_d1 = reg_8058.read();
    } else {
        v1_13_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_13_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state593.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state673.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state753.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state833.read()))) {
        v1_13_we0 = ap_const_logic_1;
    } else {
        v1_13_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_13_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_13_we1 = ap_const_logic_1;
    } else {
        v1_13_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_14_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_14_address0 = v1_14_addr_11_reg_20131_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_14_address0 = v1_14_addr_9_reg_19811_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_14_address0 = v1_14_addr_7_reg_19485_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_14_address0 = v1_14_addr_5_reg_19243_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_14_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_14_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_14_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_14_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state838.read())) {
        v1_14_address0 = v1_14_addr_3_reg_18894.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state831.read())) {
        v1_14_address0 =  (sc_lv<8>) (zext_ln402_47_fu_12338_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state758.read())) {
        v1_14_address0 = v1_14_addr_2_reg_18669.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state751.read())) {
        v1_14_address0 =  (sc_lv<8>) (zext_ln402_31_fu_11828_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state678.read())) {
        v1_14_address0 = v1_14_addr_1_reg_18434.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state671.read())) {
        v1_14_address0 =  (sc_lv<8>) (zext_ln402_15_fu_11283_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state591.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state598.read()))) {
        v1_14_address0 = v1_14_addr_reg_18106.read();
    } else {
        v1_14_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_14_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_14_address1 = v1_14_addr_10_reg_20051_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_14_address1 = v1_14_addr_8_reg_19731_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_14_address1 = v1_14_addr_6_reg_19405_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_14_address1 = v1_14_addr_4_reg_19147_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_14_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_14_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_14_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_14_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_14_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_14_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state671.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state751.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state831.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state591.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state598.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state678.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state758.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state838.read()))) {
        v1_14_ce0 = ap_const_logic_1;
    } else {
        v1_14_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_14_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_14_ce1 = ap_const_logic_1;
    } else {
        v1_14_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_14_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_14_d0 = v88_1_61_reg_20411.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_14_d0 = v88_0_61_reg_20351.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_14_d0 = reg_8168.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state678.read())) {
        v1_14_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state598.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state758.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state838.read()))) {
        v1_14_d0 = reg_7438.read();
    } else {
        v1_14_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_14_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_14_d1 = reg_8272.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_14_d1 = reg_8064.read();
    } else {
        v1_14_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_14_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state598.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state678.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state758.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state838.read()))) {
        v1_14_we0 = ap_const_logic_1;
    } else {
        v1_14_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_14_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_14_we1 = ap_const_logic_1;
    } else {
        v1_14_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_15_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_15_address0 = v1_15_addr_11_reg_20136_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_15_address0 = v1_15_addr_9_reg_19816_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_15_address0 = v1_15_addr_7_reg_19490_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_15_address0 = v1_15_addr_5_reg_19249_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_15_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_15_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_15_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_15_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state843.read())) {
        v1_15_address0 = v1_15_addr_3_reg_18909.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state836.read())) {
        v1_15_address0 =  (sc_lv<8>) (zext_ln402_48_fu_12372_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state763.read())) {
        v1_15_address0 = v1_15_addr_2_reg_18684.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state756.read())) {
        v1_15_address0 =  (sc_lv<8>) (zext_ln402_32_fu_11862_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state683.read())) {
        v1_15_address0 = v1_15_addr_1_reg_18449.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state676.read())) {
        v1_15_address0 =  (sc_lv<8>) (zext_ln402_16_fu_11317_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state591.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state598.read()))) {
        v1_15_address0 = v1_15_addr_reg_18111.read();
    } else {
        v1_15_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_15_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_15_address1 = v1_15_addr_10_reg_20056_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_15_address1 = v1_15_addr_8_reg_19736_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_15_address1 = v1_15_addr_6_reg_19410_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_15_address1 = v1_15_addr_4_reg_19153_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_15_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_15_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_15_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_15_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_15_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_15_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state676.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state756.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state836.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state591.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state598.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state683.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state763.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state843.read()))) {
        v1_15_ce0 = ap_const_logic_1;
    } else {
        v1_15_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_15_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_15_ce1 = ap_const_logic_1;
    } else {
        v1_15_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_15_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_15_d0 = v88_1_62_reg_20416.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_15_d0 = v88_0_62_reg_20356.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_15_d0 = reg_8174.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state763.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state843.read()))) {
        v1_15_d0 = reg_7438.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state683.read())) {
        v1_15_d0 = reg_7481.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state598.read())) {
        v1_15_d0 = reg_7564.read();
    } else {
        v1_15_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_15_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_15_d1 = reg_8278.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_15_d1 = reg_8070.read();
    } else {
        v1_15_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_15_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state598.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state683.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state763.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state843.read()))) {
        v1_15_we0 = ap_const_logic_1;
    } else {
        v1_15_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_15_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_15_we1 = ap_const_logic_1;
    } else {
        v1_15_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_1_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_1_address0 = v1_1_addr_11_reg_20066_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_1_address0 = v1_1_addr_9_reg_19746_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_1_address0 = v1_1_addr_7_reg_19420_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_1_address0 = v1_1_addr_5_reg_19165_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_1_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_1_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_1_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_1_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state773.read())) {
        v1_1_address0 = v1_1_addr_3_reg_18699.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state766.read())) {
        v1_1_address0 =  (sc_lv<8>) (zext_ln402_34_fu_11896_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state693.read())) {
        v1_1_address0 = v1_1_addr_2_reg_18464.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state686.read())) {
        v1_1_address0 =  (sc_lv<8>) (zext_ln402_18_fu_11351_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state613.read())) {
        v1_1_address0 = v1_1_addr_1_reg_18229.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state606.read())) {
        v1_1_address0 =  (sc_lv<8>) (zext_ln402_2_fu_10806_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state533.read())) {
        v1_1_address0 = v1_1_addr_reg_17987.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state526.read())) {
        v1_1_address0 =  (sc_lv<8>) (zext_ln402_reg_17958.read());
    } else {
        v1_1_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_1_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_1_address1 = v1_1_addr_10_reg_19986_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_1_address1 = v1_1_addr_8_reg_19666_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_1_address1 = v1_1_addr_6_reg_19340_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_1_address1 = v1_1_addr_4_reg_19069_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_1_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_1_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_1_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_1_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_1_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_1_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state526.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state606.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state686.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state766.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state533.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state613.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state693.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state773.read()))) {
        v1_1_ce0 = ap_const_logic_1;
    } else {
        v1_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_1_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_1_ce1 = ap_const_logic_1;
    } else {
        v1_1_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_1_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_1_d0 = reg_8319.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_1_d0 = reg_8291.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_1_d0 = reg_8084.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state773.read())) {
        v1_1_d0 = reg_7438.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state613.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state693.read()))) {
        v1_1_d0 = reg_7481.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state533.read())) {
        v1_1_d0 = reg_7375.read();
    } else {
        v1_1_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_1_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_1_d1 = reg_8188.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_1_d1 = reg_7980.read();
    } else {
        v1_1_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_1_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state533.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state613.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state693.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state773.read()))) {
        v1_1_we0 = ap_const_logic_1;
    } else {
        v1_1_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_1_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_1_we1 = ap_const_logic_1;
    } else {
        v1_1_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_2_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_2_address0 = v1_2_addr_11_reg_20071_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_2_address0 = v1_2_addr_9_reg_19751_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_2_address0 = v1_2_addr_7_reg_19425_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_2_address0 = v1_2_addr_5_reg_19171_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_2_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_2_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_2_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_2_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state778.read())) {
        v1_2_address0 = v1_2_addr_3_reg_18714.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state771.read())) {
        v1_2_address0 =  (sc_lv<8>) (zext_ln402_35_fu_11930_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state698.read())) {
        v1_2_address0 = v1_2_addr_2_reg_18479.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state691.read())) {
        v1_2_address0 =  (sc_lv<8>) (zext_ln402_19_fu_11385_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state618.read())) {
        v1_2_address0 = v1_2_addr_1_reg_18244.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state611.read())) {
        v1_2_address0 =  (sc_lv<8>) (zext_ln402_3_fu_10840_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state538.read())) {
        v1_2_address0 = v1_2_addr_reg_17997.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state531.read())) {
        v1_2_address0 =  (sc_lv<8>) (zext_ln402_reg_17958.read());
    } else {
        v1_2_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_2_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_2_address1 = v1_2_addr_10_reg_19991_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_2_address1 = v1_2_addr_8_reg_19671_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_2_address1 = v1_2_addr_6_reg_19345_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_2_address1 = v1_2_addr_4_reg_19075_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_2_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_2_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_2_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_2_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_2_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_2_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state531.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state611.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state691.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state771.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state538.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state618.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state698.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state778.read()))) {
        v1_2_ce0 = ap_const_logic_1;
    } else {
        v1_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_2_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_2_ce1 = ap_const_logic_1;
    } else {
        v1_2_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_2_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_2_d0 = reg_8326.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_2_d0 = reg_8298.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_2_d0 = reg_8092.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state618.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state698.read()))) {
        v1_2_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state538.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state778.read()))) {
        v1_2_d0 = reg_7438.read();
    } else {
        v1_2_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_2_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_2_d1 = reg_8196.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_2_d1 = reg_7988.read();
    } else {
        v1_2_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_2_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state538.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state618.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state698.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state778.read()))) {
        v1_2_we0 = ap_const_logic_1;
    } else {
        v1_2_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_2_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_2_we1 = ap_const_logic_1;
    } else {
        v1_2_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_3_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_3_address0 = v1_3_addr_11_reg_20076_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_3_address0 = v1_3_addr_9_reg_19756_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_3_address0 = v1_3_addr_7_reg_19430_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_3_address0 = v1_3_addr_5_reg_19177_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_3_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_3_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_3_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_3_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state783.read())) {
        v1_3_address0 = v1_3_addr_3_reg_18729.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state776.read())) {
        v1_3_address0 =  (sc_lv<8>) (zext_ln402_36_fu_11964_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state703.read())) {
        v1_3_address0 = v1_3_addr_2_reg_18494.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state696.read())) {
        v1_3_address0 =  (sc_lv<8>) (zext_ln402_20_fu_11419_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state623.read())) {
        v1_3_address0 = v1_3_addr_1_reg_18259.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state616.read())) {
        v1_3_address0 =  (sc_lv<8>) (zext_ln402_4_fu_10874_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state543.read())) {
        v1_3_address0 = v1_3_addr_reg_18007.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state536.read())) {
        v1_3_address0 =  (sc_lv<8>) (zext_ln402_reg_17958.read());
    } else {
        v1_3_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_3_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_3_address1 = v1_3_addr_10_reg_19996_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_3_address1 = v1_3_addr_8_reg_19676_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_3_address1 = v1_3_addr_6_reg_19350_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_3_address1 = v1_3_addr_4_reg_19081_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_3_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_3_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_3_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_3_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_3_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_3_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state536.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state616.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state696.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state776.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state543.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state623.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state703.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state783.read()))) {
        v1_3_ce0 = ap_const_logic_1;
    } else {
        v1_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_3_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_3_ce1 = ap_const_logic_1;
    } else {
        v1_3_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_3_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_3_d0 = reg_8333.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_3_d0 = reg_8305.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_3_d0 = reg_8100.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state623.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state703.read()))) {
        v1_3_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state543.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state783.read()))) {
        v1_3_d0 = reg_7438.read();
    } else {
        v1_3_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_3_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_3_d1 = reg_8204.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_3_d1 = reg_7996.read();
    } else {
        v1_3_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_3_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state543.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state623.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state703.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state783.read()))) {
        v1_3_we0 = ap_const_logic_1;
    } else {
        v1_3_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_3_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_3_we1 = ap_const_logic_1;
    } else {
        v1_3_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_4_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_4_address0 = v1_4_addr_11_reg_20081_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_4_address0 = v1_4_addr_9_reg_19761_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_4_address0 = v1_4_addr_7_reg_19435_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_4_address0 = v1_4_addr_5_reg_19183_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_4_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_4_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_4_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_4_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state788.read())) {
        v1_4_address0 = v1_4_addr_3_reg_18744.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state781.read())) {
        v1_4_address0 =  (sc_lv<8>) (zext_ln402_37_fu_11998_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state708.read())) {
        v1_4_address0 = v1_4_addr_2_reg_18509.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state701.read())) {
        v1_4_address0 =  (sc_lv<8>) (zext_ln402_21_fu_11453_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state628.read())) {
        v1_4_address0 = v1_4_addr_1_reg_18274.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state621.read())) {
        v1_4_address0 =  (sc_lv<8>) (zext_ln402_5_fu_10908_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state548.read())) {
        v1_4_address0 = v1_4_addr_reg_18024.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state541.read())) {
        v1_4_address0 =  (sc_lv<8>) (zext_ln402_reg_17958.read());
    } else {
        v1_4_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_4_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_4_address1 = v1_4_addr_10_reg_20001_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_4_address1 = v1_4_addr_8_reg_19681_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_4_address1 = v1_4_addr_6_reg_19355_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_4_address1 = v1_4_addr_4_reg_19087_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_4_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_4_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_4_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_4_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_4_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_4_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state541.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state621.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state701.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state781.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state548.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state628.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state708.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state788.read()))) {
        v1_4_ce0 = ap_const_logic_1;
    } else {
        v1_4_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_4_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_4_ce1 = ap_const_logic_1;
    } else {
        v1_4_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_4_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_4_d0 = v88_1_51_reg_20361.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_4_d0 = v88_0_51_reg_20301.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_4_d0 = reg_8108.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state628.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state708.read()))) {
        v1_4_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state548.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state788.read()))) {
        v1_4_d0 = reg_7438.read();
    } else {
        v1_4_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_4_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_4_d1 = reg_8212.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_4_d1 = reg_8004.read();
    } else {
        v1_4_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_4_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state548.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state628.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state708.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state788.read()))) {
        v1_4_we0 = ap_const_logic_1;
    } else {
        v1_4_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_4_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_4_we1 = ap_const_logic_1;
    } else {
        v1_4_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_5_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_5_address0 = v1_5_addr_11_reg_20086_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_5_address0 = v1_5_addr_9_reg_19766_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_5_address0 = v1_5_addr_7_reg_19440_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_5_address0 = v1_5_addr_5_reg_19189_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_5_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_5_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_5_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_5_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state793.read())) {
        v1_5_address0 = v1_5_addr_3_reg_18759.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state786.read())) {
        v1_5_address0 =  (sc_lv<8>) (zext_ln402_38_fu_12032_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state713.read())) {
        v1_5_address0 = v1_5_addr_2_reg_18524.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state706.read())) {
        v1_5_address0 =  (sc_lv<8>) (zext_ln402_22_fu_11487_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state633.read())) {
        v1_5_address0 = v1_5_addr_1_reg_18289.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state626.read())) {
        v1_5_address0 =  (sc_lv<8>) (zext_ln402_6_fu_10942_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state553.read())) {
        v1_5_address0 = v1_5_addr_reg_18034.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state546.read())) {
        v1_5_address0 =  (sc_lv<8>) (zext_ln402_reg_17958.read());
    } else {
        v1_5_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_5_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_5_address1 = v1_5_addr_10_reg_20006_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_5_address1 = v1_5_addr_8_reg_19686_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_5_address1 = v1_5_addr_6_reg_19360_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_5_address1 = v1_5_addr_4_reg_19093_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_5_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_5_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_5_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_5_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_5_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_5_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state546.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state626.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state706.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state786.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state553.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state633.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state713.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state793.read()))) {
        v1_5_ce0 = ap_const_logic_1;
    } else {
        v1_5_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_5_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_5_ce1 = ap_const_logic_1;
    } else {
        v1_5_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_5_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_5_d0 = v88_1_52_reg_20366.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_5_d0 = v88_0_52_reg_20306.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_5_d0 = reg_8114.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state633.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state713.read()))) {
        v1_5_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state553.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state793.read()))) {
        v1_5_d0 = reg_7438.read();
    } else {
        v1_5_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_5_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_5_d1 = reg_8218.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_5_d1 = reg_8010.read();
    } else {
        v1_5_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_5_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state553.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state633.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state713.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state793.read()))) {
        v1_5_we0 = ap_const_logic_1;
    } else {
        v1_5_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_5_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_5_we1 = ap_const_logic_1;
    } else {
        v1_5_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_6_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_6_address0 = v1_6_addr_11_reg_20091_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_6_address0 = v1_6_addr_9_reg_19771_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_6_address0 = v1_6_addr_7_reg_19445_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_6_address0 = v1_6_addr_5_reg_19195_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_6_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_6_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_6_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_6_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state798.read())) {
        v1_6_address0 = v1_6_addr_3_reg_18774.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state791.read())) {
        v1_6_address0 =  (sc_lv<8>) (zext_ln402_39_fu_12066_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state718.read())) {
        v1_6_address0 = v1_6_addr_2_reg_18539.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state711.read())) {
        v1_6_address0 =  (sc_lv<8>) (zext_ln402_23_fu_11521_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state638.read())) {
        v1_6_address0 = v1_6_addr_1_reg_18304.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state631.read())) {
        v1_6_address0 =  (sc_lv<8>) (zext_ln402_7_fu_10976_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state558.read())) {
        v1_6_address0 = v1_6_addr_reg_18044.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state551.read())) {
        v1_6_address0 =  (sc_lv<8>) (zext_ln402_reg_17958.read());
    } else {
        v1_6_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_6_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_6_address1 = v1_6_addr_10_reg_20011_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_6_address1 = v1_6_addr_8_reg_19691_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_6_address1 = v1_6_addr_6_reg_19365_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_6_address1 = v1_6_addr_4_reg_19099_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_6_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_6_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_6_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_6_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_6_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_6_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state638.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state718.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state551.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state631.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state711.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state791.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state558.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state798.read()))) {
        v1_6_ce0 = ap_const_logic_1;
    } else {
        v1_6_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_6_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_6_ce1 = ap_const_logic_1;
    } else {
        v1_6_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_6_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_6_d0 = v88_1_53_reg_20371.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_6_d0 = v88_0_53_reg_20311.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_6_d0 = reg_8120.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state638.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state718.read()))) {
        v1_6_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state558.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state798.read()))) {
        v1_6_d0 = reg_7438.read();
    } else {
        v1_6_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_6_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_6_d1 = reg_8224.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_6_d1 = reg_8016.read();
    } else {
        v1_6_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_6_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state638.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state718.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state558.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state798.read()))) {
        v1_6_we0 = ap_const_logic_1;
    } else {
        v1_6_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_6_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_6_we1 = ap_const_logic_1;
    } else {
        v1_6_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_7_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_7_address0 = v1_7_addr_11_reg_20096_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_7_address0 = v1_7_addr_9_reg_19776_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_7_address0 = v1_7_addr_7_reg_19450_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_7_address0 = v1_7_addr_5_reg_19201_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_7_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_7_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_7_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_7_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state803.read())) {
        v1_7_address0 = v1_7_addr_3_reg_18789.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state796.read())) {
        v1_7_address0 =  (sc_lv<8>) (zext_ln402_40_fu_12100_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state723.read())) {
        v1_7_address0 = v1_7_addr_2_reg_18554.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state716.read())) {
        v1_7_address0 =  (sc_lv<8>) (zext_ln402_24_fu_11555_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state643.read())) {
        v1_7_address0 = v1_7_addr_1_reg_18319.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state636.read())) {
        v1_7_address0 =  (sc_lv<8>) (zext_ln402_8_fu_11010_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state563.read())) {
        v1_7_address0 = v1_7_addr_reg_18054.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state556.read())) {
        v1_7_address0 =  (sc_lv<8>) (zext_ln402_reg_17958.read());
    } else {
        v1_7_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_7_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_7_address1 = v1_7_addr_10_reg_20016_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_7_address1 = v1_7_addr_8_reg_19696_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_7_address1 = v1_7_addr_6_reg_19370_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_7_address1 = v1_7_addr_4_reg_19105_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_7_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_7_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_7_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_7_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_7_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_7_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state643.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state723.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state556.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state636.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state716.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state796.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state563.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state803.read()))) {
        v1_7_ce0 = ap_const_logic_1;
    } else {
        v1_7_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_7_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_7_ce1 = ap_const_logic_1;
    } else {
        v1_7_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_7_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_7_d0 = v88_1_54_reg_20376.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_7_d0 = v88_0_54_reg_20316.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_7_d0 = reg_8126.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state643.read())) {
        v1_7_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state723.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state563.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state803.read()))) {
        v1_7_d0 = reg_7438.read();
    } else {
        v1_7_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_7_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_7_d1 = reg_8230.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_7_d1 = reg_8022.read();
    } else {
        v1_7_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_7_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state643.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state723.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state563.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state803.read()))) {
        v1_7_we0 = ap_const_logic_1;
    } else {
        v1_7_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_7_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_7_we1 = ap_const_logic_1;
    } else {
        v1_7_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_8_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_8_address0 = v1_8_addr_11_reg_20101_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_8_address0 = v1_8_addr_9_reg_19781_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_8_address0 = v1_8_addr_7_reg_19455_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_8_address0 = v1_8_addr_5_reg_19207_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_8_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_8_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_8_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_8_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state808.read())) {
        v1_8_address0 = v1_8_addr_3_reg_18804.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state801.read())) {
        v1_8_address0 =  (sc_lv<8>) (zext_ln402_41_fu_12134_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state728.read())) {
        v1_8_address0 = v1_8_addr_2_reg_18579.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state721.read())) {
        v1_8_address0 =  (sc_lv<8>) (zext_ln402_25_fu_11624_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state648.read())) {
        v1_8_address0 = v1_8_addr_1_reg_18344.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state641.read())) {
        v1_8_address0 =  (sc_lv<8>) (zext_ln402_9_fu_11079_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state568.read())) {
        v1_8_address0 = v1_8_addr_reg_18071.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state561.read())) {
        v1_8_address0 =  (sc_lv<8>) (zext_ln402_reg_17958.read());
    } else {
        v1_8_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_8_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_8_address1 = v1_8_addr_10_reg_20021_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_8_address1 = v1_8_addr_8_reg_19701_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_8_address1 = v1_8_addr_6_reg_19375_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_8_address1 = v1_8_addr_4_reg_19111_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_8_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_8_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_8_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_8_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_8_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_8_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state648.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state728.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state561.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state641.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state721.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state801.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state568.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state808.read()))) {
        v1_8_ce0 = ap_const_logic_1;
    } else {
        v1_8_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_8_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_8_ce1 = ap_const_logic_1;
    } else {
        v1_8_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_8_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_8_d0 = v88_1_55_reg_20381.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_8_d0 = v88_0_55_reg_20321.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_8_d0 = reg_8132.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state648.read())) {
        v1_8_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state728.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state568.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state808.read()))) {
        v1_8_d0 = reg_7438.read();
    } else {
        v1_8_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_8_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_8_d1 = reg_8236.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_8_d1 = reg_8028.read();
    } else {
        v1_8_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_8_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state648.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state728.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state568.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state808.read()))) {
        v1_8_we0 = ap_const_logic_1;
    } else {
        v1_8_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_8_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_8_we1 = ap_const_logic_1;
    } else {
        v1_8_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_9_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_9_address0 = v1_9_addr_11_reg_20106_pp4_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_9_address0 = v1_9_addr_9_reg_19786_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_9_address0 = v1_9_addr_7_reg_19460_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_9_address0 = v1_9_addr_5_reg_19213_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_9_address0 =  (sc_lv<8>) (zext_ln443_7_fu_12639_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_9_address0 =  (sc_lv<8>) (zext_ln443_5_fu_12589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_9_address0 =  (sc_lv<8>) (zext_ln443_3_fu_12530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_9_address0 =  (sc_lv<8>) (zext_ln443_fu_12454_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state813.read())) {
        v1_9_address0 = v1_9_addr_3_reg_18819.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state806.read())) {
        v1_9_address0 =  (sc_lv<8>) (zext_ln402_42_fu_12168_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state733.read())) {
        v1_9_address0 = v1_9_addr_2_reg_18594.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state726.read())) {
        v1_9_address0 =  (sc_lv<8>) (zext_ln402_26_fu_11658_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state653.read())) {
        v1_9_address0 = v1_9_addr_1_reg_18359.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state646.read())) {
        v1_9_address0 =  (sc_lv<8>) (zext_ln402_10_fu_11113_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state566.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state573.read()))) {
        v1_9_address0 = v1_9_addr_reg_18081.read();
    } else {
        v1_9_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_9_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0))) {
        v1_9_address1 = v1_9_addr_10_reg_20026_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0))) {
        v1_9_address1 = v1_9_addr_8_reg_19706_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_9_address1 = v1_9_addr_6_reg_19380_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0))) {
        v1_9_address1 = v1_9_addr_4_reg_19117_pp4_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage3.read(), ap_const_boolean_0))) {
        v1_9_address1 =  (sc_lv<8>) (zext_ln443_6_fu_12614_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage2.read(), ap_const_boolean_0))) {
        v1_9_address1 =  (sc_lv<8>) (zext_ln443_4_fu_12563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage1.read(), ap_const_boolean_0))) {
        v1_9_address1 =  (sc_lv<8>) (zext_ln443_2_fu_12505_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage0.read(), ap_const_boolean_0))) {
        v1_9_address1 =  (sc_lv<8>) (zext_ln443_1_fu_12480_p1.read());
    } else {
        v1_9_address1 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v1_9_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state566.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state646.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state726.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state806.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state573.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state653.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state733.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state813.read()))) {
        v1_9_ce0 = ap_const_logic_1;
    } else {
        v1_9_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_9_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter0.read())))) {
        v1_9_ce1 = ap_const_logic_1;
    } else {
        v1_9_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_9_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()))) {
        v1_9_d0 = v88_1_56_reg_20386.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_9_d0 = v88_0_56_reg_20326.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)))) {
        v1_9_d0 = reg_8138.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state653.read())) {
        v1_9_d0 = reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state573.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state733.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state813.read()))) {
        v1_9_d0 = reg_7438.read();
    } else {
        v1_9_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_9_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp4_stage5.read(), ap_const_boolean_0))) {
        v1_9_d1 = reg_8242.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp4_stage7.read(), ap_const_boolean_0)))) {
        v1_9_d1 = reg_8034.read();
    } else {
        v1_9_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v1_9_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter5_reg.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state573.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state653.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state733.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state813.read()))) {
        v1_9_we0 = ap_const_logic_1;
    } else {
        v1_9_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v1_9_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp4_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln438_reg_19043_pp4_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp4_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp4_stage7_11001.read(), ap_const_boolean_0)))) {
        v1_9_we1 = ap_const_logic_1;
    } else {
        v1_9_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_0_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()))) {
        v2_0_address0 = v2_0_addr_6_reg_21780.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_0_address0 = v2_0_addr_5_reg_21700.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_0_address0 = v2_0_addr_4_reg_21620.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_0_address0 =  (sc_lv<4>) (zext_ln514_36_fu_14690_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()))) {
        v2_0_address0 = v2_0_addr_3_reg_21540.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()))) {
        v2_0_address0 = v2_0_addr_2_reg_21460.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_0_address0 = v2_0_addr_1_reg_21380.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_0_address0 =  (sc_lv<4>) (zext_ln514_fu_13437_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage28.read(), ap_const_boolean_0))) {
        v2_0_address0 = v2_0_addr_8_reg_21178.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0))) {
        v2_0_address0 =  (sc_lv<4>) (zext_ln475_5_fu_13310_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage20.read(), ap_const_boolean_0))) {
        v2_0_address0 = v2_0_addr_7_reg_21014.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0))) {
        v2_0_address0 =  (sc_lv<4>) (zext_ln475_2_fu_13268_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage12.read(), ap_const_boolean_0))) {
        v2_0_address0 = v2_0_addr_reg_20743.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_0_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_0_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_0_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage20_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage28_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_0_ce0 = ap_const_logic_1;
    } else {
        v2_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_0_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_0_d0 = grp_fu_7205_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage28.read(), ap_const_boolean_0))) {
        v2_0_d0 = reg_7375.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage20.read(), ap_const_boolean_0)))) {
        v2_0_d0 = reg_7343.read();
    } else {
        v2_0_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_0_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage12_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_reg_20739.read(), ap_const_lv4_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage20_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_3) && 
          !esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_7) && 
          !esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_B)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage28_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(ap_const_lv4_2, trunc_ln475_2_reg_20880.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_6, trunc_ln475_2_reg_20880.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_A, trunc_ln475_2_reg_20880.read())))) {
        v2_0_we0 = ap_const_logic_1;
    } else {
        v2_0_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_10_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_10_address0 = v2_10_addr_5_reg_21830.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_10_address0 =  (sc_lv<4>) (zext_ln514_67_fu_15770_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_10_address0 = v2_10_addr_4_reg_21750.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_10_address0 =  (sc_lv<4>) (zext_ln514_54_fu_15314_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_10_address0 = v2_10_addr_3_reg_21670.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_10_address0 =  (sc_lv<4>) (zext_ln514_43_fu_14931_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_10_address0 = v2_10_addr_2_reg_21590.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_10_address0 =  (sc_lv<4>) (zext_ln514_31_fu_14522_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_10_address0 = v2_10_addr_1_reg_21510.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_10_address0 =  (sc_lv<4>) (zext_ln514_18_fu_14066_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_10_address0 = v2_10_addr_reg_21430.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_10_address0 =  (sc_lv<4>) (zext_ln514_7_fu_13681_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage30.read(), ap_const_boolean_0))) {
        v2_10_address0 = v2_10_addr_8_reg_21253.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0))) {
        v2_10_address0 =  (sc_lv<4>) (zext_ln475_7_fu_13332_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_10_address0 = v2_10_addr_7_reg_21089.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0))) {
        v2_10_address0 =  (sc_lv<4>) (zext_ln475_4_fu_13290_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_10_address0 = v2_10_addr_6_reg_20811.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_10_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_10_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_10_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage30_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_10_ce0 = ap_const_logic_1;
    } else {
        v2_10_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_10_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_10_d0 = grp_fu_7245_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage30.read(), ap_const_boolean_0))) {
        v2_10_d0 = reg_7731.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_10_d0 = reg_7438.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_10_d0 = reg_7417.read();
    } else {
        v2_10_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_10_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_A, trunc_ln475_2_reg_20880.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(or_ln475_1_reg_20797.read(), ap_const_lv4_A)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage30_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_9, trunc_ln475_3_reg_20950.read())))) {
        v2_10_we0 = ap_const_logic_1;
    } else {
        v2_10_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_11_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_11_address0 = v2_11_addr_5_reg_21835.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_11_address0 =  (sc_lv<4>) (zext_ln514_67_fu_15770_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_11_address0 = v2_11_addr_4_reg_21755.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_11_address0 =  (sc_lv<4>) (zext_ln514_55_fu_15362_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_11_address0 = v2_11_addr_3_reg_21675.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_11_address0 =  (sc_lv<4>) (zext_ln514_44_fu_14956_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_11_address0 = v2_11_addr_2_reg_21595.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_11_address0 =  (sc_lv<4>) (zext_ln514_31_fu_14522_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_11_address0 = v2_11_addr_1_reg_21515.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_11_address0 =  (sc_lv<4>) (zext_ln514_19_fu_14114_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_11_address0 = v2_11_addr_reg_21435.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_11_address0 =  (sc_lv<4>) (zext_ln514_8_fu_13706_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage31.read(), ap_const_boolean_0))) {
        v2_11_address0 = v2_11_addr_8_reg_21293.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage24.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage24.read(), ap_const_boolean_0))) {
        v2_11_address0 =  (sc_lv<4>) (zext_ln475_8_fu_13343_p1.read());
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage16.read(), ap_const_boolean_0)))) {
        v2_11_address0 = v2_11_addr_7_reg_21109.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0))) {
        v2_11_address0 = v2_11_addr_6_reg_20840.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_11_address0 =  (sc_lv<4>) (zext_ln475_1_fu_12961_p1.read());
    } else {
        v2_11_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_11_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage31_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage24_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_11_ce0 = ap_const_logic_1;
    } else {
        v2_11_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_11_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_11_d0 = grp_fu_7249_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage31.read(), ap_const_boolean_0))) {
        v2_11_d0 = reg_7767.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0)))) {
        v2_11_d0 = reg_7731.read();
    } else {
        v2_11_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_11_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_B)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,4,4>(ap_const_lv4_B, or_ln475_2_reg_21139.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage31_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_9, trunc_ln475_3_reg_20950.read())))) {
        v2_11_we0 = ap_const_logic_1;
    } else {
        v2_11_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_12_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_12_address0 = v2_12_addr_6_reg_21840.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_12_address0 =  (sc_lv<4>) (zext_ln514_68_fu_15796_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_12_address0 = v2_12_addr_5_reg_21760.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_12_address0 =  (sc_lv<4>) (zext_ln514_56_fu_15387_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_12_address0 = v2_12_addr_4_reg_21680.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_12_address0 =  (sc_lv<4>) (zext_ln514_45_fu_15002_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_12_address0 = v2_12_addr_3_reg_21600.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_12_address0 =  (sc_lv<4>) (zext_ln514_32_fu_14548_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_12_address0 = v2_12_addr_2_reg_21520.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_12_address0 =  (sc_lv<4>) (zext_ln514_20_fu_14139_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_12_address0 = v2_12_addr_1_reg_21440.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_12_address0 =  (sc_lv<4>) (zext_ln514_9_fu_13753_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage28.read(), ap_const_boolean_0))) {
        v2_12_address0 = v2_12_addr_8_reg_21173.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0))) {
        v2_12_address0 =  (sc_lv<4>) (zext_ln475_5_fu_13310_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage20.read(), ap_const_boolean_0))) {
        v2_12_address0 = v2_12_addr_7_reg_21009.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0))) {
        v2_12_address0 =  (sc_lv<4>) (zext_ln475_2_fu_13268_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage12.read(), ap_const_boolean_0))) {
        v2_12_address0 = v2_12_addr_reg_20758.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_12_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_12_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_12_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage20_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage28_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_12_ce0 = ap_const_logic_1;
    } else {
        v2_12_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_12_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_12_d0 = grp_fu_7253_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage28.read(), ap_const_boolean_0))) {
        v2_12_d0 = reg_7375.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage20.read(), ap_const_boolean_0)))) {
        v2_12_d0 = reg_7343.read();
    } else {
        v2_12_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_12_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage12_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(trunc_ln475_reg_20739.read(), ap_const_lv4_0) && 
          !esl_seteq<1,4,4>(trunc_ln475_reg_20739.read(), ap_const_lv4_4) && 
          !esl_seteq<1,4,4>(trunc_ln475_reg_20739.read(), ap_const_lv4_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage20_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_B)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage28_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_A, trunc_ln475_2_reg_20880.read())))) {
        v2_12_we0 = ap_const_logic_1;
    } else {
        v2_12_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_13_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_13_address0 = v2_13_addr_5_reg_21845.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_13_address0 =  (sc_lv<4>) (zext_ln514_69_fu_15842_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_13_address0 = v2_13_addr_4_reg_21765.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_13_address0 =  (sc_lv<4>) (zext_ln514_57_fu_15412_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_13_address0 = v2_13_addr_3_reg_21685.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_13_address0 =  (sc_lv<4>) (zext_ln514_45_fu_15002_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_13_address0 = v2_13_addr_2_reg_21605.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_13_address0 =  (sc_lv<4>) (zext_ln514_33_fu_14594_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_13_address0 = v2_13_addr_1_reg_21525.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_13_address0 =  (sc_lv<4>) (zext_ln514_21_fu_14164_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_13_address0 = v2_13_addr_reg_21445.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_13_address0 =  (sc_lv<4>) (zext_ln514_9_fu_13753_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage29.read(), ap_const_boolean_0))) {
        v2_13_address0 = v2_13_addr_8_reg_21218.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_13_address0 =  (sc_lv<4>) (zext_ln475_6_fu_13321_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0))) {
        v2_13_address0 = v2_13_addr_7_reg_21049.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_13_address0 =  (sc_lv<4>) (zext_ln475_3_fu_13279_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0))) {
        v2_13_address0 = v2_13_addr_6_reg_20787.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_13_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_13_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_13_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage29_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_13_ce0 = ap_const_logic_1;
    } else {
        v2_13_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_13_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_13_d0 = grp_fu_7257_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage29.read(), ap_const_boolean_0))) {
        v2_13_d0 = reg_7417.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0)))) {
        v2_13_d0 = reg_7375.read();
    } else {
        v2_13_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_13_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(or_ln475_reg_20768.read(), ap_const_lv4_1) && 
          !esl_seteq<1,4,4>(or_ln475_reg_20768.read(), ap_const_lv4_5) && 
          !esl_seteq<1,4,4>(or_ln475_reg_20768.read(), ap_const_lv4_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_B)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage29_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(ap_const_lv4_1, trunc_ln475_3_reg_20950.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_5, trunc_ln475_3_reg_20950.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_9, trunc_ln475_3_reg_20950.read())))) {
        v2_13_we0 = ap_const_logic_1;
    } else {
        v2_13_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_14_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_14_address0 = v2_14_addr_5_reg_21850.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_14_address0 =  (sc_lv<4>) (zext_ln514_70_fu_15867_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_14_address0 = v2_14_addr_4_reg_21770.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_14_address0 =  (sc_lv<4>) (zext_ln514_58_fu_15458_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_14_address0 = v2_14_addr_3_reg_21690.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_14_address0 =  (sc_lv<4>) (zext_ln514_45_fu_15002_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_14_address0 = v2_14_addr_2_reg_21610.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_14_address0 =  (sc_lv<4>) (zext_ln514_34_fu_14619_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_14_address0 = v2_14_addr_1_reg_21530.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_14_address0 =  (sc_lv<4>) (zext_ln514_22_fu_14210_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_14_address0 = v2_14_addr_reg_21450.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_14_address0 =  (sc_lv<4>) (zext_ln514_9_fu_13753_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage30.read(), ap_const_boolean_0))) {
        v2_14_address0 = v2_14_addr_8_reg_21258.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0))) {
        v2_14_address0 =  (sc_lv<4>) (zext_ln475_7_fu_13332_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_14_address0 = v2_14_addr_7_reg_21094.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0))) {
        v2_14_address0 =  (sc_lv<4>) (zext_ln475_4_fu_13290_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_14_address0 = v2_14_addr_6_reg_20816.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_14_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_14_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_14_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage30_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_14_ce0 = ap_const_logic_1;
    } else {
        v2_14_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_14_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_14_d0 = grp_fu_7261_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage30.read(), ap_const_boolean_0))) {
        v2_14_d0 = reg_7731.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_14_d0 = reg_7438.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_14_d0 = reg_7417.read();
    } else {
        v2_14_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_14_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(ap_const_lv4_2, trunc_ln475_2_reg_20880.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_6, trunc_ln475_2_reg_20880.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_A, trunc_ln475_2_reg_20880.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(or_ln475_1_reg_20797.read(), ap_const_lv4_2) && 
          !esl_seteq<1,4,4>(or_ln475_1_reg_20797.read(), ap_const_lv4_6) && 
          !esl_seteq<1,4,4>(or_ln475_1_reg_20797.read(), ap_const_lv4_A)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage30_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(ap_const_lv4_1, trunc_ln475_3_reg_20950.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_5, trunc_ln475_3_reg_20950.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_9, trunc_ln475_3_reg_20950.read())))) {
        v2_14_we0 = ap_const_logic_1;
    } else {
        v2_14_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_15_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_15_address0 = v2_15_addr_5_reg_21855.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_15_address0 =  (sc_lv<4>) (zext_ln514_71_fu_15892_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_15_address0 = v2_15_addr_4_reg_21775.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_15_address0 =  (sc_lv<4>) (zext_ln514_58_fu_15458_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_15_address0 = v2_15_addr_3_reg_21695.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_15_address0 =  (sc_lv<4>) (zext_ln514_46_fu_15050_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_15_address0 = v2_15_addr_2_reg_21615.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_15_address0 =  (sc_lv<4>) (zext_ln514_35_fu_14644_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_15_address0 = v2_15_addr_1_reg_21535.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_15_address0 =  (sc_lv<4>) (zext_ln514_22_fu_14210_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_15_address0 = v2_15_addr_reg_21455.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_15_address0 =  (sc_lv<4>) (zext_ln514_10_fu_13802_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage31.read(), ap_const_boolean_0))) {
        v2_15_address0 = v2_15_addr_8_reg_21298.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage24.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage24.read(), ap_const_boolean_0))) {
        v2_15_address0 =  (sc_lv<4>) (zext_ln475_8_fu_13343_p1.read());
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage16.read(), ap_const_boolean_0)))) {
        v2_15_address0 = v2_15_addr_7_reg_21114.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0))) {
        v2_15_address0 = v2_15_addr_6_reg_20845.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_15_address0 =  (sc_lv<4>) (zext_ln475_1_fu_12961_p1.read());
    } else {
        v2_15_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_15_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage31_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage24_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_15_ce0 = ap_const_logic_1;
    } else {
        v2_15_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_15_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_15_d0 = grp_fu_7265_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage31.read(), ap_const_boolean_0))) {
        v2_15_d0 = reg_7767.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0)))) {
        v2_15_d0 = reg_7731.read();
    } else {
        v2_15_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_15_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_3) && 
          !esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_7) && 
          !esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_B)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_3, or_ln475_2_reg_21139.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_7, or_ln475_2_reg_21139.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_B, or_ln475_2_reg_21139.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage31_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(ap_const_lv4_1, trunc_ln475_3_reg_20950.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_5, trunc_ln475_3_reg_20950.read()) && 
          !esl_seteq<1,4,4>(ap_const_lv4_9, trunc_ln475_3_reg_20950.read())))) {
        v2_15_we0 = ap_const_logic_1;
    } else {
        v2_15_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_1_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_1_address0 = v2_1_addr_5_reg_21785.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_1_address0 =  (sc_lv<4>) (zext_ln514_60_fu_15530_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_1_address0 = v2_1_addr_4_reg_21705.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_1_address0 = v2_1_addr_3_reg_21625.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_1_address0 =  (sc_lv<4>) (zext_ln514_36_fu_14690_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_1_address0 = v2_1_addr_2_reg_21545.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_1_address0 =  (sc_lv<4>) (zext_ln514_24_fu_14282_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()))) {
        v2_1_address0 = v2_1_addr_1_reg_21465.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_1_address0 = v2_1_addr_reg_21385.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_1_address0 =  (sc_lv<4>) (zext_ln514_fu_13437_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage29.read(), ap_const_boolean_0))) {
        v2_1_address0 = v2_1_addr_8_reg_21203.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_1_address0 =  (sc_lv<4>) (zext_ln475_6_fu_13321_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0))) {
        v2_1_address0 = v2_1_addr_7_reg_21054.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_1_address0 =  (sc_lv<4>) (zext_ln475_3_fu_13279_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0))) {
        v2_1_address0 = v2_1_addr_6_reg_20772.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_1_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_1_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_1_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage29_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_1_ce0 = ap_const_logic_1;
    } else {
        v2_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_1_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_1_d0 = grp_fu_7209_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage29.read(), ap_const_boolean_0))) {
        v2_1_d0 = reg_7417.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0)))) {
        v2_1_d0 = reg_7375.read();
    } else {
        v2_1_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_1_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(or_ln475_reg_20768.read(), ap_const_lv4_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0) && 
          !esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_3) && 
          !esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_7) && 
          !esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_B)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage29_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_1, trunc_ln475_3_reg_20950.read())))) {
        v2_1_we0 = ap_const_logic_1;
    } else {
        v2_1_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_2_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_2_address0 = v2_2_addr_5_reg_21790.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_2_address0 =  (sc_lv<4>) (zext_ln514_61_fu_15555_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_2_address0 = v2_2_addr_4_reg_21710.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_2_address0 =  (sc_lv<4>) (zext_ln514_49_fu_15146_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_2_address0 = v2_2_addr_3_reg_21630.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_2_address0 =  (sc_lv<4>) (zext_ln514_36_fu_14690_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_2_address0 = v2_2_addr_2_reg_21550.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_2_address0 =  (sc_lv<4>) (zext_ln514_25_fu_14307_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_2_address0 = v2_2_addr_1_reg_21470.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_2_address0 =  (sc_lv<4>) (zext_ln514_13_fu_13898_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_2_address0 = v2_2_addr_reg_21390.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_2_address0 =  (sc_lv<4>) (zext_ln514_fu_13437_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage30.read(), ap_const_boolean_0))) {
        v2_2_address0 = v2_2_addr_8_reg_21243.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0))) {
        v2_2_address0 =  (sc_lv<4>) (zext_ln475_7_fu_13332_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_2_address0 = v2_2_addr_7_reg_21079.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0))) {
        v2_2_address0 =  (sc_lv<4>) (zext_ln475_4_fu_13290_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_2_address0 = v2_2_addr_6_reg_20801.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_2_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_2_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_2_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage30_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_2_ce0 = ap_const_logic_1;
    } else {
        v2_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_2_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_2_d0 = grp_fu_7213_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage30.read(), ap_const_boolean_0))) {
        v2_2_d0 = reg_7731.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_2_d0 = reg_7438.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_2_d0 = reg_7417.read();
    } else {
        v2_2_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_2_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_2, trunc_ln475_2_reg_20880.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(or_ln475_1_reg_20797.read(), ap_const_lv4_2)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage30_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_1, trunc_ln475_3_reg_20950.read())))) {
        v2_2_we0 = ap_const_logic_1;
    } else {
        v2_2_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_3_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_3_address0 = v2_3_addr_5_reg_21795.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_3_address0 =  (sc_lv<4>) (zext_ln514_62_fu_15580_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_3_address0 = v2_3_addr_4_reg_21715.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_3_address0 =  (sc_lv<4>) (zext_ln514_49_fu_15146_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_3_address0 = v2_3_addr_3_reg_21635.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_3_address0 =  (sc_lv<4>) (zext_ln514_37_fu_14738_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_3_address0 = v2_3_addr_2_reg_21555.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_3_address0 =  (sc_lv<4>) (zext_ln514_26_fu_14332_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_3_address0 = v2_3_addr_1_reg_21475.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_3_address0 =  (sc_lv<4>) (zext_ln514_13_fu_13898_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_3_address0 = v2_3_addr_reg_21395.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_3_address0 =  (sc_lv<4>) (zext_ln514_1_fu_13486_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage31.read(), ap_const_boolean_0))) {
        v2_3_address0 = v2_3_addr_8_reg_21283.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage24.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage24.read(), ap_const_boolean_0))) {
        v2_3_address0 =  (sc_lv<4>) (zext_ln475_8_fu_13343_p1.read());
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage16.read(), ap_const_boolean_0)))) {
        v2_3_address0 = v2_3_addr_7_reg_21099.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0))) {
        v2_3_address0 = v2_3_addr_6_reg_20830.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_3_address0 =  (sc_lv<4>) (zext_ln475_1_fu_12961_p1.read());
    } else {
        v2_3_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_3_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage31_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage24_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_3_ce0 = ap_const_logic_1;
    } else {
        v2_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_3_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_3_d0 = grp_fu_7217_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage31.read(), ap_const_boolean_0))) {
        v2_3_d0 = reg_7767.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0)))) {
        v2_3_d0 = reg_7731.read();
    } else {
        v2_3_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_3_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_3)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,4,4>(ap_const_lv4_3, or_ln475_2_reg_21139.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage31_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_1, trunc_ln475_3_reg_20950.read())))) {
        v2_3_we0 = ap_const_logic_1;
    } else {
        v2_3_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_4_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_4_address0 = v2_4_addr_6_reg_21800.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_4_address0 =  (sc_lv<4>) (zext_ln514_63_fu_15626_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_4_address0 = v2_4_addr_5_reg_21720.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_4_address0 =  (sc_lv<4>) (zext_ln514_50_fu_15172_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_4_address0 = v2_4_addr_4_reg_21640.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_4_address0 =  (sc_lv<4>) (zext_ln514_38_fu_14763_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_4_address0 = v2_4_addr_3_reg_21560.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_4_address0 =  (sc_lv<4>) (zext_ln514_27_fu_14378_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_4_address0 = v2_4_addr_2_reg_21480.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_4_address0 =  (sc_lv<4>) (zext_ln514_14_fu_13924_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_4_address0 = v2_4_addr_1_reg_21400.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_4_address0 =  (sc_lv<4>) (zext_ln514_2_fu_13511_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage28.read(), ap_const_boolean_0))) {
        v2_4_address0 = v2_4_addr_8_reg_21163.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0))) {
        v2_4_address0 =  (sc_lv<4>) (zext_ln475_5_fu_13310_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage20.read(), ap_const_boolean_0))) {
        v2_4_address0 = v2_4_addr_7_reg_20999.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0))) {
        v2_4_address0 =  (sc_lv<4>) (zext_ln475_2_fu_13268_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage12.read(), ap_const_boolean_0))) {
        v2_4_address0 = v2_4_addr_reg_20748.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_4_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_4_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_4_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage20_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage28_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_4_ce0 = ap_const_logic_1;
    } else {
        v2_4_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_4_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_4_d0 = grp_fu_7221_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage28.read(), ap_const_boolean_0))) {
        v2_4_d0 = reg_7375.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage20.read(), ap_const_boolean_0)))) {
        v2_4_d0 = reg_7343.read();
    } else {
        v2_4_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_4_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage12_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_reg_20739.read(), ap_const_lv4_4)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage20_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage28_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_2, trunc_ln475_2_reg_20880.read())))) {
        v2_4_we0 = ap_const_logic_1;
    } else {
        v2_4_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_5_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_5_address0 = v2_5_addr_5_reg_21805.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_5_address0 =  (sc_lv<4>) (zext_ln514_63_fu_15626_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_5_address0 = v2_5_addr_4_reg_21725.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_5_address0 =  (sc_lv<4>) (zext_ln514_51_fu_15218_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_5_address0 = v2_5_addr_3_reg_21645.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_5_address0 =  (sc_lv<4>) (zext_ln514_39_fu_14788_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_5_address0 = v2_5_addr_2_reg_21565.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_5_address0 =  (sc_lv<4>) (zext_ln514_27_fu_14378_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_5_address0 = v2_5_addr_1_reg_21485.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_5_address0 =  (sc_lv<4>) (zext_ln514_15_fu_13970_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_5_address0 = v2_5_addr_reg_21405.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_5_address0 =  (sc_lv<4>) (zext_ln514_3_fu_13536_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage29.read(), ap_const_boolean_0))) {
        v2_5_address0 = v2_5_addr_8_reg_21208.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_5_address0 =  (sc_lv<4>) (zext_ln475_6_fu_13321_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0))) {
        v2_5_address0 = v2_5_addr_7_reg_21039.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_5_address0 =  (sc_lv<4>) (zext_ln475_3_fu_13279_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0))) {
        v2_5_address0 = v2_5_addr_6_reg_20777.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_5_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_5_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_5_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage29_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_5_ce0 = ap_const_logic_1;
    } else {
        v2_5_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_5_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_5_d0 = grp_fu_7225_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage29.read(), ap_const_boolean_0))) {
        v2_5_d0 = reg_7417.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0)))) {
        v2_5_d0 = reg_7375.read();
    } else {
        v2_5_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_5_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(or_ln475_reg_20768.read(), ap_const_lv4_5)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_3)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage29_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_5, trunc_ln475_3_reg_20950.read())))) {
        v2_5_we0 = ap_const_logic_1;
    } else {
        v2_5_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_6_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_6_address0 = v2_6_addr_5_reg_21810.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_6_address0 =  (sc_lv<4>) (zext_ln514_63_fu_15626_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_6_address0 = v2_6_addr_4_reg_21730.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_6_address0 =  (sc_lv<4>) (zext_ln514_52_fu_15243_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_6_address0 = v2_6_addr_3_reg_21650.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_6_address0 =  (sc_lv<4>) (zext_ln514_40_fu_14834_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_6_address0 = v2_6_addr_2_reg_21570.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_6_address0 =  (sc_lv<4>) (zext_ln514_27_fu_14378_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_6_address0 = v2_6_addr_1_reg_21490.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_6_address0 =  (sc_lv<4>) (zext_ln514_16_fu_13995_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_6_address0 = v2_6_addr_reg_21410.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_6_address0 =  (sc_lv<4>) (zext_ln514_4_fu_13583_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage30.read(), ap_const_boolean_0))) {
        v2_6_address0 = v2_6_addr_8_reg_21248.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0))) {
        v2_6_address0 =  (sc_lv<4>) (zext_ln475_7_fu_13332_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_6_address0 = v2_6_addr_7_reg_21084.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0))) {
        v2_6_address0 =  (sc_lv<4>) (zext_ln475_4_fu_13290_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_6_address0 = v2_6_addr_6_reg_20806.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_6_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_6_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_6_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage30_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_6_ce0 = ap_const_logic_1;
    } else {
        v2_6_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_6_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_6_d0 = grp_fu_7229_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage30.read(), ap_const_boolean_0))) {
        v2_6_d0 = reg_7731.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_6_d0 = reg_7438.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_6_d0 = reg_7417.read();
    } else {
        v2_6_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_6_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_6, trunc_ln475_2_reg_20880.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(or_ln475_1_reg_20797.read(), ap_const_lv4_6)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage30_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_5, trunc_ln475_3_reg_20950.read())))) {
        v2_6_we0 = ap_const_logic_1;
    } else {
        v2_6_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_7_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_7_address0 = v2_7_addr_5_reg_21815.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_7_address0 =  (sc_lv<4>) (zext_ln514_64_fu_15674_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_7_address0 = v2_7_addr_4_reg_21735.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_7_address0 =  (sc_lv<4>) (zext_ln514_53_fu_15268_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_7_address0 = v2_7_addr_3_reg_21655.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_7_address0 =  (sc_lv<4>) (zext_ln514_40_fu_14834_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_7_address0 = v2_7_addr_2_reg_21575.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_7_address0 =  (sc_lv<4>) (zext_ln514_28_fu_14426_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_7_address0 = v2_7_addr_1_reg_21495.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_7_address0 =  (sc_lv<4>) (zext_ln514_17_fu_14020_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_7_address0 = v2_7_addr_reg_21415.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_7_address0 =  (sc_lv<4>) (zext_ln514_4_fu_13583_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage31.read(), ap_const_boolean_0))) {
        v2_7_address0 = v2_7_addr_8_reg_21288.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage24.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage24.read(), ap_const_boolean_0))) {
        v2_7_address0 =  (sc_lv<4>) (zext_ln475_8_fu_13343_p1.read());
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage16.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage16.read(), ap_const_boolean_0)))) {
        v2_7_address0 = v2_7_addr_7_reg_21104.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0))) {
        v2_7_address0 = v2_7_addr_6_reg_20835.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_7_address0 =  (sc_lv<4>) (zext_ln475_1_fu_12961_p1.read());
    } else {
        v2_7_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_7_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage31_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage24_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_7_ce0 = ap_const_logic_1;
    } else {
        v2_7_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_7_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_7_d0 = grp_fu_7233_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage31.read(), ap_const_boolean_0))) {
        v2_7_d0 = reg_7767.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage15.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage23.read(), ap_const_boolean_0)))) {
        v2_7_d0 = reg_7731.read();
    } else {
        v2_7_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_7_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage15_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_7)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,4,4>(ap_const_lv4_7, or_ln475_2_reg_21139.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage23_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage31_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_5, trunc_ln475_3_reg_20950.read())))) {
        v2_7_we0 = ap_const_logic_1;
    } else {
        v2_7_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_8_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_8_address0 = v2_8_addr_6_reg_21820.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_8_address0 =  (sc_lv<4>) (zext_ln514_65_fu_15699_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_8_address0 = v2_8_addr_5_reg_21740.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_8_address0 =  (sc_lv<4>) (zext_ln514_54_fu_15314_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_8_address0 = v2_8_addr_4_reg_21660.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_8_address0 =  (sc_lv<4>) (zext_ln514_41_fu_14860_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_8_address0 = v2_8_addr_3_reg_21580.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_8_address0 =  (sc_lv<4>) (zext_ln514_29_fu_14451_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_8_address0 = v2_8_addr_2_reg_21500.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_8_address0 =  (sc_lv<4>) (zext_ln514_18_fu_14066_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_8_address0 = v2_8_addr_1_reg_21420.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_8_address0 =  (sc_lv<4>) (zext_ln514_5_fu_13609_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage28.read(), ap_const_boolean_0))) {
        v2_8_address0 = v2_8_addr_8_reg_21168.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0))) {
        v2_8_address0 =  (sc_lv<4>) (zext_ln475_5_fu_13310_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage20.read(), ap_const_boolean_0))) {
        v2_8_address0 = v2_8_addr_7_reg_21004.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0))) {
        v2_8_address0 =  (sc_lv<4>) (zext_ln475_2_fu_13268_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage12.read(), ap_const_boolean_0))) {
        v2_8_address0 = v2_8_addr_reg_20753.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_8_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_8_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_8_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage20_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage28_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_8_ce0 = ap_const_logic_1;
    } else {
        v2_8_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_8_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_8_d0 = grp_fu_7237_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage28.read(), ap_const_boolean_0))) {
        v2_8_d0 = reg_7375.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage12.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage20.read(), ap_const_boolean_0)))) {
        v2_8_d0 = reg_7343.read();
    } else {
        v2_8_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_8_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage12_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_reg_20739.read(), ap_const_lv4_8)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage20_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_7)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage28_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_6, trunc_ln475_2_reg_20880.read())) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_8_we0 = ap_const_logic_1;
    } else {
        v2_8_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_9_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read())) {
        v2_9_address0 = v2_9_addr_5_reg_21825.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read())) {
        v2_9_address0 =  (sc_lv<4>) (zext_ln514_66_fu_15724_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read())) {
        v2_9_address0 = v2_9_addr_4_reg_21745.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read())) {
        v2_9_address0 =  (sc_lv<4>) (zext_ln514_54_fu_15314_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read())) {
        v2_9_address0 = v2_9_addr_3_reg_21665.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read())) {
        v2_9_address0 =  (sc_lv<4>) (zext_ln514_42_fu_14906_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read())) {
        v2_9_address0 = v2_9_addr_2_reg_21585.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read())) {
        v2_9_address0 =  (sc_lv<4>) (zext_ln514_30_fu_14476_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read())) {
        v2_9_address0 = v2_9_addr_1_reg_21505.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read())) {
        v2_9_address0 =  (sc_lv<4>) (zext_ln514_18_fu_14066_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read())) {
        v2_9_address0 = v2_9_addr_reg_21425.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read())) {
        v2_9_address0 =  (sc_lv<4>) (zext_ln514_6_fu_13656_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage29.read(), ap_const_boolean_0))) {
        v2_9_address0 = v2_9_addr_8_reg_21213.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage22.read(), ap_const_boolean_0))) {
        v2_9_address0 =  (sc_lv<4>) (zext_ln475_6_fu_13321_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0))) {
        v2_9_address0 = v2_9_addr_7_reg_21044.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage14.read(), ap_const_boolean_0))) {
        v2_9_address0 =  (sc_lv<4>) (zext_ln475_3_fu_13279_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0))) {
        v2_9_address0 = v2_9_addr_6_reg_20782.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
        v2_9_address0 =  (sc_lv<4>) (zext_ln475_fu_12868_p1.read());
    } else {
        v2_9_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v2_9_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage29_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1168.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1200.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1232.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1264.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1296.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1328.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_9_ce0 = ap_const_logic_1;
    } else {
        v2_9_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v2_9_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()))) {
        v2_9_d0 = grp_fu_7241_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp6_stage29.read(), ap_const_boolean_0))) {
        v2_9_d0 = reg_7417.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage13.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp6_stage21.read(), ap_const_boolean_0)))) {
        v2_9_d0 = reg_7375.read();
    } else {
        v2_9_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v2_9_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1359.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1199.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1231.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1263.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1295.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1327.read()) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage13_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(or_ln475_reg_20768.read(), ap_const_lv4_9)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage21_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(trunc_ln475_1_reg_20826.read(), ap_const_lv4_7)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln464_reg_20720.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage29_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,4,4>(ap_const_lv4_9, trunc_ln475_3_reg_20950.read())))) {
        v2_9_we0 = ap_const_logic_1;
    } else {
        v2_9_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v30_fu_10381_p2() {
    v30_fu_10381_p2 = (!ap_phi_mux_v30_0_phi_fu_6827_p4.read().is_01() || !ap_const_lv4_1.is_01())? sc_lv<4>(): (sc_biguint<4>(ap_phi_mux_v30_0_phi_fu_6827_p4.read()) + sc_biguint<4>(ap_const_lv4_1));
}

void update_weights::thread_v3_0_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state153.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_48_fu_10038_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_40_fu_9760_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_32_fu_9725_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state143.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_24_fu_9655_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state142.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_16_fu_9625_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state133.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_44_fu_9342_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state125.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_36_fu_9103_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state124.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_28_fu_9068_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state123.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_20_fu_9033_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state122.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_12_fu_8998_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state102.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_8_fu_8860_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state82.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_4_fu_8720_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state62.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_3_fu_8691_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state42.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_2_fu_8681_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state22.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_1_fu_8671_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        v3_0_address0 =  (sc_lv<8>) (zext_ln332_fu_8648_p1.read());
    } else {
        v3_0_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v3_0_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state123.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state143.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state133.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state153.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state124.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state144.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state125.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state145.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state22.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state42.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state62.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state82.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state102.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state122.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state142.read()))) {
        v3_0_ce0 = ap_const_logic_1;
    } else {
        v3_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v3_1_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state158.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_49_fu_10212_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_41_fu_9934_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_33_fu_9899_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state148.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_25_fu_9829_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state147.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_17_fu_9799_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state138.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_45_fu_9516_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state130.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_37_fu_9238_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state129.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_29_fu_9203_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state128.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_21_fu_9168_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state127.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_13_fu_9138_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state107.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_9_fu_8894_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state87.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_5_fu_8755_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state67.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_3_reg_16125.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state47.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_2_reg_16098.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state27.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_1_reg_16011.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state7.read())) {
        v3_1_address0 =  (sc_lv<8>) (zext_ln332_reg_15945.read());
    } else {
        v3_1_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v3_1_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state128.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state138.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state148.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state158.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state129.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state149.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state130.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state150.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state7.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state27.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state47.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state67.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state87.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state107.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state127.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state147.read()))) {
        v3_1_ce0 = ap_const_logic_1;
    } else {
        v3_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v3_2_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state163.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_50_fu_10321_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_42_fu_10108_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_34_fu_10073_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state153.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_26_fu_10003_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state152.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_18_fu_9973_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state143.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_46_fu_9690_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_38_fu_9412_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_30_fu_9377_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state133.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_22_fu_9307_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state132.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_14_fu_9277_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state112.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_10_fu_8929_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state92.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_6_fu_8790_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state72.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_3_reg_16125.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state52.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_2_reg_16098.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state32.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_1_reg_16011.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state12.read())) {
        v3_2_address0 =  (sc_lv<8>) (zext_ln332_reg_15945.read());
    } else {
        v3_2_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v3_2_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state134.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state143.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state154.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state133.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state153.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state163.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state135.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state155.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state12.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state32.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state52.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state72.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state92.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state112.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state132.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state152.read()))) {
        v3_2_ce0 = ap_const_logic_1;
    } else {
        v3_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v3_3_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state163.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_51_fu_10356_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_43_fu_10282_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_35_fu_10247_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state158.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_27_fu_10177_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state157.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_19_fu_10147_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state148.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_47_fu_9864_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_39_fu_9586_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_31_fu_9551_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state138.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_23_fu_9481_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state137.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_15_fu_9451_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state117.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_11_fu_8964_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state97.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_7_fu_8825_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state72.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_3_reg_16125.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state52.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_2_reg_16098.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state32.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_1_reg_16011.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state17.read())) {
        v3_3_address0 =  (sc_lv<8>) (zext_ln332_reg_15945.read());
    } else {
        v3_3_address0 =  (sc_lv<8>) ("XXXXXXXX");
    }
}

void update_weights::thread_v3_3_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state138.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state148.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state158.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state163.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state139.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state159.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state140.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state160.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state17.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state32.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state52.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state72.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state97.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state117.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state137.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state157.read()))) {
        v3_3_ce0 = ap_const_logic_1;
    } else {
        v3_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v43_fu_10429_p2() {
    v43_fu_10429_p2 = (!ap_phi_mux_v43_0_phi_fu_6838_p4.read().is_01() || !ap_const_lv4_1.is_01())? sc_lv<4>(): (sc_biguint<4>(ap_phi_mux_v43_0_phi_fu_6838_p4.read()) + sc_biguint<4>(ap_const_lv4_1));
}

void update_weights::thread_v47_fu_10545_p2() {
    v47_fu_10545_p2 = (!ap_phi_mux_v47_0_phi_fu_6849_p4.read().is_01() || !ap_const_lv2_1.is_01())? sc_lv<2>(): (sc_biguint<2>(ap_phi_mux_v47_0_phi_fu_6849_p4.read()) + sc_biguint<2>(ap_const_lv2_1));
}

void update_weights::thread_v4_0_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state816.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_48_fu_12255_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state796.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_44_fu_12119_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state776.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_40_fu_11983_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state736.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_32_fu_11745_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state717.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_36_fu_11604_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state716.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_28_fu_11574_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state696.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_24_fu_11438_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state656.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_16_fu_11200_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state637.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_20_fu_11059_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state636.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_12_fu_11029_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state616.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_8_fu_10893_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state596.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_4_fu_10757_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_3_fu_10729_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state556.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_2_fu_10719_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state536.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_1_fu_10709_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state516.read())) {
        v4_0_address0 =  (sc_lv<10>) (zext_ln400_fu_10687_p1.read());
    } else {
        v4_0_address0 =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void update_weights::thread_v4_0_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state637.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state717.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state516.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state536.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state556.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state596.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state616.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state636.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state656.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state696.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state716.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state736.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state776.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state796.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state816.read()))) {
        v4_0_ce0 = ap_const_logic_1;
    } else {
        v4_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v4_1_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state821.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_49_fu_12289_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state801.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_45_fu_12153_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state781.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_41_fu_12017_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state761.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_37_fu_11881_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state741.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_33_fu_11779_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state721.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_29_fu_11643_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state701.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_25_fu_11472_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state681.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_21_fu_11336_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state661.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_17_fu_11234_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state641.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_13_fu_11098_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state621.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_9_fu_10927_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state601.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_5_fu_10791_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state581.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_3_reg_18126.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state561.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_2_reg_18059.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state541.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_1_reg_18012.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state521.read())) {
        v4_1_address0 =  (sc_lv<10>) (zext_ln400_reg_17946.read());
    } else {
        v4_1_address0 =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void update_weights::thread_v4_1_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state521.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state541.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state561.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state581.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state601.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state621.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state641.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state661.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state681.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state701.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state721.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state741.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state761.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state781.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state801.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state821.read()))) {
        v4_1_ce0 = ap_const_logic_1;
    } else {
        v4_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v4_2_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state826.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_50_fu_12323_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state806.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_46_fu_12187_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state786.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_42_fu_12051_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state766.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_38_fu_11915_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state746.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_34_fu_11813_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state726.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_30_fu_11677_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state706.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_26_fu_11506_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state686.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_22_fu_11370_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state666.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_18_fu_11268_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state646.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_14_fu_11132_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state626.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_10_fu_10961_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state606.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_6_fu_10825_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state586.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_3_reg_18126.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state566.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_2_reg_18059.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state546.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_1_reg_18012.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state526.read())) {
        v4_2_address0 =  (sc_lv<10>) (zext_ln400_reg_17946.read());
    } else {
        v4_2_address0 =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void update_weights::thread_v4_2_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state526.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state546.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state566.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state586.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state606.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state626.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state646.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state666.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state686.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state706.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state726.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state746.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state766.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state786.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state806.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state826.read()))) {
        v4_2_ce0 = ap_const_logic_1;
    } else {
        v4_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v4_3_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state831.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_51_fu_12357_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state811.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_47_fu_12221_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state791.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_43_fu_12085_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state771.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_39_fu_11949_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state751.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_35_fu_11847_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state731.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_31_fu_11711_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state711.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_27_fu_11540_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state691.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_23_fu_11404_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state671.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_19_fu_11302_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state651.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_15_fu_11166_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state631.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_11_fu_10995_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state611.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_7_fu_10859_p1.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state586.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_3_reg_18126.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state566.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_2_reg_18059.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state551.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_1_reg_18012.read());
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state531.read())) {
        v4_3_address0 =  (sc_lv<10>) (zext_ln400_reg_17946.read());
    } else {
        v4_3_address0 =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void update_weights::thread_v4_3_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state531.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state551.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state566.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state586.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state611.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state631.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state651.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state671.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state691.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state711.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state731.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state751.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state771.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state791.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state811.read()) || 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state831.read()))) {
        v4_3_ce0 = ap_const_logic_1;
    } else {
        v4_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v56_fu_10669_p2() {
    v56_fu_10669_p2 = (!v56_0_reg_6868.read().is_01() || !ap_const_lv7_1.is_01())? sc_lv<7>(): (sc_biguint<7>(v56_0_reg_6868.read()) + sc_biguint<7>(ap_const_lv7_1));
}

void update_weights::thread_v5_0_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage1.read()) && 
             esl_seteq<1,1,1>(ap_block_pp6_stage1.read(), ap_const_boolean_0))) {
            v5_0_address0 =  (sc_lv<6>) (zext_ln473_5_fu_13120_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
            v5_0_address0 =  (sc_lv<6>) (zext_ln473_fu_12843_p1.read());
        } else {
            v5_0_address0 =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        v5_0_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v5_0_address1() {
    v5_0_address1 =  (sc_lv<6>) (zext_ln473_2_fu_12989_p1.read());
}

void update_weights::thread_v5_0_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)))) {
        v5_0_ce0 = ap_const_logic_1;
    } else {
        v5_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v5_0_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0))) {
        v5_0_ce1 = ap_const_logic_1;
    } else {
        v5_0_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v5_1_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage1.read()) && 
             esl_seteq<1,1,1>(ap_block_pp6_stage1.read(), ap_const_boolean_0))) {
            v5_1_address0 =  (sc_lv<6>) (zext_ln473_6_fu_13176_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
            v5_1_address0 =  (sc_lv<6>) (zext_ln473_fu_12843_p1.read());
        } else {
            v5_1_address0 =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        v5_1_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v5_1_address1() {
    v5_1_address1 =  (sc_lv<6>) (zext_ln473_3_fu_13024_p1.read());
}

void update_weights::thread_v5_1_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)))) {
        v5_1_ce0 = ap_const_logic_1;
    } else {
        v5_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v5_1_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0))) {
        v5_1_ce1 = ap_const_logic_1;
    } else {
        v5_1_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v5_2_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage1.read()) && 
             esl_seteq<1,1,1>(ap_block_pp6_stage1.read(), ap_const_boolean_0))) {
            v5_2_address0 =  (sc_lv<6>) (zext_ln473_7_fu_13215_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
            v5_2_address0 =  (sc_lv<6>) (zext_ln473_fu_12843_p1.read());
        } else {
            v5_2_address0 =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        v5_2_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v5_2_address1() {
    v5_2_address1 =  (sc_lv<6>) (zext_ln473_4_fu_13081_p1.read());
}

void update_weights::thread_v5_2_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)))) {
        v5_2_ce0 = ap_const_logic_1;
    } else {
        v5_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v5_2_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0))) {
        v5_2_ce1 = ap_const_logic_1;
    } else {
        v5_2_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v5_3_address0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage1.read()) && 
             esl_seteq<1,1,1>(ap_block_pp6_stage1.read(), ap_const_boolean_0))) {
            v5_3_address0 =  (sc_lv<6>) (zext_ln473_8_fu_13250_p1.read());
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp6_stage0.read(), ap_const_boolean_0))) {
            v5_3_address0 =  (sc_lv<6>) (zext_ln473_1_fu_12938_p1.read());
        } else {
            v5_3_address0 =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        v5_3_address0 =  (sc_lv<6>) ("XXXXXX");
    }
}

void update_weights::thread_v5_3_address1() {
    v5_3_address1 =  (sc_lv<6>) (zext_ln473_4_fu_13081_p1.read());
}

void update_weights::thread_v5_3_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0)))) {
        v5_3_ce0 = ap_const_logic_1;
    } else {
        v5_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v5_3_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp6_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp6_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp6_stage0_11001.read(), ap_const_boolean_0))) {
        v5_3_ce1 = ap_const_logic_1;
    } else {
        v5_3_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_0_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        v6_0_address0 = v6_0_addr_8_reg_17844_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v6_0_address0 = v6_0_addr_6_reg_17764_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_0_address0 = v6_0_addr_4_reg_17684_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v6_0_address0 = v6_0_addr_2_reg_17644_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v6_0_address0 =  (sc_lv<4>) (zext_ln382_6_fu_10642_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v6_0_address0 =  (sc_lv<4>) (zext_ln382_4_fu_10616_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v6_0_address0 =  (sc_lv<4>) (zext_ln382_2_fu_10590_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v6_0_address0 =  (sc_lv<4>) (zext_ln382_fu_10563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0))) {
        v6_0_address0 = v6_0_addr_reg_16983.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v6_0_address0 =  (sc_lv<4>) (zext_ln356_fu_10393_p1.read());
    } else {
        v6_0_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v6_0_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()))) {
        v6_0_address1 = v6_0_addr_9_reg_17864_pp2_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v6_0_address1 = v6_0_addr_7_reg_17784_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_0_address1 = v6_0_addr_5_reg_17704_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v6_0_address1 = v6_0_addr_3_reg_17664_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v6_0_address1 =  (sc_lv<4>) (zext_ln382_7_fu_10655_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v6_0_address1 =  (sc_lv<4>) (zext_ln382_5_fu_10629_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v6_0_address1 =  (sc_lv<4>) (zext_ln382_3_fu_10603_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v6_0_address1 =  (sc_lv<4>) (zext_ln382_1_fu_10577_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0))) {
        v6_0_address1 = v6_0_addr_1_reg_17023.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v6_0_address1 =  (sc_lv<4>) (zext_ln356_1_fu_10411_p1.read());
    } else {
        v6_0_address1 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v6_0_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)))) {
        v6_0_ce0 = ap_const_logic_1;
    } else {
        v6_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_0_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read())))) {
        v6_0_ce1 = ap_const_logic_1;
    } else {
        v6_0_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_0_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_0_d0 = reg_8180.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v6_0_d0 = reg_7972.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0))) {
        v6_0_d0 = reg_7343.read();
    } else {
        v6_0_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v6_0_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()))) {
        v6_0_d1 = reg_8312.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_0_d1 = reg_8284.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v6_0_d1 = reg_8076.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0))) {
        v6_0_d1 = reg_7767.read();
    } else {
        v6_0_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v6_0_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln351_reg_16969.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0)))) {
        v6_0_we0 = ap_const_logic_1;
    } else {
        v6_0_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_0_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln351_reg_16969.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter5_reg.read())))) {
        v6_0_we1 = ap_const_logic_1;
    } else {
        v6_0_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_1_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        v6_1_address0 = v6_1_addr_8_reg_17849_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v6_1_address0 = v6_1_addr_6_reg_17769_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_1_address0 = v6_1_addr_4_reg_17689_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v6_1_address0 = v6_1_addr_2_reg_17649_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v6_1_address0 =  (sc_lv<4>) (zext_ln382_6_fu_10642_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v6_1_address0 =  (sc_lv<4>) (zext_ln382_4_fu_10616_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v6_1_address0 =  (sc_lv<4>) (zext_ln382_2_fu_10590_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v6_1_address0 =  (sc_lv<4>) (zext_ln382_fu_10563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage13.read(), ap_const_boolean_0))) {
        v6_1_address0 = v6_1_addr_reg_16993.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v6_1_address0 =  (sc_lv<4>) (zext_ln356_fu_10393_p1.read());
    } else {
        v6_1_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v6_1_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()))) {
        v6_1_address1 = v6_1_addr_9_reg_17869_pp2_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v6_1_address1 = v6_1_addr_7_reg_17789_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_1_address1 = v6_1_addr_5_reg_17709_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v6_1_address1 = v6_1_addr_3_reg_17669_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v6_1_address1 =  (sc_lv<4>) (zext_ln382_7_fu_10655_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v6_1_address1 =  (sc_lv<4>) (zext_ln382_5_fu_10629_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v6_1_address1 =  (sc_lv<4>) (zext_ln382_3_fu_10603_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v6_1_address1 =  (sc_lv<4>) (zext_ln382_1_fu_10577_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0))) {
        v6_1_address1 = v6_1_addr_1_reg_17033.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v6_1_address1 =  (sc_lv<4>) (zext_ln356_1_fu_10411_p1.read());
    } else {
        v6_1_address1 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v6_1_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)))) {
        v6_1_ce0 = ap_const_logic_1;
    } else {
        v6_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_1_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read())))) {
        v6_1_ce1 = ap_const_logic_1;
    } else {
        v6_1_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_1_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_1_d0 = reg_8188.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v6_1_d0 = reg_7980.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage13.read(), ap_const_boolean_0))) {
        v6_1_d0 = reg_7375.read();
    } else {
        v6_1_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v6_1_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()))) {
        v6_1_d1 = reg_8319.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_1_d1 = reg_8291.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v6_1_d1 = reg_8084.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0))) {
        v6_1_d1 = reg_7343.read();
    } else {
        v6_1_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v6_1_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln351_reg_16969.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0)))) {
        v6_1_we0 = ap_const_logic_1;
    } else {
        v6_1_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_1_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln351_reg_16969.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter5_reg.read())))) {
        v6_1_we1 = ap_const_logic_1;
    } else {
        v6_1_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_2_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        v6_2_address0 = v6_2_addr_8_reg_17854_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v6_2_address0 = v6_2_addr_6_reg_17774_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_2_address0 = v6_2_addr_4_reg_17694_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v6_2_address0 = v6_2_addr_2_reg_17654_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v6_2_address0 =  (sc_lv<4>) (zext_ln382_6_fu_10642_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v6_2_address0 =  (sc_lv<4>) (zext_ln382_4_fu_10616_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v6_2_address0 =  (sc_lv<4>) (zext_ln382_2_fu_10590_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v6_2_address0 =  (sc_lv<4>) (zext_ln382_fu_10563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage14.read(), ap_const_boolean_0))) {
        v6_2_address0 = v6_2_addr_reg_17003.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v6_2_address0 =  (sc_lv<4>) (zext_ln356_fu_10393_p1.read());
    } else {
        v6_2_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v6_2_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()))) {
        v6_2_address1 = v6_2_addr_9_reg_17874_pp2_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v6_2_address1 = v6_2_addr_7_reg_17794_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_2_address1 = v6_2_addr_5_reg_17714_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v6_2_address1 = v6_2_addr_3_reg_17674_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v6_2_address1 =  (sc_lv<4>) (zext_ln382_7_fu_10655_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v6_2_address1 =  (sc_lv<4>) (zext_ln382_5_fu_10629_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v6_2_address1 =  (sc_lv<4>) (zext_ln382_3_fu_10603_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v6_2_address1 =  (sc_lv<4>) (zext_ln382_1_fu_10577_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0))) {
        v6_2_address1 = v6_2_addr_1_reg_17043.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v6_2_address1 =  (sc_lv<4>) (zext_ln356_1_fu_10411_p1.read());
    } else {
        v6_2_address1 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v6_2_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)))) {
        v6_2_ce0 = ap_const_logic_1;
    } else {
        v6_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_2_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read())))) {
        v6_2_ce1 = ap_const_logic_1;
    } else {
        v6_2_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_2_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_2_d0 = reg_8196.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v6_2_d0 = reg_7988.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage14.read(), ap_const_boolean_0))) {
        v6_2_d0 = reg_7417.read();
    } else {
        v6_2_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v6_2_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()))) {
        v6_2_d1 = reg_8326.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_2_d1 = reg_8298.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v6_2_d1 = reg_8092.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0))) {
        v6_2_d1 = reg_7375.read();
    } else {
        v6_2_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v6_2_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln351_reg_16969.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0)))) {
        v6_2_we0 = ap_const_logic_1;
    } else {
        v6_2_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_2_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln351_reg_16969.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter5_reg.read())))) {
        v6_2_we1 = ap_const_logic_1;
    } else {
        v6_2_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_3_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0))) {
        v6_3_address0 = v6_3_addr_8_reg_17859_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v6_3_address0 = v6_3_addr_6_reg_17779_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_3_address0 = v6_3_addr_4_reg_17699_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v6_3_address0 = v6_3_addr_2_reg_17659_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v6_3_address0 =  (sc_lv<4>) (zext_ln382_6_fu_10642_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v6_3_address0 =  (sc_lv<4>) (zext_ln382_4_fu_10616_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v6_3_address0 =  (sc_lv<4>) (zext_ln382_2_fu_10590_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v6_3_address0 =  (sc_lv<4>) (zext_ln382_fu_10563_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage15.read(), ap_const_boolean_0))) {
        v6_3_address0 = v6_3_addr_reg_17013.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v6_3_address0 =  (sc_lv<4>) (zext_ln356_fu_10393_p1.read());
    } else {
        v6_3_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v6_3_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()))) {
        v6_3_address1 = v6_3_addr_9_reg_17879_pp2_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0))) {
        v6_3_address1 = v6_3_addr_7_reg_17799_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_3_address1 = v6_3_addr_5_reg_17719_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0))) {
        v6_3_address1 = v6_3_addr_3_reg_17679_pp2_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage3.read(), ap_const_boolean_0))) {
        v6_3_address1 =  (sc_lv<4>) (zext_ln382_7_fu_10655_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage2.read(), ap_const_boolean_0))) {
        v6_3_address1 =  (sc_lv<4>) (zext_ln382_5_fu_10629_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage1.read(), ap_const_boolean_0))) {
        v6_3_address1 =  (sc_lv<4>) (zext_ln382_3_fu_10603_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage0.read(), ap_const_boolean_0))) {
        v6_3_address1 =  (sc_lv<4>) (zext_ln382_1_fu_10577_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0))) {
        v6_3_address1 = v6_3_addr_1_reg_17053.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        v6_3_address1 =  (sc_lv<4>) (zext_ln356_1_fu_10411_p1.read());
    } else {
        v6_3_address1 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v6_3_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)))) {
        v6_3_ce0 = ap_const_logic_1;
    } else {
        v6_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_3_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read())))) {
        v6_3_ce1 = ap_const_logic_1;
    } else {
        v6_3_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_3_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_3_d0 = reg_8204.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0)))) {
        v6_3_d0 = reg_7996.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage15.read(), ap_const_boolean_0))) {
        v6_3_d0 = reg_7731.read();
    } else {
        v6_3_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v6_3_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp2_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()))) {
        v6_3_d1 = reg_8333.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp2_stage5.read(), ap_const_boolean_0))) {
        v6_3_d1 = reg_8305.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp2_stage6.read(), ap_const_boolean_0)))) {
        v6_3_d1 = reg_8100.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0))) {
        v6_3_d1 = reg_7417.read();
    } else {
        v6_3_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v6_3_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln351_reg_16969.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0)))) {
        v6_3_we0 = ap_const_logic_1;
    } else {
        v6_3_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v6_3_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(icmp_ln351_reg_16969.read(), ap_const_lv1_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp2_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp2_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp2_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln378_reg_17625_pp2_iter5_reg.read())))) {
        v6_3_we1 = ap_const_logic_1;
    } else {
        v6_3_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v70_fu_12382_p2() {
    v70_fu_12382_p2 = (!ap_phi_mux_v70_0_phi_fu_6895_p4.read().is_01() || !ap_const_lv4_1.is_01())? sc_lv<4>(): (sc_biguint<4>(ap_phi_mux_v70_0_phi_fu_6895_p4.read()) + sc_biguint<4>(ap_const_lv4_1));
}

void update_weights::thread_v7_0_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0))) {
        v7_0_address0 = v7_0_addr_8_reg_20640_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0))) {
        v7_0_address0 = v7_0_addr_6_reg_20560_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_0_address0 = v7_0_addr_4_reg_20480_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0))) {
        v7_0_address0 = v7_0_addr_2_reg_20440_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage3.read(), ap_const_boolean_0))) {
        v7_0_address0 =  (sc_lv<4>) (zext_ln453_6_fu_12762_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage2.read(), ap_const_boolean_0))) {
        v7_0_address0 =  (sc_lv<4>) (zext_ln453_4_fu_12736_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage1.read(), ap_const_boolean_0))) {
        v7_0_address0 =  (sc_lv<4>) (zext_ln453_2_fu_12710_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage0.read(), ap_const_boolean_0))) {
        v7_0_address0 =  (sc_lv<4>) (zext_ln453_fu_12683_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage12.read(), ap_const_boolean_0))) {
        v7_0_address0 = v7_0_addr_reg_18928.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        v7_0_address0 =  (sc_lv<4>) (zext_ln424_fu_12394_p1.read());
    } else {
        v7_0_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v7_0_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()))) {
        v7_0_address1 = v7_0_addr_9_reg_20660_pp5_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0))) {
        v7_0_address1 = v7_0_addr_7_reg_20580_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_0_address1 = v7_0_addr_5_reg_20500_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0))) {
        v7_0_address1 = v7_0_addr_3_reg_20460_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage3.read(), ap_const_boolean_0))) {
        v7_0_address1 =  (sc_lv<4>) (zext_ln453_7_fu_12775_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage2.read(), ap_const_boolean_0))) {
        v7_0_address1 =  (sc_lv<4>) (zext_ln453_5_fu_12749_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage1.read(), ap_const_boolean_0))) {
        v7_0_address1 =  (sc_lv<4>) (zext_ln453_3_fu_12723_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage0.read(), ap_const_boolean_0))) {
        v7_0_address1 =  (sc_lv<4>) (zext_ln453_1_fu_12697_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage16.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage16.read(), ap_const_boolean_0))) {
        v7_0_address1 = v7_0_addr_1_reg_18968.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        v7_0_address1 =  (sc_lv<4>) (zext_ln424_1_fu_12412_p1.read());
    } else {
        v7_0_address1 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v7_0_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())))) {
        v7_0_ce0 = ap_const_logic_1;
    } else {
        v7_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_0_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read())))) {
        v7_0_ce1 = ap_const_logic_1;
    } else {
        v7_0_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_0_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_0_d0 = reg_8180.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0)))) {
        v7_0_d0 = reg_7972.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage12.read(), ap_const_boolean_0))) {
        v7_0_d0 = reg_7343.read();
    } else {
        v7_0_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v7_0_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()))) {
        v7_0_d1 = reg_8312.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_0_d1 = reg_8284.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0)))) {
        v7_0_d1 = reg_8076.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage16.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage16.read(), ap_const_boolean_0))) {
        v7_0_d1 = reg_7767.read();
    } else {
        v7_0_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v7_0_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln419_reg_18914.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0)))) {
        v7_0_we0 = ap_const_logic_1;
    } else {
        v7_0_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_0_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln419_reg_18914.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter5_reg.read())))) {
        v7_0_we1 = ap_const_logic_1;
    } else {
        v7_0_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_1_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0))) {
        v7_1_address0 = v7_1_addr_8_reg_20645_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0))) {
        v7_1_address0 = v7_1_addr_6_reg_20565_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_1_address0 = v7_1_addr_4_reg_20485_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0))) {
        v7_1_address0 = v7_1_addr_2_reg_20445_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage3.read(), ap_const_boolean_0))) {
        v7_1_address0 =  (sc_lv<4>) (zext_ln453_6_fu_12762_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage2.read(), ap_const_boolean_0))) {
        v7_1_address0 =  (sc_lv<4>) (zext_ln453_4_fu_12736_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage1.read(), ap_const_boolean_0))) {
        v7_1_address0 =  (sc_lv<4>) (zext_ln453_2_fu_12710_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage0.read(), ap_const_boolean_0))) {
        v7_1_address0 =  (sc_lv<4>) (zext_ln453_fu_12683_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage13.read(), ap_const_boolean_0))) {
        v7_1_address0 = v7_1_addr_reg_18938.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        v7_1_address0 =  (sc_lv<4>) (zext_ln424_fu_12394_p1.read());
    } else {
        v7_1_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v7_1_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()))) {
        v7_1_address1 = v7_1_addr_9_reg_20665_pp5_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0))) {
        v7_1_address1 = v7_1_addr_7_reg_20585_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_1_address1 = v7_1_addr_5_reg_20505_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0))) {
        v7_1_address1 = v7_1_addr_3_reg_20465_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage3.read(), ap_const_boolean_0))) {
        v7_1_address1 =  (sc_lv<4>) (zext_ln453_7_fu_12775_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage2.read(), ap_const_boolean_0))) {
        v7_1_address1 =  (sc_lv<4>) (zext_ln453_5_fu_12749_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage1.read(), ap_const_boolean_0))) {
        v7_1_address1 =  (sc_lv<4>) (zext_ln453_3_fu_12723_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage0.read(), ap_const_boolean_0))) {
        v7_1_address1 =  (sc_lv<4>) (zext_ln453_1_fu_12697_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage17.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage17.read(), ap_const_boolean_0))) {
        v7_1_address1 = v7_1_addr_1_reg_18978.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        v7_1_address1 =  (sc_lv<4>) (zext_ln424_1_fu_12412_p1.read());
    } else {
        v7_1_address1 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v7_1_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())))) {
        v7_1_ce0 = ap_const_logic_1;
    } else {
        v7_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_1_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage17_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read())))) {
        v7_1_ce1 = ap_const_logic_1;
    } else {
        v7_1_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_1_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_1_d0 = reg_8188.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0)))) {
        v7_1_d0 = reg_7980.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage13.read(), ap_const_boolean_0))) {
        v7_1_d0 = reg_7375.read();
    } else {
        v7_1_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v7_1_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()))) {
        v7_1_d1 = reg_8319.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_1_d1 = reg_8291.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0)))) {
        v7_1_d1 = reg_8084.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage17.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage17.read(), ap_const_boolean_0))) {
        v7_1_d1 = reg_7343.read();
    } else {
        v7_1_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v7_1_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln419_reg_18914.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0)))) {
        v7_1_we0 = ap_const_logic_1;
    } else {
        v7_1_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_1_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln419_reg_18914.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage17_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter5_reg.read())))) {
        v7_1_we1 = ap_const_logic_1;
    } else {
        v7_1_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_2_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0))) {
        v7_2_address0 = v7_2_addr_8_reg_20650_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0))) {
        v7_2_address0 = v7_2_addr_6_reg_20570_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_2_address0 = v7_2_addr_4_reg_20490_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0))) {
        v7_2_address0 = v7_2_addr_2_reg_20450_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage3.read(), ap_const_boolean_0))) {
        v7_2_address0 =  (sc_lv<4>) (zext_ln453_6_fu_12762_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage2.read(), ap_const_boolean_0))) {
        v7_2_address0 =  (sc_lv<4>) (zext_ln453_4_fu_12736_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage1.read(), ap_const_boolean_0))) {
        v7_2_address0 =  (sc_lv<4>) (zext_ln453_2_fu_12710_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage0.read(), ap_const_boolean_0))) {
        v7_2_address0 =  (sc_lv<4>) (zext_ln453_fu_12683_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage14.read(), ap_const_boolean_0))) {
        v7_2_address0 = v7_2_addr_reg_18948.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        v7_2_address0 =  (sc_lv<4>) (zext_ln424_fu_12394_p1.read());
    } else {
        v7_2_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v7_2_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()))) {
        v7_2_address1 = v7_2_addr_9_reg_20670_pp5_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0))) {
        v7_2_address1 = v7_2_addr_7_reg_20590_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_2_address1 = v7_2_addr_5_reg_20510_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0))) {
        v7_2_address1 = v7_2_addr_3_reg_20470_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage3.read(), ap_const_boolean_0))) {
        v7_2_address1 =  (sc_lv<4>) (zext_ln453_7_fu_12775_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage2.read(), ap_const_boolean_0))) {
        v7_2_address1 =  (sc_lv<4>) (zext_ln453_5_fu_12749_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage1.read(), ap_const_boolean_0))) {
        v7_2_address1 =  (sc_lv<4>) (zext_ln453_3_fu_12723_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage0.read(), ap_const_boolean_0))) {
        v7_2_address1 =  (sc_lv<4>) (zext_ln453_1_fu_12697_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage18.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage18.read(), ap_const_boolean_0))) {
        v7_2_address1 = v7_2_addr_1_reg_18988.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        v7_2_address1 =  (sc_lv<4>) (zext_ln424_1_fu_12412_p1.read());
    } else {
        v7_2_address1 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v7_2_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())))) {
        v7_2_ce0 = ap_const_logic_1;
    } else {
        v7_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_2_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage18_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read())))) {
        v7_2_ce1 = ap_const_logic_1;
    } else {
        v7_2_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_2_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_2_d0 = reg_8196.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0)))) {
        v7_2_d0 = reg_7988.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage14.read(), ap_const_boolean_0))) {
        v7_2_d0 = reg_7417.read();
    } else {
        v7_2_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v7_2_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()))) {
        v7_2_d1 = reg_8326.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_2_d1 = reg_8298.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0)))) {
        v7_2_d1 = reg_8092.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage18.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage18.read(), ap_const_boolean_0))) {
        v7_2_d1 = reg_7375.read();
    } else {
        v7_2_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v7_2_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln419_reg_18914.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0)))) {
        v7_2_we0 = ap_const_logic_1;
    } else {
        v7_2_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_2_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln419_reg_18914.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage18_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter5_reg.read())))) {
        v7_2_we1 = ap_const_logic_1;
    } else {
        v7_2_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_3_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0))) {
        v7_3_address0 = v7_3_addr_8_reg_20655_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0))) {
        v7_3_address0 = v7_3_addr_6_reg_20575_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_3_address0 = v7_3_addr_4_reg_20495_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0))) {
        v7_3_address0 = v7_3_addr_2_reg_20455_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage3.read(), ap_const_boolean_0))) {
        v7_3_address0 =  (sc_lv<4>) (zext_ln453_6_fu_12762_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage2.read(), ap_const_boolean_0))) {
        v7_3_address0 =  (sc_lv<4>) (zext_ln453_4_fu_12736_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage1.read(), ap_const_boolean_0))) {
        v7_3_address0 =  (sc_lv<4>) (zext_ln453_2_fu_12710_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage0.read(), ap_const_boolean_0))) {
        v7_3_address0 =  (sc_lv<4>) (zext_ln453_fu_12683_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage15.read(), ap_const_boolean_0))) {
        v7_3_address0 = v7_3_addr_reg_18958.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        v7_3_address0 =  (sc_lv<4>) (zext_ln424_fu_12394_p1.read());
    } else {
        v7_3_address0 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v7_3_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()))) {
        v7_3_address1 = v7_3_addr_9_reg_20675_pp5_iter5_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0))) {
        v7_3_address1 = v7_3_addr_7_reg_20595_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_3_address1 = v7_3_addr_5_reg_20515_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0))) {
        v7_3_address1 = v7_3_addr_3_reg_20475_pp5_iter4_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage3.read(), ap_const_boolean_0))) {
        v7_3_address1 =  (sc_lv<4>) (zext_ln453_7_fu_12775_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage2.read(), ap_const_boolean_0))) {
        v7_3_address1 =  (sc_lv<4>) (zext_ln453_5_fu_12749_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage1.read(), ap_const_boolean_0))) {
        v7_3_address1 =  (sc_lv<4>) (zext_ln453_3_fu_12723_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage0.read(), ap_const_boolean_0))) {
        v7_3_address1 =  (sc_lv<4>) (zext_ln453_1_fu_12697_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage19.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage19.read(), ap_const_boolean_0))) {
        v7_3_address1 = v7_3_addr_1_reg_18998.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage0.read(), ap_const_boolean_0))) {
        v7_3_address1 =  (sc_lv<4>) (zext_ln424_1_fu_12412_p1.read());
    } else {
        v7_3_address1 =  (sc_lv<4>) ("XXXX");
    }
}

void update_weights::thread_v7_3_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())))) {
        v7_3_ce0 = ap_const_logic_1;
    } else {
        v7_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_3_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage19_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage1_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage2_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read())))) {
        v7_3_ce1 = ap_const_logic_1;
    } else {
        v7_3_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_3_d0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_3_d0 = reg_8204.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0)))) {
        v7_3_d0 = reg_7996.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage15.read(), ap_const_boolean_0))) {
        v7_3_d0 = reg_7731.read();
    } else {
        v7_3_d0 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v7_3_d1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp5_stage7.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()))) {
        v7_3_d1 = reg_8333.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp5_stage5.read(), ap_const_boolean_0))) {
        v7_3_d1 = reg_8305.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp5_stage6.read(), ap_const_boolean_0)))) {
        v7_3_d1 = reg_8100.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage19.read()) && 
                esl_seteq<1,1,1>(ap_block_pp3_stage19.read(), ap_const_boolean_0))) {
        v7_3_d1 = reg_7417.read();
    } else {
        v7_3_d1 =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void update_weights::thread_v7_3_we0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln419_reg_18914.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0)))) {
        v7_3_we0 = ap_const_logic_1;
    } else {
        v7_3_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v7_3_we1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp3_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln419_reg_18914.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp3_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp3_stage19_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage4_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter4.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter4_reg.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp5_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp5_stage7_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp5_iter5.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln449_reg_20421_pp5_iter5_reg.read())))) {
        v7_3_we1 = ap_const_logic_1;
    } else {
        v7_3_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v83_fu_12430_p2() {
    v83_fu_12430_p2 = (!ap_phi_mux_v83_0_phi_fu_6906_p4.read().is_01() || !ap_const_lv6_1.is_01())? sc_lv<6>(): (sc_biguint<6>(ap_phi_mux_v83_0_phi_fu_6906_p4.read()) + sc_biguint<6>(ap_const_lv6_1));
}

void update_weights::thread_v89_fu_12665_p2() {
    v89_fu_12665_p2 = (!ap_phi_mux_v89_0_phi_fu_6917_p4.read().is_01() || !ap_const_lv2_1.is_01())? sc_lv<2>(): (sc_biguint<2>(ap_phi_mux_v89_0_phi_fu_6917_p4.read()) + sc_biguint<2>(ap_const_lv2_1));
}

void update_weights::thread_v8_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp9_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp9_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp9_stage0.read(), ap_const_boolean_0))) {
        v8_address0 =  (sc_lv<2>) (zext_ln522_fu_15909_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp7_iter2.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp7_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp7_stage1.read(), ap_const_boolean_0))) {
        v8_address0 = v8_addr_reg_21337_pp7_iter2_reg.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp7_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp7_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp7_stage0.read(), ap_const_boolean_0))) {
        v8_address0 =  (sc_lv<2>) (zext_ln496_fu_13363_p1.read());
    } else {
        v8_address0 = "XX";
    }
}

void update_weights::thread_v8_address1() {
    v8_address1 = v8_addr_1_reg_21869_pp9_iter30_reg.read();
}

void update_weights::thread_v8_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp7_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp7_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp7_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp9_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp9_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp9_iter0.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp7_iter2.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp7_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp7_stage1_11001.read(), ap_const_boolean_0)))) {
        v8_ce0 = ap_const_logic_1;
    } else {
        v8_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v8_ce1() {
    if ((esl_seteq<1,1,1>(ap_block_pp9_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp9_iter31.read()))) {
        v8_ce1 = ap_const_logic_1;
    } else {
        v8_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v8_d0() {
    v8_d0 = reg_7343.read();
}

void update_weights::thread_v8_d1() {
    v8_d1 = grp_fu_7205_p2.read();
}

void update_weights::thread_v8_we0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp7_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp7_stage1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp7_stage1_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln493_reg_21323_pp7_iter2_reg.read()))) {
        v8_we0 = ap_const_logic_1;
    } else {
        v8_we0 = ap_const_logic_0;
    }
}

void update_weights::thread_v8_we1() {
    if ((esl_seteq<1,1,1>(ap_block_pp9_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp9_iter31.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln520_reg_21860_pp9_iter30_reg.read()))) {
        v8_we1 = ap_const_logic_1;
    } else {
        v8_we1 = ap_const_logic_0;
    }
}

void update_weights::thread_v98_fu_12789_p2() {
    v98_fu_12789_p2 = (!ap_phi_mux_v98_0_phi_fu_6940_p4.read().is_01() || !ap_const_lv5_1.is_01())? sc_lv<5>(): (sc_biguint<5>(ap_phi_mux_v98_0_phi_fu_6940_p4.read()) + sc_biguint<5>(ap_const_lv5_1));
}

void update_weights::thread_v9_0_address0() {
    v9_0_address0 =  (sc_lv<4>) (zext_ln356_fu_10393_p1.read());
}

void update_weights::thread_v9_0_address1() {
    v9_0_address1 =  (sc_lv<4>) (zext_ln356_1_fu_10411_p1.read());
}

void update_weights::thread_v9_0_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v9_0_ce0 = ap_const_logic_1;
    } else {
        v9_0_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v9_0_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v9_0_ce1 = ap_const_logic_1;
    } else {
        v9_0_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v9_1_address0() {
    v9_1_address0 =  (sc_lv<4>) (zext_ln356_fu_10393_p1.read());
}

void update_weights::thread_v9_1_address1() {
    v9_1_address1 =  (sc_lv<4>) (zext_ln356_1_fu_10411_p1.read());
}

void update_weights::thread_v9_1_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v9_1_ce0 = ap_const_logic_1;
    } else {
        v9_1_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v9_1_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v9_1_ce1 = ap_const_logic_1;
    } else {
        v9_1_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v9_2_address0() {
    v9_2_address0 =  (sc_lv<4>) (zext_ln356_fu_10393_p1.read());
}

void update_weights::thread_v9_2_address1() {
    v9_2_address1 =  (sc_lv<4>) (zext_ln356_1_fu_10411_p1.read());
}

void update_weights::thread_v9_2_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v9_2_ce0 = ap_const_logic_1;
    } else {
        v9_2_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v9_2_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v9_2_ce1 = ap_const_logic_1;
    } else {
        v9_2_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_v9_3_address0() {
    v9_3_address0 =  (sc_lv<4>) (zext_ln356_fu_10393_p1.read());
}

void update_weights::thread_v9_3_address1() {
    v9_3_address1 =  (sc_lv<4>) (zext_ln356_1_fu_10411_p1.read());
}

void update_weights::thread_v9_3_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v9_3_ce0 = ap_const_logic_1;
    } else {
        v9_3_ce0 = ap_const_logic_0;
    }
}

void update_weights::thread_v9_3_ce1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        v9_3_ce1 = ap_const_logic_1;
    } else {
        v9_3_ce1 = ap_const_logic_0;
    }
}

void update_weights::thread_zext_ln332_10_fu_8929_p1() {
    zext_ln332_10_fu_8929_p1 = esl_zext<64,8>(lshr_ln332_6_fu_8919_p4.read());
}

void update_weights::thread_zext_ln332_11_fu_8964_p1() {
    zext_ln332_11_fu_8964_p1 = esl_zext<64,8>(lshr_ln332_7_fu_8954_p4.read());
}

void update_weights::thread_zext_ln332_12_fu_8998_p1() {
    zext_ln332_12_fu_8998_p1 = esl_zext<64,8>(lshr_ln332_8_fu_8988_p4.read());
}

void update_weights::thread_zext_ln332_13_fu_9138_p1() {
    zext_ln332_13_fu_9138_p1 = esl_zext<64,8>(lshr_ln332_9_fu_9128_p4.read());
}

void update_weights::thread_zext_ln332_14_fu_9277_p1() {
    zext_ln332_14_fu_9277_p1 = esl_zext<64,8>(lshr_ln332_s_fu_9267_p4.read());
}

void update_weights::thread_zext_ln332_15_fu_9451_p1() {
    zext_ln332_15_fu_9451_p1 = esl_zext<64,8>(lshr_ln332_10_fu_9441_p4.read());
}

void update_weights::thread_zext_ln332_16_fu_9625_p1() {
    zext_ln332_16_fu_9625_p1 = esl_zext<64,8>(lshr_ln332_11_fu_9615_p4.read());
}

void update_weights::thread_zext_ln332_17_fu_9799_p1() {
    zext_ln332_17_fu_9799_p1 = esl_zext<64,8>(lshr_ln332_12_fu_9789_p4.read());
}

void update_weights::thread_zext_ln332_18_fu_9973_p1() {
    zext_ln332_18_fu_9973_p1 = esl_zext<64,8>(lshr_ln332_13_fu_9963_p4.read());
}

void update_weights::thread_zext_ln332_19_fu_10147_p1() {
    zext_ln332_19_fu_10147_p1 = esl_zext<64,8>(lshr_ln332_14_fu_10137_p4.read());
}

void update_weights::thread_zext_ln332_1_fu_8671_p1() {
    zext_ln332_1_fu_8671_p1 = esl_zext<64,8>(or_ln332_fu_8666_p2.read());
}

void update_weights::thread_zext_ln332_20_fu_9033_p1() {
    zext_ln332_20_fu_9033_p1 = esl_zext<64,8>(lshr_ln332_15_fu_9023_p4.read());
}

void update_weights::thread_zext_ln332_21_fu_9168_p1() {
    zext_ln332_21_fu_9168_p1 = esl_zext<64,8>(lshr_ln332_16_fu_9158_p4.read());
}

void update_weights::thread_zext_ln332_22_fu_9307_p1() {
    zext_ln332_22_fu_9307_p1 = esl_zext<64,8>(lshr_ln332_17_fu_9297_p4.read());
}

void update_weights::thread_zext_ln332_23_fu_9481_p1() {
    zext_ln332_23_fu_9481_p1 = esl_zext<64,8>(lshr_ln332_18_fu_9471_p4.read());
}

void update_weights::thread_zext_ln332_24_fu_9655_p1() {
    zext_ln332_24_fu_9655_p1 = esl_zext<64,8>(lshr_ln332_19_fu_9645_p4.read());
}

void update_weights::thread_zext_ln332_25_fu_9829_p1() {
    zext_ln332_25_fu_9829_p1 = esl_zext<64,8>(lshr_ln332_20_fu_9819_p4.read());
}

void update_weights::thread_zext_ln332_26_fu_10003_p1() {
    zext_ln332_26_fu_10003_p1 = esl_zext<64,8>(lshr_ln332_21_fu_9993_p4.read());
}

void update_weights::thread_zext_ln332_27_fu_10177_p1() {
    zext_ln332_27_fu_10177_p1 = esl_zext<64,8>(lshr_ln332_22_fu_10167_p4.read());
}

void update_weights::thread_zext_ln332_28_fu_9068_p1() {
    zext_ln332_28_fu_9068_p1 = esl_zext<64,8>(lshr_ln332_23_fu_9058_p4.read());
}

void update_weights::thread_zext_ln332_29_fu_9203_p1() {
    zext_ln332_29_fu_9203_p1 = esl_zext<64,8>(lshr_ln332_24_fu_9193_p4.read());
}

void update_weights::thread_zext_ln332_2_fu_8681_p1() {
    zext_ln332_2_fu_8681_p1 = esl_zext<64,8>(or_ln332_1_fu_8676_p2.read());
}

void update_weights::thread_zext_ln332_30_fu_9377_p1() {
    zext_ln332_30_fu_9377_p1 = esl_zext<64,8>(lshr_ln332_25_fu_9367_p4.read());
}

void update_weights::thread_zext_ln332_31_fu_9551_p1() {
    zext_ln332_31_fu_9551_p1 = esl_zext<64,8>(lshr_ln332_26_fu_9541_p4.read());
}

void update_weights::thread_zext_ln332_32_fu_9725_p1() {
    zext_ln332_32_fu_9725_p1 = esl_zext<64,8>(lshr_ln332_27_fu_9715_p4.read());
}

void update_weights::thread_zext_ln332_33_fu_9899_p1() {
    zext_ln332_33_fu_9899_p1 = esl_zext<64,8>(lshr_ln332_28_fu_9889_p4.read());
}

void update_weights::thread_zext_ln332_34_fu_10073_p1() {
    zext_ln332_34_fu_10073_p1 = esl_zext<64,8>(lshr_ln332_29_fu_10063_p4.read());
}

void update_weights::thread_zext_ln332_35_fu_10247_p1() {
    zext_ln332_35_fu_10247_p1 = esl_zext<64,8>(lshr_ln332_30_fu_10237_p4.read());
}

void update_weights::thread_zext_ln332_36_fu_9103_p1() {
    zext_ln332_36_fu_9103_p1 = esl_zext<64,8>(lshr_ln332_31_fu_9093_p4.read());
}

void update_weights::thread_zext_ln332_37_fu_9238_p1() {
    zext_ln332_37_fu_9238_p1 = esl_zext<64,8>(lshr_ln332_32_fu_9228_p4.read());
}

void update_weights::thread_zext_ln332_38_fu_9412_p1() {
    zext_ln332_38_fu_9412_p1 = esl_zext<64,8>(lshr_ln332_33_fu_9402_p4.read());
}

void update_weights::thread_zext_ln332_39_fu_9586_p1() {
    zext_ln332_39_fu_9586_p1 = esl_zext<64,8>(lshr_ln332_34_fu_9576_p4.read());
}

void update_weights::thread_zext_ln332_3_fu_8691_p1() {
    zext_ln332_3_fu_8691_p1 = esl_zext<64,8>(or_ln332_2_fu_8686_p2.read());
}

void update_weights::thread_zext_ln332_40_fu_9760_p1() {
    zext_ln332_40_fu_9760_p1 = esl_zext<64,8>(lshr_ln332_35_fu_9750_p4.read());
}

void update_weights::thread_zext_ln332_41_fu_9934_p1() {
    zext_ln332_41_fu_9934_p1 = esl_zext<64,8>(lshr_ln332_36_fu_9924_p4.read());
}

void update_weights::thread_zext_ln332_42_fu_10108_p1() {
    zext_ln332_42_fu_10108_p1 = esl_zext<64,8>(lshr_ln332_37_fu_10098_p4.read());
}

void update_weights::thread_zext_ln332_43_fu_10282_p1() {
    zext_ln332_43_fu_10282_p1 = esl_zext<64,8>(lshr_ln332_38_fu_10272_p4.read());
}

void update_weights::thread_zext_ln332_44_fu_9342_p1() {
    zext_ln332_44_fu_9342_p1 = esl_zext<64,8>(lshr_ln332_39_fu_9332_p4.read());
}

void update_weights::thread_zext_ln332_45_fu_9516_p1() {
    zext_ln332_45_fu_9516_p1 = esl_zext<64,8>(lshr_ln332_40_fu_9506_p4.read());
}

void update_weights::thread_zext_ln332_46_fu_9690_p1() {
    zext_ln332_46_fu_9690_p1 = esl_zext<64,8>(lshr_ln332_41_fu_9680_p4.read());
}

void update_weights::thread_zext_ln332_47_fu_9864_p1() {
    zext_ln332_47_fu_9864_p1 = esl_zext<64,8>(lshr_ln332_42_fu_9854_p4.read());
}

void update_weights::thread_zext_ln332_48_fu_10038_p1() {
    zext_ln332_48_fu_10038_p1 = esl_zext<64,8>(lshr_ln332_43_fu_10028_p4.read());
}

void update_weights::thread_zext_ln332_49_fu_10212_p1() {
    zext_ln332_49_fu_10212_p1 = esl_zext<64,8>(lshr_ln332_44_fu_10202_p4.read());
}

void update_weights::thread_zext_ln332_4_fu_8720_p1() {
    zext_ln332_4_fu_8720_p1 = esl_zext<64,8>(lshr_ln_fu_8710_p4.read());
}

void update_weights::thread_zext_ln332_50_fu_10321_p1() {
    zext_ln332_50_fu_10321_p1 = esl_zext<64,8>(lshr_ln332_45_fu_10311_p4.read());
}

void update_weights::thread_zext_ln332_51_fu_10356_p1() {
    zext_ln332_51_fu_10356_p1 = esl_zext<64,8>(lshr_ln332_46_fu_10346_p4.read());
}

void update_weights::thread_zext_ln332_5_fu_8755_p1() {
    zext_ln332_5_fu_8755_p1 = esl_zext<64,8>(lshr_ln332_1_fu_8745_p4.read());
}

void update_weights::thread_zext_ln332_6_fu_8790_p1() {
    zext_ln332_6_fu_8790_p1 = esl_zext<64,8>(lshr_ln332_2_fu_8780_p4.read());
}

void update_weights::thread_zext_ln332_7_fu_8825_p1() {
    zext_ln332_7_fu_8825_p1 = esl_zext<64,8>(lshr_ln332_3_fu_8815_p4.read());
}

void update_weights::thread_zext_ln332_8_fu_8860_p1() {
    zext_ln332_8_fu_8860_p1 = esl_zext<64,8>(lshr_ln332_4_fu_8850_p4.read());
}

void update_weights::thread_zext_ln332_9_fu_8894_p1() {
    zext_ln332_9_fu_8894_p1 = esl_zext<64,8>(lshr_ln332_5_fu_8884_p4.read());
}

void update_weights::thread_zext_ln332_fu_8648_p1() {
    zext_ln332_fu_8648_p1 = esl_zext<64,8>(shl_ln332_1_fu_8640_p3.read());
}

void update_weights::thread_zext_ln334_10_fu_9258_p1() {
    zext_ln334_10_fu_9258_p1 = esl_zext<64,6>(lshr_ln334_9_reg_16429.read());
}

void update_weights::thread_zext_ln334_11_fu_9432_p1() {
    zext_ln334_11_fu_9432_p1 = esl_zext<64,6>(lshr_ln334_s_reg_16474.read());
}

void update_weights::thread_zext_ln334_12_fu_9606_p1() {
    zext_ln334_12_fu_9606_p1 = esl_zext<64,6>(lshr_ln334_10_reg_16529.read());
}

void update_weights::thread_zext_ln334_13_fu_9780_p1() {
    zext_ln334_13_fu_9780_p1 = esl_zext<64,6>(lshr_ln334_11_reg_16591.read());
}

void update_weights::thread_zext_ln334_14_fu_9954_p1() {
    zext_ln334_14_fu_9954_p1 = esl_zext<64,6>(lshr_ln334_12_reg_16667.read());
}

void update_weights::thread_zext_ln334_15_fu_10128_p1() {
    zext_ln334_15_fu_10128_p1 = esl_zext<64,6>(lshr_ln334_13_reg_16743.read());
}

void update_weights::thread_zext_ln334_16_fu_10302_p1() {
    zext_ln334_16_fu_10302_p1 = esl_zext<64,6>(lshr_ln334_14_reg_16819.read());
}

void update_weights::thread_zext_ln334_17_fu_9048_p1() {
    zext_ln334_17_fu_9048_p1 = esl_zext<64,6>(lshr_ln334_15_fu_9038_p4.read());
}

void update_weights::thread_zext_ln334_18_fu_9183_p1() {
    zext_ln334_18_fu_9183_p1 = esl_zext<64,6>(lshr_ln334_16_fu_9173_p4.read());
}

void update_weights::thread_zext_ln334_19_fu_9322_p1() {
    zext_ln334_19_fu_9322_p1 = esl_zext<64,6>(lshr_ln334_17_fu_9312_p4.read());
}

void update_weights::thread_zext_ln334_1_fu_8735_p1() {
    zext_ln334_1_fu_8735_p1 = esl_zext<64,6>(lshr_ln1_fu_8725_p4.read());
}

void update_weights::thread_zext_ln334_20_fu_9496_p1() {
    zext_ln334_20_fu_9496_p1 = esl_zext<64,6>(lshr_ln334_18_fu_9486_p4.read());
}

void update_weights::thread_zext_ln334_21_fu_9670_p1() {
    zext_ln334_21_fu_9670_p1 = esl_zext<64,6>(lshr_ln334_19_fu_9660_p4.read());
}

void update_weights::thread_zext_ln334_22_fu_9844_p1() {
    zext_ln334_22_fu_9844_p1 = esl_zext<64,6>(lshr_ln334_20_fu_9834_p4.read());
}

void update_weights::thread_zext_ln334_23_fu_10018_p1() {
    zext_ln334_23_fu_10018_p1 = esl_zext<64,6>(lshr_ln334_21_fu_10008_p4.read());
}

void update_weights::thread_zext_ln334_24_fu_10192_p1() {
    zext_ln334_24_fu_10192_p1 = esl_zext<64,6>(lshr_ln334_22_fu_10182_p4.read());
}

void update_weights::thread_zext_ln334_25_fu_9083_p1() {
    zext_ln334_25_fu_9083_p1 = esl_zext<64,6>(lshr_ln334_23_fu_9073_p4.read());
}

void update_weights::thread_zext_ln334_26_fu_9218_p1() {
    zext_ln334_26_fu_9218_p1 = esl_zext<64,6>(lshr_ln334_24_fu_9208_p4.read());
}

void update_weights::thread_zext_ln334_27_fu_9392_p1() {
    zext_ln334_27_fu_9392_p1 = esl_zext<64,6>(lshr_ln334_25_fu_9382_p4.read());
}

void update_weights::thread_zext_ln334_28_fu_9566_p1() {
    zext_ln334_28_fu_9566_p1 = esl_zext<64,6>(lshr_ln334_26_fu_9556_p4.read());
}

void update_weights::thread_zext_ln334_29_fu_9740_p1() {
    zext_ln334_29_fu_9740_p1 = esl_zext<64,6>(lshr_ln334_27_fu_9730_p4.read());
}

void update_weights::thread_zext_ln334_2_fu_8770_p1() {
    zext_ln334_2_fu_8770_p1 = esl_zext<64,6>(lshr_ln334_1_fu_8760_p4.read());
}

void update_weights::thread_zext_ln334_30_fu_9914_p1() {
    zext_ln334_30_fu_9914_p1 = esl_zext<64,6>(lshr_ln334_28_fu_9904_p4.read());
}

void update_weights::thread_zext_ln334_31_fu_10088_p1() {
    zext_ln334_31_fu_10088_p1 = esl_zext<64,6>(lshr_ln334_29_fu_10078_p4.read());
}

void update_weights::thread_zext_ln334_32_fu_10262_p1() {
    zext_ln334_32_fu_10262_p1 = esl_zext<64,6>(lshr_ln334_30_fu_10252_p4.read());
}

void update_weights::thread_zext_ln334_33_fu_9118_p1() {
    zext_ln334_33_fu_9118_p1 = esl_zext<64,6>(lshr_ln334_31_fu_9108_p4.read());
}

void update_weights::thread_zext_ln334_34_fu_9253_p1() {
    zext_ln334_34_fu_9253_p1 = esl_zext<64,6>(lshr_ln334_32_fu_9243_p4.read());
}

void update_weights::thread_zext_ln334_35_fu_9427_p1() {
    zext_ln334_35_fu_9427_p1 = esl_zext<64,6>(lshr_ln334_33_fu_9417_p4.read());
}

void update_weights::thread_zext_ln334_36_fu_9601_p1() {
    zext_ln334_36_fu_9601_p1 = esl_zext<64,6>(lshr_ln334_34_fu_9591_p4.read());
}

void update_weights::thread_zext_ln334_37_fu_9775_p1() {
    zext_ln334_37_fu_9775_p1 = esl_zext<64,6>(lshr_ln334_35_fu_9765_p4.read());
}

void update_weights::thread_zext_ln334_38_fu_9949_p1() {
    zext_ln334_38_fu_9949_p1 = esl_zext<64,6>(lshr_ln334_36_fu_9939_p4.read());
}

void update_weights::thread_zext_ln334_39_fu_10123_p1() {
    zext_ln334_39_fu_10123_p1 = esl_zext<64,6>(lshr_ln334_37_fu_10113_p4.read());
}

void update_weights::thread_zext_ln334_3_fu_8805_p1() {
    zext_ln334_3_fu_8805_p1 = esl_zext<64,6>(lshr_ln334_2_fu_8795_p4.read());
}

void update_weights::thread_zext_ln334_40_fu_10297_p1() {
    zext_ln334_40_fu_10297_p1 = esl_zext<64,6>(lshr_ln334_38_fu_10287_p4.read());
}

void update_weights::thread_zext_ln334_41_fu_9357_p1() {
    zext_ln334_41_fu_9357_p1 = esl_zext<64,6>(lshr_ln334_39_fu_9347_p4.read());
}

void update_weights::thread_zext_ln334_42_fu_9531_p1() {
    zext_ln334_42_fu_9531_p1 = esl_zext<64,6>(lshr_ln334_40_fu_9521_p4.read());
}

void update_weights::thread_zext_ln334_43_fu_9705_p1() {
    zext_ln334_43_fu_9705_p1 = esl_zext<64,6>(lshr_ln334_41_fu_9695_p4.read());
}

void update_weights::thread_zext_ln334_44_fu_9879_p1() {
    zext_ln334_44_fu_9879_p1 = esl_zext<64,6>(lshr_ln334_42_fu_9869_p4.read());
}

void update_weights::thread_zext_ln334_45_fu_10053_p1() {
    zext_ln334_45_fu_10053_p1 = esl_zext<64,6>(lshr_ln334_43_fu_10043_p4.read());
}

void update_weights::thread_zext_ln334_46_fu_10227_p1() {
    zext_ln334_46_fu_10227_p1 = esl_zext<64,6>(lshr_ln334_44_fu_10217_p4.read());
}

void update_weights::thread_zext_ln334_47_fu_10336_p1() {
    zext_ln334_47_fu_10336_p1 = esl_zext<64,6>(lshr_ln334_45_fu_10326_p4.read());
}

void update_weights::thread_zext_ln334_48_fu_10371_p1() {
    zext_ln334_48_fu_10371_p1 = esl_zext<64,6>(lshr_ln334_46_reg_16905.read());
}

void update_weights::thread_zext_ln334_4_fu_8840_p1() {
    zext_ln334_4_fu_8840_p1 = esl_zext<64,6>(lshr_ln334_3_fu_8830_p4.read());
}

void update_weights::thread_zext_ln334_5_fu_8875_p1() {
    zext_ln334_5_fu_8875_p1 = esl_zext<64,6>(lshr_ln334_4_reg_16304.read());
}

void update_weights::thread_zext_ln334_6_fu_8909_p1() {
    zext_ln334_6_fu_8909_p1 = esl_zext<64,6>(lshr_ln334_5_fu_8899_p4.read());
}

void update_weights::thread_zext_ln334_7_fu_8944_p1() {
    zext_ln334_7_fu_8944_p1 = esl_zext<64,6>(lshr_ln334_6_fu_8934_p4.read());
}

void update_weights::thread_zext_ln334_8_fu_8979_p1() {
    zext_ln334_8_fu_8979_p1 = esl_zext<64,6>(lshr_ln334_7_reg_16360.read());
}

void update_weights::thread_zext_ln334_9_fu_9013_p1() {
    zext_ln334_9_fu_9013_p1 = esl_zext<64,6>(lshr_ln334_8_fu_9003_p4.read());
}

void update_weights::thread_zext_ln334_fu_8661_p1() {
    zext_ln334_fu_8661_p1 = esl_zext<64,6>(shl_ln1_fu_8653_p3.read());
}

void update_weights::thread_zext_ln356_1_fu_10411_p1() {
    zext_ln356_1_fu_10411_p1 = esl_zext<64,4>(or_ln356_fu_10405_p2.read());
}

void update_weights::thread_zext_ln356_fu_10393_p1() {
    zext_ln356_fu_10393_p1 = esl_zext<64,4>(shl_ln356_fu_10387_p2.read());
}

void update_weights::thread_zext_ln373_1_fu_10469_p1() {
    zext_ln373_1_fu_10469_p1 = esl_zext<64,6>(or_ln373_fu_10463_p2.read());
}

void update_weights::thread_zext_ln373_2_fu_10494_p1() {
    zext_ln373_2_fu_10494_p1 = esl_zext<64,6>(or_ln373_1_fu_10489_p2.read());
}

void update_weights::thread_zext_ln373_3_fu_10519_p1() {
    zext_ln373_3_fu_10519_p1 = esl_zext<64,6>(or_ln373_2_fu_10514_p2.read());
}

void update_weights::thread_zext_ln373_fu_10443_p1() {
    zext_ln373_fu_10443_p1 = esl_zext<64,6>(shl_ln3_fu_10435_p3.read());
}

void update_weights::thread_zext_ln382_1_fu_10577_p1() {
    zext_ln382_1_fu_10577_p1 = esl_zext<64,4>(or_ln382_fu_10571_p2.read());
}

void update_weights::thread_zext_ln382_2_fu_10590_p1() {
    zext_ln382_2_fu_10590_p1 = esl_zext<64,4>(or_ln382_1_fu_10585_p2.read());
}

void update_weights::thread_zext_ln382_3_fu_10603_p1() {
    zext_ln382_3_fu_10603_p1 = esl_zext<64,4>(or_ln382_2_fu_10598_p2.read());
}

void update_weights::thread_zext_ln382_4_fu_10616_p1() {
    zext_ln382_4_fu_10616_p1 = esl_zext<64,4>(or_ln382_3_fu_10611_p2.read());
}

void update_weights::thread_zext_ln382_5_fu_10629_p1() {
    zext_ln382_5_fu_10629_p1 = esl_zext<64,4>(or_ln382_4_fu_10624_p2.read());
}

void update_weights::thread_zext_ln382_6_fu_10642_p1() {
    zext_ln382_6_fu_10642_p1 = esl_zext<64,4>(or_ln382_5_fu_10637_p2.read());
}

void update_weights::thread_zext_ln382_7_fu_10655_p1() {
    zext_ln382_7_fu_10655_p1 = esl_zext<64,4>(or_ln382_6_fu_10650_p2.read());
}

void update_weights::thread_zext_ln382_fu_10563_p1() {
    zext_ln382_fu_10563_p1 = esl_zext<64,4>(shl_ln4_fu_10555_p3.read());
}

void update_weights::thread_zext_ln400_10_fu_10961_p1() {
    zext_ln400_10_fu_10961_p1 = esl_zext<64,10>(lshr_ln400_6_fu_10951_p4.read());
}

void update_weights::thread_zext_ln400_11_fu_10995_p1() {
    zext_ln400_11_fu_10995_p1 = esl_zext<64,10>(lshr_ln400_7_fu_10985_p4.read());
}

void update_weights::thread_zext_ln400_12_fu_11029_p1() {
    zext_ln400_12_fu_11029_p1 = esl_zext<64,10>(lshr_ln400_8_fu_11019_p4.read());
}

void update_weights::thread_zext_ln400_13_fu_11098_p1() {
    zext_ln400_13_fu_11098_p1 = esl_zext<64,10>(lshr_ln400_9_fu_11088_p4.read());
}

void update_weights::thread_zext_ln400_14_fu_11132_p1() {
    zext_ln400_14_fu_11132_p1 = esl_zext<64,10>(lshr_ln400_s_fu_11122_p4.read());
}

void update_weights::thread_zext_ln400_15_fu_11166_p1() {
    zext_ln400_15_fu_11166_p1 = esl_zext<64,10>(lshr_ln400_10_fu_11156_p4.read());
}

void update_weights::thread_zext_ln400_16_fu_11200_p1() {
    zext_ln400_16_fu_11200_p1 = esl_zext<64,10>(lshr_ln400_11_fu_11190_p4.read());
}

void update_weights::thread_zext_ln400_17_fu_11234_p1() {
    zext_ln400_17_fu_11234_p1 = esl_zext<64,10>(lshr_ln400_12_fu_11224_p4.read());
}

void update_weights::thread_zext_ln400_18_fu_11268_p1() {
    zext_ln400_18_fu_11268_p1 = esl_zext<64,10>(lshr_ln400_13_fu_11258_p4.read());
}

void update_weights::thread_zext_ln400_19_fu_11302_p1() {
    zext_ln400_19_fu_11302_p1 = esl_zext<64,10>(lshr_ln400_14_fu_11292_p4.read());
}

void update_weights::thread_zext_ln400_1_fu_10709_p1() {
    zext_ln400_1_fu_10709_p1 = esl_zext<64,10>(or_ln400_fu_10704_p2.read());
}

void update_weights::thread_zext_ln400_20_fu_11059_p1() {
    zext_ln400_20_fu_11059_p1 = esl_zext<64,10>(lshr_ln400_15_fu_11049_p4.read());
}

void update_weights::thread_zext_ln400_21_fu_11336_p1() {
    zext_ln400_21_fu_11336_p1 = esl_zext<64,10>(lshr_ln400_16_fu_11326_p4.read());
}

void update_weights::thread_zext_ln400_22_fu_11370_p1() {
    zext_ln400_22_fu_11370_p1 = esl_zext<64,10>(lshr_ln400_17_fu_11360_p4.read());
}

void update_weights::thread_zext_ln400_23_fu_11404_p1() {
    zext_ln400_23_fu_11404_p1 = esl_zext<64,10>(lshr_ln400_18_fu_11394_p4.read());
}

void update_weights::thread_zext_ln400_24_fu_11438_p1() {
    zext_ln400_24_fu_11438_p1 = esl_zext<64,10>(lshr_ln400_19_fu_11428_p4.read());
}

void update_weights::thread_zext_ln400_25_fu_11472_p1() {
    zext_ln400_25_fu_11472_p1 = esl_zext<64,10>(lshr_ln400_20_fu_11462_p4.read());
}

void update_weights::thread_zext_ln400_26_fu_11506_p1() {
    zext_ln400_26_fu_11506_p1 = esl_zext<64,10>(lshr_ln400_21_fu_11496_p4.read());
}

void update_weights::thread_zext_ln400_27_fu_11540_p1() {
    zext_ln400_27_fu_11540_p1 = esl_zext<64,10>(lshr_ln400_22_fu_11530_p4.read());
}

void update_weights::thread_zext_ln400_28_fu_11574_p1() {
    zext_ln400_28_fu_11574_p1 = esl_zext<64,10>(lshr_ln400_23_fu_11564_p4.read());
}

void update_weights::thread_zext_ln400_29_fu_11643_p1() {
    zext_ln400_29_fu_11643_p1 = esl_zext<64,10>(lshr_ln400_24_fu_11633_p4.read());
}

void update_weights::thread_zext_ln400_2_fu_10719_p1() {
    zext_ln400_2_fu_10719_p1 = esl_zext<64,10>(or_ln400_1_fu_10714_p2.read());
}

void update_weights::thread_zext_ln400_30_fu_11677_p1() {
    zext_ln400_30_fu_11677_p1 = esl_zext<64,10>(lshr_ln400_25_fu_11667_p4.read());
}

void update_weights::thread_zext_ln400_31_fu_11711_p1() {
    zext_ln400_31_fu_11711_p1 = esl_zext<64,10>(lshr_ln400_26_fu_11701_p4.read());
}

void update_weights::thread_zext_ln400_32_fu_11745_p1() {
    zext_ln400_32_fu_11745_p1 = esl_zext<64,10>(lshr_ln400_27_fu_11735_p4.read());
}

void update_weights::thread_zext_ln400_33_fu_11779_p1() {
    zext_ln400_33_fu_11779_p1 = esl_zext<64,10>(lshr_ln400_28_fu_11769_p4.read());
}

void update_weights::thread_zext_ln400_34_fu_11813_p1() {
    zext_ln400_34_fu_11813_p1 = esl_zext<64,10>(lshr_ln400_29_fu_11803_p4.read());
}

void update_weights::thread_zext_ln400_35_fu_11847_p1() {
    zext_ln400_35_fu_11847_p1 = esl_zext<64,10>(lshr_ln400_30_fu_11837_p4.read());
}

void update_weights::thread_zext_ln400_36_fu_11604_p1() {
    zext_ln400_36_fu_11604_p1 = esl_zext<64,10>(lshr_ln400_31_fu_11594_p4.read());
}

void update_weights::thread_zext_ln400_37_fu_11881_p1() {
    zext_ln400_37_fu_11881_p1 = esl_zext<64,10>(lshr_ln400_32_fu_11871_p4.read());
}

void update_weights::thread_zext_ln400_38_fu_11915_p1() {
    zext_ln400_38_fu_11915_p1 = esl_zext<64,10>(lshr_ln400_33_fu_11905_p4.read());
}

void update_weights::thread_zext_ln400_39_fu_11949_p1() {
    zext_ln400_39_fu_11949_p1 = esl_zext<64,10>(lshr_ln400_34_fu_11939_p4.read());
}

void update_weights::thread_zext_ln400_3_fu_10729_p1() {
    zext_ln400_3_fu_10729_p1 = esl_zext<64,10>(or_ln400_2_fu_10724_p2.read());
}

void update_weights::thread_zext_ln400_40_fu_11983_p1() {
    zext_ln400_40_fu_11983_p1 = esl_zext<64,10>(lshr_ln400_35_fu_11973_p4.read());
}

void update_weights::thread_zext_ln400_41_fu_12017_p1() {
    zext_ln400_41_fu_12017_p1 = esl_zext<64,10>(lshr_ln400_36_fu_12007_p4.read());
}

void update_weights::thread_zext_ln400_42_fu_12051_p1() {
    zext_ln400_42_fu_12051_p1 = esl_zext<64,10>(lshr_ln400_37_fu_12041_p4.read());
}

void update_weights::thread_zext_ln400_43_fu_12085_p1() {
    zext_ln400_43_fu_12085_p1 = esl_zext<64,10>(lshr_ln400_38_fu_12075_p4.read());
}

void update_weights::thread_zext_ln400_44_fu_12119_p1() {
    zext_ln400_44_fu_12119_p1 = esl_zext<64,10>(lshr_ln400_39_fu_12109_p4.read());
}

void update_weights::thread_zext_ln400_45_fu_12153_p1() {
    zext_ln400_45_fu_12153_p1 = esl_zext<64,10>(lshr_ln400_40_fu_12143_p4.read());
}

void update_weights::thread_zext_ln400_46_fu_12187_p1() {
    zext_ln400_46_fu_12187_p1 = esl_zext<64,10>(lshr_ln400_41_fu_12177_p4.read());
}

void update_weights::thread_zext_ln400_47_fu_12221_p1() {
    zext_ln400_47_fu_12221_p1 = esl_zext<64,10>(lshr_ln400_42_fu_12211_p4.read());
}

void update_weights::thread_zext_ln400_48_fu_12255_p1() {
    zext_ln400_48_fu_12255_p1 = esl_zext<64,10>(lshr_ln400_43_fu_12245_p4.read());
}

void update_weights::thread_zext_ln400_49_fu_12289_p1() {
    zext_ln400_49_fu_12289_p1 = esl_zext<64,10>(lshr_ln400_44_fu_12279_p4.read());
}

void update_weights::thread_zext_ln400_4_fu_10757_p1() {
    zext_ln400_4_fu_10757_p1 = esl_zext<64,10>(lshr_ln2_fu_10747_p4.read());
}

void update_weights::thread_zext_ln400_50_fu_12323_p1() {
    zext_ln400_50_fu_12323_p1 = esl_zext<64,10>(lshr_ln400_45_fu_12313_p4.read());
}

void update_weights::thread_zext_ln400_51_fu_12357_p1() {
    zext_ln400_51_fu_12357_p1 = esl_zext<64,10>(lshr_ln400_46_fu_12347_p4.read());
}

void update_weights::thread_zext_ln400_5_fu_10791_p1() {
    zext_ln400_5_fu_10791_p1 = esl_zext<64,10>(lshr_ln400_1_fu_10781_p4.read());
}

void update_weights::thread_zext_ln400_6_fu_10825_p1() {
    zext_ln400_6_fu_10825_p1 = esl_zext<64,10>(lshr_ln400_2_fu_10815_p4.read());
}

void update_weights::thread_zext_ln400_7_fu_10859_p1() {
    zext_ln400_7_fu_10859_p1 = esl_zext<64,10>(lshr_ln400_3_fu_10849_p4.read());
}

void update_weights::thread_zext_ln400_8_fu_10893_p1() {
    zext_ln400_8_fu_10893_p1 = esl_zext<64,10>(lshr_ln400_4_fu_10883_p4.read());
}

void update_weights::thread_zext_ln400_9_fu_10927_p1() {
    zext_ln400_9_fu_10927_p1 = esl_zext<64,10>(lshr_ln400_5_fu_10917_p4.read());
}

void update_weights::thread_zext_ln400_fu_10687_p1() {
    zext_ln400_fu_10687_p1 = esl_zext<64,10>(shl_ln400_1_fu_10679_p3.read());
}

void update_weights::thread_zext_ln402_10_fu_11113_p1() {
    zext_ln402_10_fu_11113_p1 = esl_zext<64,8>(lshr_ln402_9_reg_18354.read());
}

void update_weights::thread_zext_ln402_11_fu_11147_p1() {
    zext_ln402_11_fu_11147_p1 = esl_zext<64,8>(lshr_ln402_s_reg_18369.read());
}

void update_weights::thread_zext_ln402_12_fu_11181_p1() {
    zext_ln402_12_fu_11181_p1 = esl_zext<64,8>(lshr_ln402_10_reg_18384.read());
}

void update_weights::thread_zext_ln402_13_fu_11215_p1() {
    zext_ln402_13_fu_11215_p1 = esl_zext<64,8>(lshr_ln402_11_reg_18399.read());
}

void update_weights::thread_zext_ln402_14_fu_11249_p1() {
    zext_ln402_14_fu_11249_p1 = esl_zext<64,8>(lshr_ln402_12_reg_18414.read());
}

void update_weights::thread_zext_ln402_15_fu_11283_p1() {
    zext_ln402_15_fu_11283_p1 = esl_zext<64,8>(lshr_ln402_13_reg_18429.read());
}

void update_weights::thread_zext_ln402_16_fu_11317_p1() {
    zext_ln402_16_fu_11317_p1 = esl_zext<64,8>(lshr_ln402_14_reg_18444.read());
}

void update_weights::thread_zext_ln402_17_fu_11074_p1() {
    zext_ln402_17_fu_11074_p1 = esl_zext<64,8>(lshr_ln402_15_fu_11064_p4.read());
}

void update_weights::thread_zext_ln402_18_fu_11351_p1() {
    zext_ln402_18_fu_11351_p1 = esl_zext<64,8>(lshr_ln402_16_reg_18459.read());
}

void update_weights::thread_zext_ln402_19_fu_11385_p1() {
    zext_ln402_19_fu_11385_p1 = esl_zext<64,8>(lshr_ln402_17_reg_18474.read());
}

void update_weights::thread_zext_ln402_1_fu_10772_p1() {
    zext_ln402_1_fu_10772_p1 = esl_zext<64,8>(lshr_ln3_reg_18209.read());
}

void update_weights::thread_zext_ln402_20_fu_11419_p1() {
    zext_ln402_20_fu_11419_p1 = esl_zext<64,8>(lshr_ln402_18_reg_18489.read());
}

void update_weights::thread_zext_ln402_21_fu_11453_p1() {
    zext_ln402_21_fu_11453_p1 = esl_zext<64,8>(lshr_ln402_19_reg_18504.read());
}

void update_weights::thread_zext_ln402_22_fu_11487_p1() {
    zext_ln402_22_fu_11487_p1 = esl_zext<64,8>(lshr_ln402_20_reg_18519.read());
}

void update_weights::thread_zext_ln402_23_fu_11521_p1() {
    zext_ln402_23_fu_11521_p1 = esl_zext<64,8>(lshr_ln402_21_reg_18534.read());
}

void update_weights::thread_zext_ln402_24_fu_11555_p1() {
    zext_ln402_24_fu_11555_p1 = esl_zext<64,8>(lshr_ln402_22_reg_18549.read());
}

void update_weights::thread_zext_ln402_25_fu_11624_p1() {
    zext_ln402_25_fu_11624_p1 = esl_zext<64,8>(lshr_ln402_23_reg_18564.read());
}

void update_weights::thread_zext_ln402_26_fu_11658_p1() {
    zext_ln402_26_fu_11658_p1 = esl_zext<64,8>(lshr_ln402_24_reg_18589.read());
}

void update_weights::thread_zext_ln402_27_fu_11692_p1() {
    zext_ln402_27_fu_11692_p1 = esl_zext<64,8>(lshr_ln402_25_reg_18604.read());
}

void update_weights::thread_zext_ln402_28_fu_11726_p1() {
    zext_ln402_28_fu_11726_p1 = esl_zext<64,8>(lshr_ln402_26_reg_18619.read());
}

void update_weights::thread_zext_ln402_29_fu_11760_p1() {
    zext_ln402_29_fu_11760_p1 = esl_zext<64,8>(lshr_ln402_27_reg_18634.read());
}

void update_weights::thread_zext_ln402_2_fu_10806_p1() {
    zext_ln402_2_fu_10806_p1 = esl_zext<64,8>(lshr_ln402_1_reg_18224.read());
}

void update_weights::thread_zext_ln402_30_fu_11794_p1() {
    zext_ln402_30_fu_11794_p1 = esl_zext<64,8>(lshr_ln402_28_reg_18649.read());
}

void update_weights::thread_zext_ln402_31_fu_11828_p1() {
    zext_ln402_31_fu_11828_p1 = esl_zext<64,8>(lshr_ln402_29_reg_18664.read());
}

void update_weights::thread_zext_ln402_32_fu_11862_p1() {
    zext_ln402_32_fu_11862_p1 = esl_zext<64,8>(lshr_ln402_30_reg_18679.read());
}

void update_weights::thread_zext_ln402_33_fu_11619_p1() {
    zext_ln402_33_fu_11619_p1 = esl_zext<64,8>(lshr_ln402_31_fu_11609_p4.read());
}

void update_weights::thread_zext_ln402_34_fu_11896_p1() {
    zext_ln402_34_fu_11896_p1 = esl_zext<64,8>(lshr_ln402_32_reg_18694.read());
}

void update_weights::thread_zext_ln402_35_fu_11930_p1() {
    zext_ln402_35_fu_11930_p1 = esl_zext<64,8>(lshr_ln402_33_reg_18709.read());
}

void update_weights::thread_zext_ln402_36_fu_11964_p1() {
    zext_ln402_36_fu_11964_p1 = esl_zext<64,8>(lshr_ln402_34_reg_18724.read());
}

void update_weights::thread_zext_ln402_37_fu_11998_p1() {
    zext_ln402_37_fu_11998_p1 = esl_zext<64,8>(lshr_ln402_35_reg_18739.read());
}

void update_weights::thread_zext_ln402_38_fu_12032_p1() {
    zext_ln402_38_fu_12032_p1 = esl_zext<64,8>(lshr_ln402_36_reg_18754.read());
}

void update_weights::thread_zext_ln402_39_fu_12066_p1() {
    zext_ln402_39_fu_12066_p1 = esl_zext<64,8>(lshr_ln402_37_reg_18769.read());
}

void update_weights::thread_zext_ln402_3_fu_10840_p1() {
    zext_ln402_3_fu_10840_p1 = esl_zext<64,8>(lshr_ln402_2_reg_18239.read());
}

void update_weights::thread_zext_ln402_40_fu_12100_p1() {
    zext_ln402_40_fu_12100_p1 = esl_zext<64,8>(lshr_ln402_38_reg_18784.read());
}

void update_weights::thread_zext_ln402_41_fu_12134_p1() {
    zext_ln402_41_fu_12134_p1 = esl_zext<64,8>(lshr_ln402_39_reg_18799.read());
}

void update_weights::thread_zext_ln402_42_fu_12168_p1() {
    zext_ln402_42_fu_12168_p1 = esl_zext<64,8>(lshr_ln402_40_reg_18814.read());
}

void update_weights::thread_zext_ln402_43_fu_12202_p1() {
    zext_ln402_43_fu_12202_p1 = esl_zext<64,8>(lshr_ln402_41_reg_18829.read());
}

void update_weights::thread_zext_ln402_44_fu_12236_p1() {
    zext_ln402_44_fu_12236_p1 = esl_zext<64,8>(lshr_ln402_42_reg_18844.read());
}

void update_weights::thread_zext_ln402_45_fu_12270_p1() {
    zext_ln402_45_fu_12270_p1 = esl_zext<64,8>(lshr_ln402_43_reg_18859.read());
}

void update_weights::thread_zext_ln402_46_fu_12304_p1() {
    zext_ln402_46_fu_12304_p1 = esl_zext<64,8>(lshr_ln402_44_reg_18874.read());
}

void update_weights::thread_zext_ln402_47_fu_12338_p1() {
    zext_ln402_47_fu_12338_p1 = esl_zext<64,8>(lshr_ln402_45_reg_18889.read());
}

void update_weights::thread_zext_ln402_48_fu_12372_p1() {
    zext_ln402_48_fu_12372_p1 = esl_zext<64,8>(lshr_ln402_46_reg_18904.read());
}

void update_weights::thread_zext_ln402_4_fu_10874_p1() {
    zext_ln402_4_fu_10874_p1 = esl_zext<64,8>(lshr_ln402_3_reg_18254.read());
}

void update_weights::thread_zext_ln402_5_fu_10908_p1() {
    zext_ln402_5_fu_10908_p1 = esl_zext<64,8>(lshr_ln402_4_reg_18269.read());
}

void update_weights::thread_zext_ln402_6_fu_10942_p1() {
    zext_ln402_6_fu_10942_p1 = esl_zext<64,8>(lshr_ln402_5_reg_18284.read());
}

void update_weights::thread_zext_ln402_7_fu_10976_p1() {
    zext_ln402_7_fu_10976_p1 = esl_zext<64,8>(lshr_ln402_6_reg_18299.read());
}

void update_weights::thread_zext_ln402_8_fu_11010_p1() {
    zext_ln402_8_fu_11010_p1 = esl_zext<64,8>(lshr_ln402_7_reg_18314.read());
}

void update_weights::thread_zext_ln402_9_fu_11079_p1() {
    zext_ln402_9_fu_11079_p1 = esl_zext<64,8>(lshr_ln402_8_reg_18329.read());
}

void update_weights::thread_zext_ln402_fu_10699_p1() {
    zext_ln402_fu_10699_p1 = esl_zext<64,8>(shl_ln6_fu_10692_p3.read());
}

void update_weights::thread_zext_ln424_1_fu_12412_p1() {
    zext_ln424_1_fu_12412_p1 = esl_zext<64,4>(or_ln424_fu_12406_p2.read());
}

void update_weights::thread_zext_ln424_fu_12394_p1() {
    zext_ln424_fu_12394_p1 = esl_zext<64,4>(shl_ln424_fu_12388_p2.read());
}

void update_weights::thread_zext_ln443_1_fu_12480_p1() {
    zext_ln443_1_fu_12480_p1 = esl_zext<64,8>(or_ln443_fu_12474_p2.read());
}

void update_weights::thread_zext_ln443_2_fu_12505_p1() {
    zext_ln443_2_fu_12505_p1 = esl_zext<64,8>(or_ln443_1_fu_12500_p2.read());
}

void update_weights::thread_zext_ln443_3_fu_12530_p1() {
    zext_ln443_3_fu_12530_p1 = esl_zext<64,8>(or_ln443_2_fu_12525_p2.read());
}

void update_weights::thread_zext_ln443_4_fu_12563_p1() {
    zext_ln443_4_fu_12563_p1 = esl_zext<64,8>(shl_ln443_1_fu_12555_p3.read());
}

void update_weights::thread_zext_ln443_5_fu_12589_p1() {
    zext_ln443_5_fu_12589_p1 = esl_zext<64,8>(or_ln443_4_fu_12583_p2.read());
}

void update_weights::thread_zext_ln443_6_fu_12614_p1() {
    zext_ln443_6_fu_12614_p1 = esl_zext<64,8>(or_ln443_5_fu_12609_p2.read());
}

void update_weights::thread_zext_ln443_7_fu_12639_p1() {
    zext_ln443_7_fu_12639_p1 = esl_zext<64,8>(or_ln443_6_fu_12634_p2.read());
}

void update_weights::thread_zext_ln443_fu_12454_p1() {
    zext_ln443_fu_12454_p1 = esl_zext<64,8>(shl_ln9_fu_12446_p3.read());
}

void update_weights::thread_zext_ln453_1_fu_12697_p1() {
    zext_ln453_1_fu_12697_p1 = esl_zext<64,4>(or_ln453_fu_12691_p2.read());
}

void update_weights::thread_zext_ln453_2_fu_12710_p1() {
    zext_ln453_2_fu_12710_p1 = esl_zext<64,4>(or_ln453_1_fu_12705_p2.read());
}

void update_weights::thread_zext_ln453_3_fu_12723_p1() {
    zext_ln453_3_fu_12723_p1 = esl_zext<64,4>(or_ln453_2_fu_12718_p2.read());
}

void update_weights::thread_zext_ln453_4_fu_12736_p1() {
    zext_ln453_4_fu_12736_p1 = esl_zext<64,4>(or_ln453_3_fu_12731_p2.read());
}

void update_weights::thread_zext_ln453_5_fu_12749_p1() {
    zext_ln453_5_fu_12749_p1 = esl_zext<64,4>(or_ln453_4_fu_12744_p2.read());
}

void update_weights::thread_zext_ln453_6_fu_12762_p1() {
    zext_ln453_6_fu_12762_p1 = esl_zext<64,4>(or_ln453_5_fu_12757_p2.read());
}

void update_weights::thread_zext_ln453_7_fu_12775_p1() {
    zext_ln453_7_fu_12775_p1 = esl_zext<64,4>(or_ln453_6_fu_12770_p2.read());
}

void update_weights::thread_zext_ln453_fu_12683_p1() {
    zext_ln453_fu_12683_p1 = esl_zext<64,4>(shl_ln2_fu_12675_p3.read());
}

void update_weights::thread_zext_ln467_1_fu_12902_p1() {
    zext_ln467_1_fu_12902_p1 = esl_zext<9,6>(or_ln467_fu_12896_p2.read());
}

void update_weights::thread_zext_ln467_2_fu_13045_p1() {
    zext_ln467_2_fu_13045_p1 = esl_zext<9,6>(or_ln467_1_fu_13039_p2.read());
}

void update_weights::thread_zext_ln467_3_fu_13140_p1() {
    zext_ln467_3_fu_13140_p1 = esl_zext<9,6>(or_ln467_2_fu_13135_p2.read());
}

void update_weights::thread_zext_ln467_fu_12807_p1() {
    zext_ln467_fu_12807_p1 = esl_zext<9,6>(shl_ln7_fu_12799_p3.read());
}

void update_weights::thread_zext_ln473_10_fu_12914_p1() {
    zext_ln473_10_fu_12914_p1 = esl_zext<9,8>(shl_ln473_1_fu_12906_p3.read());
}

void update_weights::thread_zext_ln473_11_fu_13057_p1() {
    zext_ln473_11_fu_13057_p1 = esl_zext<9,8>(shl_ln473_2_fu_13049_p3.read());
}

void update_weights::thread_zext_ln473_12_fu_13152_p1() {
    zext_ln473_12_fu_13152_p1 = esl_zext<9,8>(shl_ln473_3_fu_13144_p3.read());
}

void update_weights::thread_zext_ln473_1_fu_12938_p1() {
    zext_ln473_1_fu_12938_p1 = esl_zext<64,30>(sext_ln473_1_fu_12934_p1.read());
}

void update_weights::thread_zext_ln473_2_fu_12989_p1() {
    zext_ln473_2_fu_12989_p1 = esl_zext<64,30>(sext_ln473_2_fu_12985_p1.read());
}

void update_weights::thread_zext_ln473_3_fu_13024_p1() {
    zext_ln473_3_fu_13024_p1 = esl_zext<64,30>(sext_ln473_3_fu_13020_p1.read());
}

void update_weights::thread_zext_ln473_4_fu_13081_p1() {
    zext_ln473_4_fu_13081_p1 = esl_zext<64,30>(sext_ln473_4_fu_13077_p1.read());
}

void update_weights::thread_zext_ln473_5_fu_13120_p1() {
    zext_ln473_5_fu_13120_p1 = esl_zext<64,30>(sext_ln473_5_fu_13116_p1.read());
}

void update_weights::thread_zext_ln473_6_fu_13176_p1() {
    zext_ln473_6_fu_13176_p1 = esl_zext<64,30>(sext_ln473_6_fu_13172_p1.read());
}

void update_weights::thread_zext_ln473_7_fu_13215_p1() {
    zext_ln473_7_fu_13215_p1 = esl_zext<64,30>(sext_ln473_7_fu_13211_p1.read());
}

void update_weights::thread_zext_ln473_8_fu_13250_p1() {
    zext_ln473_8_fu_13250_p1 = esl_zext<64,30>(sext_ln473_8_fu_13246_p1.read());
}

void update_weights::thread_zext_ln473_9_fu_12819_p1() {
    zext_ln473_9_fu_12819_p1 = esl_zext<9,8>(shl_ln8_fu_12811_p3.read());
}

void update_weights::thread_zext_ln473_fu_12843_p1() {
    zext_ln473_fu_12843_p1 = esl_zext<64,30>(sext_ln473_fu_12839_p1.read());
}

void update_weights::thread_zext_ln475_1_fu_12961_p1() {
    zext_ln475_1_fu_12961_p1 = esl_zext<64,28>(sext_ln475_1_fu_12957_p1.read());
}

void update_weights::thread_zext_ln475_2_fu_13268_p1() {
    zext_ln475_2_fu_13268_p1 = esl_zext<64,28>(sext_ln475_2_fu_13265_p1.read());
}

void update_weights::thread_zext_ln475_3_fu_13279_p1() {
    zext_ln475_3_fu_13279_p1 = esl_zext<64,28>(sext_ln475_3_fu_13276_p1.read());
}

void update_weights::thread_zext_ln475_4_fu_13290_p1() {
    zext_ln475_4_fu_13290_p1 = esl_zext<64,28>(sext_ln475_4_fu_13287_p1.read());
}

void update_weights::thread_zext_ln475_5_fu_13310_p1() {
    zext_ln475_5_fu_13310_p1 = esl_zext<64,28>(sext_ln475_5_fu_13307_p1.read());
}

void update_weights::thread_zext_ln475_6_fu_13321_p1() {
    zext_ln475_6_fu_13321_p1 = esl_zext<64,28>(sext_ln475_6_fu_13318_p1.read());
}

void update_weights::thread_zext_ln475_7_fu_13332_p1() {
    zext_ln475_7_fu_13332_p1 = esl_zext<64,28>(sext_ln475_7_fu_13329_p1.read());
}

void update_weights::thread_zext_ln475_8_fu_13343_p1() {
    zext_ln475_8_fu_13343_p1 = esl_zext<64,28>(sext_ln475_8_fu_13340_p1.read());
}

void update_weights::thread_zext_ln475_fu_12868_p1() {
    zext_ln475_fu_12868_p1 = esl_zext<64,28>(sext_ln475_fu_12864_p1.read());
}

void update_weights::thread_zext_ln496_fu_13363_p1() {
    zext_ln496_fu_13363_p1 = esl_zext<64,2>(ap_phi_mux_v114_0_phi_fu_7131_p4.read());
}

void update_weights::thread_zext_ln512_10_fu_14174_p1() {
    zext_ln512_10_fu_14174_p1 = esl_zext<9,6>(or_ln512_9_fu_14169_p2.read());
}

void update_weights::thread_zext_ln512_11_fu_14246_p1() {
    zext_ln512_11_fu_14246_p1 = esl_zext<9,6>(or_ln512_10_fu_14241_p2.read());
}

void update_weights::thread_zext_ln512_12_fu_14342_p1() {
    zext_ln512_12_fu_14342_p1 = esl_zext<9,6>(or_ln512_11_fu_14337_p2.read());
}

void update_weights::thread_zext_ln512_13_fu_14390_p1() {
    zext_ln512_13_fu_14390_p1 = esl_zext<9,6>(or_ln512_12_fu_14385_p2.read());
}

void update_weights::thread_zext_ln512_14_fu_14486_p1() {
    zext_ln512_14_fu_14486_p1 = esl_zext<9,6>(or_ln512_13_fu_14481_p2.read());
}

void update_weights::thread_zext_ln512_15_fu_14558_p1() {
    zext_ln512_15_fu_14558_p1 = esl_zext<9,6>(or_ln512_14_fu_14553_p2.read());
}

void update_weights::thread_zext_ln512_16_fu_14654_p1() {
    zext_ln512_16_fu_14654_p1 = esl_zext<9,6>(or_ln512_15_fu_14649_p2.read());
}

void update_weights::thread_zext_ln512_17_fu_14702_p1() {
    zext_ln512_17_fu_14702_p1 = esl_zext<9,6>(or_ln512_16_fu_14697_p2.read());
}

void update_weights::thread_zext_ln512_18_fu_14798_p1() {
    zext_ln512_18_fu_14798_p1 = esl_zext<9,6>(or_ln512_17_fu_14793_p2.read());
}

void update_weights::thread_zext_ln512_19_fu_14870_p1() {
    zext_ln512_19_fu_14870_p1 = esl_zext<9,6>(or_ln512_18_fu_14865_p2.read());
}

void update_weights::thread_zext_ln512_1_fu_13450_p1() {
    zext_ln512_1_fu_13450_p1 = esl_zext<9,6>(or_ln512_fu_13444_p2.read());
}

void update_weights::thread_zext_ln512_20_fu_14966_p1() {
    zext_ln512_20_fu_14966_p1 = esl_zext<9,6>(or_ln512_19_fu_14961_p2.read());
}

void update_weights::thread_zext_ln512_21_fu_15014_p1() {
    zext_ln512_21_fu_15014_p1 = esl_zext<9,6>(or_ln512_20_fu_15009_p2.read());
}

void update_weights::thread_zext_ln512_22_fu_15110_p1() {
    zext_ln512_22_fu_15110_p1 = esl_zext<9,6>(or_ln512_21_fu_15105_p2.read());
}

void update_weights::thread_zext_ln512_23_fu_15182_p1() {
    zext_ln512_23_fu_15182_p1 = esl_zext<9,6>(or_ln512_22_fu_15177_p2.read());
}

void update_weights::thread_zext_ln512_24_fu_15278_p1() {
    zext_ln512_24_fu_15278_p1 = esl_zext<9,6>(or_ln512_23_fu_15273_p2.read());
}

void update_weights::thread_zext_ln512_25_fu_15326_p1() {
    zext_ln512_25_fu_15326_p1 = esl_zext<9,6>(or_ln512_24_fu_15321_p2.read());
}

void update_weights::thread_zext_ln512_26_fu_15422_p1() {
    zext_ln512_26_fu_15422_p1 = esl_zext<9,6>(or_ln512_25_fu_15417_p2.read());
}

void update_weights::thread_zext_ln512_27_fu_15494_p1() {
    zext_ln512_27_fu_15494_p1 = esl_zext<9,6>(or_ln512_26_fu_15489_p2.read());
}

void update_weights::thread_zext_ln512_28_fu_15590_p1() {
    zext_ln512_28_fu_15590_p1 = esl_zext<9,6>(or_ln512_27_fu_15585_p2.read());
}

void update_weights::thread_zext_ln512_29_fu_15638_p1() {
    zext_ln512_29_fu_15638_p1 = esl_zext<9,6>(or_ln512_28_fu_15633_p2.read());
}

void update_weights::thread_zext_ln512_2_fu_13547_p1() {
    zext_ln512_2_fu_13547_p1 = esl_zext<9,6>(or_ln512_1_fu_13541_p2.read());
}

void update_weights::thread_zext_ln512_30_fu_15734_p1() {
    zext_ln512_30_fu_15734_p1 = esl_zext<9,6>(or_ln512_29_fu_15729_p2.read());
}

void update_weights::thread_zext_ln512_31_fu_15806_p1() {
    zext_ln512_31_fu_15806_p1 = esl_zext<9,6>(or_ln512_30_fu_15801_p2.read());
}

void update_weights::thread_zext_ln512_3_fu_13620_p1() {
    zext_ln512_3_fu_13620_p1 = esl_zext<9,6>(or_ln512_2_fu_13614_p2.read());
}

void update_weights::thread_zext_ln512_4_fu_13717_p1() {
    zext_ln512_4_fu_13717_p1 = esl_zext<9,6>(or_ln512_3_fu_13711_p2.read());
}

void update_weights::thread_zext_ln512_5_fu_13766_p1() {
    zext_ln512_5_fu_13766_p1 = esl_zext<9,6>(or_ln512_4_fu_13760_p2.read());
}

void update_weights::thread_zext_ln512_6_fu_13862_p1() {
    zext_ln512_6_fu_13862_p1 = esl_zext<9,6>(or_ln512_5_fu_13857_p2.read());
}

void update_weights::thread_zext_ln512_7_fu_13934_p1() {
    zext_ln512_7_fu_13934_p1 = esl_zext<9,6>(or_ln512_6_fu_13929_p2.read());
}

void update_weights::thread_zext_ln512_8_fu_14030_p1() {
    zext_ln512_8_fu_14030_p1 = esl_zext<9,6>(or_ln512_7_fu_14025_p2.read());
}

void update_weights::thread_zext_ln512_9_fu_14078_p1() {
    zext_ln512_9_fu_14078_p1 = esl_zext<9,6>(or_ln512_8_fu_14073_p2.read());
}

void update_weights::thread_zext_ln512_fu_13401_p1() {
    zext_ln512_fu_13401_p1 = esl_zext<9,6>(shl_ln10_fu_13393_p3.read());
}

void update_weights::thread_zext_ln514_100_fu_15602_p1() {
    zext_ln514_100_fu_15602_p1 = esl_zext<9,8>(shl_ln514_27_fu_15594_p3.read());
}

void update_weights::thread_zext_ln514_101_fu_15650_p1() {
    zext_ln514_101_fu_15650_p1 = esl_zext<9,8>(shl_ln514_28_fu_15642_p3.read());
}

void update_weights::thread_zext_ln514_102_fu_15746_p1() {
    zext_ln514_102_fu_15746_p1 = esl_zext<9,8>(shl_ln514_29_fu_15738_p3.read());
}

void update_weights::thread_zext_ln514_103_fu_15818_p1() {
    zext_ln514_103_fu_15818_p1 = esl_zext<9,8>(shl_ln514_30_fu_15810_p3.read());
}

void update_weights::thread_zext_ln514_10_fu_13802_p1() {
    zext_ln514_10_fu_13802_p1 = esl_zext<64,28>(sext_ln514_10_fu_13798_p1.read());
}

void update_weights::thread_zext_ln514_11_fu_13827_p1() {
    zext_ln514_11_fu_13827_p1 = esl_zext<64,28>(sext_ln514_11_fu_13823_p1.read());
}

void update_weights::thread_zext_ln514_12_fu_13852_p1() {
    zext_ln514_12_fu_13852_p1 = esl_zext<64,28>(sext_ln514_12_fu_13848_p1.read());
}

void update_weights::thread_zext_ln514_13_fu_13898_p1() {
    zext_ln514_13_fu_13898_p1 = esl_zext<64,28>(sext_ln514_13_fu_13894_p1.read());
}

void update_weights::thread_zext_ln514_14_fu_13924_p1() {
    zext_ln514_14_fu_13924_p1 = esl_zext<64,28>(sext_ln514_14_fu_13920_p1.read());
}

void update_weights::thread_zext_ln514_15_fu_13970_p1() {
    zext_ln514_15_fu_13970_p1 = esl_zext<64,28>(sext_ln514_15_fu_13966_p1.read());
}

void update_weights::thread_zext_ln514_16_fu_13995_p1() {
    zext_ln514_16_fu_13995_p1 = esl_zext<64,28>(sext_ln514_16_fu_13991_p1.read());
}

void update_weights::thread_zext_ln514_17_fu_14020_p1() {
    zext_ln514_17_fu_14020_p1 = esl_zext<64,28>(sext_ln514_17_fu_14016_p1.read());
}

void update_weights::thread_zext_ln514_18_fu_14066_p1() {
    zext_ln514_18_fu_14066_p1 = esl_zext<64,28>(sext_ln514_18_fu_14062_p1.read());
}

void update_weights::thread_zext_ln514_19_fu_14114_p1() {
    zext_ln514_19_fu_14114_p1 = esl_zext<64,28>(sext_ln514_19_fu_14110_p1.read());
}

void update_weights::thread_zext_ln514_1_fu_13486_p1() {
    zext_ln514_1_fu_13486_p1 = esl_zext<64,28>(sext_ln514_1_fu_13482_p1.read());
}

void update_weights::thread_zext_ln514_20_fu_14139_p1() {
    zext_ln514_20_fu_14139_p1 = esl_zext<64,28>(sext_ln514_20_fu_14135_p1.read());
}

void update_weights::thread_zext_ln514_21_fu_14164_p1() {
    zext_ln514_21_fu_14164_p1 = esl_zext<64,28>(sext_ln514_21_fu_14160_p1.read());
}

void update_weights::thread_zext_ln514_22_fu_14210_p1() {
    zext_ln514_22_fu_14210_p1 = esl_zext<64,28>(sext_ln514_22_fu_14206_p1.read());
}

void update_weights::thread_zext_ln514_23_fu_14236_p1() {
    zext_ln514_23_fu_14236_p1 = esl_zext<64,28>(sext_ln514_23_fu_14232_p1.read());
}

void update_weights::thread_zext_ln514_24_fu_14282_p1() {
    zext_ln514_24_fu_14282_p1 = esl_zext<64,28>(sext_ln514_24_fu_14278_p1.read());
}

void update_weights::thread_zext_ln514_25_fu_14307_p1() {
    zext_ln514_25_fu_14307_p1 = esl_zext<64,28>(sext_ln514_25_fu_14303_p1.read());
}

void update_weights::thread_zext_ln514_26_fu_14332_p1() {
    zext_ln514_26_fu_14332_p1 = esl_zext<64,28>(sext_ln514_26_fu_14328_p1.read());
}

void update_weights::thread_zext_ln514_27_fu_14378_p1() {
    zext_ln514_27_fu_14378_p1 = esl_zext<64,28>(sext_ln514_27_fu_14374_p1.read());
}

void update_weights::thread_zext_ln514_28_fu_14426_p1() {
    zext_ln514_28_fu_14426_p1 = esl_zext<64,28>(sext_ln514_28_fu_14422_p1.read());
}

void update_weights::thread_zext_ln514_29_fu_14451_p1() {
    zext_ln514_29_fu_14451_p1 = esl_zext<64,28>(sext_ln514_29_fu_14447_p1.read());
}

void update_weights::thread_zext_ln514_2_fu_13511_p1() {
    zext_ln514_2_fu_13511_p1 = esl_zext<64,28>(sext_ln514_2_fu_13507_p1.read());
}

void update_weights::thread_zext_ln514_30_fu_14476_p1() {
    zext_ln514_30_fu_14476_p1 = esl_zext<64,28>(sext_ln514_30_fu_14472_p1.read());
}

void update_weights::thread_zext_ln514_31_fu_14522_p1() {
    zext_ln514_31_fu_14522_p1 = esl_zext<64,28>(sext_ln514_31_fu_14518_p1.read());
}

void update_weights::thread_zext_ln514_32_fu_14548_p1() {
    zext_ln514_32_fu_14548_p1 = esl_zext<64,28>(sext_ln514_32_fu_14544_p1.read());
}

void update_weights::thread_zext_ln514_33_fu_14594_p1() {
    zext_ln514_33_fu_14594_p1 = esl_zext<64,28>(sext_ln514_33_fu_14590_p1.read());
}

void update_weights::thread_zext_ln514_34_fu_14619_p1() {
    zext_ln514_34_fu_14619_p1 = esl_zext<64,28>(sext_ln514_34_fu_14615_p1.read());
}

void update_weights::thread_zext_ln514_35_fu_14644_p1() {
    zext_ln514_35_fu_14644_p1 = esl_zext<64,28>(sext_ln514_35_fu_14640_p1.read());
}

void update_weights::thread_zext_ln514_36_fu_14690_p1() {
    zext_ln514_36_fu_14690_p1 = esl_zext<64,28>(sext_ln514_36_fu_14686_p1.read());
}

void update_weights::thread_zext_ln514_37_fu_14738_p1() {
    zext_ln514_37_fu_14738_p1 = esl_zext<64,28>(sext_ln514_37_fu_14734_p1.read());
}

void update_weights::thread_zext_ln514_38_fu_14763_p1() {
    zext_ln514_38_fu_14763_p1 = esl_zext<64,28>(sext_ln514_38_fu_14759_p1.read());
}

void update_weights::thread_zext_ln514_39_fu_14788_p1() {
    zext_ln514_39_fu_14788_p1 = esl_zext<64,28>(sext_ln514_39_fu_14784_p1.read());
}

void update_weights::thread_zext_ln514_3_fu_13536_p1() {
    zext_ln514_3_fu_13536_p1 = esl_zext<64,28>(sext_ln514_3_fu_13532_p1.read());
}

void update_weights::thread_zext_ln514_40_fu_14834_p1() {
    zext_ln514_40_fu_14834_p1 = esl_zext<64,28>(sext_ln514_40_fu_14830_p1.read());
}

void update_weights::thread_zext_ln514_41_fu_14860_p1() {
    zext_ln514_41_fu_14860_p1 = esl_zext<64,28>(sext_ln514_41_fu_14856_p1.read());
}

void update_weights::thread_zext_ln514_42_fu_14906_p1() {
    zext_ln514_42_fu_14906_p1 = esl_zext<64,28>(sext_ln514_42_fu_14902_p1.read());
}

void update_weights::thread_zext_ln514_43_fu_14931_p1() {
    zext_ln514_43_fu_14931_p1 = esl_zext<64,28>(sext_ln514_43_fu_14927_p1.read());
}

void update_weights::thread_zext_ln514_44_fu_14956_p1() {
    zext_ln514_44_fu_14956_p1 = esl_zext<64,28>(sext_ln514_44_fu_14952_p1.read());
}

void update_weights::thread_zext_ln514_45_fu_15002_p1() {
    zext_ln514_45_fu_15002_p1 = esl_zext<64,28>(sext_ln514_45_fu_14998_p1.read());
}

void update_weights::thread_zext_ln514_46_fu_15050_p1() {
    zext_ln514_46_fu_15050_p1 = esl_zext<64,28>(sext_ln514_46_fu_15046_p1.read());
}

void update_weights::thread_zext_ln514_47_fu_15075_p1() {
    zext_ln514_47_fu_15075_p1 = esl_zext<64,28>(sext_ln514_47_fu_15071_p1.read());
}

void update_weights::thread_zext_ln514_48_fu_15100_p1() {
    zext_ln514_48_fu_15100_p1 = esl_zext<64,28>(sext_ln514_48_fu_15096_p1.read());
}

void update_weights::thread_zext_ln514_49_fu_15146_p1() {
    zext_ln514_49_fu_15146_p1 = esl_zext<64,28>(sext_ln514_49_fu_15142_p1.read());
}

void update_weights::thread_zext_ln514_4_fu_13583_p1() {
    zext_ln514_4_fu_13583_p1 = esl_zext<64,28>(sext_ln514_4_fu_13579_p1.read());
}

void update_weights::thread_zext_ln514_50_fu_15172_p1() {
    zext_ln514_50_fu_15172_p1 = esl_zext<64,28>(sext_ln514_50_fu_15168_p1.read());
}

void update_weights::thread_zext_ln514_51_fu_15218_p1() {
    zext_ln514_51_fu_15218_p1 = esl_zext<64,28>(sext_ln514_51_fu_15214_p1.read());
}

void update_weights::thread_zext_ln514_52_fu_15243_p1() {
    zext_ln514_52_fu_15243_p1 = esl_zext<64,28>(sext_ln514_52_fu_15239_p1.read());
}

void update_weights::thread_zext_ln514_53_fu_15268_p1() {
    zext_ln514_53_fu_15268_p1 = esl_zext<64,28>(sext_ln514_53_fu_15264_p1.read());
}

void update_weights::thread_zext_ln514_54_fu_15314_p1() {
    zext_ln514_54_fu_15314_p1 = esl_zext<64,28>(sext_ln514_54_fu_15310_p1.read());
}

void update_weights::thread_zext_ln514_55_fu_15362_p1() {
    zext_ln514_55_fu_15362_p1 = esl_zext<64,28>(sext_ln514_55_fu_15358_p1.read());
}

void update_weights::thread_zext_ln514_56_fu_15387_p1() {
    zext_ln514_56_fu_15387_p1 = esl_zext<64,28>(sext_ln514_56_fu_15383_p1.read());
}

void update_weights::thread_zext_ln514_57_fu_15412_p1() {
    zext_ln514_57_fu_15412_p1 = esl_zext<64,28>(sext_ln514_57_fu_15408_p1.read());
}

void update_weights::thread_zext_ln514_58_fu_15458_p1() {
    zext_ln514_58_fu_15458_p1 = esl_zext<64,28>(sext_ln514_58_fu_15454_p1.read());
}

void update_weights::thread_zext_ln514_59_fu_15484_p1() {
    zext_ln514_59_fu_15484_p1 = esl_zext<64,28>(sext_ln514_59_fu_15480_p1.read());
}

void update_weights::thread_zext_ln514_5_fu_13609_p1() {
    zext_ln514_5_fu_13609_p1 = esl_zext<64,28>(sext_ln514_5_fu_13605_p1.read());
}

void update_weights::thread_zext_ln514_60_fu_15530_p1() {
    zext_ln514_60_fu_15530_p1 = esl_zext<64,28>(sext_ln514_60_fu_15526_p1.read());
}

void update_weights::thread_zext_ln514_61_fu_15555_p1() {
    zext_ln514_61_fu_15555_p1 = esl_zext<64,28>(sext_ln514_61_fu_15551_p1.read());
}

void update_weights::thread_zext_ln514_62_fu_15580_p1() {
    zext_ln514_62_fu_15580_p1 = esl_zext<64,28>(sext_ln514_62_fu_15576_p1.read());
}

void update_weights::thread_zext_ln514_63_fu_15626_p1() {
    zext_ln514_63_fu_15626_p1 = esl_zext<64,28>(sext_ln514_63_fu_15622_p1.read());
}

void update_weights::thread_zext_ln514_64_fu_15674_p1() {
    zext_ln514_64_fu_15674_p1 = esl_zext<64,28>(sext_ln514_64_fu_15670_p1.read());
}

void update_weights::thread_zext_ln514_65_fu_15699_p1() {
    zext_ln514_65_fu_15699_p1 = esl_zext<64,28>(sext_ln514_65_fu_15695_p1.read());
}

void update_weights::thread_zext_ln514_66_fu_15724_p1() {
    zext_ln514_66_fu_15724_p1 = esl_zext<64,28>(sext_ln514_66_fu_15720_p1.read());
}

void update_weights::thread_zext_ln514_67_fu_15770_p1() {
    zext_ln514_67_fu_15770_p1 = esl_zext<64,28>(sext_ln514_67_fu_15766_p1.read());
}

}

